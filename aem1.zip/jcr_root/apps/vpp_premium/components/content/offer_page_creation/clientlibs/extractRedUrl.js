use(function () {

    var extractUrl = null;


   if (this.fieldName != '') {
        extractUrl = granite.resource.properties[this.fieldName];
        console.log(extractUrl);
        if (typeof extractUrl != "undefined" && extractUrl != null && extractUrl != "") {
        	if (extractUrl.length !== 0) {                
                var urlVal = extractUrl.trim();
                if (urlVal.indexOf('href') != -1) {
                    urlVal = urlVal.match(/href="(.*?)"/)[1];
                }
               
                var urlv = urlVal.trim();

            }
        }
    }

    return {
        extractRedUrl: urlv
    }
});