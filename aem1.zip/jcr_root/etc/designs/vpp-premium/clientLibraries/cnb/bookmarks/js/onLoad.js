$(document).ready(function() {
     var pathname = $('#currentPagePath').val();
	 $('.bookmark-clear-container').hide();

    $.ajax({
         url: "/bin/getLandingPageOffersPremium",
         cache: true,
         type: "POST",		 
        data : { currentPagePath : pathname } ,
         success: function(data) {
			 console.log("Offer Data" + "--" + JSON.stringify(data));
             searchQueryInOffers(data);
	     }
     });


 });


function searchQueryInOffers(offerdata) {
	
    var searchArr = getBookmarkOffers();
	var resultJsonArr = [];
	console.log("OfferArray -" + searchArr );
    
    if(searchArr === null || offerdata == undefined || searchArr == undefined ){
        showSearchResult([]);
    }
    if(offerdata.length == 0 ){
    	showSearchResult([]);
    }
    var _ = window._;
    for (var i = 0; i < searchArr.length; i++) {
		console.log(searchArr[i]);
        var resultOffers = JSON.search(offerdata, "//*[contains(offerId, \"" +searchArr[i] +  "\")]");
		console.log(resultOffers);
        for(var item in resultOffers){
			resultJsonArr.push(resultOffers[item]) ;
            
        }

    }
    var uniqResultOffers = _.uniq(resultJsonArr,function(item){ return item.offerId });

     showSearchResult(uniqResultOffers);

}
function getBookmarkOffers() {
	var offerArray= [];
	var pathname = $('#currentPagePath').val();
        var hashContent = pathname.split('/');
        var issuerName = hashContent[4];  
    	var isConciergeUser = $('#isConciergeUser').val();
        var uid = "";
        if(isConciergeUser!='' && isConciergeUser!=undefined ){
			uid =$('#cardHolderId').val();
          }else{
                uid =$('#userId').val();
          }
        console.log(uid);
        var product = "infinite";
    var startPoint = "/vpp-backend/v1/" +issuerName+ "/" + product +"/bookmark/getAllBookmark";
     $.ajax({
         url: startPoint,
         type: "GET",
		 async:false,
         data: {
             userId: uid
         },
         success: function(data) {
			 console.log("success data--" + data);
    var offers = $.parseJSON(data);
    if(offers.response){
    var offerList = offers.response.bookmarks;
    for(i=0; i<offerList.length; i++){
		offerArray.push(offerList[i].offerId);
		
	}

            //bookmarkOffers(data);
         }
		 }

     });
	return offerArray;
	 }

 function showSearchResult(searchJSON)
{ 

 //  console.log("Search Result --" + searchJSON);

    if(searchJSON.length===0)
    {
		$('.offer-list').hide();
        $('.bookmark-clear-container').hide();
        $('.bookmark-empty-list').show();

    }
    else
    { $('.bookmark-empty-list').hide();
      $('.bookmark-clear-container').show();
    var resultData="";
    var srcVal="";
    var heroImage="";
    var offerTitle="";
    var shortDesc="";
    var offerId="";
    var offerSource="";
    var previewURL="";
    var firstIteration=true;

    finalArr = [];
	var offerValidity = true ; 
    $('#search_result_data').empty();
    var searchPreviewUrl=$('.search_offer_preview').val();
    localStorage.setItem("catPagePath",$('.landing_page').val());
	localStorage.setItem("isSearchPreview","yes");
    $.each(searchJSON, function(key, value) 
     {
         srcVal=value.thumbImage;
		 offerTitle=value.offerTitle;
         shortDesc=value.offerShortDesc;
         offerId=value.offerId;
         previewURL=value.previewURL;
         bookmarkURL="#cat/bookmark/id/"+offerId;
         heroImage=value.heroImage;
		 offerValidity = true ; 
		if( offerTitle === undefined || shortDesc === undefined || srcVal === undefined || heroImage === undefined|| heroImage === "" ){
			offerValidity = false;
        }else if ( offerTitle.trim() == "" || shortDesc.trim() == "" || srcVal == "failure"){
			offerValidity = false;
        }
        if(offerValidity){

                resultData = appendSearchResultData(srcVal,offerTitle,shortDesc,bookmarkURL,offerId,previewURL);


        }
         $('#offerList').append(resultData);

     });


    }
}


function appendSearchResultData(srcVal,offerTitle,shortDesc,searchPreviewUrl,offerId,previewURL)
{
var htmlData="<div class='one-col-offer offer-container' role='presentation' offer-id='"+offerId+"'>"+
    "<a class='imgAnchor' href='"+searchPreviewUrl+"' aria-hidden='true' tabindex='-1'>"+
        "<img class='lazy offer-img' src='"+srcVal+"' data-original='https://www.visa.com/images/merchantoffers/2015-04/1429659219657.Relais-_-Chateaux_770x430.jpg' title='Relais &amp; Chateaux' alt='' aria-hidden='true' style='display: inline;'>"+
          "<span class='textWrapper' title='"+offerTitle+"'>"+
              "<span class='caption'>"+
                  "<span class='titleWrapper'>"+
                     "<span class='title'>"+offerTitle+"</span>"+
                         "<span class='shortDesc'>"+shortDesc+"</span>"+"</span>"+
                              "<span class='blank-cell accessible-text'> opens dialog</span>"+
                               "</span>"+
                           "</span>"+
      "</a>"+
       "<a class='bookmark-btn bookmarked' href='#' offerid='"+offerId+"' aria-label='not bookmarked yet' aria-hidden='true' tabindex='-1'>bookmark <span class='accessible-text selected'></span></a>"+
   "</div>";

return htmlData;
}
  


