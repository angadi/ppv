$(document).ready(function() {
     var pathname = $('#currentPagePath').val();
        var hashContent = pathname.split('/');
        var issuerName = hashContent[4];
        var isConciergeUser = $('#isConciergeUser').val();
        var uid = "";
        if(isConciergeUser!='' && isConciergeUser!=undefined ){
			uid =$('#cardHolderId').val();
          }else{
                uid =$('#userId').val();
          }     
        console.log(uid);
        var product = "infinite";
    var startPoint = "/vpp-backend/v1/" +issuerName+ "/" + product +"/bookmark/getAllBookmark";
     $.ajax({
         url: startPoint,
         type: "GET",
         data: {
             userId: uid
         },
         success: function(data) {

            bookmarkOffers(data);
         }

     });
 //    createJson(pathname);
 });

function bookmarkOffers(data){
    console.log("success data--" + data);
    var offers = $.parseJSON(data);
    if(offers.response){
    var offerList = offers.response.bookmarks;
    for(i=0; i<offerList.length; i++){

        $("div[offer-id="+ offerList[i].offerId+"]").find('a.bookmark-btn').removeClass('bookmark-btn').addClass('bookmark-btn  bookmarked');
    }
    }
}

