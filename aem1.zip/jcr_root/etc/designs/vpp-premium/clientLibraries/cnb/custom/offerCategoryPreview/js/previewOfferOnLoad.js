$(document).ready(function() {
     var pathname =  $('#_currentPagePath').val();
     $.ajax({
         url: "/bin/cardArtLanding",
         cache: true,
         type: "GET",
         data: {
             pagePath: pathname
         },
         success: function(data) {
             $('#cardLogoImgId').attr('src', data);
         }

     });

    getAllOfferPreviewUrls();

 });
function getAllOfferPreviewUrls() {

    var currentOffer = localStorage.getItem("currentOffer");
    var catPagePath = localStorage.getItem("catPagePath");
    var parentName = localStorage.getItem("parentName");
    var isSearchPreview  = localStorage.getItem("isSearchPreview");
    
    var inputParam = {};

    if(parentName == undefined && catPagePath == undefined ){
		var currPath =  $('#_currentPagePath').val();
        var hashPath = window.location.hash.substring(1) ;
        var hashPathArr = hashPath.split("/");
        if( hashPathArr.length == 2 ) {
            var catPageName = hashPathArr[0];
        	var currOfferId = hashPathArr[1];
            inputParam = {
                catPageName: catPageName,
                currOfferId: currOfferId,
                currPagePath: currPath
        	};

        }

    } else if (isSearchPreview != undefined) {
        inputParam = {
            currentOffer: currentOffer,
            isSearchPreview: "yes",
            catPagePath: catPagePath
        };
    } else {
        inputParam = {
            currentOffer: currentOffer,
            catPagePath: catPagePath,
            parentName: parentName
        };
    }


    $.ajax({
        url: "/bin/getAllPreviewOfferPages",
        type: "POST",
        data: inputParam,
        success: function(data) {
            assignGlobalVariables(data);
        }
    });
}