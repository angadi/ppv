function fetchRedirectUrl(e){
   var templateName = $('.templateName').val(),
      currentPagePath = $('.currentPagePath').val(),
      parentPagePath  = $('.parentPagePath').val(),
         queryParam = $('.search:visible').val(),
        //temp =  $(this).siblings('input').val(),
    redirectUrl = parentPagePath ,
      searchPageName = "search_page";

 queryParam=$($.parseHTML(queryParam)).text();
   if(templateName === 'welcome_page'){
    redirectUrl = currentPagePath ;

    }
    else if(templateName === 'category_page'){
    redirectUrl = parentPagePath ;

    }
    else if(templateName === 'search_page'){
    redirectUrl = parentPagePath ;

    }
  redirectUrl = redirectUrl +"/" + searchPageName + ".html";
    if(queryParam.length != 0 ){
      localStorage.setItem("queryParam",queryParam);
    window.open(redirectUrl,'_self');
       
    }
    return false;

}