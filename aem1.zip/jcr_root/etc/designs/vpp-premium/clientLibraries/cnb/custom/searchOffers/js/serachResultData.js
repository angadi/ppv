var finalArr = [];
function showSearchResult(searchJSON)
{ 
	var keyword="";
 	var userBenefitTypeCode1="";
	userBenefitTypeCode1=$('#benefitTypeCode').val();
    keyword=localStorage.getItem("queryParam");

	if(keyword!=undefined )
    {	
		keyword = encodeURI(keyword);
		keyword = decodeURI(keyword);
        $('#keyword').empty();
        $('#keyword').html(keyword);
    }
	
    if(searchJSON.length===0)
    {
		$('.offer-list').append("<div class='no-search-result'>No matched offer found.</div>");

    }
    else
    {
    var resultData="";
    var srcVal="";
    var heroImage="";
    var offerTitle="";
    var shortDesc="";
    var offerId="";
    var offerSource="";
    var previewURL="";
    var benefitTypeCode="";
    var firstIteration=true;

    finalArr = [];
	var offerValidity = true ; 
    $('#search_result_data').empty();
    var searchPreviewUrl=$('.search_offer_preview').val();
    localStorage.setItem("catPagePath",$('.landing_page').val());
	localStorage.setItem("isSearchPreview","yes");
    $.each(searchJSON, function(key, value) 
     {

         srcVal=value.thumbImage;
         offerSource=value.offerSource;
		 offerTitle=value.offerTitle;
         shortDesc=value.offerShortDesc;
         offerId=value.offerId;
         previewURL=value.previewURL;
         benefitTypeCode=value.benefitTypeCode;
		 searchURL="#cat/search_page/id/"+offerId
         heroImage=value.heroImage;
		 offerValidity = true ; 
         aemOffer=false;
		if( offerTitle === undefined || shortDesc === undefined || srcVal === undefined || heroImage === undefined|| heroImage === "" ){
			offerValidity = false;
        }else if ( offerTitle.trim() == "" || shortDesc.trim() == "" || srcVal == "failure"){
			offerValidity = false;
        }
         if(userBenefitTypeCode1===undefined ||userBenefitTypeCode1===""){
			aemOffer=true;
         }
         if(offerSource==="AEM" && typeof benefitTypeCode !== "undefined" && typeof userBenefitTypeCode1 !== "undefined"){
             if(($.isArray(benefitTypeCode))){
                     for(var i =0; i<benefitTypeCode.length; i++){
                     if(userBenefitTypeCode1.indexOf(benefitTypeCode[i])!=-1){
                        aemOffer=true;
                         break;
                     }

                 }
				
             }
             else if(userBenefitTypeCode1.indexOf(benefitTypeCode)!=-1){
				aemOffer=true;
             }else {
                 aemOffer=false;
             }

         }

		if(aemOffer && offerSource==="AEM")
        {
           if(offerValidity){
             if(firstIteration){
                firstIteration=false;
            	resultData = appendSearchResultDataFirst(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL,heroImage);

            	}else{
                resultData = appendSearchResultData(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL);

            }
               $('.offer-list').append(resultData);
		   }

        }
         if(offerSource==="VMORC"){
            if(offerValidity){
             	if(firstIteration){
                firstIteration=false;
            	resultData = appendSearchResultDataFirst(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL,heroImage);

            	}else{
                resultData = appendSearchResultData(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL);

            }
               $('.offer-list').append(resultData);
		   }

         }
     });


    }
}
function appendSearchResultDataFirst(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL,heroImage)
{
    var htmlData=" <div class='two-col-offer offer-container' role='presentation' offer-id='"+offerId+"'>"+
                                        "<a class='imgAnchor' href='"+searchURL+"' aria-hidden='true' tabindex='-1'>"+
                            
                            "<img class='smLiImgHide lazy offer-img' src='"+heroImage+"' data-original='https://www.visa.com/images/merchantoffers/2015-04/1429655312727.VILHC_1600x430.jpg' title='Visa Infinite Luxury Hotel Collection' alt='' aria-hidden='true' style='display: inline;'>"+
                            
                            "<img class='lazy offer-img' src='"+srcVal+"' data-original='https://www.visa.com/images/merchantoffers/2015-04/1429655295878.VILHC_770x430.jpg' title='Visa Infinite Luxury Hotel Collection' alt='' aria-hidden='true' style='display: inline;'>"+

                            "<span class='textWrapper' title='"+offerTitle+"'>"+
                                "<span class='caption'>"+
                                    "<span class='titleWrapper'>"+
                                        "<span class='title'>"+offerTitle+"</span>"+
                                        "<span class='shortDesc'>"+shortDesc+"</span>"+
                                    "</span>"+
                                    "<span class='blank-cell accessible-text'> opens dialog</span>"+                     
                                "</span>"+
                            "</span>"+
                        "</a>"+
                "<a class='bookmark-btn ' href='#' offerid='106422' aria-label='not bookmarked yet' aria-hidden='true' tabindex='-1'>bookmark <span class='accessible-text selected'></span></a>"+
            "</div>";
return htmlData;

}

function appendSearchResultData(srcVal,offerTitle,shortDesc,searchURL,offerId,previewURL)
{
var htmlData="<div class='one-col-offer offer-container' role='presentation' offer-id='"+offerId+"'>"+
    "<a class='imgAnchor' href='"+searchURL+"' aria-hidden='true' tabindex='-1'>"+
        "<img class='lazy offer-img' src='"+srcVal+"' data-original='https://www.visa.com/images/merchantoffers/2015-04/1429659219657.Relais-_-Chateaux_770x430.jpg' title='Relais &amp; Chateaux' alt='' aria-hidden='true' style='display: inline;'>"+
          "<span class='textWrapper' title='"+offerTitle+"'>"+
              "<span class='caption'>"+
                  "<span class='titleWrapper'>"+
                     "<span class='title'>"+offerTitle+"</span>"+
                         "<span class='shortDesc'>"+shortDesc+"</span>"+"</span>"+
                              "<span class='blank-cell accessible-text'> opens dialog</span>"+
                               "</span>"+
                           "</span>"+
      "</a>"+
       "<a class='bookmark-btn' href='#' offerid='"+offerId+"' aria-label='not bookmarked yet' aria-hidden='true' tabindex='-1'>bookmark <span class='accessible-text selected'></span></a>"+
   "</div>";

return htmlData;
}
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


