// Filename: app.js
define( [
    'jquery',
    'router',
    'Constants'
], function( $, Router, Constants ) {
    var initialize = function() {
        //Inject custom validaion method for password.
        $.validator.addMethod( "passwordRegex", function( value ) {
            return /[a-zA-Z]/.test( value ) && /[0-9]/.test( value ) && /[\@\#\$\%\^\&\*\(\)\_\+\!\-=]/.test( value );
        } );
        $.validator.addMethod( "selectedOptionNotEquals", function( value, element, arg ) {
            return value != $( arg ).val();
        } );
        $.validator.addMethod( "noSpecialCharacters", function( value, element, arg ) {
            return /^[a-zA-Z0-9 ]+$/.test( value );
        } );
        $.validator.addMethod( "postalCodeCharacterCheck", function( value, element, arg ) {
            return /^[a-zA-Z0-9 -]+$/.test( value );
        } );
        $.validator.addMethod( 'noSpecialCharactersAndSpace', function( value, element, arg ) {
            return /^[a-zA-Z0-9]+$/.test( value );
        } );
        $.validator.addMethod( 'equalToCaseIgnore', function( value, element, arg ) {
            return value.toLowerCase() === $( arg ).val().toLowerCase();
        } );
        $.validator.addMethod( 'noSpace', function( value, element, arg ) {
            return value.indexOf( " " ) < 0;
        } );
        $.validator.addMethod( 'emailOrUsername', function( value, element, arg ) {
            var emailCheck, usernameCheck;
            emailCheck = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test( value );
            usernameCheck = /[a-zA-Z0-9]/.test( value );
            return emailCheck || usernameCheck;
        } );
        /* Add Validator method - regex check for invalid characters */
        if ( $.validator ) {
            $.validator.addMethod( "regex", function( value, element, regexp ) {
                var re = new RegExp( regexp );
                return this.optional( element ) || re.test( value );
            }, "Input contains invalid characters. Please revise using only letters, numbers, spaces, or ?,.!-'&@#/*:)(_" );
            $.validator.addMethod( "pswCheck", function( value, element ) {
                return this.optional( element ) || /^(?=.*?[!@#$%^&*?~`])(?=.*?[0-9]).{8,}$/.test( value );
            }, Constants.errorMsg.pswNotMeetRequirements );
        }
        //update page title
        //$('title').html(SessionObject.bankConfig.CARD_NAME);
        var login = $("#v-login-content"),
        forgotusername = $("#v-forgot-user-content"),
        forgotpassword = $("#v-forgot-password-content"),
        register = $("#v-register-content"),
        forgotpasswordsecQ = $("#v-forgot-password-securityq"),
        resetpassword = $("#v-reset-password");
        Constants['login'] = login.html();login.empty();
        Constants['forgotusername'] = forgotusername.html(); forgotusername.empty();
        Constants['forgotpassword'] = forgotpassword.html(); forgotpassword.empty();
        Constants['register'] = register.html(); register.empty();
        Constants['forgotpasswordsecQ'] = forgotpasswordsecQ.html(); forgotpasswordsecQ.empty();
        Constants['resetpassword'] = resetpassword.html(); resetpassword.empty();

        Router.initialize();
    };
    return {
        initialize: initialize
    };
} );