// Filename: main.js
require.config( {
    paths: {
        jquery: 'vendor/jquery/jquery-1.12.4.min',
        bootstrap: 'vendor/bootstrap/bootstrap',
        'Constants': 'utils/Constants_' + language,
        'jquery.validate': 'vendor/jquery/jquery.validate',
        'jquery.validate.additional-methods': 'vendor/jquery/additional-methods',
        'jquery.maskedinput': 'vendor/jquery/jquery.maskedinput',
        // NON-AMD
        'select2': 'vendor/jquery/select2.min',
        'jquery.lazyload': 'vendor/lazyload/jquery.lazyload',
        'jquery.placeholder': 'vendor/jquery/jquery.placeholder',
        'jquery-sessionTimeout': 'vendor/jquery/jquery.sessionTimeout'
    },
    waitSeconds: 15,
    shim: {
        bootstrap: {
            deps: [ 'jquery' ]
        },
        'jquery.lazyload': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.lazyload'
        },
        'jquery.placeholder': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.placeholder'
        },
        'jquery-sessionTimeout': {
            deps: [ 'jquery' ]
        },
        'select2': {
            deps: [ 'jquery' ]
        },
        'jquery.maskedinput': {
            deps: [ 'jquery' ]
        }
    }
} );
require( [
    'app',
    'jquery-sessionTimeout'
], function( App ) {
	$.ajaxSetup({ cache: false });
    App.initialize();

    //wcag, in case jump to default
    $( '#skip-to-content a' ).bind( 'click', function( e ) {
        e.preventDefault();
        $( $( e.currentTarget ).attr( 'href' ) ).focus();
    } );

    $.fn.serializeObject = function() {
        var o = {};
        var a = this.serializeArray();
        $.each( a, function() {
            if ( o[ this.name ] !== undefined ) {
                if ( !o[ this.name ].push ) {
                    o[ this.name ] = [ o[ this.name ] ];
                }
                o[ this.name ].push( encodeURIComponent( this.value ) || '' );
            } else {
                o[ this.name ] = encodeURIComponent( this.value ) || '';
            }
        } );
        return o;
    };

    $.fn.serializeObjectWithoutEncodeURI = function() {
        var o = {};
        var a = this.serializeArray();
        $.each( a, function() {
            if ( o[ this.name ] !== undefined ) {
                if ( !o[ this.name ].push ) {
                    o[ this.name ] = [ o[ this.name ] ];
                }
                o[ this.name ].push( this.value || '' );
            } else {
                o[ this.name ] = this.value || '';
            }
        } );
        return o;
    };
} );