// Filename: router.js
define( [
    'jquery',
    'views/landing/LandingPageView',
    'views/popups/LoginView',
    'views/popups/RegisterView',
    'views/popups/ForgotUsernameView',
    'views/popups/ForgotPasswordView',
    'views/popups/ForgotPasswordSecurityQView',
    'views/others/FAQView',
    'jquery.validate',
    'jquery.validate.additional-methods'
], function(
    $,
    LandingPageView,
    LoginView,
    RegisterView,
    ForgotUsernameView,
    ForgotPasswordView,
    ForgotPasswordSecurityQView,
    FAQView
) {
    var initialize = function() {
        loadPage();
        /** xss filtering **/
        function xssFilter( toOutput ) {
            return toOutput.replace( '&', '&amp;' ).
            replace( '<', '&lt;' ).
            replace( '>', '&gt;' ).
            replace( '"', '&quot;' ).
            replace( "'", '&#x27' ).
            replace( '/', '&#x2F' );
        }

        function forgotPasswordTokenValidate( token ) {

            var issuerName = xssFilter( $( '#issuerName' ).val() );
            var tokenInfo = {
                "token": token
            };

            var path = '/vpp-backend/v1/' + issuerName + '/infinite/pwReset/validateToken';

            $.ajax( {
                type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify( tokenInfo ),
                success: function( result ) {

                    if ( result.status != undefined && result.status.statusCode === '200' ) {
                        ForgotPasswordSecurityQView( result.response.securityQuestions, token );
                    } else {
                        $( ".popup_invalidLink" ).fadeIn();
                        $( ".popup_invalidLink" ).delay( 3000 ).fadeOut();
                    }
                }
            } );
        }

        function loadPage() {
            var regex = /^[\w\#\-\/]+$/g;
            var hash =(regex.exec(window.location.hash) !== null) ? window.location.hash : '';
            if ( hash.length > 15 !== 0) {
                var hashsplit = hash.split( '/' );
                if ( hashsplit.length === 3) {
                    var tokentoValidate = hashsplit[ 2 ];
                    regex = /^[a-zA-Z0-9-]{10,50}$/g;
                   if( regex.exec(tokentoValidate) !== null )
                       forgotPasswordTokenValidate( tokentoValidate );
                    return false;
                }
            }
            switch ( hash ) {
                case '#faq':
                    FAQView();
                    break;
                case '#register':
                    RegisterView();
                    break;
                case '#log-in':
                    LoginView();
                    break;
                case '#forgot-username':
                    ForgotUsernameView();
                    break;
                case '#forgot-password':
                    ForgotPasswordView();
                    break;
                default:
                    LandingPageView();
                    break;
            }
        }
        window.onhashchange = loadPage;
    };
    return {
        initialize: initialize
    };
} );