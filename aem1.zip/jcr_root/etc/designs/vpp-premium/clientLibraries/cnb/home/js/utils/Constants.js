define( [
    'jquery'
], function( $ ) {
    'use strict';
    var contextPath = '';
    var Constants = {
        delayAutoStartCarousel: 4000, //4 seconds
        validations: {
            maxLength: 40,
            passwordMaxLength: 40,
            userNameMinLength: 5,
            userNameMaxLength: 40,
            postalCodeMaxLength: 40,
            maxAddressLength: 40,
            maxUnsuccessfulAttempts: 3,
            validPhoneNumberLength: 10
        },
        defaultOfferImagePath: {
            small: 'images/defaultOfferListImage_770x430.jpg',
            large: 'images/defaultOfferListImage_1600x430.jpg',
            detail: 'images/defaultHeroImage_1280x572.jpg',
            merchantLogo: 'images/defaultMerchantLogo.jpg'
        },
        faqJSONUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/faq.json?callback=?',
        visaAndYourDataUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/visa-and-your-data.json?callback=?',
        apiStatus: {
            OK: "OK",
            ERROR: 'ERROR',
            NO: 'NO',
            YES: 'YES'
        },
        statesJsonPath: 'doc/state.json',
       countriesJsonPath: '/etc/designs/vpp-premium/clientLibraries/cnb/home/js/json/countries.json',

        errorMsg: {
            required: 'All fields are required.',
            forgotPasswordSecurityAnswerNotMatch: 'Security answer does not match the one in our system. Please try again.',
            pswNotMeetRequirements: 'Please provide your password. It must contain at least 1 number and 1 symbol and have a total length of at least 8 characters.',
            invalidCreditCard: 'We are sorry we cannot locate the card number you entered. Please contact the number on the back of your {cardName} credit card.',
            generalError: 'An error has occurred. Please contact the administrator.',
            invalidUsername: 'Sorry, did not find this username in system.',
            billingInfoNotMatch: 'Information entered does not match billing information.',
            invalidEmail: 'Email listed is incorrect format.',
            emailNotMatch: 'The confirm email you entered doesn\'t match.',
            acceptTermsPolicy: 'In order to complete your registration, you	must accept the {toc} and {pp}.',
            electronicPolicy: 'Please accept our electronic communication policy.',
            userNameInvalid: 'Please enter a correct username.',
            userAlreadyExists: 'User already exists.',
            passwordMinLength: 'Password must be at least {0} characters long.',
            passwordMaxLength: 'Password should be less than {0} characters.',
            passwordInvalid: 'Passwords must be a minimum of 7 characters and contain at least one letter, one number and one special character. Spaces are not allowed.',
            questionsSame: 'Both security questions cannot be same.',
            passwordnotMatch: 'Password entered does not match.',
            securityAnswerInvalid: 'Security answer contains invalid characters. Please use letters and numbers only.',
            securityAnswerMaxLengthExceeded: 'Security answer should be less than 40 characters.',
            stateInvalid: 'Please select a State.',
            streetAddressLimitExceeded: 'Street Address cannot be more than 100 characters.',
            profileImageNotSelected: 'Please select a profile image.',
            tokenInvalid: 'Token is not valid.',
            errorHasOccurred: 'An error has occurred.',
            phoneNumberInvalid: 'Please use digits only. Enter a 10 digit phone number without any punctutation, hyphens or spacing.',
            nameMissing: 'The information you entered does not match your billing information.',
            exceedMaxOfRegisterTimes: 'Sorry, we cannot verify your eligibility.',
            securityQuestionRequired: 'Please select a security question.',
            userNameMinLengthInvalid: 'Username must be of minimum {0} characters.',
            userNameMaxLengthInvalid: 'Username can have maximum {0} characters.',
            firstNameLengthExceeded: 'First Name should be less than {0} characters.',
            lastNameLengthExceeded: 'Last Name should be less than {0} characters.',
            postalCodeLengthExceeded: 'Postal Code should be less than {0} characters.',
            postalCodeRequired: 'Please enter the Postal Code.',
            cityLengthExceeded: 'City should be less than {0} characters.',
            emailAlreadyExists: 'Email already exists!',
            registrationTokenInvalid: 'We are sorry, your invitation has expired. Please contact an administrator to resend you a new invitation.',
            emailOrUsernameInvalid: 'Email or Username listed is incorrect format.',
            emailOrUsernameLoginFailed: 'Password and email/username do not match.',
            emailLoginFailed: 'Password and email do not match.'
        },
        successMsg: {
            tokenValid: 'Token is valid.'
        },
        apiPaths: {
            cardNumberValidationApi: contextPath + '/bank/setCreditCardNumber.do',
            registrationApi: contextPath + '/user/registerUser.do',
            securityQuestionApi: contextPath + '/user/getAllSecurityQuestion.do',
            gravtarCollectionApi: contextPath + '/user/getAllConcgImg.do',
            validateConciergeRegisterToken: contextPath + '/user/validateConciergeRegisterToken.do',
            registerConciergeUser: contextPath + '/user/conciergeRegistration.do',
            userNameCheckApi: contextPath + '/user/isUserNameUsed.do'
        },
        labels: {
            TermsOfService: 'Website Terms of Use',
            PrivacyPolicy: 'Privacy Policy'
        },
        configs: {
            loader: {
                message: '<div class="loaderContainer"><div><img src="' + contextPath + '/infinite/images/busy.gif" /></div><span id="loaderLoadingText">Loading...</span></div>',
                css: { backgroundColor: 'transparent', color: '#fff', border: 'none' }
            }
        },
        //R4_only
        defaultHeroImagePath: {
            hd_desktop: 'images/landingpage-heroimage-placeholder-hd-desktop.jpg',
            desktop: 'images/landingpage-heroimage-placeholder-desktop.jpg',
            tablet: 'images/landingpage-heroimage-placeholder-tablet.jpg',
            mobile: 'images/landingpage-heroimage-placeholder-mobile.jpg'
        },
        defaultBenefitImagePath: {
            hd_desktop: 'images/landingpage-benefit-placeholder-hd-desktop.jpg',
            desktop: 'images/landingpage-benefit-placeholder-desktop.jpg',
            tablet: 'images/landingpage-benefit-placeholder-tablet.jpg',
            mobile: 'images/landingpage-benefit-placeholder-mobile.jpg'
        },
        passwordSuggestion: 'Please choose a password that is difficult to compromise and isn\'t a common sequence of letters or numbers.<br><br>Passwords must be a minimum of 7 characters and contain at least one letter, one number and one special character. Spaces are not allowed.'
    };
    return Constants;
} );