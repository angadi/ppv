define( [
    'jquery'
], function( $ ) {
    'use strict';
    var contextPath = '';
    var otherIssuer='xyz';
    var cardNames= {
            cnb: 'Crystal® Visa Infinite® Credit Card',
            suntrust: 'Suntrust Visa Infinite® Credit Card',
            wellsfargo:'wellsfargo Visa Infinite® Credit Card',
            default:'Visa Infinite® Credit Card'
        };
    var issuerName = $( '#issuerName' ).val();
    otherIssuer = issuerName;
    otherIssuer = (cardNames[otherIssuer]) ? issuerName : 'default';
    console.log(issuerName);
    var Constants = {
        delayAutoStartCarousel: 4000, //4 seconds
        validations: {
            maxLength: 40,
            passwordMaxLength: 40,
            userNameMinLength: 5,
            userNameMaxLength: 40,
            postalCodeMaxLength: 40,
            maxAddressLength: 40,
            maxUnsuccessfulAttempts: 3,
            validPhoneNumberLength: 10
        },
        cardNames: {
            cnb: 'Crystal® Visa Infinite® Credit Card',
            suntrust: 'Suntrust Visa Infinite® Credit Card'
        },
        defaultOfferImagePath: {
            small: 'images/defaultOfferListImage_770x430.jpg',
            large: 'images/defaultOfferListImage_1600x430.jpg',
            detail: 'images/defaultHeroImage_1280x572.jpg',
            merchantLogo: 'images/defaultMerchantLogo.jpg'
        },
        faqJSONUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/faq.json?callback=?',
        visaAndYourDataUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/visa-and-your-data.json?callback=?',
        apiStatus: {
            OK: "OK",
            ERROR: 'ERROR',
            NO: 'NO',
            YES: 'YES'
        },
        statesJsonPath: 'doc/state.json',
        countriesJsonPath: '/etc/designs/vpp-premium/clientLibraries/cnb/home/js/json/countries_fr_fr.json',
        errorMsg: {
            required: 'Kaikki kentät ovat pakollisia.',
            forgotPasswordSecurityAnswerNotMatch: 'La réponse de sécurité ne correspond pas à celle de notre système. Veuillez réessayer.',
            pswNotMeetRequirements: 'S\'il vous plaît fournir votre mot de passe. Il doit contenir au moins 1 chiffre et 1 symbole et avoir une longueur totale d\'au moins 8 caractères.',
            invalidCreditCard: 'Nous sommes désolés de ne pas pouvoir trouver le numéro de carte que vous avez entré. Veuillez contacter le numéro au dos de votre'+ cardNames[otherIssuer] +'carte de crédit.',
            generalError: 'Une erreur est survenue. S\'il vous plaît contacter l\'administrateur..',
            invalidUsername: 'Désolé, n\'a pas trouvé ce nom d\'utilisateur dans le système.',
            billingInfoNotMatch: 'Les informations saisies ne correspondent pas aux informations de facturation.',
            invalidEmail: 'Le courrier électronique indiqué est un format incorrect.',
            emailNotMatch: 'L\'e-mail de confirmation que vous avez entré ne correspond pas.',
            acceptTermsPolicy: 'Afin de compléter votre inscription, vous devez accepter les {toc} et {pp}.',
            electronicPolicy: 'Veuillez accepter notre politique de communication électronique',
            userNameInvalid: 'Veuillez entrer un nom d\'utilisateur correct.',
            userAlreadyExists: 'L\'utilisateur existe déjà.',
            passwordMinLength: 'Le mot de passe doit contenir au moins {0} caractères.',
            passwordMaxLength: 'Le mot de passe doit être inférieur à {0} caractères.',
            passwordInvalid: 'Les mots de passe doivent comporter au moins 7 caractères et contenir au moins une lettre, un chiffre et un caractère spécial. Les espaces ne sont pas autorisés.',
            questionsSame: 'Les deux questions de sécurité ne peuvent pas être identiques.',
            passwordnotMatch: 'Le mot de passe entré ne correspond pas.',
            securityAnswerInvalid: 'La réponse de sécurité contient des caractères non valides. Veuillez utiliser uniquement des lettres et des chiffres.',
            securityAnswerMaxLengthExceeded: 'La réponse de sécurité doit être inférieure à 40 caractères.',
            stateInvalid: 'Veuillez sélectionner un État.',
            streetAddressLimitExceeded: 'L\'adresse ne peut pas dépasser 100 caractères.',
            profileImageNotSelected: 'Veuillez sélectionner une image de profil',
            tokenInvalid: 'Le jeton n\'est pas valide.',
            errorHasOccurred: 'Une erreur est survenue.',
            phoneNumberInvalid: 'Merci d\'utiliser uniquement les chiffres. Entrez un numéro de téléphone à 10 chiffres sans aucune ponctuation, tiret ou espacement.',
            nameMissing: 'Les informations que vous avez saisies ne correspondent pas à vos informations de facturation.',
            exceedMaxOfRegisterTimes: 'Désolé, nous ne pouvons pas vérifier votre éligibilité.',
            securityQuestionRequired: 'Veuillez sélectionner une question de sécurité',
            userNameMinLengthInvalid: 'Le nom d\'utilisateur doit contenir au moins {0} caractères.',
            userNameMaxLengthInvalid: 'Le nom d\'utilisateur peut avoir un maximum de {0} caractères',
            firstNameLengthExceeded: 'Le prénom doit être inférieur à {0} caractères.',
            lastNameLengthExceeded: 'Le nom de famille doit être inférieur à {0} caractères.',
            postalCodeLengthExceeded: 'Le code postal doit être inférieur à {0} caractères.',
            postalCodeRequired: 'Veuillez entrer le code postal.',
            cityLengthExceeded: 'La ville doit contenir moins de {0} caractères.',
            emailAlreadyExists: 'L\'email existe déjà!.',
            registrationTokenInvalid: 'Nous sommes désolés, votre invitation a expiré. Veuillez contacter un administrateur pour vous renvoyer une nouvelle invitation.',
            emailOrUsernameInvalid: 'L\'adresse e-mail ou le nom d\'utilisateur indiqué est incorrect.',
            emailOrUsernameLoginFailed: 'Le mot de passe et le courriel / nom d\'utilisateur ne correspondent pas.',
            emailLoginFailed: 'Le mot de passe et le courrier électronique ne correspondent pas.',
            regValidationError:'veuillez entrer un autre email. Cet email existe déjà.',
            validationfailed:'validation Failed',
            issuernotfound:'validation échouée',
            invalidsiteCodeparamvalue:'site invalide Code paramvalue',
            internalservererror:'Erreur Interne du Serveur',
            loginUserLockedError:'tentative de connexion dépasse plus de 5 tentatives l utilisateur est verrouillé.',
            loginFailedError:'Si vous éprouvez des difficultés à vous connecter, appelez Crystal Card Concierge au 1-800-595-8950 depuis les États-Unis ou le Canada ou appelez le 00-800-2797-8251 de lextérieur de l Amérique du Nord pour obtenir de laide.',
             passwordError:'Mot de passe a été précédemment utilisé. Plese creatre nouveau mot de passe.'
      
        },
        securityQuestions:{
            1:"Quel était ton jouet préféré enfant?",
            2:'',
            3:"Où avez-vous rencontré votre conjoint / partenaire pour la première fois? Entrez le nom complet de la ville seulement",
            4:'Quel était le nom de famille de votre enseignant de première année?',
            5:'Quel était le surnom que vous avez donné à votre première voiture?',
            6:'',
            7:'Si non utilisé, quel était votre premier numéro de téléphone?',
            8:'Quel est ton numéro de carte de bibliothèque?',
            9:'',
            10:'Quel est le prénom de votre meilleur ami d\'enfance?',
            11:'Quel était le prénom de votre premier manager ou patron?',
            12:'Quel était ton restaurant préféré à l\'université?',
        },
        successMsg: {
            tokenValid: 'Token is valid.'
        },
        apiPaths: {
            cardNumberValidationApi: contextPath + '/bank/setCreditCardNumber.do',
            registrationApi: contextPath + '/user/registerUser.do',
            securityQuestionApi: contextPath + '/user/getAllSecurityQuestion.do',
            gravtarCollectionApi: contextPath + '/user/getAllConcgImg.do',
            validateConciergeRegisterToken: contextPath + '/user/validateConciergeRegisterToken.do',
            registerConciergeUser: contextPath + '/user/conciergeRegistration.do',
            userNameCheckApi: contextPath + '/user/isUserNameUsed.do'
        },
        labels: {
            TermsOfService: 'Website Terms of Use',
            PrivacyPolicy: 'Privacy Policy'
        },
        configs: {
            loader: {
                message: '<div class="loaderContainer"><div><img src="' + contextPath + '/infinite/images/busy.gif" /></div><span id="loaderLoadingText">Loading...</span></div>',
                css: { backgroundColor: 'transparent', color: '#fff', border: 'none' }
            }
        },
        //R4_only
        defaultHeroImagePath: {
            hd_desktop: 'images/landingpage-heroimage-placeholder-hd-desktop.jpg',
            desktop: 'images/landingpage-heroimage-placeholder-desktop.jpg',
            tablet: 'images/landingpage-heroimage-placeholder-tablet.jpg',
            mobile: 'images/landingpage-heroimage-placeholder-mobile.jpg'
        },
        defaultBenefitImagePath: {
            hd_desktop: 'images/landingpage-benefit-placeholder-hd-desktop.jpg',
            desktop: 'images/landingpage-benefit-placeholder-desktop.jpg',
            tablet: 'images/landingpage-benefit-placeholder-tablet.jpg',
            mobile: 'images/landingpage-benefit-placeholder-mobile.jpg'
        },
        passwordSuggestion: 'Veuillez choisir un mot de passe difficile à transiger et qui n\'est pas une séquence commune de lettres ou de chiffres..<br><br>Les mots de passe doivent comporter au moins 7 caractères et contenir au moins une lettre, un chiffre et un caractère spécial. Les espaces ne sont pas autorisés.'
    };
    return Constants;
} );