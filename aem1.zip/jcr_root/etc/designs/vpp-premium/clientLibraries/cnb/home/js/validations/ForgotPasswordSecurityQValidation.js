define([
  'jquery',
  'Constants'
], function($, Constants){
	var settings = {
		ignore: ':hidden',
		onkeyup: false,
		onfocusout: false,
		
		rules: {
			securityQ : {
				required: true
			},
			securityQ_answer : {
				required: true,
				maxlength: Constants.validations.maxLength,
				noSpecialCharacters: true,
			}
		},
		messages: {
			securityQ : Constants.errorMsg.required,
			securityQ_answer : {
				required: Constants.errorMsg.required,
				noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
				maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
			}
		},
		errorPlacement: function(error, element) {
			element.closest('.form-group').after(error);
		},
		invalidHandler: function(form, validator) {
	        var errors = validator.numberOfInvalids();
	        if (errors) {                    
	            validator.errorList[0].element.focus();
	        }
	    },
		submitHandler: function(form) {
		
		}
	};
	
	return settings;
});
