define( [
    'jquery',
    'Constants'
], function( $, Constants ) {
    var settings = {
        ignore: ':hidden',
        onkeyup: false,
        onfocusout: false,
        rules: {
            'emailOrUser': {
                required: true,
                emailOrUsername: true
            },
            'email': {
                required: true,
                email: true
            },
            'password': {
                required: true
            }
        },
        messages: {
            'emailOrUser': {
                required: Constants.errorMsg.required,
                emailOrUsername: Constants.errorMsg.emailOrUsernameInvalid
            },
            'email': {
                required: Constants.errorMsg.required,
                email: Constants.errorMsg.invalidEmail
            },
            'password': {
                required: Constants.errorMsg.required
            }
        },
        groups: {
            'fields': 'email emailOrUser password'
        },
        errorPlacement: function( error, element ) {
            if ( element.attr( 'name' ) === 'email' || element.attr( 'name' ) === 'emailOrUser' || element.attr( 'name' ) === 'password' ) {
                error.insertBefore( '.email-input' );
            } else {
                error.insertAfter( element );
            }
        },
        invalidHandler: function( form, validator ) {
            var errors = validator.numberOfInvalids();
            if ( errors ) {
                validator.errorList[ 0 ].element.focus();
            }
        },
        submitHandler: function( form ) {
        }
    };
    return settings;
} );