define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/landing/landingListTemplate.html',
  'utils/Constants',
  'models/SessionObject',
  'jquery.lazyload',
  'bootstrap'
], function($, _, Backbone, landingListTemplate, Constants, SessionObject){

  var LandingListView = Backbone.View.extend({
    el: '#page-content .bottom-section',

    events: {},

    LandingListViewHelper: {},

    render: function(options){

      var data = {};
      _.extend(data, Constants, SessionObject, this.LandingListViewHelper); 

      var template = _.template($(landingListTemplate).html());
      this.$el.html(template(data));

      this.$('img.lazy').lazyload({
        threshold: 400
      });
    }
    
  });

  return LandingListView;
  
});