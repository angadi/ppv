define( [
    'jquery',
    'Constants',
    'jquery.lazyload',
    'bootstrap'
], function( $, Constants ) {
    var LandingPageView = function() {
        var component = $( '#page-content #v-home-content' );
        var carousel = component.find( '#carousel-generic.carousel' );
        if ( carousel.length > 0 ) {
            $( carousel ).carousel( {
                interval: 8000,
                pause: 'false'
            } );
        }
        $('.scroll-down').on('click', function(e){
            $('html, body').animate({
                scrollTop: $('.benefits-section').offset().top
            });
        });
        $('.slide-nav .closeBtn, .navbar-toggle').off('click').on('click', function(){
            $('#wrapper').toggleClass('slide-nav-open');
        });
    };
    return LandingPageView;
} );