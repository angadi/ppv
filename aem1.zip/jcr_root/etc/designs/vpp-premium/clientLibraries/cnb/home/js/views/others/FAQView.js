define( [
    'jquery',
    'Constants'
], function( $, Constants ) {
    var FAQView = function() {
        var component = $( '#v-faq-content' );
        var homeContent = $( "#v-home-content" );
        var homeLink = component.find( 'a.home' );
        homeLink.click( refreshToHome );
        init();

        function refreshToHome( e ) {
            $( homeContent ).removeClass( 'hidden' );
            component.addClass( 'hidden' );
        }

        function init( e ) {
            $( homeContent ).addClass( 'hidden' );
            component.removeClass( 'hidden' );
            $( window ).scrollTop( 0 );
        }
    };
    return FAQView;
} );