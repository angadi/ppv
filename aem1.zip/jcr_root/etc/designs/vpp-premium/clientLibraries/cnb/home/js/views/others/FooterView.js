define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/others/footerTemplate.html',
  'models/SessionObject'
], function($, _, Backbone, footerTemplate, SessionObject){

  var FooterView = Backbone.View.extend({
    el: 'footer',

    events: {},

    render: function(){

      var data = {};
      _.extend(data, SessionObject); 

      var template = _.template($(footerTemplate).html());
      this.$el.html(template(data));

    }
    
  });

  return FooterView;
  
});
