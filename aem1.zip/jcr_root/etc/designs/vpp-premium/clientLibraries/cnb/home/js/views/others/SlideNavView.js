define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/others/slideNavTemplate.html',
  'models/SessionObject'
], function($, _, Backbone, slideNavTemplate, SessionObject){

  var SlideNavView = Backbone.View.extend({
    el: '.slide-nav',

    events: {
      'click a.closeBtn': 'closeSideNav',
      'click a.log-in': 'logInTriggered'

      // 'blur a.closeBtn': 'circleInPopup',
      // 'keydown a.log-in': 'focusToCloseBtn'
    },

    initialize: function(options) {
      this.navView = options.navView;
      //wcag
      $(window).on("resize", this.updateCSS);
    },

    SlideNavViewHelper: {},

    render: function(){

      var data = {};
      _.extend(data, SessionObject, this.SlideNavViewHelper); 

      var template = _.template($(slideNavTemplate).html());
      this.$el.html(template(data));

      this.updateCSS();
      
    },

    circleInPopup: function(e) {
      this.$('a.log-in').focus();
    },
    focusToCloseBtn: function(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              this.$('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }

    },


    logInTriggered: function(e) {
      e.preventDefault();

      this.navView.toggleSlideNav(e);

      Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: true});
    },

    updateCSS: function() {
      var windowWidth = $(window).width();

      if(windowWidth<=1099) {
        this.$('a').attr('aria-hidden', 'false');
        this.$('a').attr('tabindex', '0');
      }
      else {
        this.$('a').attr('aria-hidden', 'true');
        this.$('a').attr('tabindex', '-1');
      }
    },

    closeSideNav: function(e) {
      e.preventDefault();

      // console.log('close slide nav');
      this.navView.toggleSlideNav(e);

    },

    onClose: function() {
      $(window).off("resize", this.updateCSS);
    }
    
  });

  return SlideNavView;
  
});
