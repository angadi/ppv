define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/conciergeRegisterStep2Template.html',
  'models/SessionObject',
  'utils/Constants',
  'select2'
], function($, _, Backbone, conciergeRegisterStep2Template, SessionObject, Constants){

  var ConciergeLoginStep2View = Backbone.View.extend({
    el: '.popup .concierge-register-step2-container',

    events: {  
      'click .profile-img-container': 'profileImgClicked',
      'click #concierge-register-step2-submit': 'conciergeLoginSubmit',
      'click .back': 'cancelLogin'
    },

    initialize: function(options) {
      this.parentView = options.parentView;
      this.formData = options.formData;
      this.concgImgs = options.concgImgs;
    },

    render: function(){

      var that = this;
      
      var data = {
        images:  this.concgImgs
      };
      _.extend(data, SessionObject, Constants); 

      var template = _.template($(conciergeRegisterStep2Template).html());
      that.$el.html(template(data));       


      return this;
    },

    profileImgClicked: function(e) {
      e.preventDefault();

      this.$('.profile-img-container').removeClass('selected');
      $(e.currentTarget).addClass('selected');

    },

    conciergeLoginSubmit: function(e) {
      e.preventDefault();
      
      this.$('label.error').remove();

      if(this.$('.profile-img-container.selected') && this.$('.profile-img-container.selected').length>0) {

        this.formData.concgImgId = this.$('.profile-img-container.selected').attr('profile-img-id');

        SessionObject.conciergeLogin(this.formData, this.successCallback, this.failureCallback, this);
      }
      else {
         $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.profileImageNotSelected+'</label>').insertBefore('.concierge-register-step-2-wrapper .form-container');
      }
    },

    successCallback: function(data, self) {
      window.location = data.redirectUrl
    },

    failureCallback: function(data, self) {
      $('<label class="systemError error" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>').insertBefore('.concierge-register-step-2-wrapper .form-container');
    },

    cancelLogin: function(e) {
      e.preventDefault();

      this.parentView.closePopup(e);
    },

    onClose: function() {

      if(this.childView) {
        this.childView.close();
      }
    }



  });

  return ConciergeLoginStep2View;
  
});
  
