define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/conciergeRegisterStep1Template.html',
  'views/popups/ConciergeRegisterStep2View',
  'models/SessionObject',
  'validations/ConciergeRegistrationStep1Validation',
  'utils/Constants',
  'select2'
], function($, _, Backbone, conciergeRegisterStep1Template, ConciergeRegisterStep2View, SessionObject, ValidationSettings, Constants){

  var ConciergeRegisterStep1View = Backbone.View.extend({
    el: '.popup .concierge-register-step1-container',

    events: {  
      'select2-selecting #securityQuestionId1' : 'securityQuestionChangeHandler',
      'select2-selecting #securityQuestionId2' : 'securityQuestionChangeHandler',

      'click #concierge-register-step1-submit': 'conciergeRegisterStep1Submit',
      'click .back': 'cancelRegister'
    },

    initialize: function(options) {
      this.parentView = options.parentView;
      this.userName = options.userName;
      this.token = options.token;
    },

    render: function(){

      var data = {
        userName: this.userName
      };
      _.extend(data, SessionObject, Constants); 

      var template = _.template($(conciergeRegisterStep1Template).html());
      this.$el.html(template(data));
      
      this.$('[data-toggle="popover"]').popover({html: true}); 
      this.$('input, textarea').placeholder();

      this.$form = this.$el.find('.concierge-register-step-1-form');

      this.$form.validate(ValidationSettings);

      this.loadSecurityQuestions();

      return this;

    },

    loadSecurityQuestions : function() {
      var $sQuestionSelectBox1 = this.$("#securityQuestionId1");
      var $sQuestionSelectBox2 = this.$("#securityQuestionId2");
      this.questions = '';
      var that = this;
      SessionObject.getSecurityQuestions(function(data) {
        if(data) {
          that.questionJson = data;
          that.questions += '<option value=""></option>';
          _.each(data, function(item) {
            that.questions += '<option value="' + item.questionId + '">' + item.questionDescription + '</option>';
          });
          
          $sQuestionSelectBox1.append(that.questions);
          $sQuestionSelectBox2.append(that.questions);
          
          this.$('#securityQuestionId1').select2({
            placeholder: this.$('#securityQuestionId1').siblings('label').html(),
            dropdownParent: $('.form-group'),
            minimumResultsForSearch: -1
          });
          this.$('#securityQuestionId2').select2({
            placeholder: this.$('#securityQuestionId2').siblings('label').html(),
            dropdownParent: $('.form-group'),
            minimumResultsForSearch: -1
          });
        }

         //wcag:
        _.defer(function(){
          that.$('#password').focus();
        });
      });
    },

    securityQuestionChangeHandler : function(e) {
      var selectBoxIdToChange = '';
      if($(e.currentTarget).prop('id') == 'securityQuestionId1') {
        selectBoxIdToChange = "#securityQuestionId2";      
      } 
      else {
        selectBoxIdToChange = "#securityQuestionId1";
      }
      this.removeOptionFromSelect(selectBoxIdToChange, e);
    },
    removeOptionFromSelect : function(selectBoxToChange, optionValue) {
      this.populateQuestionInSelectBox(selectBoxToChange, optionValue);
    },
    populateQuestionInSelectBox : function(selectBoxSelector, valueToExclude) {
      var excludeId = valueToExclude.choice.id;
      var oldSelectedValue = $(selectBoxSelector).select2('data') ? $(selectBoxSelector).select2('data').id : null;
      $(selectBoxSelector).find("option").remove();
      $(selectBoxSelector).append('<option value=""></option>');

      _.each(this.questionJson, function(item) {
        if(item.questionId != excludeId) {
          var optionHtml = '<option value="' + item.questionId + '">' + item.questionDescription + '</option>';
          $(selectBoxSelector).append(optionHtml);          
        }
      });
      if(oldSelectedValue == excludeId) {
        $(selectBoxSelector).select2('val', null);        
      } else {
        $(selectBoxSelector).select2('val', oldSelectedValue);
      }
    },

    conciergeRegisterStep1Submit: function(e) {
      e.preventDefault();

      this.$('label.error').remove();
      this.$('.form-control').removeClass('error');
      this.$form.find('#s2id_securityQuestionId1 a.select2-choice').removeClass('error');
      this.$form.find('#s2id_securityQuestionId2 a.select2-choice').removeClass('error');

      //manually check if any required field empty
      var $missingFields = this.$form.find('.form-control:not(.select2-container,select).required:blank');

      var isSpecialError = false;

      //check select2
      if(!this.$form.find('#s2id_securityQuestionId1').select2('data') || !this.$form.find('#s2id_securityQuestionId1').select2('data').text) {
        $missingFields.push($('#s2id_securityQuestionId1 a.select2-choice')[0]);

        this.$('#securityQuestionId1').select2('focus');
        isSpecialError = true;
      } 
      if(!this.$form.find('#s2id_securityQuestionId2').select2('data') || !this.$form.find('#s2id_securityQuestionId2').select2('data').text) {
        $missingFields.push($('#s2id_securityQuestionId2 a.select2-choice')[0]);

        if(!isSpecialError) {
          this.$('#securityQuestionId2').select2('focus');
          isSpecialError = true;
        }
      } 

      if($missingFields.length > 0) {

        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.required+'</label>').insertBefore('#userName');
        $missingFields.addClass('error');

        if(!isSpecialError) {
          $missingFields.first().focus();
        }
      }
      else {
        if(this.$form.valid()) {  //check if any required form missing      
          this.formData = this.$form.serializeObject();
          this.formData.phoneNumber = '';
          this.formData.token = this.token;
          delete this.formData['confirmPassword'];

          this.parentView.$('.concierge-register-step1-container').hide();
          this.childView = new ConciergeRegisterStep2View({parentView: this, formData: this.formData, userName: this.userName});
          this.childView.render();
          this.parentView.$('.concierge-register-step2-container').show();
        }
      }
    },

    cancelRegister: function(e) {
      e.preventDefault();

      this.parentView.closeChildren();
    },

    onClose: function() {

      if(this.childView) {
        this.childView.close();
      }
    }



  });

  return ConciergeRegisterStep1View;
  
});
  
