define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/conciergeRegisterTemplate.html',
  'views/popups/ConciergeRegisterStep1View',
  'models/SessionObject',
  'utils/Constants',
  'select2'
], function($, _, Backbone, registerTemplate, ConciergeRegisterStep1View, SessionObject, Constants){

  var ConciergeRegisterView = Backbone.View.extend({
    el: '.popup',

    initialize: function(options) {
      this.parentView = options.parentView;
      this.token = options.token;
    },
    events: {  
      'click .register': 'registerClicked',
      'click .closeBtn': 'cancelRegister'
    },
  

    render: function(){
      $('.heroImageContainer .welcome-container').remove();
      $('ul .log-in').remove();
      $('.slide-nav').remove();
      $('.navbar-toggle').remove();

      var data = {};
      _.extend(data, SessionObject, Constants); 

      var template = _.template($(registerTemplate).html());
      this.$el.html(template(data));

      this.parentView.pauseCarousel();

      return this;

    },

    registerClicked: function(e) {
      e.preventDefault();

      var postData = {};
      postData.token = this.token;

      var that = this;

      SessionObject.validateConciergeRegisterToken(postData, function(data) {
        that.$('.concierge-register-container').removeClass('register-start');

        that.$('.concierge-register-container .closeBtn').show();

        that.$('.concierge-register-start-container').hide();
        that.childView = new ConciergeRegisterStep1View({parentView: that, userName: data.userName, token: that.token});
        that.childView.render();
        that.$('.concierge-register-step1-container').show();
            
      }, function() {
        that.$el.find('#token-error-msg').html(Constants.errorMsg.registrationTokenInvalid);
        that.$el.find('#token-error-msg').show(); 
      });
    },

    cancelRegister: function(e) {
      e.preventDefault();

      if(this.$el.find('.concierge-register-confirm').is(':visible') && this.childView && this.childView.childView) {
        this.childView.childView.goToHomepage();
      }
      else {
        this.closeChildren();
      }
    },

    closeChildren: function() {

      if(this.childView) {
        if(this.childView.childView) {
          this.childView.childView.unbind();
          this.childView.childView.undelegateEvents();
          this.childView.childView.$el.empty();
        }
        this.childView.unbind();
        this.childView.undelegateEvents();
        this.childView.$el.empty();
      }

      this.$el.find('.concierge-register-container').addClass('register-start');
      this.$el.find('.concierge-register-start-container').show();
    },

    onClose: function() {
      if(this.childView) {
        this.childView.close();
      }
    }
    

  });

  return ConciergeRegisterView;
  
});
