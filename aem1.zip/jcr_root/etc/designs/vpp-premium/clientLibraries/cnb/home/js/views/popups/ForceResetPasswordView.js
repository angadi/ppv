define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/resetPasswordTemplate.html',
  'validations/ResetPasswordValidation',
  'models/SessionObject',
  'utils/Constants',
  'jquery.validate',
  'jquery.placeholder'
], function($, _, Backbone, resetPasswordTemplate, ValidationSettings, SessionObject, Constants){

  var ForceResetPasswordView = Backbone.View.extend({
    el: '.popup',

    events: {
      'click a.cancel': 'closePopup',
      'click a.closeBtn': 'closePopup',  
      'click #reset-password-submit': 'submitResetPassword',

      'click .profile-img-container': 'profileImgClicked',
      'click #concierge-register-step2-submit': 'conciergeRegisterStep2Submit',
      'click .back': 'cancelReset',
      
      'blur a.closeBtn': 'circleInPopup',
      'keydown input#password': 'focusToCloseBtn'
    },

    initialize: function(options) {
      this.parentView = options.parentView;
      this.userRole = options.userRole;
    },

    circleInPopup: function(e) {
      this.$('#password').focus();
    },
    focusToCloseBtn: function(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              $('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    },
    render: function(){
      var that = this;

      if(this.userRole && this.userRole === 'concierge') {

        SessionObject.getProfileImages(function(images) {
          var data = {
            images:  images,
            isForceReset: true,
            userRole: that.userRole
          };
          _.extend(data, SessionObject); 

          var template = _.template($(resetPasswordTemplate).html());
          that.$el.html(template(data));

          that.parentView.pauseCarousel();
          that.$('input, textarea').placeholder();

          that.$form = that.$el.find('form');
          that.$form.validate(ValidationSettings);

          //wcag:
          _.defer(function(){
            that.$('input#password').focus();
          });
        });
      }
      else {
        var data = {
          images: [],
          isForceReset: true,
          userRole: this.userRole
        };
        _.extend(data, SessionObject); 

        var template = _.template($(resetPasswordTemplate).html());
        that.$el.html(template(data));

        that.parentView.pauseCarousel();
        that.$('input, textarea').placeholder();

        that.$form = that.$el.find('form');
        that.$form.validate(ValidationSettings);

        //wcag:
        _.defer(function(){
          that.$('input#password').focus();
        });
      }
      return this;

    },
 
    submitResetPassword: function(e) {
      e.preventDefault();
    
      if($(e.currentTarget).hasClass('grey-out')) {
        return false;
      }

      this.$('label.error').remove();
      this.$('.form-control').removeClass('error');

      //manually check if any required field empty
      var $missingFields = this.$form.find('.form-control:not(.select2-container,select,:hidden).required:blank');
      if($missingFields.length > 0) {
        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>').insertBefore('#password');
        $missingFields.addClass('error');
      }
      else {
        if(this.$form.valid()) {
          var data = {
            'confirmNewPsw': this.$('#confirmPassword').val()
          };

          if(this.userRole && this.userRole === 'concierge') {
            this.formData = {
              password: this.$('#confirmPassword').val()
            }
            this.$('.reset-password-container.force-reset-password .reset-password-wrapper').hide();
            this.$('.reset-password-container.force-reset-password .concierge-register-step2-container').show();
          }
          else {
            this.$form.find('#reset-password-submit').addClass('grey-out');
            
            SessionObject.resetPasswordSubmit(data, this.resetPasswordSuccessCallback, this.resetPasswordFailureCallback, this);
          }
        }
      }
    },

    resetPasswordSuccessCallback: function(data, self) {
      self.$('#reset-password-submit').removeClass('grey-out');

      self.$('.reset-password-wrapper').hide();
      self.$('.reset-password-confirm-wrapper').show();
    },

    resetPasswordFailureCallback: function(data, self) {
      self.$('#reset-password-submit').removeClass('grey-out');

      self.$('#confirmPassword').closest('.form-group').after('<label class="systemError error" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>');
    },

    profileImgClicked: function(e) {
      e.preventDefault();

      this.$('.profile-img-container').removeClass('selected');
      $(e.currentTarget).addClass('selected');
    },

    conciergeRegisterStep2Submit: function(e) {
      e.preventDefault();
      
      this.$('label.error').remove();

      if(this.$('.profile-img-container.selected') && this.$('.profile-img-container.selected').length>0) {

        this.formData.imgId = this.$('.profile-img-container.selected').attr('profile-img-id');

        SessionObject.resetPasswordConciergeSubmit(this.formData, this.conciergeResetPswSuccessCallback, this.conciergeResetPswFailureCallback, this);
      }
      else {
         $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.profileImageNotSelected+'</label>').insertBefore('.concierge-register-step-2-wrapper .form-container');
      }
    },

    conciergeResetPswSuccessCallback: function(data, self) {
      self.$('#reset-password-submit').removeClass('grey-out');

      self.$('.reset-password-wrapper').hide();
      self.$('.concierge-register-step2-container').hide();
      self.$('.reset-password-confirm-wrapper').show();
    },

    conciergeResetPswFailureCallback: function(data, self) {
      self.$('#reset-password-submit').removeClass('grey-out');

      $('<label class="systemError error" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.generalError+'</label>').insertBefore('.concierge-register-step-2-wrapper .form-container');
    },

    cancelReset: function(e) {
      e.preventDefault();

      this.$('.reset-password-container.force-reset-password .concierge-register-step2-container').hide();
      this.$('.reset-password-container.force-reset-password .reset-password-wrapper').show();
    },

    closePopup: function(e) {
      e.preventDefault();

      this.parentView.resumeCarousel();

      this.close();

      Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: true});
    },

    onClose: function() {
      if(this.childView) {
        this.childView.close();
        this.childView = null;
      }
    }
    
  });

  return ForceResetPasswordView;
  
});
