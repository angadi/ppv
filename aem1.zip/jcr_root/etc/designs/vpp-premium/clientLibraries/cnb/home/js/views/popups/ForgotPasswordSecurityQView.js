define([
  'jquery',
  'validations/ForgotPasswordSecurityQValidation',
  'views/popups/ResetPasswordView',
  'Constants',
  'jquery.validate',
  'jquery.placeholder',
  'select2'
], function($, ValidationSettings, ResetPasswordView, Constants){

  var ForgotPasswordSecurityQView = function(questions,token){

    $("#v-forgot-password-securityq").html(Constants['forgotpasswordsecQ']);
    var component = $("#v-forgot-password-securityq");
    //el: '.popup',

    var cancel = $(component).find("a.cancel");
    var closeBtn = $(component).find("a.closeBtn");
    var secQsubmit = $(component).find("#security-questions-submit");
    var select = $(component).find("input#s2id_securityQ");
    var secQ = questions;
    render(secQ);
    cancel.click(closePopup);
    closeBtn.click(closePopup);
    secQsubmit.click(submitSecurityQ);
    closeBtn.blur(circleInPopup);
    select.keydown(focusToCloseBtn);
    function circleInPopup(e) {
      $('#s2id_securityQ').focus();
    }
    function focusToCloseBtn(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              $('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }
    function render(ques){
      $( '.popup' ).addClass( 'hidden' );
      component.removeClass( 'hidden' );
      $('.popup_block').show();
      $('.carousel').carousel('pause');
      var optionQ = ''; optionQ += '<option value=""></option>';
      $.each(questions, function(index, item){
          optionQ += '<option value="' + item.questionId + '">' + item.questionText + '</option>';
      });
      $('select#securityQ').append(optionQ);
      $('select#securityQ').select2({
        placeholder: $('#securityQ').siblings('label').html(),
        dropdownParent: $('.form-group'),
        minimumResultsForSearch: -1
      });

      $('input, textarea').placeholder();
      var $form = $(component).find('form');
      $form.validate(ValidationSettings);

      //wcag:
      //_.defer(function(){
        $('input#s2id_securityQ').focus();
      //});

      //return this;

    }

    function submitSecurityQ(e) {
      e.preventDefault();

      if($(e.currentTarget).hasClass('grey-out')) {
        return false;
      }
      var $form = $(component).find('form');

      $('label.error').remove();
      $('.form-control').removeClass('error');
      $('#s2id_securityQ a.select2-choice').removeClass('error');

      //manually check if any required field empty
      var $missingFields = $form.find('.form-control:not(.select2-container,select,:hidden).required:blank');
      //check select2
      if(!$form.find('#s2id_securityQ').select2('data')) {
        $missingFields.push($('#s2id_securityQ a.select2-choice')[0]);
      } 
      if($missingFields.length > 0) {
        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>').insertBefore('#s2id_securityQ');
        $missingFields.addClass('error');
      }
      else {
        if($form.valid()) {
          $form.find('#security-questions-submit').addClass('grey-out');

          var data = {
              'token':token,
            'questionId': $('#s2id_securityQ').select2('data').id,
            'questionAnswer' : $('#securityQ_answer').val()
          };
          forgotPasswordSecurityQSubmit(data, forgotPasswordSecurityQSuccessCallback, forgotPasswordSecurityQFailureCallback);
        }
      }
    }

    function objectToString(obj) {
      var str = '';
      for (var key in obj) {
          if (obj.hasOwnProperty(key)) {
              str += key + '=' + obj[key] + '&';
          }
      }
      str = str.substring(0, str.length-1);
      return str;
    }

    function forgotPasswordSecurityQSubmit(postData, successCallback, failureCallback) {
      var issuerName=$('#issuerName').val();
 	    var path = '/vpp-backend/v1/'+issuerName+'/infinite/pwReset/validateAnswer';

			$.ajax({
                                type: "POST",
                                url: path,
                                dataType: "json",
                                async:false,
                                contentType: "application/json; charset=utf-8",
                                data: JSON.stringify(postData),
                                success: function(result){
                              	  if(result.status!=undefined && result.status.statusCode === '200'){
                              		     forgotPasswordSecurityQSuccessCallback(result,postData.token); 
                              	  }else{
                              		  forgotPasswordSecurityQFailureCallback(result);
                              	  }
                                }
          });


    }

    function forgotPasswordSecurityQSuccessCallback(data,token) {

      console.log('forgot password security q succeed;');
      var $form = $(component).find('form');
      $form.find('#security-questions-submit').removeClass('grey-out');

      ResetPasswordView(token);

      $('.forgot-password-container').hide();
      $('.reset-password-container').show();
    }

    function forgotPasswordSecurityQFailureCallback(data) {
      console.log('forgot password security q failed;');
      var $form = $(component).find("form");
      $form.find('#security-questions-submit').removeClass('grey-out');

      $('#securityQ_answer').closest('.form-group').after('<label class="systemError error" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.forgotPasswordSecurityAnswerNotMatch + '</label>');
    }

    function closePopup(e) {
      e.preventDefault();
      component.addClass( 'hidden' );
      $('.popup_block').hide();
      $('.carousel').carousel('cycle');
      $("#v-forgot-password-securityq").empty();
    }

    function onClose() {
        component.addClass( 'hidden' );
        $('.popup_block').hide();
        $('.carousel').carousel('cycle');
        $("#v-forgot-password-securityq").empty();
    }

  };

  return ForgotPasswordSecurityQView;

});
