define( [
    'jquery',
    'validations/ForgotPasswordValidation',
    'Constants',
    'jquery.validate',
    'jquery.placeholder'
], function( $, ValidationSettings, Constants ) {
    var ForgotPasswordView = function() {
        $("#v-forgot-password-content").html(Constants['forgotpassword']);
        //element
        var component = $( '#v-forgot-password-content' );
        // variables
        var forgotPasswordContainer = component.find('.forgot-password-container');
        var confirmationContainer = component.find('.confirmation-container');
        var cancel = component.find( 'a.cancel' );
        var closeBtn = component.find( 'a.closeBtn' );
        var submitBtn = component.find( '.submitBtn' );
        var email = component.find( 'input.email-input' );
        var errorLabel = component.find( 'label.error' );
        var form = component.find( '.forgot-password-form' );
        //events
        cancel.click( closePopup );
        closeBtn.click( closePopup );
        closeBtn.keydown( closeBtnKeydown );
        submitBtn.click( submitSignIn );
        closeBtn.blur( circleInPopup );
        email.keydown( focusToCloseBtn );
        render();
        //functions
        function circleInPopup( e ) {
            email.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function render() {
            //this.parentView.pauseCarousel();
            component.find( 'input, textarea' ).placeholder();
            form.validate( ValidationSettings );
            $('.popup_block').show();
            forgotPasswordContainer.show();
            form[0].reset();
            $( '.popup' ).addClass( 'hidden' );
            component.removeClass( 'hidden' );
            $('.carousel').carousel('pause');
            //wcag:
            email.focus();
        }

        function submitSignIn( e ) {
            e.preventDefault();
            errorLabel.remove();
            if ( form.valid() ) {
                var userInfo = {
                    'userName': email.val(),
                    'templateType':'email_reset_password_template'
                };

                forgotPassword(userInfo);
            }
            // }
        }


        function forgotPassword(userInfo){

       	   	var issuerName=$('#issuerName').val();
       	    var path = '/vpp-backend/v1/'+issuerName+'/infinite/forgetPassword';

				$.ajax({
                                      type: "POST",
                                      url: path,
                                      dataType: "json",
                                      async:false,
                                      contentType: "application/json; charset=utf-8",
                                      data: JSON.stringify(userInfo),
                                      success: function(result){
                                    	  if(result.status!=undefined && result.status.statusCode === '200'){
                                    		  successCallback(result);
                                    	  }else{
											  successCallback(result);
										  }
                                      }
                });
		}

        function successCallback( data ) {
			var message = '';
            if(data.status.statusCode === "429"){
            	message += data.status.statusDescription;
				$('p.popup-instruction').html(message);
            }
			
            component.find( '.forgot-password-container' ).hide();
            component.find( '.confirmation-container' ).show();
        }

        function failureCallback( data, self ) {}

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                closePopup( e );
            }
        }

        function closePopup( e ) {
            confirmationContainer.hide();
            $('.popup_block').hide();
            $( '.popup' ).addClass( 'hidden' );
            $('.carousel').carousel('cycle');
            $("#v-forgot-password-content").empty();
        }
    };
    return ForgotPasswordView;
} );