define( [
    'jquery',
    'validations/ForgotUsernameValidation',
    'Constants',
    'jquery.validate',
    'jquery.placeholder'
], function( $, ValidationSettings, Constants ) {
    var ForgotUsernameView = function() {
        $("#v-forgot-user-content").html(Constants['forgotusername']);
        // element
        var component = $( '#v-forgot-user-content' );
        //vaiables
        var forgotPasswordContainer = component.find('.forgot-user-container');
        var confirmationContainer = component.find('.confirmation-container');
        var cancel = component.find( 'a.cancel' );
        var closeBtn = component.find( 'a.closeBtn' );
        var submitBtn = component.find( '.submitBtn' );
        var email = component.find( 'input#email' );
        var last4Pan = component.find( 'input#last4Pan' );
        var form = component.find( '.forgot-username-form' );
        var errorLabel;
        //events
        cancel.click( closePopup );
        closeBtn.click( closePopup );
        closeBtn.keydown( closeBtnKeydown );
        submitBtn.click( submitSignIn );
        closeBtn.blur( circleInPopup );
        email.keydown( focusToCloseBtn );

        render();
        //functions
        function circleInPopup( e ) {
            email.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function render() {
            //this.parentView.pauseCarousel();
            component.find( 'input, textarea' ).placeholder();
            $(form).validate( ValidationSettings );
            $('.popup_block').show();
            forgotPasswordContainer.show();
            form[0].reset();
            $('.popup').addClass('hidden');
            component.removeClass('hidden');
            $('.carousel').carousel('pause');
            //wcag:
            email.focus();
        }

        function submitSignIn( e ) {
            e.preventDefault();
            // this.$('.form-control').removeClass('error');
            errorLabel = component.find( 'label.error' );
            errorLabel.remove();
            component.find('.form-control').removeClass('error');
            //manually check if any required field empty
            var $missingFields = component.find('form').find('.form-control:not(.select2-container,select).required:blank');
            if($missingFields.length > 0) {

              $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.required+'</label>').insertBefore('#v-forgot-user-content #email');
              $missingFields.addClass('error');

              $missingFields.first().focus();
            } else{
              if ( form.valid() ) {
                  var userInfo = {
                      'email': email.val(),
                      'last4Pan':last4Pan.val()
                  };
                var issuerName=$('#issuerName').val();
 	    		var path = '/vpp-backend/v1/'+issuerName+'/infinite/pwReset/forgetUsername';

				$.ajax({
                                type: "POST",
                                url: path,
                                dataType: "json",
                                async:false,
                                contentType: "application/json; charset=utf-8",
                                data: JSON.stringify(userInfo),
                                success: function(result){
                              	  if(result.status!=undefined && result.status.statusCode === '200'){
                              		successCallback();
                              	  }else{
									  successCallback();
								  }
                                }
          });


              }
          }


        }

        function successCallback( data, self ) {
            forgotPasswordContainer.hide();
            confirmationContainer.show();
        }

        function failureCallback( data, self ) {}

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                closePopup( e );
            }
        }

        function closePopup( e ) {
            //e.preventDefault();
            //this.parentView.resumeCarousel();
            confirmationContainer.hide();
            $('.popup_block').hide();
            $('.popup').addClass('hidden');
            $('.carousel').carousel('cycle');
            $("#v-forgot-user-content").empty();
        }
    };
    return ForgotUsernameView;
} );