define( [
    'jquery',
    'validations/LoginValidation',
    'Constants',
    'jquery.validate',
    'jquery.placeholder'
], function( $, ValidationSettings, Constants ) {
    var loginFails = 0;
    var LoginView = function() {
         $("#v-login-content").html(Constants['login']);
        console.log("inside login");
        // element
        var component = $( '#v-login-content' );
        //variables
        var closeBtn = component.find( 'a.closeBtn' );
        var form = component.find( '.login-form' );
        var loginSubmit = component.find( '.submitBtn.login-submitBtn' );
        var email = component.find( 'input.email-input' );
        var password = component.find( '#password' );
        var errorMsg = component.find( '#login-error-msg' );
        var pageHeading =component.find('.popup-title');
        // events
        closeBtn.click( closePopup );
        closeBtn.keydown( closeBtnKeydown );
        loginSubmit.click( submitSignIn );
        closeBtn.blur( circleInPopup );
        email.keydown( focusToCloseBtn );
        render();
        //functions
        function render() {
            // this.parentView.pauseCarousel();
            component.find( 'input, textarea' ).placeholder();
            form.validate( ValidationSettings );
            $( '.popup' ).addClass( 'hidden' );
            component.removeClass( 'hidden' );
            $('.popup_block').show();
            //wcag:
           pageHeading.focus();
            $('.carousel').carousel('pause');
        }

        function circleInPopup( e ) {
            email.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function removeErrorMsg( e ) {
            if ( loginFails < 6 )
                errorMsg.fadeOut();
            else
                errorMsg.fadeOut( function() {
                    errorMsg.html( "If you are having trouble logging in, please call Crystal Card Concierge at 1-800-595-8950 from the U.S. or Canada or call 00-800-2797-8251 from outside North America for further assistance." );
                } );
        }

        function submitSignIn( e ) {
            e.preventDefault();
            removeErrorMsg();
            if ( form.valid() ) {
                
                console.log( "Successfully Login" );
                
                var userLoginInfo = {
                    'userName': email.val().trim(),
                    'password': password.val()
                };
                login( userLoginInfo, successCallback, failureCallback );
            }
        }

        function login(postData, successCallback, failureCallback) {

        	var issuerName=$('#issuerName').val();
       	    var path = '/vpp-backend/v1/'+issuerName+'/infinite/login/user';
              var postingData = JSON.stringify(postData);

                    $.ajax({
                                      type: "POST",
                                      url: path, 
                                      dataType: "json",
                                      async:false,
                                      contentType: "application/json; charset=utf-8",
                                      data: JSON.stringify(postData),
                                      success: function(result){
                                    	  if(result.status!=undefined && result.status.statusCode === '200' && result.response.userId !== null && result.response.userId!==""){
                                    		    
                                    		  if(result.response.benefitTypeCode!=undefined){
  												var bcode=result.response.benefitTypeCode.toString();
                                                   var code=bcode.replace(/,/g,"-");
                                                }

                                      		 
                                    		  redirectLandingPage(result.response.userId,result.response.firstName,code); 
                                    	  }else{
                                    		  failureCallback(result);
                                    	  } 
                                      }
                });
          
        }
        function redirectLandingPage(userid,firstName,bcode){
        	var cpath=$('#wrapper').find('#currentPagePath').val();
        	 $.ajax({
                 type: "GET",
                 url: "/bin/userRedirection", 
                 data: {currentPagePath : cpath,id:userid,firstName:firstName,benefitCode:bcode},
                 success: function(result){
                         location=result; 
                 }
        });
        	
        }
        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                closePopup( e );
            } else if ( e.which === 9 ) {
                closeBtn.focus();
            }
        }

        function closePopup( e ) {
            component.addClass( 'hidden' );
            $('.popup_block').hide();
            $('.carousel').carousel('cycle');
            $("#v-login-content").empty();
            window.location.hash = '#';
            setTimeout(function() { $('.log-in').focus(); }, 300);
        }

        function onClose() {
            if ( this.childView ) {
                this.childView.close();
            }
        }

        function conciergeSuccessCallback( data, self ) {
            /*self.$( '.login-step1-container' ).hide();
            self.childView = new ConciergeLoginStep2View( { parentView: self, formData: self.formData, concgImgs: data.concgImg } );
            self.childView.render();
            self.$( '.concierge-register-step2-container' ).show();*/
        }

        function successCallback( data ) {
            location = '/content/vpp/premium/cnb/home.html';
        }

        function failureCallback( response ) {
            component.find( '.form-control.required' ).removeClass( 'valid' ).addClass( 'error' );
            if ( loginFails < 6 ) {
                if(response.status.statusCode!=undefined && response.status.statusCode==451){
                    errorMsg.html( Constants.errorMsg.loginUserLockedError );
                }else if(response.status.statusCode!=undefined && response.status.statusCode==450){
              		errorMsg.html( Constants.errorMsg.emailOrUsernameLoginFailed );
                }

           } else {
               errorMsg.html(Constants.errorMsg.loginFailedError);
           }
            errorMsg.fadeIn();
            email.focus();
            loginFails = loginFails + 1;
        }
    };
    return LoginView;
} );