define([
    'jquery',
    'Constants',
], function($, Constants) {

    var RegisterEmailPrefView = function(data) {
        //variables
        var component = $('.popup .email-pref-container');
        var checkboxLabel = component.find('.checkbox-label');
        var notNow = component.find('.not-now');
        var emailPrefSubmit = component.find('#email-pref-submit');
        var closeBtn = component.find('a.closeBtn');
        var userid = data.response.userId;
        //events
        checkboxLabel.click(checkboxClicked);
        checkboxLabel.keydown(checkboxKeydown);
        notNow.click(selfLoginWithoutSave);
        emailPrefSubmit.click(selfLoginWithSave);
        closeBtn.blur(circleInPopup);
        render();

        function circleInPopup(e) {
            this.$('.checkbox-label').first().focus();
        }

        function focusToCloseBtn(e) {
            if (e.which === 9) {
                if (e.shiftKey === true) {
                    this.parentView.parentView.$('.closeBtn').focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function render() {
            $('#v-register-content').removeClass('hidden');
            $('.popup_block').show();
            $('.create-profile-container').hide();
            $('.security-questions-container').hide();
            component.removeClass('hidden');

            closeBtn.bind('click', function(e) {
                if ($(e.currentTarget).hasClass('grey-out')) {
                    return false;
                }
                selfLoginWithoutSave(e);
            });

            //wcag:
            checkboxLabel.first().focus();

        }

        function checkboxClicked(e) {
            if ($(e.target).hasClass('popup-link')) {

            } else {
                e.preventDefault();

                $(e.currentTarget).toggleClass('selected');

                if ($(e.currentTarget).hasClass('selected')) {
                    $(e.currentTarget).attr('aria-checked', 'true');
                } else {
                    $(e.currentTarget).attr('aria-checked', 'false');
                }
            }
        }

        function checkboxKeydown(e) {
            if (e.which == 32) {
                checkboxClicked(e);
            } else if (e.which === 9 && $(e.currentTarget).closest('.form-group').index() === 0) {
                if (e.shiftKey === true) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function selfLoginWithoutSave(e) {
            e.preventDefault();

            if ($(e.currentTarget).hasClass('grey-out')) {
                return false;
            }

            emailPrefSubmit.addClass('grey-out');
            notNow.addClass('grey-out');
            closeBtn.addClass('grey-out');
            successCallback();
        }

        function redirectLandingPage(userid, firstName, bcode) {
            var cpath = $('#wrapper').find('#currentPagePath').val();
            $.ajax({
                type: "GET",
                url: "/bin/userRedirection",
                data: { currentPagePath: cpath, id: userid, firstName: firstName, benefitCode: bcode },
                success: function(result) {
                    location = result;
                }
            });

        }

        function selfLoginWithSave(e) {
            e.preventDefault();

            checkboxLabel.removeClass('error');
            component.find('label.error').remove();

            if ($(e.currentTarget).hasClass('grey-out')) {
                return false;
            }
            emailPrefSubmit.addClass('grey-out');
            notNow.addClass('grey-out');
            closeBtn.addClass('grey-out');

            var subscribeIdList = '';

            for (var i = 0; i < component.find('.form-group label').length; ++i) {

                var $item = component.find('.form-group label').eq(i);

                if ($item.hasClass('selected')) {
                    subscribeIdList += $item.find('input').attr('id');

                    if (i === component.find('.form-group label').length - 1) {} else {
                        subscribeIdList += ',';


                    }
                }
            }

            var issuerName = $('#issuerName').val();
            var path = '/vpp-backend/v1/' + issuerName + '/infinite/register/register3';
            var inputParams3 = {
                'userId': userid,
                'subscribeIdList': subscribeIdList
            };
            $.ajax({
                type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(inputParams3),
                success: function(result) {
                    if (result.status != undefined && result.status.statusCode === '200') {
                        successCallback(result);
                    } else {
                        failureCallback(result);
                    }
                },
                error: function(result) {
                    failureCallback1(result);
                }
            });
        }

        function successCallback(data, self) {
            $('.popup_block').hide();
            $('.popup').addClass('hidden');
            $('#v-register-content').empty();
            if (data.status != undefined && data.status.statusCode === '200' && data.response.userId !== null && data.response.userId !== "") {
                if (data.response.benefitTypeCode != undefined) {
                    var bcode = data.response.benefitTypeCode.toString();
                    var code = bcode.replace(/,/g, "-");
                }

                redirectLandingPage(data.response.userId, data.response.firstName, code);
                //window.location = '/content/vpp/premium/cnb/home.html';
            }
        }

        function failureCallback(data) {
            if (data.status.statusCode === "451") {
                $(component).find("#4").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.regValidationError + '</label>');
                //return false;
            } else if (data.status.statusCode === "454") {
                $(component).find("#4").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.validationfailed + '</label>');
                //return false;
            } else if (data.status.statusCode === "450") {
                $(component).find("#4").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.issuernotfound + '</label>');
                //return false;
            } else if (data.status.statusCode === "351") {
                $(component).find("#4").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.invalidsiteCodeparamvalue + '</label>');
                //return false;
            } else if (data.status.statusCode === "500") {
                $(component).find("#4").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.internalservererror + '</label>');
                //return false;
            }
            self.$('#email-pref-submit').removeClass('grey-out');
            self.$('.not-now').removeClass('grey-out');
            self.parentView.parentView.$('.closeBtn').removeClass('grey-out');

            self.$('.form-group:last').after('<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>');
        }

        function failureCallback1(data) {
            $(component).find("#4").closest(".form-group").after('<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>');
        }

        function onClose() {

            if (this.childView) {
                this.childView.close();
            }

            if (SessionObject.prevFocus) {
                $('.' + SessionObject.prevFocus).focus();
            }
        }

    };

    return RegisterEmailPrefView;


});