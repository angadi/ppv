define( [
    'jquery',
	'views/popups/RegisterEmailPrefView',
    'validations/RegistrationSecurityQuestionsValidation',
    'Constants',
    'select2'
], function( $, RegisterEmailPrefView, ValidationSettings, Constants ) {
    var RegisterSecurityQuestionsView = function(data) {
        // element
        var component = $( '#v-register-content .security-questions-container' );
        // variables
        var secQ1 = $( component ).find( '#securityQuestionId1' );
        var secQ2 = $( component ).find( '#securityQuestionId2' );
        var checkboxLabel = $( component ).find( '.checkbox-label' );
        var secQSubmit = $( component ).find( '#security-questions-submit' );
        var back = $( component ).find( '.back' );
        var form = $( component ).find( '.security-questions-form' );
        var checkbox = $( component ).find( 'input[type=checkbox]' );
        var closeBtn = $( '#v-register-content a.closeBtn' );
        var errorLabel;
        var formControl = $( component ).find( '.form-control' );
        var secQdata = data;
        var issuerName=$('#issuerName').val();
        var emailPrefEnable;
        // events
        secQ1.on( 'select2-selecting', securityQuestionChangeHandler );
        secQ2.on( 'select2-selecting', securityQuestionChangeHandler );
        checkboxLabel.off('click').on('click', checkboxClicked );
        checkboxLabel.keydown( checkboxKeydown );
        back.click( backBtnClicked );
        secQSubmit.off('click').on('click', securityQuestionsSubmit );
        closeBtn.blur( circleInPopup );
        secQ1.keydown( focusToCloseBtn );
		$.ajax( {
                type: "GET",
                url: "/bin/getEmailPreference?language=" + language + "&issuer=" + issuerName,
                dataType: "json",
                //data:JSON.stringify( {'language' : language , 'issuer' : issuer} ),
                contentType: "application/json; charset=utf-8",
				async:false,
                // data: JSON.stringify( inputParams ),
                success: function( result ) {
                    emailPrefEnable = result;

                }
            } );

        render();
        // functions
        function render() {
            $( component ).find( 'input, textarea' ).placeholder();
            $( form ).find( 'input[type=checkbox]' ).addClass( 'input_hidden' );
            $( form ).validate( ValidationSettings );
            loadSecurityQuestions();
            $('.popup_block').show();
            $( '.create-profile-container' ).hide();
            $( '.security-questions-container' ).show();
            $('.carousel').carousel('pause');
        }

        function loadSecurityQuestions() {
            var questions = secQdata.response.securityQuestions;


                var optionQ = ''; optionQ += '<option value=""></option>';
                $.each(questions, function(index, item){
                    var questionId=item.questionId;
                    var questionText=Constants.securityQuestions[questionId];
                    optionQ += '<option value="' + item.questionId + '">' + questionText + '</option>';
                });
                secQ1.append(optionQ);
                secQ2.append(optionQ);

                $( secQ1 ).select2( {
                    placeholder: $( secQ1 ).siblings( 'label' ).html(),
                    dropdownParent: $( '.form-group' ),
                    minimumResultsForSearch: -1
                } );
                $( secQ2 ).select2( {
                    placeholder: $( secQ2 ).siblings( 'label' ).html(),
                    dropdownParent: $( '.form-group' ),
                    minimumResultsForSearch: -1
                } );
                //wcag:
                $( '#securityQuestionId1' ).select2( 'focus' );
        }

        function securityQuestionChangeHandler( e ) {
            var selectBoxIdToChange = '';
            if ( $( e.currentTarget ).prop( 'id' ) == 'securityQuestionId1' ) {
                selectBoxIdToChange = "#securityQuestionId2";
            } else {
                selectBoxIdToChange = "#securityQuestionId1";
            }
            populateQuestionInSelectBox( selectBoxIdToChange, e );
        }

        function populateQuestionInSelectBox( selectBoxSelector, valueToExclude ) {
            var questions = secQdata.response.securityQuestions;

            var excludeId = valueToExclude.choice.id;
            var oldSelectedValue = $( selectBoxSelector ).select2( 'data' ) ? $( selectBoxSelector ).select2( 'data' ).id : null;
            $( selectBoxSelector ).find( "option" ).remove();
            $(selectBoxSelector).append('<option value=""></option>');
          $.each(questions, function(index, item) {
            if(item.questionId != excludeId) {
				 var questionId=item.questionId;
                    var questionText=Constants.securityQuestions[questionId];
              var optionHtml = '<option value="' + item.questionId + '">' + questionText + '</option>';
              $(selectBoxSelector).append(optionHtml);          
            }
          });

            if ( oldSelectedValue == excludeId ) {
                $( selectBoxSelector ).select2( 'val', null );
            } else {
                $( selectBoxSelector ).select2( 'val', oldSelectedValue );
            }
        }

        function checkboxClicked( e ) {
            if ( $( e.target ).hasClass( 'popup-link' ) ) {} else {
                e.preventDefault();
                $( e.currentTarget ).toggleClass( 'selected' );
                if ( $( e.currentTarget ).hasClass( 'selected' ) ) {
                    $( e.currentTarget ).attr( 'aria-checked', 'true' );
                } else {
                    $( e.currentTarget ).attr( 'aria-checked', 'false' );
                }
            }
        }

        function checkboxKeydown( e ) {
            if ( e.which == 32 ) {
                checkboxClicked( e );
            }
        }

        function securityQuestionsSubmit( e ) {
            errorLabel = component.find('.form-group label.error');
            e.preventDefault();
            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }
            $( form ).find( '.checkbox-label' ).removeClass( 'error' );
            errorLabel.remove();
            formControl.removeClass( 'error' );
            $( form ).find( '#s2id_securityQuestionId1 a.select2-choice' ).removeClass( 'error' );
            $( form ).find( '#s2id_securityQuestionId2 a.select2-choice' ).removeClass( 'error' );
            //manually check if any required field empty
            var $missingFields = $( form ).find( '.form-control:not(.select2-container,select).required:blank' );
            var isSpecialError = false;
            //check select2
            if ( !$( form ).find( '#s2id_securityQuestionId1' ).select2( 'data' ) || !$( form ).find( '#s2id_securityQuestionId1' ).select2( 'data' ).text ) {
                $missingFields.push( $( '#s2id_securityQuestionId1 a.select2-choice' )[ 0 ] );
                secQ1.select2( 'focus' );
                isSpecialError = true;
            }
            if ( !$( form ).find( '#s2id_securityQuestionId2' ).select2( 'data' ) || !$( form ).find( '#s2id_securityQuestionId2' ).select2( 'data' ).text ) {
                $missingFields.push( $( '#s2id_securityQuestionId2 a.select2-choice' )[ 0 ] );
                if ( !isSpecialError ) {
                    secQ2.select2( 'focus' );
                    isSpecialError = true;
                }
            }
            if ( !$( form ).find( '.checkbox-label' ).hasClass( 'selected' ) ) {
                $missingFields.push( $( '.checkbox-label' )[ 0 ] );
            }
            if ( $missingFields.length > 0 ) {
                $( '<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>' ).insertBefore( '#s2id_securityQuestionId1' );
                $missingFields.addClass( 'error' );
                if ( !isSpecialError ) {
                    $missingFields.first().focus();
                }
            } else {
                if ( $( form ).valid() ) {
                    $( form ).find( '#security-questions-submit' ).addClass( 'grey-out' );
                    back.addClass( 'grey-out' );
                    closeBtn.addClass( 'grey-out' );
                    var data = form.serializeObjectWithoutEncodeURI();
                    //SessionObject.registerStep2( data, this.successCallback, this.failureCallback, this );
                    //successCallback();
                    registerStep2( data, successCallback, failureCallback ); 
                }
            }
        }

        function registerStep2(postData, successCallback, failureCallback) {

          var path = '/vpp-backend/v1/'+issuerName+'/infinite/register/register2';
		   var inputParams1 = {
                'cardHolderId':secQdata.response.cardHolderId.toString(),
                'securityQuestion1':postData.securityQuestionId1,
                'securityQuestionAnswer1':postData.securityQuestionAnswer1,
                'securityQuestion2':postData.securityQuestionId2,
                'securityQuestionAnswer2':postData.securityQuestionAnswer2};
				 $.ajax({
                    type: "POST",
					url: path, 
					dataType: "json",
					async:false,
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify(inputParams1),
					success: function(result){
                        if(result.status!=undefined && result.status.statusCode === '200'){ 
                           successCallback(result);
                        }else{
 							failureCallback(result);
                         }
                    },
                    error: function(result){
					failureCallback1(result);
                }
                    
                });
          //var postingData = objectToString(postData);
          //successCallback(postData);
          /*$.post(path, postingData, function(data) {

              if(data.status === Constants.apiStatus.YES) { 
                successCallback(data);
              } else {
                failureCallback(data);
              }

          });*/
        }

        function objectToString(obj) {
              var str = '';
              for (var key in obj) {
                  if (obj.hasOwnProperty(key)) {
                      str += key + '=' + obj[key] + '&';
                  }
              }
              str = str.substring(0, str.length-1);
              return str;
        } 

        function successCallback(data) {
            if(emailPrefEnable){
                if(data.status!=undefined && data.status.statusCode === '200' && data.response.userId !== null && data.response.userId!==""){
                    RegisterEmailPrefView(data);
				
                }
            }
            else(data.status!=undefined && data.status.statusCode === '200' && data.response.userId !== null && data.response.userId!==""){
				if (data.response.benefitTypeCode != undefined) {
                    var bcode = data.response.benefitTypeCode.toString();
                    var code = bcode.replace(/,/g, "-");
                }

				redirectLandingPage(data.response.userId, data.response.firstName,code); 
            }
        }

        function failureCallback( data ) {
			if(data.status.statusCode==="451"){
			$(component).find("#securityQuestionAnswer2").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.regValidationError + '</label>' )
		   	//return false;
            }
            else if(data.status.statusCode==="454"){
				$(component).find("#securityQuestionAnswer2").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.validationfailed + '</label>' )
		   	//return false;
            }
            else if(data.status.statusCode==="450"){
			$(component).find("#securityQuestionAnswer2").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.issuernotfound + '</label>' )
		   	//return false;
            }
            else if(data.status.statusCode==="351"){
			$(component).find("#securityQuestionAnswer2").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.invalidsiteCodeparamvalue + '</label>' )
		   	//return false;
            }
            else if(data.status.statusCode==="500"){
			$(component).find("#securityQuestionAnswer2").closest(".form-group").after('<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.internalservererror + '</label>' )
		   	//return false;
            }
            console.log( 'step2 failed' );
            $( form ).find( '#security-questions-submit' ).removeClass( 'grey-out' );
            back.removeClass( 'grey-out' );
            closeBtn.removeClass( 'grey-out' );
            $( '#securityQuestionAnswer2' ).closest( '.form-group' ).after( '<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>' );
        }
          function failureCallback1( data ) {
          component.find( '.form-control.required' ).removeClass( 'valid' ).addClass( 'error' );
           $(component).find("#securityQuestionAnswer2").closest(".form-group").after( '<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>' );
          
          }

        function backBtnClicked( e ) {
            e.preventDefault();
            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }
            $( '.security-questions-container' ).hide();
            $( '.create-profile-container' ).show();
        }

        function circleInPopup( e ) {
            $( '#securityQuestionId1' ).select2( 'focus' );
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }
 		function redirectLandingPage(userid, firstName, bcode) {
            var cpath = $('#wrapper').find('#currentPagePath').val();
            $.ajax({
                type: "GET",
                url: "/bin/userRedirection",
                data: { currentPagePath: cpath, id: userid, firstName: firstName,benefitCode: bcode },
                success: function(result) {
                    location = result;
                }
            });

        }



    };
    return RegisterSecurityQuestionsView;
} );