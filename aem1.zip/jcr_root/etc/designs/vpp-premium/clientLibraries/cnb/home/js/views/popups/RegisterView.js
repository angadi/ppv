define( [
    'jquery',
    'views/popups/RegisterSecurityQuestionsView',
    'validations/RegistrationValidation',
    'Constants',
    'select2',
    'jquery.maskedinput'
], function( $, RegisterSecurityQuestionsView, ValidationSettings, Constants ) {
    var RegisterView = function() {
        $( '#v-register-content' ).html( Constants[ 'register' ] );
        // component
        var component = $( '#v-register-content' );
        // variables
        var form = $( '.create-profile-form' );
        var profileSubmit = $( component ).find( '#create-profile-submit' );
        var closeBtn = $( component ).find( 'a.closeBtn' );
        var pan = $( component ).find( 'input#pan' );
        var country = $( component ).find( '#country' );
        var password = $( component ).find( '#password' );
        var city = $( component ).find( '#city' );
        var errorLabel;
        var formControl = $( component ).find( '.form-control' );
        var countrySelect = $( component ).find( '#s2id_country a.select2-choice' );
        var globalValues = {};
        var pageHeading = component.find( '.popup-title' );
        var issuer = $( '#issuerName' ).val();
        var countryList;
        render();
        // events
        profileSubmit.click( createProfileSubmit );
        closeBtn.blur( circleInPopup );
        closeBtn.keydown( closeBtnKeydown );
        closeBtn.click( closePopup );
        $( pan ).on( 'blur', maskInput );
        $( pan ).on( 'focus', unmaskInput );
        pan.keydown( focusToCloseBtn );
        country.change( countryChangeHandler );
        password.focus( tooltipFocused );
        password.blur( tooltipFocusedOut );
        city.focus( tooltipFocused );
        city.blur( tooltipFocusedOut );
        // functions
        function render() {
            $.mask.definitions[ 'n' ] = "[0-9\u25CF]";
            pan.mask( '?nnnn nnnn nnnn nnnn', { placeholder: " " } );
            //parentView.pauseCarousel();
            // $('[data-toggle="popover"]').popover({html: true});
            $( '.city-tooltip' ).popover( { html: true } ).data( 'bs.popover' ).tip().addClass( 'city-popover' );
            $( '.password-tooltip' ).popover( { html: true } );
            $( 'input, textarea' ).placeholder();
            addDynamicMessageForValidator( ValidationSettings );
            $( form ).validate( ValidationSettings );

            $( '.popup' ).addClass( 'hidden' );
            $( '.security-questions-container' ).hide();
            $( '#v-register-content' ).removeClass( 'hidden' );
            $( window ).scrollTop( 0 );
            $( 'form.create-profile-form' )[ 0 ].reset();
            $( '.popup_block' ).show();
            pageHeading.focus();
            $( '.create-profile-container' ).show();
            $( '.carousel' ).carousel( 'pause' );
            $.ajax( {
                type: "GET",
                url: "/bin/GetCountryListJson?language=" + language + "&issuer=" + issuer,
                dataType: "json",
                //data:JSON.stringify( {'language' : language , 'issuer' : issuer} ),
                contentType: "application/json; charset=utf-8",
                // data: JSON.stringify( inputParams ),
                success: function( result ) {
                    countryList = result;
                    loadCountries( result );
                }
            } );

        }

        function createProfileSubmit( e ) {
            e.preventDefault();
            errorLabel = component.find( 'label.error' );
            errorLabel.remove();
            formControl.removeClass( 'error' );
            countrySelect.removeClass( 'error' );
            //manually check if any required field empty
            var $missingFields = $( form ).find( '.form-control:not(.select2-container).required:blank' );
            if ( !$( form ).find( '.zip-field' ).hasClass( 'hidden' ) ) {
                var $zip = $( form ).find( '.zip-field' ).find( 'input' );
                if ( $zip.val().trim() ) {} else {
                    $missingFields.push( $zip[ 0 ] );
                }
            }
            if ( !$( form ).find( '.city-field' ).hasClass( 'hidden' ) ) {
                var $city = $( form ).find( '.city-field' ).find( 'input' );
                if ( $city.val().trim() ) {} else {
                    $missingFields.push( $city[ 0 ] );
                }
            }
            if ( $missingFields.length > 0 ) {
                $( '<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>' ).insertBefore( '#pan' );
                $missingFields.addClass( 'error' );
                $missingFields.first().focus();
            } else {
                if ( $( form ).valid() ) { //check if any required form missing
                    var data = form.serializeObjectWithoutEncodeURI();
                    data.pan = $( '#pan_copy' ).val().replace( / /g, '' ); //serializeObject will encodeURIComponent, space will turn to %20
                    //data = '';
                    //SessionObject.registerStep1( data, successCallback, failureCallback, this );
                    registerStep1( data, successCallback, failureCallback );
                } else {
                    if ( $( form ).find( '#firstname' ).hasClass( 'error' ) || $( form ).find( '#lastname' ).hasClass( 'error' ) ||
                        $( form ).find( '#zip' ).hasClass( 'error' ) || $( form ).find( '#city' ).hasClass( 'error' ) || $( form ).find( '#country' ).hasClass( 'error' ) ) {
                        $( form ).find( '#firstname' ).removeClass( 'valid' ).addClass( 'error' );
                        $( form ).find( '#lastname' ).removeClass( 'valid' ).addClass( 'error' );
                        $( form ).find( '#zip:visible' ).removeClass( 'valid' ).addClass( 'error' );
                        $( form ).find( '#s2id_country a.select2-choice' ).addClass( 'error' );
                        $( form ).find( '#city:visible' ).removeClass( 'valid' ).addClass( 'error' );
                    } else {
                        $( form ).find( '#s2id_country a.select2-choice' ).removeClass( 'error' );
                    }
                }
            }
        }

        function objectToString( obj ) {
            var str = '';
            for ( var key in obj ) {
                if ( obj.hasOwnProperty( key ) ) {
                    str += key + '=' + obj[ key ] + '&';
                }
            }
            str = str.substring( 0, str.length - 1 );
            return str;
        }

        function registerStep1( postData, successCallback, failureCallback ) {
            //var path = 'https://qa.vpp.tacpoint.net/vpp_api_service/v1/cnb/infinite/register/register1.do';
            var issuerName = $( '#issuerName' ).val();
            var path = '/vpp-backend/v1/' + issuerName + '/infinite/register/register';
            //var postingData = objectToString(postData);
            //successCallback({});
            var inputParams = {
                'pan': $( '#pan_copy' ).val().replace( / /g, '' ),
                'firstname': postData.firstname,
                'lastname': postData.lastname,
                'country': postData.country,
                'zip': postData.zip,
                'city': postData.city,
                'emailAddress': postData.email,
                'password': postData.password,
                'confirmPassword': postData.confirmPassword
            };
            $.ajax( {
                type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify( inputParams ),
                success: function( result ) {
                    if ( result.status != undefined && result.status.statusCode === '200' ) {
                        successCallback( result );
                    } else {
                        failureCallback( result );
                    }
                },
                error: function( result ) {
                    failureCallback1( result );
                }
            } );
        }

        function circleInPopup( e ) {
            if ( $( 'input#pan:visible' ) && $( 'input#pan:visible' ).length > 0 ) {
                $( 'input#pan' ).focus();
            } else if ( $( '#securityQuestionId1:visible' ) && $( '#securityQuestionId1:visible' ).length > 0 ) {
                $( '#securityQuestionId1' ).select2( 'focus' );
            } else if ( $( '.email-pref-form:visible' ) && $( '.email-pref-form:visible' ).length > 0 ) {
                $( '.email-pref-form:visible' ).find( '.checkbox-label' ).first().focus();
            }
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    $( 'a.closeBtn' ).focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function maskInput( e ) {
            var pan = $( '#pan' ).val().trim();
            globalValues.originalPan = pan;
            $( '#pan_copy' ).val( pan );
            var toRet = '';
            for ( var i = 0; i < pan.length; ++i ) {
                if ( i >= 15 ) {
                    toRet += pan[ i ];
                } else {
                    if ( pan[ i ] !== ' ' ) {
                        toRet += '\u25CF';
                    } else {
                        toRet += ' ';
                    }
                }
            }
            $( '#pan' ).val( toRet );
        }

        function unmaskInput( e ) {
            if ( globalValues.originalPan ) {
                $( e.currentTarget ).val( globalValues.originalPan )[ 0 ].setSelectionRange( 0, 0 );
            }
        }

        function tooltipFocused( e ) {
            $( e.currentTarget ).parent().find( '[data-toggle="popover"]' ).popover( 'show' );
        }

        function tooltipFocusedOut( e ) {
            $( e.currentTarget ).parent().find( '[data-toggle="popover"]' ).popover( 'hide' );
        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                $( e.currentTarget )[ 0 ].click();
            }
        }

        function onClose() {
            if ( childView ) {
                childView.close();
            }
            if ( SessionObject.prevFocus ) {
                $( '.' + SessionObject.prevFocus ).focus();
            }
        }

        function loadCountries( countries ) {
            var $countrySelect = component.find( 'select#country' );
            var countryOption = '<option value=""></option>';

            $.each( countries, function( index, country ) {
                countryOption += '<option value="' + country.id + '">' + country.name + '</option>';
            } );

            $countrySelect.append( countryOption );

            $countrySelect.select2( {
                dropdownParent: $( '.form-group' ),
                matcher: function( term, text ) {
                    if ( text.toUpperCase().indexOf( term.toUpperCase() ) == 0 ) {
                        return true;
                    }

                    return false;
                }
            } ).select2( 'val', '840' );
        }

        function countryChangeHandler( e ) {
            var id = $( e.currentTarget ).select2( 'data' ).id;
            $( '#zip' ).val( '' );
            $( '#city' ).val( '' );
            if ( id === '840' ) {
                $( '.zip-field' ).removeClass( 'hidden' );
                $( '.city-field' ).addClass( 'hidden' );
                $( '#zip' ).rules( 'remove', 'maxlength' );
                $( '#zip' ).rules( 'add', {
                    required: true,
                    maxlength: 5,
                    digits: true,
                    messages: {
                        required: Constants.errorMsg.required,
                        maxlength: Constants.errorMsg.billingInfoNotMatch,
                        digits: Constants.errorMsg.billingInfoNotMatch
                    }
                } );
            } else if ( id === '124' ) {
                $( '.zip-field' ).removeClass( 'hidden' );
                $( '.city-field' ).addClass( 'hidden' );
                $( '#zip' ).rules( 'remove', 'digits' );
                $( '#zip' ).rules( 'remove', 'maxlength' );
                $( '#zip' ).rules( 'add', {
                    required: true,
                    maxlength: 6,
                    messages: {
                        required: Constants.errorMsg.required,
                        maxlength: Constants.errorMsg.billingInfoNotMatch
                    }
                } );
            } else {
                $( '.zip-field' ).addClass( 'hidden' );
                $( '.city-field' ).removeClass( 'hidden' );
            }
        }

        function successCallback( data ) {
            RegisterSecurityQuestionsView( data );
        }

        function failureCallback( data ) {
            var errorObj = data;
            if ( data.status.statusCode === "451" ) {
                $( component ).find( "#pan" ).closest( ".form-control required valid" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.invalidCreditCard + '</label>' );
                //return false;
            } else if ( data.status.statusCode === "454" ) {
                $( component ).find( "#pan" ).closest( ".form-group" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.invalidCreditCard + '</label>' );
                //return false;
            } else if ( data.status.statusCode === "450" ) {
                $( component ).find( "#confirmPassword" ).closest( ".form-group" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.issuernotfound + '</label>' );
                //return false;
            } else if ( data.status.statusCode === "351" ) {
                $( component ).find( "#confirmPassword" ).closest( ".form-group" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.invalidsiteCodeparamvalue + '</label>' );
                //return false;
            } else if ( data.status.statusCode === "500" ) {
                $( component ).find( "#confirmPassword" ).closest( ".form-group" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.internalservererror + '</label>' );
                //return false;
            } else if ( data.status.statusCode === "350" ) {
                $( component ).find( "#email" ).closest( ".form-group" ).after( '<label id="validation-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.regValidationError + '</label>' );
                //return false;
            }
        }

        function failureCallback1( data ) {
            component.find( '.form-control.required' ).removeClass( 'valid' ).addClass( 'error' );
            component.find( '.form-group:last' ).after( '<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>' );
        }

        function addDynamicMessageForValidator( validatorSettings ) {
            var errorMsg = Constants.errorMsg.invalidCreditCard.replace( '/\{cardName\}/, SessionObject.bankConfig.CARD_NAME' );
            // validatorSettings.messages.pan.digits = errorMsg;
            validatorSettings.messages.pan.minlength = errorMsg;
            validatorSettings.messages.pan.maxlength = errorMsg;
        }

        function closePopup() {
            $( '.popup_block' ).hide();
            $( '.popup' ).addClass( 'hidden' );
            $( '.carousel' ).carousel( 'cycle' );
            window.location.hash = '#';
            setTimeout( function() { $( '.register' )[ 0 ].focus(); }, 300 );
        }
    };
    return RegisterView;
} );