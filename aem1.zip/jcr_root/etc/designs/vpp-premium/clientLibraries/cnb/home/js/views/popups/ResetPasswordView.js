define([
  'jquery',
  'validations/ResetPasswordValidation',
  'Constants',
  'jquery.validate',
  'jquery.placeholder'
], function($, ValidationSettings, Constants){

  var ResetPasswordView = function(token){
    $("#v-reset-password").html(Constants['resetpassword']);
    var component = $("#v-reset-password");

    var cancel = $(component).find("a.cancel");
    var closeBtn = $(component).find("a.closeBtn");
    var resetpwdSubmit = $(component).find("#reset-password-submit");
    var pwd = $(component).find("input#password");
    render();
    cancel.click(closePopup);
    closeBtn.click(closePopup);
    resetpwdSubmit.click(submitResetPassword);
    closeBtn.click(circleInPopup);
    pwd.keydown(focusToCloseBtn);

    function initialize(options) {
      parentView = options.parentView;
    }

    function circleInPopup(e) {
      $('#password').focus();
    }
    function focusToCloseBtn(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              $('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }
    function render(){
      $( '.popup' ).addClass( 'hidden' );
      component.removeClass( 'hidden' );
      $('.popup_block').show();
      $('.carousel').carousel('pause');

      $('input, textarea').placeholder();
      var $form = $(component).find("form");
      $form.validate(ValidationSettings);

      //wcag:
      //_.defer(function(){
        $('input#password').focus();
      //});

      //return this;

    }

    function submitResetPassword(e) {
      e.preventDefault();

      if($(e.currentTarget).hasClass('grey-out')) {
        return false;
      }
      var $form = $(component).find("form");
      $('label.error').remove();
      $('.form-control').removeClass('error');

      //manually check if any required field empty
      var $missingFields = $form.find('.form-control:not(.select2-container,select,:hidden).required:blank');
      if($missingFields.length > 0) {
        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>').insertBefore('#password');
        $missingFields.addClass('error');
      }
      else {
        if($form.valid()) {
          $form.find('#reset-password-submit').addClass('grey-out');

          var data = {
              'token':token,
            'newPassword': $('#confirmPassword').val()
          };
          resetPasswordSubmit(data, resetPasswordSuccessCallback, resetPasswordFailureCallback);
        }
      }
    }

    function resetPasswordSubmit(postData, successCallback, failureCallback) {
      var issuerName=$('#issuerName').val();
 	    var path = '/vpp-backend/v1/'+issuerName+'/infinite/pwReset/changePassword';

			$.ajax({
                                type: "POST",
                                url: path,
                                dataType: "json",
                                async:false,
                                contentType: "application/json; charset=utf-8",
                                data: JSON.stringify(postData),
                                success: function(result){
                              	  if(result.status!=undefined && result.status.statusCode === '200'){
                              		resetPasswordSuccessCallback(result);
                              	  }else{
                              		resetPasswordFailureCallback(result);
                              	  }
                                }
          });

    }

    function resetPasswordSuccessCallback(data) {
      $('#reset-password-submit').removeClass('grey-out');

      $('.reset-password-wrapper').hide();
      $('.reset-password-confirm-wrapper').show();
    }

    function resetPasswordFailureCallback(data) {
      $('#reset-password-submit').removeClass('grey-out');

       if ( data.status.statusCode === "351" ) {
      $('#confirmPassword').closest('.form-group').after('<label class="systemError" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.passwordError+'</label>');
    	}
    }

    function closePopup(e) {
      e.preventDefault();
      component.addClass( 'hidden' );
      $('.popup_block').hide();
      $('.carousel').carousel('cycle');
      $("#v-reset-password").empty();
    }

  };

  return ResetPasswordView;

});
