define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    'use strict';

    var EmailPref = {

        url: function() {
            return '../user2/getAllAvailableEmailReference.do';
        },

        fetch: function( options ) {
            options = options || {};
            options.cache = false;
            options.type = 'GET';
            //return Backbone.Collection.prototype.fetch.call(this, options);
        }
    };

    return EmailPref;
} );