define([
	'jquery',
	'underscore',
	'backbone',
	'utils/Constants',
	'models/OfferModel'
], function($, _, Backbone, Constants, OfferModel){
	'use strict';
	var OfferListCollection = Backbone.Collection.extend({
		model: OfferModel,

		url: function() { 
		    return this.constructUrl(this.options);
		},

		initialize: function(options) {
			this.options = options;
		},

		fetch: function(options) {
			options = options || {}; 
			options.cache = false
			return Backbone.Collection.prototype.fetch.call(this, options);
		},

		constructUrl: function(options) {
			var url = '';

			if(options.catName === 'searchAll' || options.catName === 'all') {
				url = '../offer/getAllOfferAndBenefitAndEvent.do';
			}
			else {
				var catName = options.catName
				url = '../offer/getOfferListByCategory.do?categoryName='+options.catName;
			}

			return url;
		}
	});

	return OfferListCollection;
});