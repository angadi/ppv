define([
	'jquery',
	'underscore',
	'backbone',
	'utils/Constants',
	'models/OfferListWithCatModel'
], function($, _, Backbone, Constants, OfferListWithCatModel){
	'use strict';

	var OfferListWithCatCollection = Backbone.Collection.extend({

		model: OfferListWithCatModel,

		url: function() { 
		    return this.constructUrl(this.options);
		},

		initialize: function(options) {
			this.options = options;
		},

		constructUrl: function(options) {
			var url = '';

			if(options.catName === 'bookmarks') {
				url = '../user2/getAllBookmark.do';
			}
			else {
				url = '../offer2/getOffersForHomePage.do';
			}

			return url;
		},

		fetch: function(options) {
			options = options || {}; 
			options.cache = false
			return Backbone.Collection.prototype.fetch.call(this, options);
		}
	});

	return OfferListWithCatCollection;
});