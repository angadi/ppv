$(document).ready(function() {
    $('.v-select2').select2({
    	placeholder: "Please select",
		dropdownParent: $('.form-group'),
		minimumResultsForSearch: -1
	});
});