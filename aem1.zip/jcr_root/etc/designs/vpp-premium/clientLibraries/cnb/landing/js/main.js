// Filename: main.js
require.config( {
    paths: {
        jquery: 'vendor/jquery/jquery-1.12.4.min',
        bootstrap: 'vendor/bootstrap/bootstrap',
        'Constants': 'utils/Constants_'+language,
        'jquery.validate': 'vendor/jquery/jquery.validate',
        'jquery.validate.additional-methods': 'vendor/jquery/additional-methods',

        // NON-AMD
        'select2': 'vendor/jquery/select2.min',
        'jquery.lazyload': 'vendor/lazyload/jquery.lazyload',
        'jquery.placeholder': 'vendor/jquery/jquery.placeholder',
        'jquery-ui': 'vendor/jquery/jquery-ui',
        'jquery-sessionTimeout': 'vendor/jquery/jquery.sessionTimeout',
        'ntpagetag': 'vendor/tracking/ntpagetag',
        'jquery.scrollbar': 'vendor/customize-scrollbar/jquery.mCustomScrollbar.min'
    },
    shim: {
        bootstrap: {
            deps: [ 'jquery' ]
        },
        'jquery.lazyload': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.lazyload'
        },
        'jquery.placeholder': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.placeholder'
        },
        'jquery-ui': {
            deps: [ 'jquery' ]
        },
        'jquery-sessionTimeout': {
            deps: [ 'jquery', 'jquery-ui' ]
        },
        'select2': {
            deps: [ 'jquery' ]
        },
        'ntpagetag': {
            exports: 'ntpagetag'
        },
        'jquery.scrollbar': {
            deps: [ 'jquery' ]
        }
    }
} );

require( [
    'app',
    'Constants',
    'jquery-sessionTimeout'
], function( App, Constants ) {
	$.ajaxSetup({ cache: false });
    //wcag, in case jump to default
    $('#skip-to-content a').bind('click', function(e) {
        e.preventDefault();
        $($(e.currentTarget).attr('href')).focus();
    });

    App.initialize();
    if ( window.isConciergePortal ) {} else {
        $.sessionTimeout( {
            'warnAfter': 840000,
            'message': Constants.message,
            'stayConnected': Constants.stayConnected,
            'logOutNow': Constants.logOutNow
        } );
    }
} );