define([
	'jquery',
	'underscore',
	'backbone',
	'utils/Constants',
	'models/OfferModel',
	'ntpagetag'
], function($, _, Backbone, Constants, OfferModel){
	'use strict';

	var OfferDetailModel = Backbone.Model.extend({

		model: { //nested model
			currentOffer: OfferModel
		},

		url: function() { 
			var url = '../offer/getOfferById.do?offerId=' + this.id;

		    return url;
		},

		parse: function(response){

	        for(var key in this.model) { //here key will be 'offerList'
	            var embeddedClass = this.model[key]; //embeddedClass = 'OfferListCollection'
	            var embeddedData = response[key]; //embeddedData = value of response.offerList
	            response[key] = new embeddedClass(embeddedData, {parse:true});
	        }
	        return response;
	    },

		// fetch: function(options) {
		// 	options = options || {}; 
		// 	options.cache = false
		// 	return Backbone.Collection.prototype.fetch.call(this, options);
		// },

		defaults: {
			prevOfferId: '',
			nextOfferId: '',
			currentOffer: new OfferModel()
		}
	});

	return OfferDetailModel;
});