define([
	'jquery',
	'underscore',
	'backbone',
	'utils/Constants',
	'collections/OfferListCollection'
], function($, _, Backbone, Constants, OfferListCollection){
	'use strict';

	var OfferListWithCatModel = Backbone.Model.extend({

		model: { //nested model
			offerList: OfferListCollection
		},
		initialize: function(options) {
			this.options = options;
		},
		parse: function(response){

	        for(var key in this.model) { //here key will be 'offerList'
	            var embeddedClass = this.model[key]; //embeddedClass = 'OfferListCollection'
	            var embeddedData = response[key]; //embeddedData = value of response.offerList
	            response[key] = new embeddedClass(embeddedData, {parse:true});
	        }
	        return response;
	    },
		defaults: {
			offerCat: '',
			isSpecial: false,
			isAll: false,
		    heroImg: {},
		    offerList: new OfferListCollection()
		}
	});

	return OfferListWithCatModel;
});