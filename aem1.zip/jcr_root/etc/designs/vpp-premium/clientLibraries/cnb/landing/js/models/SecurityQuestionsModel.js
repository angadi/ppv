define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    'use strict';

    var SecurityQuestionsModel = {

        url: function() {
            return contextPath + '/user/getUserInfo.do';
        },

        fetch: function( options ) {
           /* options = options || {};
            options.cache = false;
            options.type = 'POST';*/
            var questions = [
               {
                  "questionDescription":"What was your favorite toy as a child?",
                  "questionId":1
               },
               {
                  "questionDescription":"What was the last name of your first grade teacher?",
                  "questionId":4
               },
               {
                  "questionDescription":"What was the nickname you gave your first car?",
                  "questionId":5
               },
               {
                  "questionDescription":"If not used any more, what was your first phone number?",
                  "questionId":7
               },
               {
                  "questionDescription":"What is your library card number?",
                  "questionId":8
               },
               {
                  "questionDescription":"What is the first name of your childhood best friend?",
                  "questionId":10
               },
               {
                  "questionDescription":"What was the first name of your first manager or boss?",
                  "questionId":11
               },
               {
                  "questionDescription":"What was your favorite restaurant in college?",
                  "questionId":12
               },
               {
                  "questionDescription":"Where did you first meet your spouse/partner? Enter full name of city only",
                  "questionId":3
               }
            ];
            return questions;
            //return Backbone.Collection.prototype.fetch.call(this, options);
        },

        questions: function() {
           /* var questions = [
               {
                  "questionDescription":"What was your favorite toy as a child?",
                  "questionId":1
               },
               {
                  "questionDescription":"What was the last name of your first grade teacher?",
                  "questionId":4
               },
               {
                  "questionDescription":"What was the nickname you gave your first car?",
                  "questionId":5
               },
               {
                  "questionDescription":"If not used any more, what was your first phone number?",
                  "questionId":7
               },
               {
                  "questionDescription":"What is your library card number?",
                  "questionId":8
               },
               {
                  "questionDescription":"What is the first name of your childhood best friend?",
                  "questionId":10
               },
               {
                  "questionDescription":"What was the first name of your first manager or boss?",
                  "questionId":11
               },
               {
                  "questionDescription":"What was your favorite restaurant in college?",
                  "questionId":12
               },
               {
                  "questionDescription":"Where did you first meet your spouse/partner? Enter full name of city only",
                  "questionId":3
               }
            ];*/
			var issuerName = $("#issuerName").val();
			var path = "/vpp-backend/v1/" + issuerName + "/infinite/users/getAllSecurityQuestions" ;
			return $.ajax({
			   url: path,
			   type: "GET",
			   async: false,
			   success: function(data) {
			   },
			   error: function(e) {
			   }
			});

        },

        defaults: {
            securityQuestionId1: '',
            securityQuestion1: '',
            securityQuestionId2: '',
            securityQuestion2: ''
        }
    };

    return SecurityQuestionsModel;
} );