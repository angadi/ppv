define( [
    'jquery',
    'utils/Constants',
    'utils/RoleConstants'
], function( $, Constants, RoleConstants ) {
    'use strict';

    var SessionObject = {
        bankConfig: {},

        editProfileSubmit: function( apiUrl, postData, successCallback, failureCallback ) {

            $.post( apiUrl, postData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data );
                } else {
                    failureCallback();
                }
            } );

        },

        updateBookmarkStatus: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/deleteBookmark.do';

            if ( postData.isGoingToAdd ) {
                path = '../user2/addBookmark.do';
            }
            var postingData = 'offerId=' + postData.offerId;

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );

        },

        clearBookmarks: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/clearAllBookmark.do';

            $.post( path, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getMaskCharacters: function( length ) {
            var maskLength = Constants.maskCharacterLength;
            var maskString = '';
            if ( length ) {
                maskLength = length;
            }
            for ( var i = 0; i < maskLength; i++ ) {
                maskString += Constants.maskCharacter;
            }
            return maskString;
        },

        getSecurityQuestions: function( callback, self ) {
            var path = Constants.apiPaths.securityQuestionApi;

            $.post( path, function( data ) {
                callback( data, self );

            } );

        },

        updateSecurityQuestions: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/updateSecurity.do';

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        updatePsw: function( postData, successCallback, failureCallback, self ) {

            $.post( Constants.apiPaths.changePasswordApi, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        emailConcierge: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/sendConciergeEmail.do';

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        updateEmailPrefs: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/updateEmailSubscription.do';

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getBulletinBoard: function( callback ) {
            var path = '../user2/getBulletinMessages.do';

            $.get( path, function( data ) {

                callback( data.msg );

            } );
        },

        conciergeCardNumberSubmitted: function( postData, successCallback, failureCallback, self ) {
            var path = Constants.apiPaths.setConcgCreditNumber;

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getProfileImages: function( successCallback ) {
            var path = '../user/getAllConcgImg.do';
            $.post( path, function( data ) {

                successCallback( data );

            } );
        },

        updateConcgProfileImg: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/updateConciergeImage.do';

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getHistoryLog: function( successCallback ) {

            $.post( Constants.apiPaths.historyCommentsApi, function( data ) {

                successCallback( data );

            } );
        },

        postComment: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/addConcgComment.do';

            $.post( path, postData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        signOut: function( callback ) {
            if ( this.usertype === 'concierge' ) {
                window.location.href = '../j_spring_security_logout?usertype=concierge';
            } else {
                window.location.href = '../../j_spring_security_logout';
            }
        }

    };

    return SessionObject;
} );