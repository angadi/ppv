define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    'use strict';

    var User = {

        url: function() {
            return contextPath + '/user/getUserInfo.do';
        },

        fetch: function( options ) {
            options = options || {};
            options.cache = false;
            options.type = 'POST';
            //return Backbone.Collection.prototype.fetch.call( this, options );
        },

        defaults: {
            firstName: '',
            lastName: '',
            emailAddress: '',
            postalCode: '',
            country: ''
        }
    };

    return User;
} );