// Filename: router.js
define( [
    'jquery',
    'views/home/HomePageView',
    'views/popups/ConciergePageView',
    'views/popups/OfferDetailPageView',
    'views/popups/ClearBookmarkView',
    'views/popups/ProfilePageView',
    'views/popups/ConciergeProfilePageView',
    'views/popups/NewInquiryPageView',
    'views/popups/CardholderHistoryPageView',
    'jquery.validate',
    'jquery.validate.additional-methods'

], function(
    $,
    HomePageView,
    ConciergePageView,
    OfferDetailPageView,
    ClearBookmarkView,
    ProfilePageView,
    ConciergeProfilePageView,
    NewInquiryPageView,
    CardholderHistoryPageView
) {

    var initialize = function() {
        loadPage();
        HomePageView.init();

        function loadPage() {
            var regex = /^[\w\#\-\/]+$/g;
            var hash =(regex.exec(window.location.hash) !== null) ? window.location.hash : '';
            if ( hash.indexOf( '#cat/' ) === 0) {
                var hashContent = hash.split( '/' );
                if (hashContent.length === 4) {
                    hash = 'category';
                    var offerData = {
                        category: hashContent[ 1 ],
                        id: hashContent[ 3 ]
                    };
                }
            }
            switch ( hash ) {
                case '#concierge':
                    ConciergePageView();
                    break;
                case '#sign-out':
                    HomePageView.signout();
                    break;
                case 'category':
                    OfferDetailPageView(offerData);
                    break;
                case '#profile':
                    ProfilePageView();
                    break;
                case '#new-inquiry':
                    NewInquiryPageView();
                    break;
                case '#cardholder-history':
                    CardholderHistoryPageView();
                    break;
                case '#cprofile':
                    ConciergeProfilePageView();
                    break;
                default:
                    break;
            }
        }
        window.onhashchange = loadPage;
    };
    return {
        initialize: initialize
    };
} );