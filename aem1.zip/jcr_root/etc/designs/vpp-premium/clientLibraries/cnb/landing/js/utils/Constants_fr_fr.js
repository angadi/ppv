define( [
    'jquery'
], function( $ ) {
    'use strict';
    var contextPath = '';
    var Constants = {
        delayAutoStartCarousel: 4000, //4 seconds
        maskCharacter: '*',
        maskCharacterLength: 10,

        validations: {
            maxLength: 40,
            passwordMinLength: 7,
            passwordMaxLength: 40,
            maxAddressLength: 40,
            validPhoneNumberLength: 10,
            postalCodeMaxLength: 20,
            commentMaxLength: 2000
        },

        defaultOfferImagePath: {
            small: 'images/defaultOfferListImage_770x430.jpg',
            large: 'images/defaultOfferListImage_1600x430.jpg',
            detail: 'images/defaultOfferListImage_1600x430.jpg',
            merchantLogo: 'images/defaultMerchantLogo.jpg',
            smallIfMissing: 'images/defaultOfferListImage_770x430_ifMissing.jpg',
            largeIfMissing: 'images/defaultOfferListImage_1600x430_ifMissing.jpg'
        },

        faqJSONUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/faq.json?callback=?',

        visaAndYourDataUrl: 'https://www.visa.com/images/visa_premium_portal/bankContent/infinite/visa-and-your-data.json?callback=?',

        offerCategories: [ 'benefits', 'offers', 'events' ],

        openUrl: 'http://www.google.com',

        defaultUserName: 'Guest',

        errorMsg: {
            required: 'All fields are required.',
            noSearchResult: 'No matched offer found.',
            generalError: 'An error has occurred. Please contact the administrator.',
            securityQuestionSame: 'Security questions must not be same.',
            securityAnswerMaxLengthExceeded: 'Security answer should be less than {0} characters.',
            streetAddressLimitExceeded: 'Street Address cannot be more than {0} characters.',
            unableToChangeImage: 'Unable to change the image.',
            passwordNotMatch: 'Password entered does not match. ',
            emailNotMatch: 'The confirm email you entered doesn\'t match.',
            conciergeCardNumberInvalid: 'Invalid credit card number. Please enter a valid credit card number.',

            firstNameLengthExceeded: 'First Name should be less than {0} characters.',
            lastNameLengthExceeded: 'Last Name should be less than {0} characters.',
            firstNameRequired: 'Please enter the first name.',
            lastNameRequired: 'Please enter the last name.',
            cityRequired: 'Please enter city.',
            cityLengthExceeded: 'City should be less than {0} characters.',
            phoneNumberInvalid: 'Please use digits only. Enter a 10 digit phone number without any punctutation, hyphens or spacing.',
            passwordMaxExceeded: 'Password should be of less than {0} characters.',
            passwordMinLength: 'Password must be at least {0} characters long.',
            passwordInvalid: 'Passwords must be a minimum of 7 characters and contain at least one letter, one number and one special character. Spaces are not allowed.',
            conciergeImageNotSelected: 'Please select an image.',
            wrongConciergeImageSelected: 'Selected wrong image.',
            postalCodeMaxLengthExceeded: 'Postal Code should be less than {0} characters.',
            postalCodeRequired: 'Please enter Postal Code.',
            commentRequired: 'Please enter comments.',
            commentMaxLengthExceeded: 'Comments should be less than {0} characters.',

            nameMaxLengthExceeded: 'Name must be less than {0} characters.',
            emailListIncorrectFormat: 'Email listed is incorrect format. Emails must be separated by a space, comma or semi-colon.',
            emailMaxLengthExceeded: 'Email must be less than {0} characters.',
            emailListMaxExceeded: 'Only two emails are allowed.',

            emailBodyRequired: 'This field is required.',
            emailBodyMinLength: 'Comments should be at least 1 character',
            emailBodyMaxLength: 'Comments should be less than 4000 characters',
            emailBodyNoCreditCardNumber: 'Credit card information should not be included.',

            updateEmailPrefEmailInvalid: 'Email listed is incorrect format',
            updateEmailPrefEmailMaxExceeded: 'Email must be less than {0} characters.',

            securityAnswerInvalid: 'Security answer contains invalid characters. Please use letters and numbers only.',

            'changePswError': 'Last 4 passwords cannot be reused. Please try again.'
        },
        apiPaths: {
            userProfileApi: contextPath + '/user/getUserInfo.do',
            securityQuestionApi: contextPath + '/user/getAllSecurityQuestion.do',
            updateUserProfileApi: contextPath + '/user/updateUserInfo.do',
            changePasswordApi: contextPath + '/user/changePassword.do',
            selectGravtarImage: contextPath + '/user/selectConcgImg.do',
            updateConciergeUserProfileApi: contextPath + '/user/updateConciergeInfo.do',
            updateConciergeUserImage: contextPath + '/user/updateConciergeImage.do',
            setConcgCreditNumber: contextPath + '/bank/setConcgCreditNumber.do',
            historyCommentsApi: contextPath + '/user/getAllConcgComment.do',
            postCommentApi: contextPath + '/user/addConcgComment.do'
        },
        apiStatus: {
            OK: "OK",
            ERROR: 'ERROR',
            YES: 'YES',
            NO: 'No'
        },

        labels: {
            changePasswordSubTitle: 'Please provide the following information to change your password.',
            changeYourPassword: 'Change Password',
            profileImage: 'Profile Image',
            profileImageSubTitle: 'Choose your image from the choice below.',
            submit: 'Submit',
            passwordChanged: 'You have successfully changed your password.',
            defaultOptionText: 'Please select a security question',
            none: 'None',
            cardHolderBenefits: 'Cardholder Benefits',
            cardHolderSubTitle: 'Enter cardholder\'s Visa Card Number to access their benefits.',
            addAComment: 'Add a comment',
            commentSubTitle: 'Use the following field to add a comment.',
            more: 'MORE',
            less: 'LESS'
        },
        configs: {
            loader: {
                message: '<div class="loaderContainer"><div><img src="' + contextPath + '/infinite/images/busy.gif" /></div><span id="loaderLoadingText">Loading...</span></div>',
                css: { backgroundColor: 'transparent', color: '#fff', border: 'none' },
                baseZ: 2000
            }
        },

        //R4_only
        defaultHeroImagePath: {
            hd_desktop: 'images/heroimage-placeholder-hd-desktop.jpg',
            desktop: 'images/heroimage-placeholder-desktop.jpg',
            tablet: 'images/heroimage-placeholder-tablet.jpg',
            mobile: 'images/heroimage-placeholder-mobile.jpg'
        },
        defaultConciergeBannerImagePath: {
            hd_desktop: 'images/concierge-banner-placeholder-hd-desktop.jpg',
            desktop: 'images/concierge-banner-placeholder-desktop.jpg',
            tablet: 'images/concierge-banner-placeholder-tablet.jpg',
            mobile: 'images/concierge-banner-placeholder-mobile.jpg',
        },
        passwordSuggestion: 'Please choose a password that is difficult to compromise and isn\'t a common sequence of letters or numbers.<br><br>Passwords must be a minimum of 7 characters and contain at least one letter, one number and one special character. Spaces are not allowed.',
        message: 'Votre session est sur le point d\'expirer.',
        stayConnected: 'Rester connecté',
        logOutNow: 'Déconnexion maintenant'
    };

    return Constants;
} );