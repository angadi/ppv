/**
 * Role Constants.
 */
define(['jquery'], function($) {
	return {
		ROLE_USER: 100,
		ROLE_CONCIERGE_USER : 200,
		ROLE_ADMIN: 300
	};
});