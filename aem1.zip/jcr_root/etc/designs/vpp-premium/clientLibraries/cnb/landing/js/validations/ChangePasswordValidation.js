define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    return {
        settings: {
            ignore: '.ignore',
            errorClass: 'error block',
            rules: {
                oldPassword: "required",
                newPassword: {
                    required: true,
                    minlength: Constants.validations.passwordMinLength,
                    maxlength: Constants.validations.passwordMaxLength,
                    passwordRegex: true
                },
                confirmNewPassword: {
                    required: true,
                    equalTo: '#newPassword'
                }
            },
            onkeyup: false,
            onfocusout: false,
            messages: {
                newPassword: {
                    minlength: Constants.errorMsg.passwordMinLength,
                    maxlength: Constants.errorMsg.passwordMaxExceeded,
                    passwordRegex: Constants.errorMsg.passwordInvalid
                },
                confirmNewPassword: Constants.errorMsg.passwordNotMatch
            },
            errorPlacement: function( error, element ) {
                error.insertAfter( element );
            },
            invalidHandler: function( form, validator ) {
                var errors = validator.numberOfInvalids();
                if ( errors ) {
                    validator.errorList[ 0 ].element.focus();
                }
            },
            submitHandler: function( form ) {

            }
        }
    };
} );