define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    var settings = {
        ignore: ':hidden',
        errorClass: 'error block',

        onkeyup: false,
        onfocusout: false,

        rules: {
            email: {
                email: true,
                maxlength: Constants.validations.maxLength
            },
            newEmail: {
                email: true,
                equalTo: '#email'
            }
        },
        messages: {
            email: {
                email: Constants.errorMsg.updateEmailPrefEmailInvalid,
                maxlength: Constants.errorMsg.updateEmailPrefEmailMaxExceeded
            },
            newEmail: {
                email: Constants.errorMsg.updateEmailPrefEmailInvalid,
                equalTo: Constants.errorMsg.emailNotMatch
            }
        },
        errorPlacement: function( error, element ) {
            error.insertAfter( element );
        },
        invalidHandler: function( form, validator ) {
            var errorList = validator.errorList;
            if ( errorList && errorList.length > 0 ) {
                validator.errorList[ 0 ].element.focus();
            }
        },
        submitHandler: function( form ) {

        }
    };

    return settings;

} );