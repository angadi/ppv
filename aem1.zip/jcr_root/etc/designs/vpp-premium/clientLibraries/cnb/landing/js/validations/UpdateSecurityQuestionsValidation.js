define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    var settings = {
        ignore: ':hidden',
        onkeyup: false,
        onfocusout: false,

        rules: {
            securityQuestionAnswer1: {
                required: false,
                maxlength: Constants.validations.maxLength,
                noSpecialCharacters: true,
            },
            securityQuestionAnswer2: {
                required: false,
                maxlength: Constants.validations.maxLength,
                noSpecialCharacters: true
            }
        },
        messages: {
            securityQuestionAnswer1: {
                required: Constants.errorMsg.required,
                noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
                maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
            },
            securityQuestionAnswer2: {
                required: Constants.errorMsg.required,
                noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
                maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
            }
        },
        errorPlacement: function( error, element ) {
            error.insertAfter( element );
        },
        invalidHandler: function( form, validator ) {
            var errors = validator.numberOfInvalids();
            if ( errors ) {
                validator.errorList[ 0 ].element.focus();
            }
        },
        submitHandler: function( form ) {

        }
    };

    return settings;
} );