define([
    'jquery',
    'utils/Constants',
    'views/popups/ClearBookmarkView',
    //'jquery.lazyload',
    'bootstrap'
], function($, Constants, ClearBookmarkView) {

    var HomeListView = function() {
        var component = $('.offer-list-section');
        var bookmarkBtn = component.find('a.bookmark-btn');
        var clearBookmark = component.find('a.clear-bookmark');
        var clearBookmarksContainer = $('#v-clear-bookmarks-popup');
        //events
        bookmarkBtn.click(bookmarkClicked);
        clearBookmark.click(clearBookmarks);




        function initialize(options) {
            //this.parentView = options.parentView;

            //this.listenTo(Backbone.event_bus, 'bookmarkUpdated', this.updateBookmarkBtn);
        }

        var HomeListViewHelper = function() {
            function getImageUrl(imageList, targetWidth, targetHeight) {
                //if(!imageList || imageList.length<1) return "";
                var imagePath = '';

                if (imageList && imageList.length > 0) {
                    for (var i = 0; i < imageList.length; i++) {
                        var imageObj = imageList[i];
                        if (parseInt(imageObj.imageFileWidth, 10) === parseInt(targetWidth, 10) &&
                            parseInt(imageObj.imageFileHeight, 10) === parseInt(targetHeight, 10)) {
                            imagePath = imageObj.fileLocation;
                            break;
                        }

                    }
                }

                if (imagePath == '') {
                    //if there is no size matched, use default. 
                    if (targetWidth == 770) {
                        imagePath = Constants.defaultOfferImagePath.smallIfMissing;
                    } else {
                        imagePath = Constants.defaultOfferImagePath.largeIfMissing;
                    }
                }

                return imagePath;
            }

            function getMerchantTitle(offer) {
                var merchant = offer.get('merchantList')[0];

                return $('<div/>').text(merchant.merchant).html();
            }

        }
        render();
        function render(options) {
            ClearBookmarkView();
            /*var that = this;

            var data = {
              offerListsWithCat: options.collection,
              options: options.options,
            };
            _.extend(data, Constants, SessionObject, this.HomeListViewHelper); 

            //var template = _.template($(homeListTemplate).html());
            //this.$el.html(template(data));

            this.$('img.lazy').lazyload({
              threshold: 400
            });*/
        }

        // bookmarkMouseEnterHandler: function(e) {
        //   e.preventDefault();

        //   $(e.currentTarget).addClass('hoverOnBookmark');
        // },

        // bookmarkMouseOutHandler: function(e) {
        //   e.preventDefault();

        //   $(e.currentTarget).removeClass('hoverOnBookmark');
        // },

         function bookmarkClicked(e) {
             var offerType = "";
            e.preventDefault();

            var $bookmark = $(e.currentTarget);
            $bookmark.toggleClass('bookmarked');
            $bookmark.find('.selected').html('');
             var currentPagePath = $('#currentPagePath').val();
             var isBookmark = (currentPagePath.indexOf("bookmark") >= 0) ? true : false;


            this.offerIdBookmarkToBeUpdated = $bookmark.attr('offerId');
            this.isGoingToAdd = false;

            //homepage: in case offers have dup in different cat
            var $currentListSection = $bookmark.closest('.offer-list-section');
            var $restListSection = component.find('.offer-list-section').not($currentListSection);
            if ($restListSection.length > 0) {
                var self = this;
                var $dupOffers = $restListSection.find('.offer-container').filter(function() {
                    return $(this).attr('offer-id') === self.offerIdBookmarkToBeUpdated;
                });
                $dupOffers.find('.bookmark-btn').toggleClass('bookmarked');
            }

            if ($bookmark.hasClass('bookmarked')) {
                this.isGoingToAdd = true;

                $bookmark.find('.selected').html('added.');
                $bookmark.attr('aria-label', 'bookmark added');
            } else {
                $bookmark.find('.selected').html('removed.');
                $bookmark.attr('aria-label', 'bookmark removed');
            }
            var isConciergeUser = $('#isConciergeUser').val();
            var uid = "";
            if(isConciergeUser!='' && isConciergeUser!=undefined ){
                uid =$('#cardHolderId').val();
              }else{
                    uid =$('#userId').val();
             }     
            var currentPagePath = $( '#currentPagePath' ).val();
            var pathArray = currentPagePath.split('/');
            var issuer = xssFilter(pathArray[4]);
            var product = "infinite"; 
            var startPoint = "/vpp-backend/v1/" +issuer+ "/" + product +"/bookmark/";
            // console.log(startPoint);
             if(this.isGoingToAdd)
             {var finalUrl= startPoint + "addBookmark";
			  $("div[offer-id="+ this.offerIdBookmarkToBeUpdated+"]").find('a.bookmark-btn').removeClass('bookmark-btn').addClass('bookmark-btn  bookmarked');
             }else{
             var finalUrl = startPoint + "deleteBookmark";
			  $("div[offer-id="+ this.offerIdBookmarkToBeUpdated+"]").find('a.bookmark-btn').removeClass('bookmark-btn bookmarked').addClass('bookmark-btn');
             }
             var findAEM = this.offerIdBookmarkToBeUpdated;

             if(findAEM.indexOf("A") > -1){
                offerType = "AEMOFFER";}else{
				offerType = "VMORCOFFER";
                }
         //    console.log(finalUrl + offerType );
            var postData = {
                'userId':uid,
                'offerId': this.offerIdBookmarkToBeUpdated,
                'offerType': "VMORCOFFER"
            };
             $.ajax({
        url: finalUrl,
        type: 'POST',
       contentType: "application/json; charset=utf-8",
        data: JSON.stringify(postData),
        success: function(data) {
           console.log("Success");
            if(isBookmark) {
                window.location.reload();

            }
        }
    });

            //updateBookmarkStatus(postData, successCallback, failureCallback);
        }

        function successCallback(data, self) {
            console.log('bookmark update succeeded.');

            //if on bookmark page, need update layout
            if (SessionObject.curCat === 'bookmarks' && !self.isGoingToAdd) {
                var $offerToBeRemoved = self.$el.find('.offer-container').filter(function() {
                    return $(this).attr('offer-id') === self.offerIdBookmarkToBeUpdated;
                });

                $offerToBeRemoved.fadeOut(300, function() {
                    $(this).remove();

                    if (self.$el.find('.offer-list-section:not(.bookmark-section) .offer-container').length === 0) {

                        self.$el.find('.offer-list-section:not(.bookmark-section)').remove();
                        self.$el.find('.bookmark-clear-container').remove()
                        self.$el.find('.bookmark-section').addClass('empty-bookmark');

                    }
                })
            }
        }

        function failureCallback(data, self) {
            console.log('bookmark update failed.');
        }

        function clearBookmarks(e) {
            console.log("clear bookmarks");
            e.preventDefault();
            clearBookmarksContainer.addClass('popup-open');
            clearBookmarksContainer.removeClass('hidden').css('display','block');
            //render clear bookmark popup
            /* this.childView = new ClearBookmarkView({parentView: this});
             this.childView.render();

             //notify parent view 
             this.parentView.popupView = this.childView;*/
        }

        function updateBookmarkBtn(data) {
            var $offerToBeUpdated = this.$('.offer-container').filter(function() {
                return $(this).attr('offer-id') === data.offerId;
            });

            if (data.isGoingToAdd) {
                $offerToBeUpdated.find('.bookmark-btn').addClass('bookmarked');
            } else {
                $offerToBeUpdated.find('.bookmark-btn').removeClass('bookmarked');
            }

            //if on bookmark page, need update layout
            if (SessionObject.curCat === 'bookmarks' && !data.isGoingToAdd) {

                $offerToBeUpdated.fadeOut(300, function() {
                    $(this).remove();

                    if ($('.offer-list-section:not(.bookmark-section) .offer-container').length === 0) {

                        $('.offer-list-section:not(.bookmark-section)').remove();
                        $('.bookmark-clear-container').remove()
                        $('.bookmark-section').addClass('empty-bookmark');

                    }
                })
            }


        }

        function onClose() {

            if (this.childView) {
                this.childView.close();
            }

            this.stopListening();
        }
		
		/** xss filtering **/
		function xssFilter(toOutput){
			return toOutput.replace('&','&amp;').
				replace('<','&lt;').
				replace('>','&gt;').
				replace('"','&quot;').
				replace("'",'&#x27').
				replace('/','&#x2F');
		}

    

    };

    return HomeListView;

});