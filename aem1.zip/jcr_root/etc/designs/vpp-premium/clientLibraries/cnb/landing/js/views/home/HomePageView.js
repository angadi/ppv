define([
  'jquery',
  'utils/Constants',
  'views/home/HomeListView',
  //'jquery.lazyload',
  'jquery.scrollbar',
  'bootstrap'
], function($, Constants,HomeListView){

  var HomePageView = {
		  genericCarousel: $('#page-content .main #carousel-generic.carousel'),
       
	init: function(){
        //element
        var component = $('#page-content .main');

        // variables
        var genericCarousel = component.find('#carousel-generic.carousel');
		$(window).on("scroll", this.fixNav);
		$(window).on('hashchange', function() {
				$('label.error').empty();
         		$('.form-control.required').removeClass('error');
        		$('#cardTxtField1').val('');
            	$('#cardTxtField2').val('');
		        $('#cardTxtField3').val('');
        		$('#cardTxtField4').val('');
       		});
        render();
        //functions
        function render() {
          if(genericCarousel.length > 0) {
              $(genericCarousel).carousel({
                interval: 8000,
                pause : 'false'
              });
          }
          HomeListView();
        }
       $('.slide-nav .closeBtn, .navbar-toggle').off('click').on('click', function(){
               $('#wrapper').toggleClass('slide-nav-open');
        });
     },
     signout: function(){

 		$.ajax({
 	          type: "POST",
 	          url: "/vpp-backend/logout", 
              async:false,
 	          success: function(){

 	                  
 	          }
 	 	 });

      var cpath=$('#wrapper').find('#currentPagePath').val();
      var isConciergeUser = $('#isConciergeUser').val();
      var isSSO = $('#isSSO').val();
      //   var isSSO = "true";
      var urlPath="/bin/userSignout";
      if(isConciergeUser!='' && isConciergeUser!=undefined ){
			urlPath="/bin/conciergeUserSignout";
      }else{
          if(isSSO!='' && isSSO!=undefined ){
			urlPath= "/bin/userSingleSignOnSignout";
          }else {urlPath= "/bin/userSignout";
      }
      }  console.log(urlPath);
 	 $.ajax({
          type: "GET",
          url: urlPath, 
          data: {currentPagePath : cpath},
          success: function(result){
                  location=result;

          }
 	 });
 	      
     },
     pauseCarousel: function () {
         this.genericCarousel.carousel( 'pause' );
     },

     resumeCarousel: function () {
         this.genericCarousel.carousel( 'cycle' );
     },

      fixNav: function(e) {     
      var $nav = $('.bottom-section .page-navs');

      // console.log('scrollTop = ' + $(window).scrollTop());

      if(!$('.heroImageContainer') || $('.heroImageContainer').length===0) {
        if($(window).scrollTop() > $('.navbar').height()) {
          $nav.addClass('fixed');
        }
        else {
          $nav.removeClass('fixed');
        }
      }
      else {
        if ($(window).scrollTop() > $('.heroImageContainer').height()+$('.navbar').height()) {
          $nav.addClass('fixed');
        }
        else {
          $nav.removeClass('fixed');
        }
      }
    }
  };

  return HomePageView;
  
});
