define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/others/slideNavTemplate.html',
  'models/SessionObject'
], function($, _, Backbone, slideNavTemplate, SessionObject){

  var SlideNavView = Backbone.View.extend({
    el: '.slide-nav',

    events: {
      'click .slide-nav-ul li a': 'linkTriggered',
      'click a.closeBtn': 'closeSideNav',
      'click #submit': 'searchSubmitted'
    },

    initialize: function(options) {
      this.navView = options.navView;

      //wcag
      $(window).on("resize", this.updateCSS);
    },

    SlideNavViewHelper: {},

    render: function(){

      var data = {};
      _.extend(data, SessionObject, this.SlideNavViewHelper); 

      var template = _.template($(slideNavTemplate).html());
      this.$el.html(template(data));   

      this.updateCSS();   
    },

    updateCSS: function() {
      var windowWidth = $(window).width();

      if(windowWidth<=1099) {
        this.$('.slide-nav-container').attr('aria-hidden', 'false');
        this.$('.slide-nav-container').attr('tabindex', '0');
        this.$('a').attr('aria-hidden', 'false');
        this.$('a').attr('tabindex', '0');
        this.$('input').attr('tabindex', '0');
        this.$('input').attr('aria-hidden', 'false');
      }
      else {
        this.$('.slide-nav-container').attr('aria-hidden', 'true');
        this.$('.slide-nav-container').attr('tabindex', '-1');
        this.$('a').attr('aria-hidden', 'true');
        this.$('a').attr('tabindex', '-1');
        this.$('input').attr('tabindex', '-1');
        this.$('input').attr('aria-hidden', 'true');
      }
    },

    highlightNav: function(cat) {
      this.$('ul li a').removeClass('active');
      this.$('ul li.home-li').removeClass('home-inactive');

      if(cat) {
        this.$('ul li a').filter('.' + cat).addClass('active');
      }

      if(cat !== 'home') {
        this.$('ul li.home-li').addClass('home-inactive');
      }
    },

    searchSubmitted: function(e) {
      e.preventDefault();

      this.navView.toggleSlideNav(e);

      var val = this.$('#search').val();
      val = $.trim(_.escape(val));

      if(val === '') {}
      else {
        Backbone.history.navigate('#offer-search?q=' + val, {trigger: true});
      }
    },

    linkTriggered: function(e) {
      e.preventDefault();

      this.navView.toggleSlideNav(e);

      Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: true});
    },

    closeSideNav: function(e) {
      e.preventDefault();

      // console.log('close slide nav');
      this.navView.toggleSlideNav(e);

    },

    onClose: function() {
      $(window).off("resize", this.updateCSS);
    }
    
  });

  return SlideNavView;
  
});
