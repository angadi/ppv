define([
    'jquery',
    'views/home/HomePageView',
    'views/popups/NewCommentPageView',
    'models/SessionObject',
    'utils/Constants',
    'jquery.scrollbar'
], function($, HomePageView, NewCommentPageView, SessionObject, Constants) {

    var ProfileImgPageView = function() {
        var currentPagePath = $('#currentPagePath').val();
        var dataRequest = $.ajax({
            url: '/bin/profileOverlayHandlerPremium',
            data: {
                currentPagePath: currentPagePath,
                popup: 'cardholder_history'
            },
            dataType: 'html'
        });
        dataRequest.done(function(data) {
            $('#popup-section').html(data);
            ProfileImgPageViewRender();
        });
    };
    var ProfileImgPageViewRender = function() {
        // element
        var component = $('#popup-section');
        var profileClose = component.find('a.closeBtn.close-profile');
        var newComment = component.find('a.new-comment');
        var scrollableArea = component.find('.scrollable-area');
        var pageHeading = component.find('h1.page-heading');
        var globalValues = {};
        var childComponent = component.find('.update-security-questions-container');

        // events
        profileClose.click(closePopup);
        newComment.click(createNewComment);

        render();
        // functions
        var uid = $('#cardHolderId').val();
        

        function render(options) {
            HomePageView.pauseCarousel();
            component.addClass('popup-open');
            component.fadeIn();
            var carduid = $('#cardId').val();
            var path = '/vpp-backend/v1/concierge/getConciergeComments?cardHolderId='+carduid;
            $.ajax({
                type: "GET",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                success: function(result) {
                    if (result.status != undefined && result.status.statusCode === '200') {
                        renderMessages(result.response);
                    }
                },
                error: function(result) {

                }
            });
            pageHeading.focus();
        }

        function renderMessages(messages) {
            var data = '';
            var first = '';
            $.each(messages, function(i, message) {
                first = (i === 0) ? ' first' : '';
                data += ' <div class="history-row ' + first + '">';
                data += '<div class="date-col table-col">' + message.createdDateTime + '</div>'; //date
                data += '<div class="user-col table-col">' + message.conciergeUser + '</div>'; //name
                data += '<div class="comment-col table-col">' + message.comment + '</div>'; // comment
                data += '</div>';
            });
            $('.history-table-inner').html(data);
            scrollableArea.mCustomScrollbar({
                theme: 'gray-scrollbar'
            });
        }

        function createNewComment(e) {
            e.preventDefault();

            NewCommentPageView({ closeSubview: closeSubview });
        }

        function closePopup(e) {
            component.fadeOut();
            HomePageView.resumeCarousel();
            childComponent.html('');
            $('.navbar-customize .cardholder-history').focus();
            component.html('');
            component.removeClass('popup-open');
        }

        function closeSubview(focusItem) {
            ProfileImgPageView();
        }

    };

    return ProfileImgPageView;

});