define([
  'jquery',
  'utils/Constants',
  'bootstrap'
], function($, clearBookmarkTemplate, Constants){

  var ClearBookmarkView = function(){
    //  var uId = "42465";
    var component = $('#v-clear-bookmarks-popup');
    var clearBookmarkConfirm = component.find('a.clear-bookmark-confirm');
    var clearBookmarkCancel = component.find('a.clear-bookmark-cancel');
    var closeBtn = component.find('a.closeBtn');
    //events
    clearBookmarkConfirm.click(clearBookmarksConfirmed);
    clearBookmarkCancel.click(clearBookmarksCancelled);
    closeBtn.click(clearBookmarksCancelled);
    closeBtn.blur(circleInPopup);
    clearBookmarkConfirm.keydown(focusToCloseBtn);    

    function initialize(options) {
      this.parentView = options.parentView;
    }

    //ClearBookmarkViewHelper: {},
    render();
    function render(){

      //var data = {};
      //_.extend(data, Constants, SessionObject, this.ClearBookmarkViewHelper); 

      /*var template = _.template($(clearBookmarkTemplate).html());
      this.$el.html(template(data));

      if(this.parentView && this.parentView.parentView) {
        this.parentView.parentView.pauseCarousel();
      }*/

      component.addClass('popup-open');
      component.fadeIn();
    
    }

    function clearBookmarksConfirmed(e) {      		
       		 component.removeClass('popup-open')
      		 component.addClass('hidden').css('display','none');
             $('.offer-list').hide();         
             $('.bookmark-empty-list').show();
             $('.bookmark-clear-container').hide();  
             var uid = "";
             var isConciergeUser = $('#isConciergeUser').val();
             if(isConciergeUser!='' && isConciergeUser!=undefined ){
                uid =$('#cardHolderId').val();
              }else{
                    uid =$('#userId').val();
              }     
             console.log("User Id " + uid);
             var currentPagePath = $( '#currentPagePath' ).val();
             var pathArray = currentPagePath.split('/');
             var issuer = xssFilter(pathArray[4]);
             var product = "infinite";
             var startPoint = "/vpp-backend/v1/" +issuer+ "/" + product +"/bookmark/clearAllBookmarks";
             console.log(startPoint);
        	 var postData = {
                'userId':uid

             };
             $.ajax({
        url: startPoint,
        type: 'POST',
       contentType: "application/json; charset=utf-8",
        data: JSON.stringify(postData),
        success: function(data) {
           console.log("Success");
        }
    });
             // clearBookmarksSuccessCallback(data,self);
             // ajax call to be made

    }
	
	/** xss filtering **/
		function xssFilter(toOutput){
				return toOutput.replace('&','&amp;').
					replace('<','&lt;').
					replace('>','&gt;').
					replace('"','&quot;').
					replace("'",'&#x27').
					replace('/','&#x2F');
		}


    function clearBookmarksCancelled(e) {
      //event.preventDefault();
      component.removeClass('popup-open')
      component.addClass('hidden').css('display','none');
    }

    function clearBookmarksSuccessCallback(data, self) {
      console.log('bookmarks cleared.');

     self.parentView.$el.find('.offer-list-section:not(.bookmark-section)').remove();
     self.parentView.$el.find('.bookmark-clear-container').remove()
     self.parentView.$el.find('.bookmark-section').addClass('empty-bookmark');

      self.close();
    }

    function clearBookmarksFailureCallback(data, self) {
      console.log('bookmarks clear failed.');

      self.close();
    }

    function circleInPopup(e) {
      $('a.clear-bookmark-confirm').focus();
    }
    function focusToCloseBtn(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              $('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }

    function onClose() {
      this.$el.removeClass('popup-open');
      this.$el.fadeOut();

      if(this.parentView && this.parentView.parentView) {
        this.parentView.parentView.pauseCarousel();
      }
    }

  }

  return ClearBookmarkView;
  
});