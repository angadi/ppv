define([
  'jquery',
  'views/home/HomePageView',
  'views/popups/UpdateSecurityQuestionsView',
  'views/popups/UpdatePswView',
  'views/popups/EmailPrefPageView',
  'views/popups/ProfileImgPageView',
  'models/SessionObject',
  'utils/Constants',
  'utils/RoleConstants'
], function($, HomePageView, UpdateSecurityQuestionsView, UpdatePswView, EmailPrefPageView, ProfileImgView, SessionObject, Constants, RoleConstants){
  var ConciergeProfilePageView = function() {
	  var currentPagePath = $('#currentPagePath').val();
      var datRequest = $.ajax( {
      	url: '/bin/profileOverlayHandlerPremium',
			data : {currentPagePath : currentPagePath ,
			popup : 'concierge_profile' },
          dataType: 'html'
      } );
        datRequest.done( function( data ) {
            $( "#wrapper #popup-section" ).html(data);
            ConciergeProfilePageViewRender();
        } );
  };
  var ConciergeProfilePageViewRender = function(){
    //element
    var component = $('#wrapper #popup-section');
    var childComponent = component.find('.update-security-questions-container');
    //variables
    var closeProfile = component.find('a.closeBtn.close-profile');
    var updatePswBtn = component.find('a.update-psw');
    var updateSecurityQuestionsBtn = component.find('a.update-security-questions');
    var updateProfileImage = component.find('a.update-profile-img');
    var closeBtn = component.find('a.closeBtn');
    var pageHeading = component.find('h1.page-heading');
    var firstName = component.find('#user-firstName');
    var lastName = component.find('#user-lastName');
    var userEmail = component.find('#user-email');
    var secQuestIds = component.find('#secQuestIds');
	var emailAddr = component.find('#emailAddr');
    var parentFun = {
            'closeSubview': closeSubview
        };
    //events
    closeProfile.click(closePopup);
    closeProfile.keydown(closeBtnKeydown);
    updatePswBtn.click(updatePsw);
    updateSecurityQuestionsBtn.click(updateSecurityQuestions);
    updateProfileImage.click(updateProfileImg);
    closeBtn.blur(circleInPopup);
    pageHeading.keydown(focusToCloseBtn);
    render();


    function circleInPopup(e) {
      pageHeading.focus();
    }

    function focusToCloseBtn(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              closeBtn.focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }

    function render(){
		getUserInfoById();
      HomePageView.pauseCarousel();
      component.addClass('popup-open');
      component.removeClass('hidden');
      component.fadeIn();
      pageHeading.focus();
      $(window).on("resize", updateCSS);
      /*var that = this;

      this.catName = options.catName;

      var userModel = new UserModel();

      userModel.fetch({
          cache: false,
          success: function(userModel) {
            var data = {
              user: userModel,
              maskedUserEmail: that.getMaskedEmail(userModel.get('emailAddress'))
            };

            _.extend(data, options, SessionObject, Constants, RoleConstants, that.ProfilePageViewHelper);

            var template = _.template($(profilePageTemplate).html());
            that.$el.html(template(data));

            that.updateCSS();

            if(that.parentView) {
              that.parentView.pauseCarousel();
            }

            that.$el.addClass('popup-open');
            that.$el.fadeIn();

            that.$('h1.page-heading').focus();

          }
      });*/
    }


function getUserInfoById() {
	 
	var pathname = $('#currentPagePath').val();
        var hashContent = pathname.split('/');
        var issuerName = hashContent[4];
        var uid = $('#userId').val();      
        var product = "infinite";
    var startPoint = "/vpp-backend/v1/" +issuerName+ "/" + product +"/users/user/"+uid;
     $.ajax({
         url: startPoint,
         type: "GET",
		 async:false,
         data: {
             userId: uid
         },
         success: function(data) {
			  
			 //data = $.parseJSON(data);
            if(data.status!=undefined && data.status.statusCode === '200' ){
             var userInfo=data.response;

                firstName.html(userInfo.firstName);
                lastName.html(userInfo.lastName);
                userEmail.html(getMaskedEmail(userInfo.email));
                secQuestIds.val(userInfo.securityQuestions[0].questionId+ ','+ userInfo.securityQuestions[1].questionId);
                emailAddr.val(userInfo.email);
             }
		 }

     });
	 
}
function getMaskedEmail(email) {
	var toRet = '';
	if (email) {
		var arry = email.split('@');
		if (arry.length === 2) {
			toRet = getMaskCharacters(arry[0].length) + '@'
					+ arry[1];
		}
	}
	return toRet;
}
function getCookie(cname) {
       var name = cname + "=";
       var ca = document.cookie.split(';');
       for (var i = 0; i < ca.length; i++) {
           var c = ca[i];
           while (c.charAt(0) == ' ') {
               c = c.substring(1);
           }
           if (c.indexOf(name) == 0) {
               return c.substring(name.length, c.length);
           }
       }
       return "";
}

    function getMaskedEmail(email) {
      var toRet = '';
      if(email) {
        var arry = email.split('@');
        if(arry.length === 2) {
          toRet = SessionObject.getMaskCharacters() + '@' + arry[1];
        }
      }
      return toRet;
    }

    function updateProfileImg(e) {
        e.preventDefault();
        ProfileImgView(parentFun);
    }

    // updateEmailPref: function(e) {
    //   e.preventDefault();

    //   this.childView = new EmailPrefPageView({parentView: this});
    //   this.childView.render({catName: this.catName});
    // },

    function updatePsw(e) {
      e.preventDefault();
      UpdatePswView( parentFun );
    }

    function updateSecurityQuestions(e) {
      e.preventDefault();
      UpdateSecurityQuestionsView( parentFun );
    }

    function closeSubview(focusItem) {
      childComponent.html('');
      childComponent.removeClass();
      childComponent.addClass('popup update-security-questions-container');
      component.removeClass('scrollable');
      component.addClass('popup-open');
      component.find('.popup.profile-container').fadeTo('400', 1, function() {
        updateCSS();
        if(focusItem) {
          component.find('.'+focusItem).focus();
        }
      });
    }

    function updateCSS(event) {

      var windowWidth = $(window).width();
      var windowHeight = $(window).height();

      // var windowWidth = $(window).width();
      var windowHeight = $(window).height();

      // if(windowWidth < 768) { //mobile
        $('html,body').addClass('profile-opened');
        $('body').height(windowHeight);
        component.height(windowHeight);
      // }
      // else {
      //   $('html,body').removeClass('profile-opened');
      //   $('body').css('height', '100%');
      //   self.$el.css('height', '100%');
      // }

      if(windowHeight < $('.profile-container').height()) {
        component.addClass('scrollable');
      }
      else {
        component.removeClass('scrollable');
      }
    }

    function closePopup() {
      component.html('');
      component.removeClass('popup-open scrollable');
      component.addClass('hidden');
      component.fadeOut();
      HomePageView.resumeCarousel();
      $(window).off("resize", updateCSS);
      $('html,body').removeClass('profile-opened');
      $('body').css('height', '100%');
      $('.navbar-customize .profile').focus();
      window.location.hash = '#';
    }

    function closeBtnKeydown(e) {
      if(e.keyCode === 13) {
        closePopup(e);
      }
    }
  };

  return ConciergeProfilePageView;

});
