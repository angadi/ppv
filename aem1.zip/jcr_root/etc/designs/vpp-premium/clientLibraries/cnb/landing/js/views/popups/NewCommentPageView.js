define( [
    'jquery',
    'models/SessionObject',
    'utils/Constants'
], function( $, SessionObject, Constants ) {

    var NewCommentPageView = function(parentView) {
        $('#popup-section .update-security-questions-container').html(Constants.newComment);

        // element
        var component = $('#popup-section .update-security-questions-container');
        var parentComponent = $( '#popup-section');
        var historyComment = parentComponent.find('.cardholder-history-container');
        var popupClose = component.find('a.closeBtn.close-popup');
        var cancel = component.find('a.cancel');
        var textArea = component.find('textarea');
        var commentSubmit = component.find('a.submit-comment');
        var pageHeading = component.find('h1.page-heading');
        var globalValues = {};
        var errorLabel;

        // events
        popupClose.click(backToHistoryLog);
        cancel.click(backToHistoryLog);
        textArea.keyup(updateBlueBtn);
        commentSubmit.click(submitComment);

        render();
        // functions
        function render( options ) {
            historyComment.hide();
            component.fadeTo( '400', 1, function() {
                pageHeading.focus();
            } );
        }

        function backToHistoryLog( e ) {
            e.preventDefault();
            parentView.closeSubview( 'new-comment' );
        }

        function updateBlueBtn() {
            globalValues.comment = textArea.val();

            if ( globalValues.comment ) {
                commentSubmit.removeClass( 'grey-out' );
            } else {
                commentSubmit.addClass( 'grey-out' );
            }

        }

        function submitComment( e ) {
            e.preventDefault();
            errorLabel = component.find('label.error');
            errorLabel.remove();
            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }
            var postData = {
                'comment': $.trim( escape( globalValues.comment ) ),
                //'csrfToken': window.csrfToken
            };
            postComment();
            //successCallback();

        }

        function postComment() {
        	var cardHolderUid = $('#cardId').val();            
        	var conciergeUserId=$('#userId').val()
            var postDataCon = {
                    'cardHolderId' : cardHolderUid ,
                    'conciergeUserId': conciergeUserId,
                    'commentText': $($.parseHTML($('#comment').val())).text() ,
                };

             
				var path = "/vpp-backend/v1/concierge/addConciergeComment";
				
                $.ajax({
                    type: "POST",
					url: path, 
					dataType: "json",
					async:false,
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify(postDataCon),
					success: function(result){
						if(result.status!=undefined && result.status.statusCode === '200'){
							successCallback(result);
						}else{
							failureCallback(result);
						} 
					}
                });
            
            
        }

        function successCallback( data ) {
            parentView.closeSubview( 'new-comment' );
        }

        function failureCallback( data ) {
            console.log( 'post comment failed' );
        }
    };

    return NewCommentPageView;

} );