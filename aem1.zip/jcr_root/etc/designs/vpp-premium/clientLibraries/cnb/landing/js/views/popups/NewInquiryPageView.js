define([
    'jquery',
    'views/home/HomePageView',
    'utils/Constants',
    'jquery.scrollbar'
], function($, HomePageView, Constants) {

    var NewInquiryPageView = function() {
        //element
        var component = $('#v-new-inquiry');
        //variables
        var closeProfile = component.find('a.closeBtn.close-profile');
        var cardTxtField1 = component.find('#cardTxtField1');
        var cancelBtn = component.find('a.cancel');
        var cardNumberInput = component.find('.card-number-section input');
        var cardNumberSubmit = component.find('.card-num-submit');
        //var parentCarousel = $('.hero-container .carousel');
        //events
        closeProfile.on('click', closePopup);
        cancelBtn.on('click', closePopup);
        cardNumberInput.on('keyup', panNumberTypeHandler);
        cardNumberInput.on('change', panNumberTypeHandler);
        cardNumberSubmit.on('click', cardNumberSubmitted);
        $('a#newInquiry').on('click', clearErrorData);
        $(window).on('hashchange', clearErrorData);
        render();
        function render() {
           
            $('#carousel-generic').carousel('pause');
            component.addClass('popup-open');
            component.removeClass('hidden');
            component.fadeIn();
            
            var path = '/vpp-backend/v1/concierge/getBulletinMessages';

						$.ajax({
							type : "GET",
							url : path,
							async : false,
							success : function(result) {
                                if(result.status!=undefined && result.status.statusCode === '200'){
									renderMessages(result.response);
                                }
							},
							error : function(result) {

							}
						});
             cardTxtField1.focus();
        }

		function renderMessages(messages) {
                    var data = '';
                    if (messages.length) {
                        data += '<ul>';
                        $.each(messages, function(i, message) {
                            data += '<li>' + message.messageText + '</li>';
                        });
                        data += '</ul>';
                    } else {
                        data += '<div class="no-message">You have no new messages at this time.</div>';
                    }
                    $('.bulletin-inner-container').html(data);
    
                    component.find( '.scrollable-area' ).mCustomScrollbar( {
                        theme: 'gray-scrollbar'
                    } );

                    }

        function getCardNumber() {
            var panNumber = '';
            $('.card-number-section input').each(function() {
                panNumber += $(this).val();
            });
            return panNumber;
        }

        function panNumberTypeHandler(e) {
            if (e.keyCode === 9 || event.keyCode == 16) { //if it's tab key
                return;
            }
            
            var $currentElement = $(e.currentTarget);
            if ($currentElement.val().length == $currentElement.prop("maxlength")) {
                $currentElement.parent().next().find("input").focus();
            }
            $('#cardNumberHdn').val(getCardNumber());
        }

        function cardNumberSubmitted(e) {
            e.preventDefault();

            $('label.error').html('');
            $('.form-control').removeClass('error');

            var missingFields = $('.form-control.required:blank');
            if (missingFields.length > 0) {
                $('.form-control.required:blank').addClass('error');
                $('label.error').html(Constants.errorMsg.required);
            } else {
                var isNumber = true;
                $('.card-number-section input').each(function() {
                    if (/^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test($(this).val())) {} else {
                        isNumber = false;
                    }
                });
                if (isNumber) {
                    console.log(getCardNumber());
                    conciergeCardNumberSubmitted();
                    } else {
                    $('label.error').html(Constants.errorMsg.conciergeCardNumberInvalid);
                }
            }
        }

        function conciergeCardNumberSubmitted() {
						//Code to get the userId
						var path = '/vpp-backend/v1/concierge/setCreditCardNumber';
						var uId = $('#isConciergeUser').val();
						//var isConciergeUser = $('#isConciergeUser').val();

                        var postdata = {
							'conciergeUserId' : uId,
							'pan' : getCardNumber()
						};
						$.ajax({
							type : "POST",
							url : path,
                            cache : false,
							dataType : "json",
							async : false,
							contentType : "application/json; charset=utf-8",
							data : JSON.stringify(postdata),
							success : function(result) {
								console.log("success--" + result);

								if(result.status!=undefined && result.status.statusCode === '200' ){
								conciergeCardNumberRedirect(result);
                                }else{
                                setConcgCreditNumberFailureCallback(result);
                               }

							},
							error : function(result) {
								console.log("Failure");
								setConcgCreditNumberFailureCallback(result);
							}
						});
						
						}
						///
					function conciergeCardNumberRedirect( data ) {
						var path = '/bin/conciergeRedirection';
						var pagePath = $('#currentPagePath').val();
						var fname="";
						if(data.response.firstName!=undefined){
                            fname=data.response.firstName;
                        }
						$.ajax({
							type : "GET",
							url : path,
                            cache:true,
							async : false,
							data : {currentPagePath : pagePath,
									cardNumber : getCardNumber(),
									cardId : data.response.cardHolderId,
                                    userId : data.response.userId,
                                    firstName : fname,
                                    issuer : data.response.issuer

                                   },
							success : function(result) {
								console.log("success--" + result);

								setConcgCreditNumberSuccessCallback(result);

							},
							error : function(result) {
								console.log("Failure");
								setConcgCreditNumberFailureCallback(result);
							}
						});

					}

					function setConcgCreditNumberSuccessCallback(data) {
						console.log("Data --" + data);
						window.location.href = data;
					}


        function setConcgCreditNumberFailureCallback(data, self) {
			$('.form-control.required').addClass('error');
			$('label.error').html(Constants.errorMsg.conciergeCardNumberInvalid);
            }

        function closePopup() {
            HomePageView.resumeCarousel();
            component.removeClass('popup-open');
            component.addClass('hidden');
            component.fadeOut();
        }

        function onClose() {
            
            $('.navbar-customize .new-inquiry').focus();
        }
        function clearErrorData() {
			$('label.error').empty();
            $('.form-control.required').removeClass('error');
            $('#cardTxtField1').val('');
            $('#cardTxtField2').val('');
            $('#cardTxtField3').val('');
            $('#cardTxtField4').val('');
        }
    };

    return NewInquiryPageView;
});