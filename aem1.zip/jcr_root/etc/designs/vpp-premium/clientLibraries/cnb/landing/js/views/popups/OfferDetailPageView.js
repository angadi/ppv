define( [
	'jquery',
	'jquery.lazyload',
	'jquery.scrollbar'
], function( $ ) {
	var OfferDetailPageView = function( offerData ) {
		var links = $( "[tabindex='0']" );
		links.attr( 'tabindex', '-1' );
		var currentPagePath = $( '#currentPagePath' ).val();
		var offerCategory = offerData.category;
		var offerID = offerData.id;
		console.log( "cat", offerCategory );
		console.log( "ID", offerID );
		var datRequest = $.ajax( {
			url: '/bin/OfferPopupPremium',
			data: {
				currentPagePath: currentPagePath,
				id: offerID,
				category: offerCategory
			},
			dataType: 'html'
		} );
		datRequest.done( function( data ) {
			$( '#v-offer-details' ).html( data );
			OfferDetailPageViewRender();

		} );

		/** xss filtering **/
		function xssFilter( toOutput ) {
			return toOutput.replace( '&', '&amp;' ).
			replace( '<', '&lt;' ).
			replace( '>', '&gt;' ).
			replace( '"', '&quot;' ).
			replace( "'", '&#x27' ).
			replace( '/', '&#x2F' );
		}

		function OfferDetailPageViewRender() {
			// element
			var component = $( '#v-offer-details' );
			// variables
			var closeBtn = component.find( 'a.closeBtn' );
			var bookmarkBtn = component.find( 'a.bookmark-btn' );
			var redeemContentLink = component.find( '.redeem-content a' );
			var outBoundWarn = component.find( '.out-bound-warn' );
			var closeOutBound = component.find( '.close-outbound' );
			var cancelOutBound = component.find( '.cancel-out-bound' );
			var continueOutBound = component.find( '.continue-out-boud' );
			var offerDetailNameHeader = component.find( 'h1.offerDetailName' );
			var tabContainerList = component.find( '#tabContainer ul.nav li' );
			var tabContainerLink = component.find( '#tabContainer ul li a' );
			var offerDetailContainer = component.find( '.popup.offer-detail-container' );
			var offerListID = $( '.list-section' ).find( '.offer-list' ).attr( 'offer-id' );
			var bokmarkChanged = false;

			var globalvars = {};
			// events
			closeBtn.click( closePopup );
			closeBtn.blur( circleInPopup );
			bookmarkBtn.click( bookmarkClicked );
			redeemContentLink.click( phoneCallClicked );
			outBoundWarn.click( outboundWarning );
			closeOutBound.click( backToDetail );
			cancelOutBound.click( backToDetail );
			continueOutBound.click( goToRedeem );
			closeBtn.blur( circleInPopup );
			offerDetailNameHeader.keydown( focusToCloseBtn );
			tabContainerList.click( toggleShowHide );
			tabContainerLink.keyup( tabListTabbed );
			render();
			// functions
			function initialize( options ) {
				if ( options && options.parentView ) {
					this.parentView = options.parentView;
				}
				$( window ).on( "resize", { self: this }, this.updateCSS );
			}
		checkBookmarked( offerID, offerCategory, currentPagePath );

		function checkBookmarked() {
			console.log( "Offer to be checked --" + offerID + "--" + offerCategory + "--" + currentPagePath );
            var hashContent = currentPagePath.split("/");
			var issuerName = xssFilter( hashContent[ 4 ] );
			var uid = $('#userId').val();
			console.log( uid );
			var product = "infinite";
			var startPoint = "/vpp-backend/v1/" + issuerName + "/" + product + "/bookmark/getAllBookmark";
			$.ajax( {
				url: startPoint,
				type: "GET",
				data: {
					userId: uid
				},
				success: function( data ) {
					bookmarkOffers( data, offerID );
				}

			} );
		}

		function bookmarkOffers( data, offerID ) {
			//console.log("success data--" + data + offerID );
			var offers = $.parseJSON( data );
			var offerList = offers.response.bookmarks;
			for ( i = 0; i < offerList.length; i++ ) {
				//   console.log("Offer Comparison " + offerList[i].offerId + "--"+ offerID);
				if ( offerList[ i ].offerId == offerID ) {
					bookmarkBtn.addClass('bookmarked');
				}
			}
		}
			var HomeListViewHelper = {
				getImageUrl: function( imageList, targetWidth, targetHeight ) {
					var imgSrc = '';
					for ( var i = 0; i < imageList.length; ++i ) {
						var imgItem = imageList[ i ];
						if ( parseInt( imgItem.imageFileWidth, 10 ) === parseInt( targetWidth, 10 ) &&
							parseInt( imgItem.imageFileHeight, 10 ) === parseInt( targetHeight, 10 ) ) {
							imgSrc = imgItem.fileLocation;
							break;
						}
					}
					if ( imgSrc === '' ) {
						imgSrc = Constants.defaultOfferImagePath.detail;
					}
					return imgSrc;
				},
				getMerchant: function( merchantList ) {
					var merchant = {};
					if ( merchantList && merchantList.length > 0 ) {
						for ( var i = 0; i < merchantList.length; ++i ) {
							if ( merchantList[ i ].merchantImages && merchantList[ i ].merchantImages.length > 0 ) {
								var merchantImgs = merchantList[ i ].merchantImages;
								for ( var j = 0; j < merchantImgs.length; ++j ) {
									if ( parseInt( merchantImgs[ j ].imageFileWidth ) == 220 && parseInt( merchantImgs[ j ].imageFileHeight ) == 80 ) {
										merchant.merchantLogoUrl = merchantImgs[ j ].fileLocation;
										merchant.merchantName = merchantImgs[ i ].merchant;
										break;
									}
								}
							}
						}
					}
					return merchant;
				}
			};

			function circleInPopup( e ) {
				$( 'h1.offerDetailName' ).focus();
			}

			function focusToCloseBtn( e ) {
				if ( e.which === 9 ) {
					if ( e.shiftKey === true ) {
						$( 'a.closeBtn' ).focus();
					} else {
						// User is tabbing forward
					}
				}
			}

			function render() {
				//WCAG of tab list
				globalvars.firstTimeFocus = false;
				globalvars.count = 0;
				updateCSS();
				offerDetailNameHeader.focus();
				component.find( 'img.lazy' ).lazyload( {
					threshold: 400
				} );
				component.find( '.scrollable-area' ).mCustomScrollbar( {
					theme: 'gray-scrollbar'
				} );
				$( window ).on( "resize", updateCSS );
				component.addClass( 'popup-open' );
				component.removeClass( 'hidden' );
				component.fadeIn();
				$( 'h1.offerDetailName' ).focus();
			}

			function phoneCallClicked( e ) {
				if ( $( 'html.lte-ie9' ) && $( 'html.lte-ie9' ).length > 0 ) {
					e.preventDefault();
					return;
				}
			}

			function outboundWarning( e ) {
				e.preventDefault();
				updateOutboundingBox();
				component.find( '.offer-detail-container' ).hide();
				component.find( '.outbound-container' ).show();
			}

			function backToDetail( e ) {
				e.preventDefault();
				component.find( '.outbound-container' ).hide();
				component.find( '.offer-detail-container' ).show();
			}

			function goToRedeem( e ) {
				e.preventDefault();
				component.find( '.outbound-container' ).hide();
				component.find( '.offer-detail-container' ).show();
				var url = $( e.currentTarget ).attr( 'href' );
				window.open( url, '_blank' );
				win.focus();
			}

			function bookmarkClicked( e ) {
				var offerType = "";
				e.preventDefault();
				bokmarkChanged = !bokmarkChanged;

				var $bookmark = $( e.currentTarget );
				$bookmark.toggleClass( 'bookmarked' );
				$bookmark.find( '.selected' ).html( '' );

				this.offerIdBookmarkToBeUpdated = $bookmark.attr( 'offerId' );
				this.isGoingToAdd = false;

				//homepage: in case offers have dup in different cat
				var $currentListSection = $bookmark.closest( '.offer-list-section' );
				var $restListSection = component.find( '.offer-list-section' ).not( $currentListSection );
				if ( $restListSection.length > 0 ) {
					var self = this;
					var $dupOffers = $restListSection.find( '.offer-container' ).filter( function() {
						return $( this ).attr( 'offer-id' ) === self.offerIdBookmarkToBeUpdated;
					} );
					$dupOffers.find( '.bookmark-btn' ).toggleClass( 'bookmarked' );
				}

				if ( $bookmark.hasClass( 'bookmarked' ) ) {
					this.isGoingToAdd = true;

					$bookmark.find( '.selected' ).html( 'added.' );
					$bookmark.attr( 'aria-label', 'bookmark added' );
				} else {
					$bookmark.find( '.selected' ).html( 'removed.' );
					$bookmark.attr( 'aria-label', 'bookmark removed' );
				}
				var uid = $('#userId').val();
				console.log( "User Id " + uid );
				var currentPagePath = $( '#currentPagePath' ).val();
				var pathArray = currentPagePath.split( '/' );
				var issuer = xssFilter( pathArray[ 4 ] );
				var product = "infinite";
				var startPoint = "/vpp-backend/v1/" + issuer + "/" + product + "/bookmark/";
				console.log( startPoint );
				if ( this.isGoingToAdd ) { var finalUrl = startPoint + "addBookmark"; } else {
					var finalUrl = startPoint + "deleteBookmark";
				}
				var findAEM = this.offerIdBookmarkToBeUpdated;

				if ( findAEM.startsWith( "A" ) ) {
					offerType = "AEMOFFER";
				} else {
					offerType = "VMORCOFFER";
				}

				console.log( finalUrl + offerType );
				var postData = {
					'userId': uid,
					'offerId': this.offerIdBookmarkToBeUpdated,
					'offerType': "VMORCOFFER"
				};
				$.ajax( {
					url: finalUrl,
					type: 'POST',
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify( postData ),
					success: function( data ) {
						console.log( "Success" );
					}
				} );

				//updateBookmarkStatus(postData, successCallback, failureCallback);
			}

			function successCallback( data, self ) {
				console.log( 'bookmark update succeeded.' );

				//if on bookmark page, need update layout
				if ( SessionObject.curCat === 'bookmarks' && !self.isGoingToAdd ) {
					var $offerToBeRemoved = self.$el.find( '.offer-container' ).filter( function() {
						return $( this ).attr( 'offer-id' ) === self.offerIdBookmarkToBeUpdated;
					} );

					$offerToBeRemoved.fadeOut( 300, function() {
						$( this ).remove();

						if ( self.$el.find( '.offer-list-section:not(.bookmark-section) .offer-container' ).length === 0 ) {

							self.$el.find( '.offer-list-section:not(.bookmark-section)' ).remove();
							self.$el.find( '.bookmark-clear-container' ).remove();
							self.$el.find( '.bookmark-section' ).addClass( 'empty-bookmark' );

						}
					} )
				}
			}

			function failureCallback( data, self ) {
				console.log( 'bookmark update failed.' );
			}

			function closePopup( e ) {
				if ( bokmarkChanged ) {
					location.reload();
				} else {
					component.addClass( 'hidden' );
					component.removeClass( 'popup-open' );
					$( 'html,body' ).removeClass( 'offer-detail-opened offer-detail-opened-overflow' );
					$( 'body' ).css( 'height', '100%' );
				}
			}

			function updateCSS( event ) {
				var popupHeight = offerDetailContainer.height();
				var windowHeight = $( window ).height();
				// console.log(popupHeight + ',windowHeight = ' + windowHeight);
				var centerInWindowTop = '50%';
				var pushToWindowTop = '0px';
				$( 'body' ).height( windowHeight );
				if ( popupHeight < windowHeight ) { //popup okay to be centered in widnow
					$( 'html,body' ).addClass( 'offer-detail-opened' );
					$( 'html,body' ).removeClass( 'offer-detail-opened-overflow' );
					// console.log(self.$el.scrollTop());
					// self.$el.find('.popup.offer-detail-container').css('top',  self.oringalScrollTop + (windowHeight-popupHeight)/2); //TODO
					offerDetailContainer.css( 'top', ( windowHeight - popupHeight ) / 2 );
					component.height( windowHeight );
				} else {
					$( 'html,body' ).addClass( 'offer-detail-opened offer-detail-opened-overflow' );
					offerDetailContainer.css( 'top', 0 );
					component.height( windowHeight );
				}
			}

			function updateOutboundingBox() {
				var popupHeight = parseInt( component.find( '.outbound-container' ).css( 'height' ) );
				var windowHeight = $( window ).height();
				// console.log(popupHeight + ',windowHeight = ' + windowHeight);
				var centerInWindowTop = '50%';
				var pushToWindowTop = '0px';
				// if(!isTabTriggered) {
				// this.oringalScrollTop = $(window).scrollTop();
				// }
				// else {
				// }
				// if(window.app_router.backgroundListView) {}
				// else {
				$( 'body' ).height( windowHeight );
				// }
				if ( popupHeight < windowHeight ) { //popup okay to be centered in widnow
					// $('html,body').removeClass('offer-detail-opened');
					// $('html,body').scrollTop(self.oringalScrollTop);
					$( 'html,body' ).addClass( 'offer-detail-opened' );
					$( 'html,body' ).removeClass( 'offer-detail-opened-overflow' );
					// console.log(self.$el.scrollTop());
					// this.$el.find('.popup.outbound-container').css('top',  this.oringalScrollTop + (windowHeight-popupHeight)/2);
					// this.$el.height(windowHeight+this.oringalScrollTop);
					component.find( '.popup.outbound-container' ).css( 'top', ( windowHeight - popupHeight ) / 2 );
					component.height( windowHeight + self.oringalScrollTop );
				} else {
					$( 'html,body' ).addClass( 'offer-detail-opened offer-detail-opened-overflow' );
					// this.$el.find('.popup.outbound-container').css('top',  this.oringalScrollTop);
					// this.$el.height(windowHeight+this.oringalScrollTop);
					component.find( '.popup.outbound-container' ).css( 'top', 0 );
					component.height( windowHeight );
				}
			}

			function onClose() {
				$( window ).off( "resize", this.updateCSS );
				if ( this.parentView ) {
					this.parentView.resumeCarousel();
				}
				$( 'html,body' ).removeClass( 'offer-detail-opened offer-detail-opened-overflow' );
				$( 'body' ).css( 'height', '100%' );
				this.$el.removeClass( 'popup-open' );
				this.$el.fadeOut();
				$( window ).scrollTop( this.oringalScrollTop );
			}

			function tabListTabbed( e ) {
				e.preventDefault();
				if ( e.keyCode === 9 && $( e.currentTarget ).is( 'a#tab_1' ) && this.firstTimeFocus === false ) {
					this.firstTimeFocus = true;
					$( '#tab_1' ).trigger( 'click' );
				} else if ( e.keyCode === 38 || e.keyCode === 37 ) { //up/left
					if ( $( e.currentTarget ).parent().prev() && $( e.currentTarget ).parent().prev().length > 0 ) {
						$( e.currentTarget ).parent().prev().find( 'a' ).focus();
						$( e.currentTarget ).parent().prev().find( 'a' ).trigger( 'click' );
					}
				} else if ( e.keyCode === 39 || e.keyCode === 40 ) { //down/right
					if ( $( e.currentTarget ).parent().next() && $( e.currentTarget ).parent().next().length > 0 ) {
						$( e.currentTarget ).parent().next().find( 'a' ).focus();
						$( e.currentTarget ).parent().next().find( 'a' ).trigger( 'click' );
					}
				}
			}

			function toggleShowHide( e ) {
				e.preventDefault();
				//toggleTabs( e );
				if ( globalvars.count === 2 ) {
					toggleTabs( e );
				} else if ( globalvars.firstTimeFocus && globalvars.firstToggleTriggeredByFocus &&
					$( e.currentTarget ).find( 'a#tab_1' ) && $( e.currentTarget ).find( 'a#tab_1' ).length > 0 ) {
					globalvars.firstTimeFocus = false;
					globalvars.firstToggleTriggeredByFocus = false;
					if ( $( e.currentTarget ).hasClass( 'expanded' ) ) {
						toggleTabs( e );
					} else {
						return false;
					}
				} else {
					toggleTabs( e );
					globalvars.count++;
					if ( globalvars.firstTimeFocus ) {
						globalvars.firstToggleTriggeredByFocus = true;
					}
				}
			}

			function toggleTabs( e ) {
				e.preventDefault();
				$( '#tabContainer ul li[role="presentation"]' ).removeClass( 'active' );
				$( '#offerBottomTabs div.tab-pane' ).removeClass( 'active' );
				$( '#offerBottomTabs div.tab-pane' ).attr( 'aria-hidden', 'true' );
				$( '#tabContainer ul li[role="presentation"]' ).find( 'a' ).attr( 'aria-selected', 'false' );
				$( '#tabContainer ul li[role="presentation"]' ).find( 'a' ).attr( 'tabindex', '-1' );
				$( e.currentTarget ).toggleClass( 'expanded' );
				if ( $( e.currentTarget ).hasClass( 'expanded' ) ) {
					$( '.offer-detail-container' ).addClass( 'expanded' );
					if ( $( e.currentTarget ).find( 'a[href="#toc"]' ) && $( e.currentTarget ).find( 'a[href="#toc"]' ).length > 0 ) {
						$( '#tabContainer ul li[role="presentation"]' ).first().addClass( 'active' );
						$( '#offerBottomTabs div.tab-pane' ).first().addClass( 'active' );
						$( '#toc' ).attr( 'aria-hidden', 'false' );
						$( '#tab_1' ).attr( 'tabindex', '0' );
						$( '#tab_1' ).attr( 'aria-selected', 'true' );
						$( '#toc' ).slideDown( function() {
							updateCSS();
						} );
						$( '#faqs' ).hide();
						$( '#tabContainer ul.nav li' ).find( 'a[href="#faqs"]' ).parent().removeClass( 'expanded' );
					} else {
						$( '#tabContainer ul li[role="presentation"]' ).last().addClass( 'active' );
						$( '#offerBottomTabs div.tab-pane' ).last().addClass( 'active' );
						$( '#faqs' ).attr( 'aria-hidden', 'false' );
						$( '#tab_2' ).attr( 'tabindex', '0' );
						$( '#tab_2' ).attr( 'aria-selected', 'true' );
						$( '#toc' ).hide();
						$( '#faqs' ).slideDown( function() {
							updateCSS();
						} );
						$( '#tabContainer ul.nav li' ).find( 'a[href="#toc"]' ).parent().removeClass( 'expanded' );
					}
				} else {
					$( '.offer-detail-container' ).removeClass( 'expanded' );
					if ( $( e.currentTarget ).find( 'a[href="#toc"]' ) && $( e.currentTarget ).find( 'a[href="#toc"]' ).length > 0 ) {
						$( '#tabContainer ul li[role="presentation"]' ).first().addClass( 'active' );
						$( '#toc' ).slideUp( function() {
							updateCSS();
						} );
						$( '#faqs' ).hide();
					} else {
						$( '#tabContainer ul li[role="presentation"]' ).last().addClass( 'active' );
						$( '#toc' ).hide();
						$( '#faqs' ).slideUp( function() {
							updateCSS();
						} );
					}
				}
			}
		}
	};
	return OfferDetailPageView;
} );