define(
		[ 'jquery', 'views/popups/EmailPrefPageView',
				'views/popups/UpdatePswView',
				'views/popups/UpdateSecurityQuestionsView', 'models/UserModel',
				'models/SessionObject', 'utils/Constants',
				'utils/RoleConstants' ],
		function($, EmailPrefPageView, UpdatePswView,
				UpdateSecurityQuestionsView, UserModel, SessionObject,
				Constants, RoleConstants) {
			var ProfilePageView = function() {
				var currentPagePath = $('#currentPagePath').val();
				var datRequest = $.ajax({
					url : '/bin/profileOverlayHandlerPremium',
					data : {
						currentPagePath : currentPagePath,
						popup : 'profile'
					},
					dataType : 'html'
				});
				datRequest.done(function(data) {
					$('#wrapper #popup-section').html(data);
					ProfilePageViewReder();
				});
			};
			var ProfilePageViewReder = function() {
				// element
				var component = $('#wrapper #popup-section');
				var childComponent = component
						.find('.update-security-questions-container');

				// variables
				var profileCloseBtn = component
						.find('a.closeBtn.close-profile');
				var updateEmailPrefBtn = component.find('a.update-email-pref');
				var updatePswBtn = component.find('a.update-psw');
				var updateSecurityQuestionsBtn = component
						.find('a.update-security-questions');
				var closeBtn = component.find('a.closeBtn');
				var pageHeading = component.find('h1.page-heading');
				var firstName = component.find('.user-first-name');
				var lastName = component.find('.user-last-name');
				var emailId = component.find('.user-email-id');
				var postalCode = component.find('.user-postal-code');
				var userCountry = component.find('.user-country');
				var secQuestIds = component.find('#secQuestIds');
				var emailAddr = component.find('#emailAddr');
                var globalValues = {};
				var parentFun = {
					'closeSubview' : closeSubview
				};

				//events
				profileCloseBtn.click(closePopup);
				profileCloseBtn.keydown(closeBtnKeydown);
				updateEmailPrefBtn.click(updateEmailPref);
				updatePswBtn.click(updatePsw);
				updateSecurityQuestionsBtn.click(updateSecurityQuestions);
				closeBtn.blur(circleInPopup);
				updateEmailPrefBtn.keydown(focusToCloseBtn);
				pageHeading.keydown(focusToCloseBtn);

				render();
				// functions

				function render(options) {
					getUserInfoById();
					updateCSS();
					/*if ( that.parentView ) {
						that.parentView.pauseCarousel();
					}*/
					component.addClass('popup-open');
					component.fadeIn();
					pageHeading.focus();
					$(window).on("resize", updateCSS);
					$('html,body').removeClass(
							'offer-detail-opened offer-detail-opened-overflow');
					$('body').css('height', '100%');
				}

				function circleInPopup(e) {
					pageHeading.focus();
				}

				function focusToCloseBtn(e) {
					if (e.which === 9) {
						if (e.shiftKey === true) {
							closeBtn.focus();
						} else {
							// User is tabbing forward
						}
					}
				}

				function getUserInfoById() {

					var pathname = $('#currentPagePath').val();
					var hashContent = pathname.split('/');
					var issuerName = hashContent[4];
					var uid = $('#userId').val();
					var product = "infinite";
					var startPoint = "/vpp-backend/v1/" + issuerName + "/"
							+ product + "/users/user/" + uid;
					$
							.ajax({
								url : startPoint,
								type : "GET",
								async : false,
								data : {
									userId : uid
								},
								success : function(data) {

									//data = $.parseJSON(data);
									if (data.status != undefined
											&& data.status.statusCode === '200') {
										var userInfo = data.response;
                                        globalValues.userInfo = userInfo;

										firstName.html(userInfo.firstName);
										lastName.html(userInfo.lastName);
										emailId
												.html(getMaskedEmail(userInfo.email));
										postalCode.html(userInfo.city);
										userCountry.html(userInfo.country);

										secQuestIds
												.val(userInfo.securityQuestions[0].questionId
														+ ','
														+ userInfo.securityQuestions[1].questionId);
										emailAddr.val(userInfo.email);
									}
								}

							});

				}

				function getMaskedEmail(email) {
					var toRet = '';
					if (email) {
						var arry = email.split('@');
						if (arry.length === 2) {
							toRet = getMaskCharacters(arry[0].length) + '@'
									+ arry[1];
						}
					}
					return toRet;
				}
				function getMaskCharacters(length) {
					var maskLength = 2;
					var maskString = '';
					if (length) {
						maskLength = length;
					}
					for (var i = 0; i < maskLength; i++) {
						maskString += '*';
					}
					return maskString;
				}

				function updateEmailPref(e) {
					e.preventDefault();
                    console.log(globalValues.userInfo);
					EmailPrefPageView(parentFun, globalValues.userInfo);
					//this.childView = new EmailPrefPageView( { parentView: this } );
					//this.childView.render( { catName: this.catName } );
				}

				function updatePsw(e) {
					e.preventDefault();
					UpdatePswView(parentFun);
				}

				function updateSecurityQuestions(e) {
					e.preventDefault();
					UpdateSecurityQuestionsView(parentFun);
				}

				function closeSubview(focusItem) {
					ProfilePageView();
				}

				function updateCSS(event) {
					var windowWidth = $(window).width();
					var windowHeight = $(window).height();
					var ProfileContainerHeight = component.find(
							'.profile-container').height();
					$('html,body').addClass('profile-opened');
					$('body').height(windowHeight);
					component.height(windowHeight);
					if (windowHeight < ProfileContainerHeight) {
						component.addClass('scrollable');
					} else {
						component.removeClass('scrollable');
					}
				}

				function closePopup(e) {
					$(window).off("resize", updateCSS);
					$('html,body').removeClass('profile-opened');
					$('body').css('height', '100%');
					component.removeClass('popup-open scrollable');
					component.fadeOut();
					window.location.hash = '#';
					/*if ( this.parentView ) {
						this.parentView.resumeCarousel();
					}
					if ( this.childView ) {
						this.childView.close();
					}*/
                    				setTimeout(function() { $('.navbar-customize .profile').focus(); }, 1000);
				}

				function closeBtnKeydown(e) {
					if (e.keyCode === 13) {
						closePopup(e);
					}
				}
				return {
					'closeSubview' : closeSubview
				};
			};
			return ProfilePageView;
		});