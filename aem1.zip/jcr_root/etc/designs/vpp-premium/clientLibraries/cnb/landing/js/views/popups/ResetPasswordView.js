define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/resetPasswordTemplate.html',
  'validations/ChangePasswordValidation',
  'models/SessionObject',
  'utils/Constants',
  'utils/RoleConstants',
  'jquery.placeholder',
  'select2'
], function($, _, Backbone, resetPasswordTemplate, ChangePasswordValidation, SessionObject, Constants, RoleConstants){

  var ResetPasswordView = Backbone.View.extend({
    el: '#wrapper .popup-section',

    events: {
      'click a.update-psw-btn' : 'updatePsw',

      'focus #newPassword': 'tooltipFocused',
      'blur #newPassword': 'tooltipFocusedOut',

      'keyup .form-control.required': 'updateBlueBtn',

      'click a.security-questions-confirmation-close' : 'refreshPage'
    },

    initialize: function(options) {
      if(options && options.parentView) {
        this.parentView = options.parentView;
      }
    },

    render: function(options){

      var that = this;   

      var data = {};

      _.extend(data, options, SessionObject, Constants, RoleConstants); 

      var template = _.template($(resetPasswordTemplate).html());
      this.$el.html(template(data)); 

      this.$('form').validate(ChangePasswordValidation.settings);

      this.$('[data-toggle="popover"]').popover({html: true}); 
      this.$('input, textarea').placeholder();

      this.$el.addClass('popup-open');
      this.$('.popup').show();
      this.$el.fadeIn();

      this.$('h1.page-heading').focus();
    },

    updateBlueBtn: function(e) {
      e.preventDefault();

      // Avoid revalidate the field when pressing one of the following keys
      // Shift       => 16
      // Ctrl        => 17
      // Alt         => 18
      // Caps lock   => 20
      // End         => 35
      // Home        => 36
      // Left arrow  => 37
      // Up arrow    => 38
      // Right arrow => 39
      // Down arrow  => 40
      // Insert      => 45
      // Num lock    => 144
      // AltGr key   => 225
      var excludedKeys = [
        16, 17, 18, 20, 35, 36, 37,
        38, 39, 40, 45, 144, 225
      ];

      if ( e.which === 9 && $(e.currentTarget).val() === "" || $.inArray( e.keyCode, excludedKeys ) !== -1 ) {
        return;
      }

      var $missingFields = this.$('form').find('.form-control.required:blank');
      if($missingFields.length > 0) {
        this.$('.update-psw-btn').addClass('grey-out');
      }
      else {
        this.$('.update-psw-btn').removeClass('grey-out');
      }
    },

    updatePsw: function(e) {
      e.preventDefault();    

      this.$('label.error').remove();         

      if($(e.currentTarget).hasClass('grey-out')) {
        return false;
      }

      if(this.$('form').valid()) {

        var postData = {
          oldPassword: this.$('#oldPassword').val(),
          newPassword: this.$('#newPassword').val(),
          csrfToken: window.csrfToken
        };

        SessionObject.updatePsw(postData, this.successCallback, this.failureCallback, this);
      }
      
    },

    successCallback: function(data, self) {
      // console.log('update psw succeeded.');

      self.$('.popup-container').hide();
      self.$el.find('.update-security-questions-container').removeClass('confirmation-open').addClass('confirmation-open-open');
      self.$('.confirmation-container').fadeTo('400', 1, function() {
        self.$el.find('.security-questions-confirmation-close.blue-button').focus();
      });
    },

    failureCallback: function(data, self) {
      console.log('update psw failed.');

      self.$('.form-group:first').before('<label id="fields-error" class="error" for="fields" style="display:block;" aria-live="polite">' + data.message + '</label>');

    },

    refreshPage: function(e) {
      e.preventDefault();

      window.location.href = 'concierge.jsp';
    },


    onClose: function() { 
      if(this.childView) {
        this.childView.close();
      }
    }
  });  

  return ResetPasswordView;
  
});
