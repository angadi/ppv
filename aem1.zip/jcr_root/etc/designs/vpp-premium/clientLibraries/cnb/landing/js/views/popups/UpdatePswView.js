define( [
    'jquery',
    'models/SessionObject',
    'utils/Constants',
    'utils/RoleConstants',
    'validations/ChangePasswordValidation',
    'jquery.placeholder',
    'select2'
], function( $, SessionObject, Constants, RoleConstants, ChangePasswordValidation ) {

    var UpdatePswView = function( parentFun ) {
        var currentPagePath = $('#currentPagePath').val();
		var datRequest = $.ajax( {
            url: '/bin/profileOverlayHandlerPremium',
			data : {currentPagePath : currentPagePath ,
			popup : 'profile-password' },
            dataType: 'html'
        } );
        datRequest.done( function( data ) {
            $( '#wrapper #popup-section .update-security-questions-container' ).html( data );
            UpdatePswViewRender( parentFun );
        } );
    };
    var UpdatePswViewRender = function( parentFun ) {
        // element
        var parentComponent = $( '#wrapper #popup-section' );
        var profileComponent = parentComponent.find( '.profile-container' );
        var component = $( '#wrapper .popup-section .update-security-questions-container' );

        // variables
        var form = component.find( 'form' );
        var popupCloseBtn = component.find( 'a.closeBtn.close-popup' );
        var backToProfileBtn = component.find( 'a.back-to-profile' );
        var updatePswBtn = component.find( 'a.update-psw-btn' );
        var newPassword = component.find( '#newPassword' );
        var oldPassword = component.find( '#oldPassword' );
        var securityQuestionConfirmationClose = component.find( 'a.security-questions-confirmation-close' );
        var formControlRequired = component.find( '.form-control.required' );
        var securityQuestionConfirmationCloseBtn = component.find( 'a.security-questions-confirmation-close.closeBtn' );
        var securityQuestionConfirmationCloseBlueBtn = component.find( 'a.security-questions-confirmation-close.blue-button' );
        var closeBtn = component.find( 'a.closeBtn' );
        var pageHeading = component.find( 'h1.page-heading' );
        var errorLabel;

        // functions
        render();

        //events
        popupCloseBtn.click( backToProfile );
        popupCloseBtn.keydown( closeBtnKeydown );
        backToProfileBtn.click( backToProfile );
        updatePswBtn.click( updatePsw );
        newPassword.focus( tooltipFocused );
        newPassword.blur( tooltipFocusedOut );
        securityQuestionConfirmationClose.click( backToProfile );
        formControlRequired.keyup( updateBlueBtn );
        securityQuestionConfirmationCloseBtn.blur( circleInErrorBackToBlueBtn );
        securityQuestionConfirmationCloseBlueBtn.blur( circleInErrorBackToCloseBtn );
        closeBtn.blur( circleInPopup );
        backToProfileBtn.keydown( focusToCloseBtn );
        pageHeading.keydown( focusToCloseBtn );


        function render( options ) {
            $( window ).on( "resize", updateCSSInSecurityQ );
            component.addClass( 'update-password-container' );
            //hide previous screen
            profileComponent.hide();
            form.validate( ChangePasswordValidation.settings );
            $( '[data-toggle="popover"]' ).popover( { html: true } );
            $( 'input, textarea' ).placeholder();
            updateCSSInSecurityQ();
            component.fadeTo( '400', 1, function() {
                pageHeading.focus();
            } );

        }

        function circleInPopup( e ) {
            pageHeading.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function circleInErrorBackToBlueBtn( e ) {
            securityQuestionConfirmationCloseBlueBtn.focus();
        }

        function circleInErrorBackToCloseBtn( e ) {
            securityQuestionConfirmationCloseBtn.focus();
        }

        function backToProfile( e ) {
            e.preventDefault();

            parentFun.closeSubview( 'update-psw' );
        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                backToProfile( e );
            }
        }

        function updateBlueBtn( e ) {
            e.preventDefault();

            // Avoid revalidate the field when pressing one of the following keys
            // Shift       => 16
            // Ctrl        => 17
            // Alt         => 18
            // Caps lock   => 20
            // End         => 35
            // Home        => 36
            // Left arrow  => 37
            // Up arrow    => 38
            // Right arrow => 39
            // Down arrow  => 40
            // Insert      => 45
            // Num lock    => 144
            // AltGr key   => 225
            var excludedKeys = [
                16, 17, 18, 20, 35, 36, 37,
                38, 39, 40, 45, 144, 225
            ];

            if ( e.which === 9 && $( e.currentTarget ).val() === "" || $.inArray( e.keyCode, excludedKeys ) !== -1 ) {
                return;
            }

            var $missingFields = form.find( '.form-control.required:blank' );
            if ( $missingFields.length > 0 ) {
                updatePswBtn.addClass( 'grey-out' );
            } else {
                updatePswBtn.removeClass( 'grey-out' );
            }
        }

        function updatePsw( e ) {
            errorLabel = component.find( 'label.error' );
            e.preventDefault();
            errorLabel.remove();
            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }

            if ( form.valid() ) {

                var postData = {
                    'userId' : $('#userId').val() ,
                    'oldPassword': oldPassword.val(),
                    'newPassword': newPassword.val()
                };


                var issuerName = $("#issuerName").val();
				var path = "/vpp-backend/v1/" + issuerName + "/infinite/users/changePassword";
				
                $.ajax({
                    type: "POST",
					url: path, 
					dataType: "json",
					async:false,
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify(postData),
					success: function(result){
						if(result.status!=undefined && result.status.statusCode === '200'){
							successCallback(result);
						}else{
							failureCallback(result);
						} 
					}
                });
                //SessionObject.updatePsw( postData, this.successCallback, this.failureCallback, this );
            }

        }

        function successCallback( data ) {
            // console.log('update psw succeeded.');

            component.find( '.popup-container' ).hide();
            $(component).removeClass( 'confirmation-open' ).addClass( 'confirmation-open-open' );
            $( '.confirmation-container' ).fadeTo( '400', 1, function() {
                $(component).find( '.security-questions-confirmation-close.blue-button' ).focus();
            } );
        }

        function failureCallback( data ) {
            //console.log( 'update psw failed.' );
			if(data.status != undefined ){
                var statusDescription = {351:'Last 4 passwords cannot be used. Please try again' , 
                        450:'password incorrect'
                        };
                var statusCode = data.status.statusCode;
            	component.find( '.form-group:first' ).before( '<label id="fields-error" class="error" for="fields" style="display:block;" aria-live="polite">' +statusDescription[statusCode] + '</label>' );
            }

        }

        function updateCSSInSecurityQ( event ) {
            var windowHeight = $( window ).height();
            $( 'html,body' ).addClass( 'profile-opened' );
            $( 'body' ).height( windowHeight );
            parentComponent.height( windowHeight );
        }

        function tooltipFocused( e ) {
            $( e.currentTarget ).parent().find( '[data-toggle="popover"]' ).popover( 'show' );
        }

        function tooltipFocusedOut( e ) {
            $( e.currentTarget ).parent().find( '[data-toggle="popover"]' ).popover( 'hide' );
        }

        function closePopup( e ) {
            e.preventDefault();
            $( window ).off( "resize", updateCSSInSecurityQ );

            $( 'html,body' ).removeClass( 'profile-opened' );
            $( 'body' ).css( 'height', '100%' );

            component.removeClass( 'confirmation-open confirmation-open-open update-password-container' );

            parentComponent.removeClass( 'popup-open' );
            component.fadeOut();

            /* if ( this.childView ) {
                 this.childView.close();
             }

             this.parentView.closePopup( e );*/
        }

        function getCookie(cname) {
		   var name = cname + "=";
		   var ca = document.cookie.split(';');
		   for (var i = 0; i < ca.length; i++) {
			   var c = ca[i];
			   while (c.charAt(0) == ' ') {
				   c = c.substring(1);
			   }
			   if (c.indexOf(name) == 0) {
				   return c.substring(name.length, c.length);
			   }
		   }
		   return "";
		}

    };

    return UpdatePswView;

} );