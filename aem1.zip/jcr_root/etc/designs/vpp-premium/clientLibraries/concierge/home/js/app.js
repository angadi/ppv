// Filename: app.js
define( [
    'jquery',
    'router', // Request router.js
    'utils/Constants',
    'models/SessionObject'
], function( $, Router, Constants, SessionObject ) {
    var initialize = function() {
        // Popu content store in constant variables and remove morkup
        Constants.login = $('#login-popup').html();
        Constants.loginstep2 = $('#login-setp2').html();
        Constants.registerContainer = $('#register-container').html();
        Constants.registerstep1 = $('#register-step1').html();
        Constants.registerstep2 = $('#register-step2').html();
        Constants.forgotpassword = $('#forgot-password-container').html();
        Constants.resetpassword = $('#reset-password-container').html();
        $('#login-popup, #login-step2, #register-container, #register-step1, #register-step2, #forgot-password-container, #reset-password-container').remove();

        //Inject custom validaion method for password.
        $.validator.addMethod( "passwordRegex", function( value ) {
            return /[a-zA-Z]/.test( value ) && /[0-9]/.test( value ) && /[\@\#\$\%\^\&\*\(\)\_\+\!\-=]/.test( value );
        } );
        $.validator.addMethod( "selectedOptionNotEquals", function( value, element, arg ) {
            return value != $( arg ).val();
        } );
        $.validator.addMethod( "noSpecialCharacters", function( value, element, arg ) {
            return /^[a-zA-Z0-9 ]+$/.test( value );
        } );
        $.validator.addMethod( "postalCodeCharacterCheck", function( value, element, arg ) {
            return /^[a-zA-Z0-9 -]+$/.test( value );
        } );
        $.validator.addMethod( 'noSpecialCharactersAndSpace', function( value, element, arg ) {
            return /^[a-zA-Z0-9]+$/.test( value );
        } );
        $.validator.addMethod( 'equalToCaseIgnore', function( value, element, arg ) {
            return value.toLowerCase() === $( arg ).val().toLowerCase();
        } );
        $.validator.addMethod( 'noSpace', function( value, element, arg ) {
            return value.indexOf( " " ) < 0;
        } );

        $.validator.addMethod( 'emailOrUsername', function( value, element, arg ) {
            var emailCheck, usernameCheck;

            emailCheck = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test( value );
            usernameCheck = /[a-zA-Z0-9]/.test( value );

            return emailCheck || usernameCheck;

        } );

        /* Add Validator method - regex check for invalid characters */
        if ( $.validator ) {
            $.validator.addMethod( "regex", function( value, element, regexp ) {
                var re = new RegExp( regexp );
                return this.optional( element ) || re.test( value );
            }, "Input contains invalid characters. Please revise using only letters, numbers, spaces, or ?,.!-'&@#/*:)(_" );

            $.validator.addMethod( "pswCheck", function( value, element ) {
                return this.optional( element ) || /^(?=.*?[!@#$%^&*?~`])(?=.*?[0-9]).{8,}$/.test( value );
            }, Constants.errorMsg.pswNotMeetRequirements );
        }

        Router.initialize();
    };
    return {
        initialize: initialize
    };
} );