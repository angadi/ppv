$(document).ready(intialize);

function intialize(){
	//FAQ
	$('.footerFAQ').on('click', function(e){
		var faq = $("#faq-container");var mainContainer = $("#v-home-content");
		mainContainer.addClass('hidden');
		faq.removeClass('hidden');
		$(window).scrollTop(0);
		window.location.href = window.location.href + "#faq";
	});

	$('#faq-container .home').on('click', function(e){
		var faq = $("#faq-container");var mainContainer = $("#v-home-content");
		mainContainer.removeClass('hidden');
		faq.addClass('hidden');
	});
	//register
	$('.register').on('click', function(e) {
		$('.popup').addClass('hidden');
		$('#v-register-container').removeClass('hidden');
	});
	//security questions
	$('#create-profile-submit').on('click', function(e) {
		$('.create-profile-form').validate({
			ignore: ':hidden',
			errorClass: 'error',
		    onkeyup: false,
		    onfocusout: false,
			rules: {
				pan : {
					required: true,
					// digits: true,
					minlength: 19,
					maxlength: 19
				},
				firstname : {
					required: true,
					maxlength: Constants.validations.maxLength
				},
				lastname : {
					required: true,
					maxlength: Constants.validations.maxLength
				},
				country : {
					required : true
				},
				zip : {
					required: true,
					digits: true,
					maxlength: 5,
					noSpecialCharactersAndSpace: true
				},
				city: {
					required : true,
					maxlength: Constants.validations.maxLength
				},
				email : {
					required : true,
					email : true,
					maxlength: Constants.validations.maxLength
				},
				password : {
					required : true,
					minlength: 7,
					maxlength: Constants.validations.passwordMaxLength,
					passwordRegex: true,
					noSpace: true
				},
				confirmPassword : {
					required : true,
					equalTo : '#password'
				}
			},
			messages: {
				pan: {
					required: Constants.errorMsg.required,
					// digits: Constants.errorMsg.invalidCreditCard,
					minlength: Constants.errorMsg.invalidCreditCard,
					maxlength: Constants.errorMsg.invalidCreditCard
				},
				firstname: {
					required: Constants.errorMsg.required,
					maxlength: Constants.errorMsg.billingInfoNotMatch
				},
				lastname: {
					required: Constants.errorMsg.required,
					maxlength: Constants.errorMsg.billingInfoNotMatch
				},
				zip : {
					required: Constants.errorMsg.required,
					digits: Constants.errorMsg.billingInfoNotMatch,
					maxlength: Constants.errorMsg.billingInfoNotMatch,
					noSpecialCharactersAndSpace: Constants.errorMsg.billingInfoNotMatch
				},
				city: {
					required: Constants.errorMsg.required,
					maxlength: Constants.errorMsg.billingInfoNotMatch
				},
				country : {
					required: Constants.errorMsg.required
				},
				email: {
					required: Constants.errorMsg.required,
					email: Constants.errorMsg.invalidEmail,
					maxlength: Constants.errorMsg.invalidEmail
				},
				password: {
					required: Constants.errorMsg.required,
					maxlength: Constants.errorMsg.passwordInvalid,
					minlength: Constants.errorMsg.passwordInvalid,
					passwordRegex: Constants.errorMsg.passwordInvalid,
					noSpace: Constants.errorMsg.passwordInvalid
				},
				confirmPassword: {
					required: Constants.errorMsg.required,
					equalTo: Constants.errorMsg.passwordnotMatch
				}
			},
			groups: {
				'fields': 'firstname lastname zip country'
			},
			errorPlacement: function(error, element) {
				if($.inArray(element.attr('name'), ['firstname','lastname','zip','country','city'])>-1) {
					$('.form-group.half-right').last().after(error);
				}
				else if($.inArray(element.attr('name'), ['password','confirmPassword'])>-1) {
					$('#confirmPassword').closest('.form-group').after(error);
				}
				else {
					element.closest('.form-group').after(error);
					// error.insertAfter(element);
				}
			},
			invalidHandler: function(form, validator) {
				var errorList = validator.errorList;
				if(errorList && errorList.length > 0) {
					validator.errorList[0].element.focus();
				}
		    },
			submitHandler: function(form) {
				$('.create-profile-container').addClass('hidden');
				$('.security-questions-container').removeClass('hidden');
			}
		});
	});

	$('.v-select2').select2({
		dropdownParent: $('.form-group'),
		minimumResultsForSearch: -1
	});

	$('#securityQuestionId2').select2({
		placeholder: 'security Question 2',
		dropdownParent: $('.form-group'),
		minimumResultsForSearch: -1
	});

	$('#securityQuestionId1').select2({
		placeholder: 'security Question 1',
		dropdownParent: $('.form-group'),
		minimumResultsForSearch: -1
	});

	$('.popup .closeBtn').on('click', function(e) {
		$('.popup').addClass('hidden');
	});

	$('.security-questions-form').validate({
		ignore: ':hidden',
		onkeyup: false,
		onfocusout: false,

		rules: {
			securityQuestionId1 : {
				required: true
			},
			securityQuestionId2 : {
				required: true
			},
			securityQuestionAnswer1 : {
				required: true,
				maxlength: Constants.validations.maxLength,
				noSpecialCharacters: true,
			},
			securityQuestionAnswer2 : {
				required: true,
				maxlength: Constants.validations.maxLength,
				noSpecialCharacters: true
			},
			termsAndPrivacyPolicy : {
				required: false
			}
		},
		messages: {
			securityQuestionId1 : Constants.errorMsg.required,
			securityQuestionId2 : {
				required: Constants.errorMsg.required
			},
			securityQuestionAnswer1 : {
				required: Constants.errorMsg.required,
				noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
				maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
			},
			securityQuestionAnswer2 : {
				required: Constants.errorMsg.required,
				noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
				maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
			}
		},
		errorPlacement: function(error, element) {
			element.closest('.form-group').after(error);
		},
		invalidHandler: function(form, validator) {
	        var errors = validator.numberOfInvalids();
	        if (errors) {
	            validator.errorList[0].element.focus();
	        }
	    },
		submitHandler: function(form) {

		}
	});
}

