define( [
    'jquery',
    'utils/Constants'
], function( $, Constants ) {
    'use strict';

    var SessionObject = {
        getBankConfig: function( callback ) {

            if ( !window.isConciergePortal ) {
                var that = this;

                $.post( '../bank/getCurrentBankConfig.do', function( data ) {

                    that.bankConfig = data.bankConfig;

                    //tracking
                    that.productForTracking = 'visa_infinite',
                        that.bankName = '';
                    if ( data.bankConfig.BANK_NAME && data.bankConfig.BANK_NAME != '' ) {
                        that.bankName = data.bankConfig.BANK_NAME;
                    }
                    //end of tracking

                    if ( callback ) {
                        callback();
                    }
                } );
            } else { //concierge portal
                this.bankConfig = {
                    "LANDING_PAGE_HERO_IMAGES": {
                        "heroImages": [ {
                                "hd_desktop": {
                                    "alt": "Alila Villas Uluwatu, Bali, Indonesia | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/landingpage-heroimage-hd-desktop.png"
                                },
                                "tablet": {
                                    "alt": "Alila Villas Uluwatu, Bali, Indonesia | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/landingpage-heroimage-tablet.png"
                                },
                                "desktop": {
                                    "alt": "Alila Villas Uluwatu, Bali, Indonesia | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/landingpage-heroimage-desktop.png"
                                },
                                "mobile": {
                                    "alt": "",
                                    "path": "images/landingpage-heroimage-mobile.png"
                                }
                            },
                            {
                                "hd_desktop": {
                                    "alt": "Canaves Oia Suites, Santorini, Greece | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/protection_2000x800.png"
                                },
                                "tablet": {
                                    "alt": "Canaves Oia Suites, Santorini, Greece | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/protection_1099x480.png"
                                },
                                "desktop": {
                                    "alt": "Canaves Oia Suites, Santorini, Greece | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/protection_1399x800.png"
                                },
                                "mobile": {
                                    "alt": "",
                                    "path": "images/protection_767x668.png"
                                }
                            },
                            {
                                "hd_desktop": {
                                    "alt": "Fairmont Banff Springs, Alberta, Canada | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/services_2000x800.png"
                                },
                                "tablet": {
                                    "alt": "Fairmont Banff Springs, Alberta, Canada | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/services_1099x480.png"
                                },
                                "desktop": {
                                    "alt": "Fairmont Banff Springs, Alberta, Canada | A Visa Infinite Luxury Hotel Collection Property",
                                    "path": "images/services_1399x800.png"
                                },
                                "mobile": {
                                    "alt": "",
                                    "path": "images/services_767x668.png"
                                }
                            }
                        ],
                        "video": {}
                    },
                    "LANDING_WELCOME": {
                        "WELCOME_TITLE": "Welcome to visa infinite"
                    }
                };

                if ( callback ) {
                    callback();
                }
            }
        },

        login: function( postData, successCallback, failureCallback, self ) {

            var that = this;
            var path = '../user/loginUser.do';
            var postingData = 'userName=' + encodeURIComponent( postData.email ) +
                '&password=' + encodeURIComponent( postData.password );

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    data.errorMsg = 'Username and password not matching.';
                    failureCallback( data, self );
                }

            } );
        },

        registerStep1: function( postData, successCallback, failureCallback, self ) {
            var that = this;
            var path = '../user2/userRegisterStep1.do';
            var postingData = this.objectToString( postData );

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        registerStep2: function( postData, successCallback, failureCallback, self ) {
            var that = this;
            var path = '../user2/userRegisterStep2.do';
            var postingData = this.objectToString( postData );

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        registerStep3: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/userRegisterStep3.do';
            var postingData = this.objectToString( postData );

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getSecurityQuestions: function( callback ) {
            $.post( Constants.apiPaths.securityQuestionApi, function( data ) {

                callback( data );

            } );
        },

        getEmailPrefs: function( callback, self ) {
            var path = '../user2/getAllAvailableEmailReference.do';

            $.post( path, function( data ) {

                callback( data, self );

            } );
        },

        forgotPasswordUsernameSumbit: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/initResetPassword.do';

            var postingData = 'userName=' + encodeURIComponent( postData.username );

            var that = this;

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data.errorMsg, self );
                }

            } );
        },

        forgotPasswordTokenValidate: function( postData, successCallback, failureCallback ) {
            var path = '../user2/validateResetPasswordToken.do';

            var that = this;

            var postingData = 'resetToken=' + encodeURIComponent( postData.token );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data.questionList );
                } else {
                    failureCallback( data.errorMsg );
                }
            } );
        },

        forgotPasswordGetSecurityQ: function( postData, successCallback, failureCallback ) {
            var path = '../user/getSecurityQuestionByUserName.do';

            var that = this;

            var postingData = 'userName=' + encodeURIComponent( postData.username );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data );
                } else if ( data.status === Constants.apiStatus.No ) { //username wrong
                    failureCallback( data.status );
                } else { //exeed 3 times or other error
                    failureCallback( data.status );
                }
            } );
        },

        forgotPasswordSecurityQSubmit: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/checkSecretQuestion.do';

            var that = this;

            var postingData = this.objectToString( postData );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }
            } );
        },

        forgotUsernameSubmit: function( postData, successCallback, failureCallback ) {
            var path = '../user/forgetUserName.do';

            var that = this;

            var postingData = this.objectToString( postData );

            $.post( path, postingData, function( data ) {

                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback();
                } else {
                    failureCallback();
                }

            } );
        },

        resetPasswordSubmit: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/resetPassword.do';

            var that = this;

            var postingData = 'answer=' + encodeURIComponent( postData.confirmNewPsw );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getUserRole: function( token, successCallback, failureCallback ) {
            var path = '../user/validateResetForcePasswordToken.do';

            var that = this;

            var postingData = 'resetToken=' + encodeURIComponent( token );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data );
                } else {
                    failureCallback( data );
                }

            } );
        },
        resetPasswordConciergeSubmit: function( postData, successCallback, failureCallback, self ) {
            var path = '../user/forceResetPassword.do';

            var that = this;

            var postingData = 'newPassword=' + encodeURIComponent( postData.password ) +
                '&concgImgId=' + encodeURIComponent( postData.imgId );

            $.post( path, postingData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        validateConciergeRegisterToken: function( postData, successCallback, failureCallback ) {
            var path = Constants.apiPaths.validateConciergeRegisterToken;

            var that = this;

            $.post( path, postData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data );
                } else {
                    failureCallback( data );
                }

            } );
        },

        registerConciergeStep1: function( postData, successCallback, failureCallback, self ) {
            var path = Constants.apiPaths.registerConciergeUser;

            $.post( path, postData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        getProfileImages: function( successCallback ) {
            $.post( Constants.apiPaths.gravtarCollectionApi, function( data ) {

                successCallback( data );

            } );
        },

        conciergeRegister: function( postData, successCallback, failureCallback, self ) {
            var path = Constants.apiPaths.registerConciergeUser;

            $.post( path, postData, function( data ) {
                if ( data.status === Constants.apiStatus.OK ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );

        },

        conciergeLogin: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/loginConciergeUser.do';

            $.post( path, postData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        verifyConcierge: function( postData, successCallback, failureCallback, self ) {
            var path = '../user2/checkConciergeUserPass.do';

            $.post( path, postData, function( data ) {
                if ( data.status === Constants.apiStatus.YES ) {
                    successCallback( data, self );
                } else {
                    failureCallback( data, self );
                }

            } );
        },

        objectToString: function( obj ) {
            var str = '';
            for ( var key in obj ) {
                if ( obj.hasOwnProperty( key ) ) {
                    str += key + '=' + obj[ key ] + '&';
                }
            }
            str = str.substring( 0, str.length - 1 );
            return str;
        }

    };

    return SessionObject;
} );