// Filename: router.js
define([
    'jquery',
    'views/landing/LandingPageView',
    'views/popups/LoginView',
    'views/popups/ConciergeRegisterView',
    'views/popups/ForgotPasswordView',
    'views/popups/ForgotPasswordSecurityQView',
    'models/SessionObject',
    'jquery.validate',
    'jquery.validate.additional-methods'
], function(
    $,
    LandingPageView,
    LoginView,
    ConciergeRegisterView,
    ForgotPasswordView,
    ForgotPasswordSecurityQView,
    SessionObject
) {
    var initialize = function() {
        var parentView = LandingPageView();
        var token = '';
        loadPage();

        function forgotPasswordTokenValidate(parentView, token) {
            if (token && token != '') {
                var tokenInfo = {
                    "token": token
                };

                var path = '/vpp-backend/v1/cnb/infinite/pwReset/validateToken';

                $.ajax({
                    type: "POST",
                    url: path,
                    dataType: "json",
                    async: false,
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(tokenInfo),
                    success: function(result) {

                        if (result.status != undefined && result.status.statusCode === '200') {
                            //ForgotPasswordSecurityQView(result );
                            SuccessCallback(result);
                        } else {
                            $(".popup_invalidLink").fadeIn();
                            $(".popup_invalidLink").delay(3000).fadeOut();
                        }
                    }
                });

            }
        }

        function SuccessCallback(result) {
            ForgotPasswordSecurityQView(result.response.securityQuestions, parentView, token);
        }

        function loadPage() {
            var route = '';
            //var token = '';
            var regex = /^[\w\#\-\/]+$/g;
            var hash = (regex.exec(window.location.hash) !== null) ? window.location.hash : '';
            if (hash.length !== 0) {
                var hashContent = hash.split('/');
                if (hashContent.length == 3) {
                    route = hashContent[1] ? hashContent[1] : '';
                    token = hashContent[2] ? hashContent[2] : '';
                } else {
                    route = hashContent[0] ? hashContent[0] : '';
                    token = hashContent[1] ? hashContent[1] : '';
                }
            }

            switch (route) {
                case '#log-in':
                    LoginView(parentView);
                    break;
                case '#register':
                    if (token) {
                        ConciergeRegisterView(parentView, token);
                    } else {
                        window.location.hash = '#';
                    }
                    break;
                case '#forgot-password':
                    ForgotPasswordView(parentView);
                    break;
                case 'reset-password':
                    forgotPasswordTokenValidate(parentView, token);
                    //ForgotPasswordSecurityQView(parentView);
                    break;
                default:
                    break;
            }
        }
        window.onhashchange = loadPage;
    };

    return {
        initialize: initialize
    };
});