define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	var settings = {
		ignore: ':hidden',
		onkeyup: false,
		onfocusout: false,
		
		rules: {
			'emailOrUser' : {
				required: true,
				emailOrUsername: true
			},
			'email' : {
				required: true,
				email: true,
				maxlength: Constants.validations.maxLength,
			}
		},
		messages: {
			'emailOrUser' : {
				required: Constants.errorMsg.required,
				emailOrUsername: Constants.errorMsg.emailOrUsernameInvalid
			},
			'email' : {
				required: Constants.errorMsg.required,
				email: Constants.errorMsg.invalidEmail,
				maxlength: Constants.validations.invalidEmail,
			}
		},
		errorPlacement: function(error, element) {
			if((element.attr('name') === 'email' && element.val() === '') || (element.attr('name') === 'emailOrUser' && element.val() === '')  ) {
				error.insertBefore('.email-input');
			}
			else {
				element.closest('.form-group').after(error);
			}
		},
		invalidHandler: function(form, validator) {
	        var errors = validator.numberOfInvalids();
	        if (errors) {                    
	            validator.errorList[0].element.focus();
	        }
	    },
		submitHandler: function(form) {
		
		}
	};
	
	return settings;
});
