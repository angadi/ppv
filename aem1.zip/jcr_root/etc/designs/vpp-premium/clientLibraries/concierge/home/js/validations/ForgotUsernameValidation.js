define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	var settings = {
		errorClass: 'error',
	    onkeyup: false,
	    onfocusout: false,
		rules: {
			last4Pan : {
				required: true,
				digits: true,
				minlength: 4,
				maxlength: 4
			},
			email : {
				required : true,
				email : true,
				maxlength: Constants.validations.maxLength
			}
		},
		messages: {
			last4Pan: {
				required: Constants.errorMsg.required
			},
			email: {
				required: Constants.errorMsg.required,
				email: Constants.errorMsg.invalidEmail,
				maxlength: Constants.errorMsg.invalidEmail
			}
		},
		errorPlacement: function(error, element) {
			element.closest('.form-group').after(error);
		},
		invalidHandler: function(form, validator) {
			var errorList = validator.errorList;
			if(errorList && errorList.length > 0) {
				validator.errorList[0].element.focus();
			}
	    },
		submitHandler: function(form) {
		
		}
	};

	return settings;
		

});
