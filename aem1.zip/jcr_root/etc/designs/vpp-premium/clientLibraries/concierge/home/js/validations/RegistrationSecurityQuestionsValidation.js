define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	var settings = {
		ignore: ':hidden',
		onkeyup: false,
		onfocusout: false,
		
		rules: {
			securityQuestionId1 : {
				required: true
			},
			securityQuestionId2 : {
				required: true
			},
			securityQuestionAnswer1 : {
				required: true,
				maxlength: Constants.validations.maxLength,
				noSpecialCharacters: true,
			},
			securityQuestionAnswer2 : {
				required: true,
				maxlength: Constants.validations.maxLength,
				noSpecialCharacters: true
			},
			termsAndPrivacyPolicy : {
				required: false
			}
		},
		messages: {
			securityQuestionId1 : Constants.errorMsg.required,
			securityQuestionId2 : {
				required: Constants.errorMsg.required
			},
			securityQuestionAnswer1 : {
				required: Constants.errorMsg.required,
				noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
				maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
			},
			securityQuestionAnswer2 : {
				required: Constants.errorMsg.required,
				noSpecialCharacters: Constants.errorMsg.securityAnswerInvalid,
				maxlength: Constants.errorMsg.securityAnswerMaxLengthExceeded
			}
		},
		errorPlacement: function(error, element) {
			element.closest('.form-group').after(error);
		},
		invalidHandler: function(form, validator) {
	        var errors = validator.numberOfInvalids();
	        if (errors) {                    
	            validator.errorList[0].element.focus();
	        }
	    },
		submitHandler: function(form) {
		
		}
	};
	
	return settings;
});
