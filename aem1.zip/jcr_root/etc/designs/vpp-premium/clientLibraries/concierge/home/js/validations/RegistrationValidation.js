define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	var settings = {
		ignore: ':hidden',
		errorClass: 'error',
	    onkeyup: false,
	    onfocusout: false,
		rules: {
			pan : {
				required: true,
				// digits: true,
				minlength: 19,
				maxlength: 19
			},
			firstname : {
				required: true,
				maxlength: Constants.validations.maxLength
			},
			lastname : {
				required: true,
				maxlength: Constants.validations.maxLength
			},
			country : {
				required : true
			},
			zip : {
				required: true,
				digits: true,
				maxlength: 5,
				noSpecialCharactersAndSpace: true
			},
			city: {
				required : true,
				maxlength: Constants.validations.maxLength
			},
			email : {
				required : true,
				email : true,
				maxlength: Constants.validations.maxLength
			},
			password : {
				required : true,
				minlength: 7,
				maxlength: Constants.validations.passwordMaxLength,
				passwordRegex: true, 
				noSpace: true
			},
			confirmPassword : {
				required : true,
				equalTo : '#password'
			}
		},
		messages: {
			pan: {
				required: Constants.errorMsg.required,
				// digits: Constants.errorMsg.invalidCreditCard,
				minlength: Constants.errorMsg.invalidCreditCard,
				maxlength: Constants.errorMsg.invalidCreditCard
			},
			firstname: {
				required: Constants.errorMsg.required,
				maxlength: Constants.errorMsg.billingInfoNotMatch
			},
			lastname: {
				required: Constants.errorMsg.required,
				maxlength: Constants.errorMsg.billingInfoNotMatch
			},
			zip : {
				required: Constants.errorMsg.required,
				digits: Constants.errorMsg.billingInfoNotMatch,
				maxlength: Constants.errorMsg.billingInfoNotMatch,
				noSpecialCharactersAndSpace: Constants.errorMsg.billingInfoNotMatch
			},
			city: {
				required: Constants.errorMsg.required,
				maxlength: Constants.errorMsg.billingInfoNotMatch
			},
			country : {
				required: Constants.errorMsg.required
			},
			email: {
				required: Constants.errorMsg.required,
				email: Constants.errorMsg.invalidEmail,
				maxlength: Constants.errorMsg.invalidEmail
			},
			password: {
				required: Constants.errorMsg.required,
				maxlength: Constants.errorMsg.passwordInvalid,
				minlength: Constants.errorMsg.passwordInvalid,
				passwordRegex: Constants.errorMsg.passwordInvalid,
				noSpace: Constants.errorMsg.passwordInvalid
			},
			confirmPassword: {
				required: Constants.errorMsg.required,
				equalTo: Constants.errorMsg.passwordnotMatch
			}
		},
		groups: {
			'fields': 'firstname lastname zip country'
		},
		errorPlacement: function(error, element) {
			if($.inArray(element.attr('name'), ['firstname','lastname','zip','country','city'])>-1) {
				$('.form-group.half-right').last().after(error);
			}
			else if($.inArray(element.attr('name'), ['password','confirmPassword'])>-1) {
				$('#confirmPassword').closest('.form-group').after(error);
			}
			else {
				element.closest('.form-group').after(error);
				// error.insertAfter(element);
			}
		},
		invalidHandler: function(form, validator) {
			var errorList = validator.errorList;
			if(errorList && errorList.length > 0) {
				validator.errorList[0].element.focus();
			}
	    },
		submitHandler: function(form) {
		
		}
	};

	return settings;
		

});
