define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	var settings = {
		ignore: ':hidden',
		onkeyup: false,
		onfocusout: false,
		
		rules: {
			password : {
				required : true,
				minlength: 7,
				maxlength: Constants.validations.passwordMaxLength,
				passwordRegex: true
			},
			confirmPassword : {
				required : true,
				equalTo : '#password'
			}
		},
		messages: {
			password: {
				required: Constants.errorMsg.required,
				maxlength: Constants.errorMsg.passwordInvalid,
				minlength: Constants.errorMsg.passwordInvalid,
				passwordRegex: Constants.errorMsg.passwordInvalid
			},
			confirmPassword: {
				required: Constants.errorMsg.required,
				equalTo: Constants.errorMsg.passwordnotMatch
			}
		},
		errorPlacement: function(error, element) {
			element.closest('.form-group').parent().find('.form-group.last').after(error);
		},
		invalidHandler: function(form, validator) {
	        var errors = validator.numberOfInvalids();
	        if (errors) {                    
	            validator.errorList[0].element.focus();
	        }
	    },
		submitHandler: function(form) {
		
		}
	};
	
	return settings;
});
