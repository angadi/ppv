define( [
    'jquery',
    'models/SessionObject',
    'utils/Constants',
    'jquery.lazyload',
    'bootstrap'
], function( $, SessionObject, Constants ) {

    var LandingPageView = function() {
        // element
        var component = $('#page-content .main');

        // variables
        var genericCarousel = component.find('#carousel-generic.carousel');

        // functions
        function render( options ) {
            $( '.lazy' ).lazyload( {
                threshold: 400
            } );

            if ( genericCarousel && genericCarousel.length > 0 ) {
                genericCarousel.carousel( {
                    interval: 8000,
                    pause: 'false'
                } );
            }
        }

        function pauseCarousel() {
            genericCarousel.carousel( 'pause' );
        }

        function resumeCarousel() {
            genericCarousel.carousel( 'cycle' );
        }

        return {
            'pauseCarousel': pauseCarousel,
            'resumeCarousel': resumeCarousel
        };
    };

    return LandingPageView;

} );