define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/others/navTemplate.html',
  'models/SessionObject'
], function($, _, Backbone, navTemplate, SessionObject){
  var NavViewHelper = {};

  var NavView = Backbone.View.extend({
    el: '.navbar-customize',

    events: {
      'click a.navbar-brand.navBarBrand' : 'goHome',
      'click a.navbar-toggle' : 'toggleSlideNav'
    },

    render: function(){
      var data = {};
      _.extend(data, SessionObject, NavViewHelper); 

      var template = _.template($(navTemplate).html());
      this.$el.html(template(data));
      
    },

    goHome: function(e) {
      e.preventDefault;
      if(Backbone.history.fragment === '#' || Backbone.history.fragment === '') {}
      else {
        Backbone.history.navigate('#');
        window.location.reload();
      }
    },

    toggleSlideNav: function(e) {
      e.preventDefault();

      $('#wrapper').toggleClass('slide-nav-open');

    }
    
  });

  return NavView;
  
});
