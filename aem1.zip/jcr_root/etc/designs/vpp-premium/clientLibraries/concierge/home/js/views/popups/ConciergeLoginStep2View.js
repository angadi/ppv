define(
		[ 'jquery', 'models/SessionObject', 'utils/Constants', 'select2' ],
		function($, SessionObject, Constants) {

			var ConciergeLoginStep2View = function(options) {
				var imageHtml = '';
				data = options.concgImgs;
				data
						.forEach(function(item) {
							imageHtml += '<a class="profile-img-container" href="#" profile-img-id="'
									+ item.conciergeImageId
									+ '" aria-hidden="true" tabindex="-1">';
							imageHtml += '<img class="img-responsive" src="/etc/designs/vpp-premium/clientLibraries/concierge/home'
									+ item.conciergeImageUrl + '" alt=""></a>';
						});
				$('.popup .concierge-register-step2-container').html(
						Constants.loginstep2);
				$('.popup .concierge-register-step2-container .form-container')
						.prepend(imageHtml);
				// element
				component = $('.popup .concierge-register-step2-container');

				// variables
				var CRstep2Wrapper = component
						.find('.concierge-register-step-2-wrapper');
				var profileImgContainer = component
						.find('.profile-img-container');
				var CRstep2Submit = component
						.find('#concierge-register-step2-submit');
				var backBtn = component.find('.back');
				var globalVariables = {
					parentView : options.parentView,
					formData : options.formData,
					concgImgs : options.concgImgs
				};
				var errorLabel;
				var selectedImg;

				// events
				profileImgContainer.click(profileImgClicked);
				CRstep2Submit.click(conciergeLoginSubmit);
				backBtn.click(cancelLogin);

				// functions
				function profileImgClicked(e) {
					e.preventDefault();

					profileImgContainer.removeClass('selected');
					$(e.currentTarget).addClass('selected');

				}

				function conciergeLoginSubmit(e) {
					e.preventDefault();
					errorLabel = component.find('label.error');
					selectedImg = component
							.find('.profile-img-container.selected');
					errorLabel.remove();

					if (selectedImg && selectedImg.length > 0) {
						globalVariables.formData.concgImgId = selectedImg
								.attr('profile-img-id');
						//conciergeLogin( globalVariables.formData);
						userImageInfo = {
							'userId' : globalVariables.formData.userId,
							'imageId' : globalVariables.formData.concgImgId
						};

						//successCallback(globalVariables.formData);
						verifyConciergeImage(userImageInfo);
					} else {
						$(
								'<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'
										+ Constants.errorMsg.profileImageNotSelected
										+ '</label>')
								.insertBefore(
										'.concierge-register-step-2-wrapper .form-container');
					}
				}

				function verifyConciergeImage(postData) {
					var path = '/vpp-backend/v1/concierge/checkConciergeImage';

					$.ajax({
						type : "POST",
						url : path,
						dataType : "json",
						async : false,
						contentType : "application/json; charset=utf-8",
						data : JSON.stringify(postData),
						success : function(result) {
							if (result.status != undefined
									&& result.status.statusCode === '200'
									&& result.response.userId !== null
									&& result.response.userId !== "") {

								successCallback(result);
							} else {
								failureCallback(result);

							}

						}
					});

				}

				function successCallback(data) {
					if (data.status != undefined
							&& data.status.statusCode === '200'
							&& data.response.userId !== null
							&& data.response.userId !== "") {

						redirectLandingPage(data.response.userId,
								globalVariables.formData.firstName);

					}
				}

				function redirectLandingPage(userid, firstName) {
					var cpath = $('#wrapper').find('#currentPagePath').val();
					$.ajax({
						type : "GET",
						url : "/bin/conciergeLandingRedirection",
						data : {
							currentPagePath : cpath,
							id : userid,
							firstName : firstName
						},
						success : function(result) {
							location = result;
						}
					});

				}

				function failureCallback(data) {
					$(
							'<label class="systemError error" style="display: inline-block;" aria-live="polite">'
									+ Constants.errorMsg.generalError
									+ '</label>')
							.insertBefore(
									'.concierge-register-step-2-wrapper .form-container');
				}

				function cancelLogin(e) {
					//e.preventDefault();

					globalVariables.parentView.closePopup(e);
					component.html('');
				}
			};

			return ConciergeLoginStep2View;

		});