define( [
    'jquery',
    'views/popups/ConciergeRegisterStep2View',
    'validations/ConciergeRegistrationStep1Validation',
    'utils/Constants',
    'select2'
], function( $, ConciergeRegisterStep2View, ValidationSettings, Constants ) {

    var ConciergeRegisterStep1View = function( parentView, userData, token ) {
        $( '.concierge-register-step1-container' ).html( Constants.registerstep1 );
        //variables
        console.log( "step1" );
        var component = $( '.popup .concierge-register-step1-container' );
        var popup = $( '.popup' );
        var closeBtn = popup.find( '.closeBtn' );
        var popupBlock = $( '.popup_block' );
        var securityQuestionId1 = component.find( '#securityQuestionId1' );
        var securityQuestionId2 = component.find( '#securityQuestionId2' );
        var conciergeRegisterStep1SubmitBtn = component.find( '#concierge-register-step1-submit' );
        var CRcontainer = $( '.concierge-register-container' );
        var back = component.find( '.back' );
        var userName = component.find('#userName');
        var globalValues = {};
        //events
        securityQuestionId1.on( 'select2-selecting', securityQuestionChangeHandler );
        securityQuestionId1.on( 'select2-selecting', securityQuestionChangeHandler );
        conciergeRegisterStep1SubmitBtn.click( conciergeRegisterStep1Submit );
        back.click( cancelRegister );
        closeBtn.click( cancelRegister );
        render();

        function render() {
            $( 'input, textarea' ).placeholder();
            userName.val(userData.emailAddress);
            globalValues.$form = component.find( '.concierge-register-step-1-form' );
            globalValues.$form.validate( ValidationSettings );
            loadSecurityQuestions();
        }

        function loadSecurityQuestions() {
            var $sQuestionSelectBox1 = $( "#securityQuestionId1" );
            var $sQuestionSelectBox2 = $( "#securityQuestionId2" );
            var questions = '';
            //var that = this;
            var JsonData = userData.securityQuestions;
             globalValues.questionJson = JsonData;
            questions += '<option value=""></option>';
            $.each( JsonData, function( index, item ) {
                questions += '<option value="' + item.questionId + '">' + item.questionText + '</option>';
            } );
            $sQuestionSelectBox1.append( questions );
            $sQuestionSelectBox2.append( questions );
            $sQuestionSelectBox1.select2( {
                placeholder: $( $sQuestionSelectBox1 ).siblings( 'label' ).html(),
                dropdownParent: $( '.form-group' ),
                minimumResultsForSearch: -1
            } );
            $sQuestionSelectBox2.select2( {
                placeholder: $( $sQuestionSelectBox2 ).siblings( 'label' ).html(),
                dropdownParent: $( '.form-group' ),
                minimumResultsForSearch: -1
            } );
            //wcag:
            $( '#password' ).focus();

        }

        function securityQuestionChangeHandler( e ) {
            var selectBoxIdToChange = '';
            if ( $( e.currentTarget ).prop( 'id' ) == 'securityQuestionId1' ) {
                selectBoxIdToChange = "#securityQuestionId2";
            } else {
                selectBoxIdToChange = "#securityQuestionId1";
            }
            removeOptionFromSelect( selectBoxIdToChange, e );
        }

        function removeOptionFromSelect( selectBoxToChange, optionValue ) {
            populateQuestionInSelectBox( selectBoxToChange, optionValue );
        }

        function populateQuestionInSelectBox( selectBoxSelector, valueToExclude ) {
            var excludeId = valueToExclude.choice.id;
            var oldSelectedValue = $( selectBoxSelector ).select2( 'data' ) ? $( selectBoxSelector ).select2( 'data' ).id : null;
            $( selectBoxSelector ).find( "option" ).remove();
            $( selectBoxSelector ).append( '<option value=""></option>' );

            $.each( globalValues.questionJson, function( index, item ) {
                if ( item.questionId != excludeId ) {
                    var optionHtml = '<option value="' + item.questionId + '">' + item.questionText + '</option>';
                    $( selectBoxSelector ).append( optionHtml );
                }
            } );
            if ( oldSelectedValue == excludeId ) {
                $( selectBoxSelector ).select2( 'val', null );
            } else {
                $( selectBoxSelector ).select2( 'val', oldSelectedValue );
            }
        }

        function conciergeRegisterStep1Submit( e ) {

            //e.preventDefault();
            $( 'label.error' ).remove();
            $( '.form-control' ).removeClass( 'error' );
            globalValues.$form.find( '#s2id_securityQuestionId1 a.select2-choice' ).removeClass( 'error' );
            globalValues.$form.find( '#s2id_securityQuestionId2 a.select2-choice' ).removeClass( 'error' );

            //manually check if any required field empty
            var $missingFields = globalValues.$form.find( '.form-control:not(.select2-container,select).required:blank' );

            var isSpecialError = false;

            //check select2
            if ( !globalValues.$form.find( '#s2id_securityQuestionId1' ).select2( 'data' ) || !globalValues.$form.find( '#s2id_securityQuestionId1' ).select2( 'data' ).text ) {
                $missingFields.push( $( '#s2id_securityQuestionId1 a.select2-choice' )[ 0 ] );

                $( '#securityQuestionId1' ).select2( 'focus' );
                isSpecialError = true;
            }
            if ( !globalValues.$form.find( '#s2id_securityQuestionId2' ).select2( 'data' ) || !globalValues.$form.find( '#s2id_securityQuestionId2' ).select2( 'data' ).text ) {
                $missingFields.push( $( '#s2id_securityQuestionId2 a.select2-choice' )[ 0 ] );

                if ( !isSpecialError ) {
                    $( '#securityQuestionId2' ).select2( 'focus' );
                    isSpecialError = true;
                }
            }

            if ( $missingFields.length > 0 ) {

                $( '<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>' ).insertBefore( '#userName' );
                $missingFields.addClass( 'error' );

                if ( !isSpecialError ) {
                    $missingFields.first().focus();
                }
            } else {
                if ( globalValues.$form.valid() ) { //check if any required form missing
                    formData = globalValues.$form.serializeObject();
                    formData.phoneNumber = '';
                    formData.token = token;
                    delete formData['confirmPassword'];
                    component.hide();
                    ConciergeRegisterStep2View({
                        'parentView': parentView,
                        'formData': formData,
                        'userName': userData.emailAddress,
                        'securityImage': userData.securityImage
                    });
                    //$('.concierge-register-step2-container').show();

                }
            }
        }

        function cancelRegister( e ) {
            //e.preventDefault();
            popupBlock.hide();
            popup.hide();

        }

        function onClose() {

            //if(this.childView) {
            //this.childView.close();
            //}
        }

    };

    return ConciergeRegisterStep1View;

} );