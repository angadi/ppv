define( [
    'jquery',
    'models/SessionObject',
    'utils/Constants',
    'select2'
], function( $, SessionObject, Constants ) {

    var ConciergeRegisterStep2View = function(options) {
        var securityImage = options.securityImage;
        var imageHtml = '';
        securityImage.forEach( function( item ) {
            imageHtml += '<a class="profile-img-container" href="#" profile-img-id="' + item.imageId + '" aria-hidden="true" tabindex="-1">';
            imageHtml += '<img class="img-responsive" src="/etc/designs/vpp-premium/clientLibraries/concierge/home' + item.imageUrl + '" alt=""></a>';
        } );
        ConciergeRegisterStep2ViewRendar( options, imageHtml );
    };
    var ConciergeRegisterStep2ViewRendar = function( options, imageHtml ) {
        $( '.popup .concierge-register-step2-container' ).html( Constants.registerstep2 );
        $( '.concierge-register-step2-container .form-container'  ).prepend(imageHtml);

        // element
        var component = $( '.popup .concierge-register-step2-container' );

        // variables
        var CRstep2Wrapper = component.find( '.concierge-register-step-2-wrapper' );
        var profileImgContainer = component.find( '.profile-img-container' );
        var CRstep2Submit = component.find( '#concierge-register-step2-submit' );
        var registerConfirm = component.find( '.concierge-register-confirm' );
        var backBtn = component.find( '.back' );
        var goToHomepageBtn = component.find( '.goToHomepage' );
        var errorLabel;
        var selectedImg;
        var globalValues = {};

        // events
        profileImgContainer.click( profileImgClicked );
        CRstep2Submit.click( conciergeRegisterStep2Submit );
        backBtn.click( cancelRegister );
        goToHomepageBtn.click( goToHomepage );

        render();
        // functions
        function render() {
            globalValues.parentView = options.parentView ? options.parentView : {};
            globalValues.formData = options.formData ? options.formData : {};
            globalValues.userName = options.userName ? options.userName : '';
        }

        function profileImgClicked( e ) {
            e.preventDefault();

            profileImgContainer.removeClass( 'selected' );
            $( e.currentTarget ).addClass( 'selected' );
        }

        function conciergeRegisterStep2Submit( e ) {
            e.preventDefault();
            errorLabel = component.find( 'label.error' );
            errorLabel.remove();
            selectedImg = component.find( '.profile-img-container.selected' );

            if ( selectedImg && selectedImg.length > 0 ) {
                globalValues.formData.conciergeImageId = selectedImg.attr( 'profile-img-id' );
                conciergeRegister(globalValues.formData);
            } else {
                $( '<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.profileImageNotSelected + '</label>' ).insertBefore( '.concierge-register-step-2-wrapper .form-container' );
            }
        }

        function conciergeRegister( postData ) { 

            var path = '/vpp-backend/v1/concierge/register';
            console.log(postData);
             $.ajax( {
             	type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify( postData ),
                success: function( result ) {
                    if ( result.status != undefined && result.status.statusCode === '200' ) {
                        successCallback( result );
                    } else {
                        failureCallback( result );
                    } 
                },
                 error: function(result) {
                    failureCallback(result);
                }
                
                });


        }

        function successCallback( data ) {
            CRstep2Wrapper.hide();
            registerConfirm.show();
        }

        function failureCallback( data ) {
            $( '<label class="systemError error" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>' ).insertBefore( '.concierge-register-step-2-wrapper .form-container' );
        }

        function goToHomepage() {
            var userLoginInfo = {
                'userName': globalValues.userName,
                'password': globalValues.formData.password,
                'concgImgId': globalValues.formData.conciergeImageId
            };
            conciergeLogin(userLoginInfo);
        }

         function conciergeLogin( postData ) {           
            var path = '/vpp-backend/v1/concierge/login';
            console.log(path);
             $.ajax( {
             	type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify( postData ),
                success: function( result ) {
                    console.log("success" + result.status.statusCode);
                    if ( result.status != undefined  ) { 

                        conciergesuccessCallback(result);
                    } else {
                       failureCallback( result);
                    } 
                }
                });


        }

         function conciergesuccessCallback( data ) {             
             var cpath=$('#wrapper').find('#currentPagePath').val();
			 if (data.status != undefined
							&& data.status.statusCode === '200'
							&& data.response.userId !== null
								&& data.response.userId !== "") {

				 $.ajax({
					 type: "GET",
					 url: "/bin/conciergeLandingRedirection", 
					 data: {currentPagePath : cpath,
								id : data.response.userId,
								firstName : data.response.firstName
						   },
					 success: function(result){ 
							location= result; 
						}
					});
			}
        }
        function cancelRegister( e ) {
            e.preventDefault();

            globalValues.parentView.cancelRegister( e );
        }
    };

    return ConciergeRegisterStep2View;

} );