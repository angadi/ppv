define( [
    'jquery',
    'views/popups/ConciergeRegisterStep1View',
    'models/SessionObject',
    'utils/Constants',
    'select2'
], function( $, ConciergeRegisterStep1View, SessionObject, Constants ) {
    var ConciergeRegisterView = function( parentView, token ) {
        $( '.popup' ).html( Constants.registerContainer );
        // element
        var component = $( '.popup' );
        var popupBlock = $( '.popup_block' );
        var CRcontainer = component.find( '.concierge-register-container' );
        var CRstartContainer = component.find( '.concierge-register-start-container' );
        var CRstep1Container = component.find( '.concierge-register-step1-container' );
        var CRconfirm = component.find( '.concierge-register-confirm' );
        var registerBtn = component.find( '.register' );
        var closeBtn = component.find( '.closeBtn' );

        // events
        registerBtn.click( registerClicked );
        closeBtn.click( cancelRegister );

        render();
        // functions
        function render() {
            $( '.heroImageContainer .welcome-container' ).remove();
            $( 'ul .log-in' ).remove();
            $( '.slide-nav' ).remove();
            $( '.navbar-toggle' ).remove();

            parentView.pauseCarousel();
            component.show();
            popupBlock.show();
        }

        function validateConciergeRegisterToken( postData ) {
            var path = '/vpp-backend/v1/concierge/registerTokenValidation';
            	 $.ajax( {
             	type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify( postData ),
                success: function( result ) {
                    if ( result.status != undefined && result.status.statusCode === '200' ) {
                        successCallback( result.response );
                    } else {
                        failureCallback( result.response );
                    } 
                }
                });

        }

        function registerClicked( e ) {
            e.preventDefault();
            var postData = {};
            postData.token = token;

            validateConciergeRegisterToken( postData );
        }

        function successCallback( data ) {
            var parentView = {};
            CRcontainer.removeClass( 'register-start' );
            CRcontainer.find( '.closeBtn' ).show();
            CRstartContainer.hide();
            ConciergeRegisterStep1View( parentView, data, token );
        }

        function failureCallback() {
            tokenErrorMsg = component.find( '#token-error-msg' );
            tokenErrorMsg.html( Constants.errorMsg.registrationTokenInvalid );
            tokenErrorMsg.show();
        }

        function cancelRegister( e ) {
             location.reload();
        }

        function closeChildren() {
            CRcontainer.addClass( 'register-start' );
            CRstartContainer.show();
        }
    };

    return ConciergeRegisterView;

} );