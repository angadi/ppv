define([
    'jquery',
    'validations/ResetPasswordValidation',
    'models/SessionObject',
    'utils/Constants',
    'jquery.validate',
    'jquery.placeholder'
], function($, ValidationSettings, SessionObject, Constants) {

    var ResetPasswordView = function(parentView, token) {


        var component = $('.popup');
        var popupBlock = $('.popup_block');
        var resetpasswordcontainer = component.find(".reset-password-container");

        // variables
        var closeBtn = resetpasswordcontainer.find('a.closeBtn');
        var cancel = resetpasswordcontainer.find('a.cancel');
        var resetpwdSubmit = resetpasswordcontainer.find('#reset-password-submit');
        var inputPwd = resetpasswordcontainer.find('input#password');
        var form = resetpasswordcontainer.find('form');

        render();

        closeBtn.click(closePopup);
        cancel.click(closePopup);
        resetpwdSubmit.click(submitResetPassword);
        closeBtn.blur(circleInPopup);
        inputPwd.keydown(focusToCloseBtn);




        function circleInPopup(e) {
            $(resetpasswordcontainer).find('#password').focus();
        }

        function focusToCloseBtn(e) {
            if (e.which === 9) {
                if (e.shiftKey === true) {
                    $(resetpasswordcontainer).find('a.closeBtn').focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function render() {

            var $form = $(resetpasswordcontainer).find('form');
            parentView.pauseCarousel();
            $(resetpasswordcontainer).find('input, textarea').placeholder();
            $form.validate(ValidationSettings);
            resetpasswordcontainer.show();
            popupBlock.show();

            //wcag:
            //_.defer(function(){
            $(resetpasswordcontainer).find('input#password').focus();
            //});


        }

        function submitResetPassword(e) {
            e.preventDefault();

            if ($(e.currentTarget).hasClass('grey-out')) {
                return false;
            }
            var $form = $(resetpasswordcontainer).find('form');

            $(resetpasswordcontainer).find('label.error').remove();
            $(resetpasswordcontainer).find('.form-control').removeClass('error');

            //manually check if any required field empty
            var $missingFields = $form.find('.form-control:not(.select2-container,select,:hidden).required:blank');
            if ($missingFields.length > 0) {
                $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>').insertBefore('#password');
                $missingFields.addClass('error');
            } else {
                if ($form.valid()) {
                    $form.find('#reset-password-submit').addClass('grey-out');

                    var data = {
                        'token': token,
                        'newPassword': $('#confirmPassword').val()
                    }
                    //SessionObject.resetPasswordSubmit(data, resetPasswordSuccessCallback, resetPasswordFailureCallback);
                    resetPasswordSubmit(data, resetPasswordSuccessCallback, resetPasswordFailureCallback);
                }
            }
        }

        function resetPasswordSubmit(postData, successCallback, failureCallback) {

            var path = '/vpp-backend/v1/cnb/infinite/pwReset/changePassword';

            $.ajax({
                type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(postData),
                success: function(result) {
                    if (result.status != undefined && result.status.statusCode === '200') {
                        resetPasswordSuccessCallback(result);
                    } else {
                        resetPasswordFailureCallback(result);
                    }
                },
                error: function(result) {
                    resetPasswordFailureCallback(result);
                }
            });
        }

        function resetPasswordSuccessCallback(data) {
            $(resetpasswordcontainer).find('#reset-password-submit').removeClass('grey-out');

            $(resetpasswordcontainer).find('.reset-password-wrapper').hide();
            $(resetpasswordcontainer).find('.reset-password-confirm-wrapper').show();
        }

        function resetPasswordFailureCallback(data) {
            $(resetpasswordcontainer).find('#reset-password-submit').removeClass('grey-out');

            $(resetpasswordcontainer).find('#confirmPassword').closest('.form-group').after('<label class="systemError" style="display: inline-block;" aria-live="polite">' + data.message + '</label>');
        }

        function closePopup(e) {
            e.preventDefault();
            parentView.resumeCarousel();
            component.html('');
            component.hide();
            popupBlock.hide();
            window.location.hash = '#';

        }
    };

    return ResetPasswordView;

});