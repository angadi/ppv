define([
    'jquery',
    'validations/ForgotPasswordSecurityQValidation',
    'views/popups/ResetPasswordView',
    'models/SessionObject',
    'utils/Constants',
    'jquery.validate',
    'jquery.placeholder',
    'select2'
], function($, ValidationSettings, ResetPasswordView, SessionObject, Constants) {

    var ForgotPasswordSecurityQView = function(quesData, parentView, token) {
        //element
        $('.popup').html(Constants.resetpassword);

        var component = $('.popup');
        var popupBlock = $('.popup_block');

        // variables
        var closeBtn = component.find('a.closeBtn');
        var cancel = component.find('a.cancel');
        var securityQSubmit = component.find('#security-questions-submit');
        var inputSecQ = component.find('input#s2id_securityQ');
        var form = component.find('form');
        var qdata = quesData;
        var parentView = parentView;

        render(qdata);

        closeBtn.click(closePopup);
        cancel.click(closePopup);
        securityQSubmit.click(submitSecurityQ);
        closeBtn.blur(circleInPopup);
        inputSecQ.keydown(focusToCloseBtn);
        // events: {
        //   'click a.cancel': 'closePopup',
        //   'click a.closeBtn': 'closePopup',
        //   'click #security-questions-submit': 'submitSecurityQ',

        //   'blur a.closeBtn': 'circleInPopup',
        //   'keydown input#s2id_securityQ': 'focusToCloseBtn'
        // },

        function circleInPopup(e) {
            $('#s2id_securityQ').focus();
        }

        function focusToCloseBtn(e) {
            if (e.which === 9) {
                if (e.shiftKey === true) {
                    $('a.closeBtn').focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function render(qdata) {

            parentView.pauseCarousel();
            $('input, textarea').placeholder();
            form.validate(ValidationSettings);
            component.show();
            popupBlock.show();

            // var data = {};
            // data.questions = questions;

            // _.extend(data, SessionObject); 

            // var template = _.template($(forgotPasswordSecurityQTemplate).html());
            // this.$el.html(template(data));
            var optionQ = '';
            optionQ += '<option value=""></option>';
            $.each(qdata, function(index, item) {
                optionQ += '<option value="' + item.questionId + '">' + item.questionText + '</option>';
            });
            $('select#securityQ').append(optionQ);

            $(component).find('select').select2({
                placeholder: $('#securityQ').siblings('label').html(),
                dropdownParent: $('.form-group'),
                minimumResultsForSearch: -1
            });


            //wcag:
            //_.defer(function(){
            $('input#s2id_securityQ').focus();
            //});

        }

        function submitSecurityQ(e) {
            e.preventDefault();
            var $form = form;

            if ($(e.currentTarget).hasClass('grey-out')) {
                return false;
            }

            $('label.error').remove();
            $('.form-control').removeClass('error');
            $('#s2id_securityQ a.select2-choice').removeClass('error');

            //manually check if any required field empty
            var $missingFields = $form.find('.form-control:not(.select2-container,select,:hidden).required:blank');
            //check select2
            if (!$form.find('#s2id_securityQ').select2('data')) {
                $missingFields.push($('#s2id_securityQ a.select2-choice')[0]);
            }
            if ($missingFields.length > 0) {
                $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.required + '</label>').insertBefore('#s2id_securityQ');
                $missingFields.addClass('error');
            } else {
                if ($form.valid()) {
                    $form.find('#security-questions-submit').addClass('grey-out');

                    var data = {
                        'token': token,
                        'questionId': $('#s2id_securityQ').select2('data').id,
                        'questionAnswer': $('#securityQ_answer').val()
                    };
                    //SessionObject.forgotPasswordSecurityQSubmit(data, forgotPasswordSecurityQSuccessCallback, forgotPasswordSecurityQFailureCallback);
                    forgotPasswordSecurityQSubmit(data, forgotPasswordSecurityQSuccessCallback, forgotPasswordSecurityQFailureCallback);
                }
            }
        }

        function objectToString(obj) {
            var str = '';
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    str += key + '=' + obj[key] + '&';
                }
            }
            str = str.substring(0, str.length - 1);
            return str;
        }

        function forgotPasswordSecurityQSubmit(postData, successCallback, failureCallback) {

            var path = '/vpp-backend/v1/cnb/infinite/pwReset/validateAnswer';

            $.ajax({
                type: "POST",
                url: path,
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(postData),
                success: function(result) {
                    if (result.status != undefined && result.status.statusCode === '200') {
                        forgotPasswordSecurityQSuccessCallback(result, postData.token);
                    } else {
                        forgotPasswordSecurityQFailureCallback(result);
                    }
                },
                error: function(result) {
                    forgotPasswordSecurityQFailureCallback(result);
                }
            });
        }

        function forgotPasswordSecurityQSuccessCallback(data) {
            console.log('forgot password security q succeed;')

            form.find('#security-questions-submit').removeClass('grey-out');

            // var resetPasswordView = new ResetPasswordView({parentView: self});
            // childView = resetPasswordView;
            ResetPasswordView(parentView, token);

            $('.forgot-password-container').hide();
            $('.reset-password-container').show();
        }

        function forgotPasswordSecurityQFailureCallback(data) {
            console.log('forgot password security q failed;')

            form.find('#security-questions-submit').removeClass('grey-out');

            $('#securityQ_answer').closest('.form-group').after('<label class="systemError error" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.forgotPasswordSecurityAnswerNotMatch + '</label>');
        }

        function closePopup(e) {
            e.preventDefault();
            parentView.resumeCarousel();
            component.html('');
            component.hide();
            popupBlock.hide();

            //Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: false});
        }

        function onClose() {
            // if(this.childView) {
            //   this.childView.close();
            //   this.childView = null;
            // }
        }

    };

    return ForgotPasswordSecurityQView;

});