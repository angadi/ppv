define([
  'jquery',
  'validations/ForgotPasswordValidation',
  'models/SessionObject',
  'utils/Constants',
  'jquery.validate',
  'jquery.placeholder'
], function($, ValidationSettings, SessionObject, Constants){

  var ForgotPasswordView = function(parentView){
    $('.popup').html(Constants.forgotpassword);

    // element
    var component = $('.popup');
    var popupBlock = $('.popup_block');
    var forgotpassword = $(component).find('.forgot-password-container');

    var closePopupBtn = $(forgotpassword).find('a.cancel');
    var closePopupBtnSiblings = $(forgotpassword).next().find('a.cancel');
    var closeBtn = $(forgotpassword).find('a.closeBtn');
    var closeBtnSiblings = $(forgotpassword).next().find('a.closeBtn');
    var submitBtn = $(forgotpassword).find('.submitBtn');
    var inputEmail = $(forgotpassword).find('input.email-input');
    var form = $(forgotpassword).find('form');


    closePopupBtn.click(closePopup);
    closePopupBtnSiblings.click(closePopup);
    closeBtn.click(closePopup);
    closeBtn.keydown(closeBtnKeydown);
    closeBtn.blur(circleInPopup);
    closeBtnSiblings.click(closePopup);
    closeBtnSiblings.keydown(closeBtnKeydown);
    closeBtnSiblings.blur(circleInPopup);
    submitBtn.click(submitSignIn);
    inputEmail.keydown(focusToCloseBtn);

    render();
    // events: {
    //   'click a.cancel': 'closePopup',
    //   'click a.closeBtn': 'closePopup',
    //   'keydown a.closeBtn': 'closeBtnKeydown',
    //   'click .submitBtn': 'submitSignIn',
    //   'blur a.closeBtn': 'circleInPopup',
    //   'keydown input.email-input': 'focusToCloseBtn'
    // },

    // initialize: function(options) {
    //   this.parentView = options.parentView;
    // }

    function circleInPopup(e) {
     inputEmail.focus();
    }

    function focusToCloseBtn(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              $('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }

    function render(){

      // var data = {};
      // _.extend(data, SessionObject); 

      // var template = _.template($(forgotPasswordTemplate).html());
      // this.$el.html(template(data));

      //this.parentView.pauseCarousel();
      parentView.pauseCarousel();
      component.show();
      popupBlock.show();
      $('input, textarea').placeholder();
      form.validate(ValidationSettings);
      inputEmail.focus();;

    }

    function submitSignIn(e) {
      e.preventDefault();

      //$('.form-control').removeClass('error');
      $('label.error').remove();

      // if(!this.$('#email').val()) {
      //    $('<label id="email-error" class="error required-missing" for="email" style="display: inline-block;">'+Constants.errorMsg.required'</label>').insertBefore('#email');
      //    this.$('#email').addClass('error');
      // }
      // else {


        if(form.valid()) {
          var userInfo = {
            "userName" : inputEmail.val(),
			 "templateType":"concierge_reset_password_template"

          };
	   	    var path = '/vpp-backend/v1/concierge/forgetPassword';
                //var path = '/vpp-backend/v1/email/sendEmail';
				$.ajax({
                                      type: "POST",
                                      url: path, 
                                      dataType: "json",
                                      async:false,
                                      contentType: "application/json; charset=utf-8",
                    				  data:JSON.stringify(userInfo),
                                      success: function(result){
                                    	  if(result.status!=undefined && result.status.statusCode === '200'){
                                    		  successCallback();
                                          } else{
											  successCallback();
                                          }
                                      }
                });
          //SessionObject.forgotPasswordUsernameSumbit(userInfo, this.successCallback, this.failureCallback, this);
          forgotPasswordUsernameSumbit(userInfo, successCallback, failureCallback);
        }
      // }
    }

     function forgotPasswordUsernameSumbit( postData, successCallback, failureCallback ) {
          //var path = '../user/initResetPassword.do';

          //var postingData = 'userName=' + encodeURIComponent( postData.username );


          // $.post( path, postingData, function( data ) {

          //     if ( data.status === Constants.apiStatus.OK ) {
          //         successCallback( data, self );
          //     } else {
          //         failureCallback( data.errorMsg, self );
          //     }

          // } );
          successCallback();
      }

    function successCallback(data) {
      $('.forgot-password-container').hide();
      $('.confirmation-container').show();
    }

    function failureCallback(data) {
    }

    function closeBtnKeydown(e) {  
      if(e.keyCode === 13) {
        closePopup(e);
      }
    }

    function closePopup(e) {
      //debugger;
      //e.preventDefault();
      parentView.resumeCarousel();
      popupBlock.hide();
      component.hide();
      component.empty();
      //close();

      // if(SessionObject.prevFocus) {
      //   $('.'+ SessionObject.prevFocus).focus();
      // }

      // Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: false});
    }
    
  };

  return ForgotPasswordView;
  
});

