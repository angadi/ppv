define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/forgotUsernameTemplate.html',
  'validations/ForgotUsernameValidation',
  'models/SessionObject',
  'utils/Constants',
  'jquery.validate',
  'jquery.placeholder'
], function($, _, Backbone, forgotUsernameTemplate, ValidationSettings, SessionObject, Constants){

  var ForgotUsernameView = Backbone.View.extend({
    el: '.popup',

    events: {
      'click a.closeBtn': 'closePopup',
      'keydown a.closeBtn': 'closeBtnKeydown',
      'click .submitBtn': 'submitSignIn',
      'click a.cancel': 'closePopup',
      'blur a.closeBtn': 'circleInPopup',
      'keydown input#email': 'focusToCloseBtn'
    },

    initialize: function(options) {
      this.parentView = options.parentView;
    },

    circleInPopup: function(e) {
      this.$('input#email').focus();
    },
    focusToCloseBtn: function(e) {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              this.$('a.closeBtn').focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    },
    render: function(){

      var data = {};
      _.extend(data, SessionObject); 

      var template = _.template($(forgotUsernameTemplate).html());
      this.$el.html(template(data));

      this.parentView.pauseCarousel();

      this.$('input, textarea').placeholder();

      this.$form = this.$el.find('form');
      this.$form.validate(ValidationSettings);

      var that = this;
      //wcag:
      _.defer(function(){
        that.$('input#email').focus();
      });

      return this;

    },

    submitSignIn: function(e) {
      e.preventDefault();

      var that = this;

      this.$('label.error').remove();
      this.$('.form-control').removeClass('error');
      //manually check if any required field empty
      var $missingFields = this.$('form').find('.form-control:not(.select2-container,select).required:blank');
      if($missingFields.length > 0) {

        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.required+'</label>').insertBefore('#email');
        $missingFields.addClass('error');

        $missingFields.first().focus();
      }
      else {
        if(this.$('form').valid()) {

          this.$('.forgot-password-container').hide();
          this.$('.confirmation-container').show();

          var userEmail = {
            'email' : this.$('#email').val(),
            'last4Pan' : this.$('#last4Pan').val()
          }

          SessionObject.forgotUsernameSubmit(userEmail, this.successCallback, this.failureCallback);
        } 
      }
    },

    successCallback: function(data) {
      
    },

    failureCallback: function(response) {
     
    },

    closeBtnKeydown: function(e) {  
      if(e.keyCode === 13) {
        this.closePopup(e);
      }
    },
    closePopup: function(e) {
      e.preventDefault();

      
      this.parentView.resumeCarousel();
      

      this.close();

      if(SessionObject.prevFocus) {
        $('.'+ SessionObject.prevFocus).focus();
      }
      
      Backbone.history.navigate($(e.currentTarget).attr('href'), {trigger: false});
     
    }
    
  });

  return ForgotUsernameView;
  
});
