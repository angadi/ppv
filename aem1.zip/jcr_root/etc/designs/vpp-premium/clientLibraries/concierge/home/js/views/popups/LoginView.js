define( [
    'jquery',
    'validations/LoginValidation',
    'views/popups/ConciergeLoginStep2View',
    'models/SessionObject',
    'utils/Constants',
    'jquery.validate',
    'jquery.placeholder'
], function( $, ValidationSettings, ConciergeLoginStep2View, SessionObject, Constants ) {
    var loginFails = 0;
    var LoginView = function(parentView) {
        $('.popup').html(Constants.login);
        // element
        var component = $('.popup');
        var popupBlock = $('.popup_block');

        // variables
        var loginContainer = component.find('.login-step1-container');
        var loginForm = component.find( 'form' );
        var closeBtn = component.find('a.closeBtn');
        var cancel = component.find('a.cancel');
        var submitBtn = component.find('.submitBtn.login-submitBtn');
        var emailInput = component.find('input.email-input');
        var loginErrorMsg;
        var password;
        var userLoginInfo;
        var globalVariables = {};

        // events
        closeBtn.click(closePopup);
        closeBtn.keydown(closeBtnKeydown);
        closeBtn.blur(circleInPopup);
        cancel.click(closePopup);
        submitBtn.click(submitSignIn);
        emailInput.keydown(focusToCloseBtn);

        render();
        // functions
        function render() {
            parentView.pauseCarousel();
            $( 'input, textarea' ).placeholder();
            loginForm.validate( ValidationSettings );
            component.show();
            popupBlock.show();
            component.find( '.login-step1-container .popup-title' ).focus();
        }

        function circleInPopup( e ) {
            emailInput.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function removeErrorMsg( e ) {
            loginErrorMsg = $( '#login-error-msg' );
            if ( loginFails < 4 )
                loginErrorMsg.fadeOut();
            else
                loginErrorMsg.fadeOut( function() {
                    //loginErrorMsg.html( SessionObject.bankConfig.EXCEED_LOGIN_ATTEMPT_ERROR );
                    loginErrorMsg.html( "Exceed Login Attempts" );
                } );
        }

        function submitSignIn( e ) {
            e.preventDefault();
            removeErrorMsg();
            if ( loginForm.valid() ) {
                userLoginInfo = {
                    'userName': $( '.email-input' ).val().trim(),
                    'password': $( '#password' ).val()
                };
                globalVariables.formData = userLoginInfo;
                verifyConcierge( userLoginInfo );
            }
        }

        function verifyConcierge( postData ) {
            var path = '/vpp-backend/v1/concierge/login';

           

             $.ajax({
                                      type: "POST",
                                      url: path, 
                                      dataType: "json",
                                      async:false,
                                      contentType: "application/json; charset=utf-8",
                                      data: JSON.stringify(postData),
                                      success: function(result){
                                          if(result.status!=undefined && result.status.statusCode === '200' && result.response.userId !== null && result.response.userId!==""){
											conciergeSuccessCallback( result.response);
                                          }else{
											failureCallback(result);

                                          }

                                      }
                });




        }

        function conciergeSuccessCallback( data ) {
            loginContainer.hide();
            globalVariables.formData.userId = data.userId;
            globalVariables.formData.firstName= data.firstName;
             


            var options = {
                parentView: { closePopup: closePopup},
                formData : globalVariables.formData,
                concgImgs: data.conciegeImages
            };
           /* self.childView = new ConciergeLoginStep2View( { parentView: self, formData: self.formData, concgImgs: data.concgImg } );
            self.childView.render();*/
            ConciergeLoginStep2View(options);
        }

        function successCallback( data ) {
            location = data.redirectUrl;
        }

        function failureCallback( response, self ) {

            component.find( '.form-control.required' ).removeClass( 'valid' ).addClass( 'error' );
            loginErrorMsg = $( '#login-error-msg' );
            if ( loginFails < 3 ) {
                loginErrorMsg.html( Constants.errorMsg.emailLoginFailed );
            }
            loginErrorMsg.fadeIn();
            emailInput.focus();
            loginFails = loginFails + 1;

        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                closePopup( e );
            }
        }

        function closePopup( e ) {
            //e.preventDefault();
            parentView.resumeCarousel();
            component.html('');
            component.hide();
            popupBlock.hide();
            //close();

            /*if ( SessionObject.prevFocus ) {
                $( '.' + SessionObject.prevFocus ).focus();
            }

            Backbone.history.navigate( $( e.currentTarget ).attr( 'href' ), { trigger: false } );*/
        }
    };

    return LoginView;

} );