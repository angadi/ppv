define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/registerEmailPrefTemplate.html',
  'models/SessionObject',
  'utils/Constants',
], function($, _, Backbone, registerEmailPrefTemplate, SessionObject, Constants){

  var RegisterEmailPrefView = Backbone.View.extend({
    el: '.popup .email-pref-container',

    initialize: function(options) {
      this.parentView = options.parentView;
    },
    events: {  
      'click .checkbox-label' : 'checkboxClicked',
      'keydown .checkbox-label' : 'checkboxKeydown',

      'click .not-now': 'selfLoginWithoutSave',
      'click #email-pref-submit': 'selfLoginWithSave',

      'blur a.closeBtn': 'circleInPopup'
      // 'keydown input#pan': 'focusToCloseBtn'
    },
   
    circleInPopup: function(e) {
      this.$('.checkbox-label').first().focus();
    },
    focusToCloseBtn: function(e) {
      if (e.which === 9) {
        if(e.shiftKey === true)
        {
            this.parentView.parentView.$('.closeBtn').focus();
        }
        else
        {
            // User is tabbing forward
        }
      }
    },

    render: function(){
      SessionObject.getEmailPrefs(function(response, self) {
        var data = {};
        data.emailPrefs = response;
        _.extend(data, SessionObject); 

        var template = _.template($(registerEmailPrefTemplate).html());
        self.$el.html(template(data));

        self.$('input[type=checkbox]').addClass('input_hidden');

        self.$('input, textarea').placeholder();

        self.parentView.parentView.$('.closeBtn').bind('click', function(e) {
          if($(e.currentTarget).hasClass('grey-out')) {
            return false;
          }
          self.selfLoginWithoutSave(e);
        });

        //wcag:
        _.defer(function(){
          self.$('.checkbox-label').first().focus();
        });

      }, this);

      return this;

    },

    checkboxClicked: function(e) {
      if($(e.target).hasClass('popup-link')) {

      }

      else {
        e.preventDefault();

        $(e.currentTarget).toggleClass('selected');

        if($(e.currentTarget).hasClass('selected')) {
          $(e.currentTarget).attr('aria-checked', 'true');
        }
        else {
          $(e.currentTarget).attr('aria-checked', 'false');
        }
      }
    },

    checkboxKeydown: function(e) {
      if ( e.which == 32 ) {
        this.checkboxClicked(e);
      }
      else if (e.which === 9 && $(e.currentTarget).closest('.form-group').index()===0) {
        if(e.shiftKey === true)
        {
            this.parentView.parentView.$('.closeBtn').focus();
        }
        else
        {
            // User is tabbing forward
        }
      }
    },

    selfLoginWithoutSave: function(e) {
      e.preventDefault();

      if($(e.currentTarget).hasClass('grey-out')) {
        return false;
      }

      this.$('#email-pref-submit').addClass('grey-out');
      this.$('.not-now').addClass('grey-out');
      this.parentView.parentView.$('.closeBtn').addClass('grey-out');

      var userLoginInfo = {
          'email' : this.parentView.parentView.$('#email').val(),
          'password' : this.parentView.parentView.$('#password').val(),
      }
      var self = this;
      SessionObject.login(userLoginInfo, 
        function(data){
          location = data.redirectUrl
        }, 
        function(){
          self.failureCallback({}, self)
        });
    },

    selfLoginWithSave: function(e) {
      e.preventDefault();

      this.$('.checkbox-label').removeClass('error');
      this.$('label.error').remove();

      // if(!this.$('label.additional').hasClass('selected')) {
      //   $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;">'+Constants.errorMsg.required+'</label>').insertBefore('.email-pref-form .form-group:first');
      //   this.$('label.additional').addClass('error');
      // }
      // else {
        if($(e.currentTarget).hasClass('grey-out')) {
          return false;
        }
        this.$('#email-pref-submit').addClass('grey-out');
        this.$('.not-now').addClass('grey-out');
        this.parentView.parentView.$('.closeBtn').addClass('grey-out');

        var subscribeIdList = '';

        for(var i=0; i<this.$('.form-group label').length; ++i) {

          var $item = this.$('.form-group label').eq(i);

          if($item.hasClass('selected')) {
            subscribeIdList += $item.find('input').attr('id');

            if(i === this.$('.form-group label').length-1) {}
            else {
              subscribeIdList += ',';
            } 
          }
        }

        var data = {
          username: this.parentView.parentView.$('#email').val(),
          subscribeIdList: subscribeIdList
        };
        SessionObject.registerStep3(data, this.successCallback, this.failureCallback, this);
      // }
    },

    successCallback: function(data, self) {
      var userLoginInfo = {
          'email' : self.parentView.parentView.$('#email').val(),
          'password' : self.parentView.parentView.$('#password').val(),
      }
      SessionObject.login(userLoginInfo, 
        function(data){
          location = data.redirectUrl
        }, 
        function(){
          self.failureCallback({}, self)
        }, self);
    },

    failureCallback: function(data, self) {
      self.$('#email-pref-submit').removeClass('grey-out');
      self.$('.not-now').removeClass('grey-out');
      self.parentView.parentView.$('.closeBtn').removeClass('grey-out');

      self.$('.form-group:last').after('<label class="systemError" style="display: inline-block;" aria-live="polite">' + Constants.errorMsg.generalError + '</label>');
    },

    onClose: function() {

      if(this.childView) {
        this.childView.close();
      }

      if(SessionObject.prevFocus) {
        $('.' + SessionObject.prevFocus).focus();
      }
    }
    

  });

  return RegisterEmailPrefView;
  
});
