define([
  'jquery',
  'underscore',
  'backbone',
  'text!templates/popups/registerTemplate.html',
  'views/popups/RegisterSecurityQuestionsView',
  'models/SessionObject',
  'validations/RegistrationValidation',
  'utils/Constants',
  'select2',
  'jquery.maskedinput'
], function($, _, Backbone, registerTemplate, RegisterSecurityQuestionsView, SessionObject, ValidationSettings, Constants){

  var RegisterView = Backbone.View.extend({
    el: '.popup',

    initialize: function(options) {
      this.parentView = options.parentView;
      this.countErrorTimes = 0;
    },
    events: {  
      'click #create-profile-submit': 'createProfileSubmit',
      'blur a.closeBtn': 'circleInPopup',
      'keydown a.closeBtn': 'closeBtnKeydown',
      'keydown input#pan': 'focusToCloseBtn',
      'blur input#pan': 'maskInput',
      'focus input#pan': 'unmaskInput',

      'change #country' : 'countryChangeHandler',

      'focus #password': 'tooltipFocused',
      'blur #password': 'tooltipFocusedOut',

      'focus #city': 'tooltipFocused',
      'blur #city': 'tooltipFocusedOut'
    },
   
    circleInPopup: function(e) {
      if(this.$('input#pan:visible') && this.$('input#pan:visible').length > 0) {
        this.$('input#pan').focus();
      }
      else if(this.$('#securityQuestionId1:visible') && this.$('#securityQuestionId1:visible').length > 0) {
        this.$('#securityQuestionId1').select2('focus');
      }
      else if(this.$('.email-pref-form:visible') && this.$('.email-pref-form:visible').length > 0) {
        this.$('.email-pref-form:visible').find('.checkbox-label').first().focus();
      }
    },
    focusToCloseBtn: function(e) {
      if (e.which === 9) {
        if(e.shiftKey === true)
        {
            this.$('a.closeBtn').focus();
        }
        else
        {
            // User is tabbing forward
        }
      }


    },

    maskInput: function(e) {
      var pan = $('#pan').val().trim();
      this.originalPan = pan;
      $('#pan_copy').val(pan);

      var toRet = '';
      for(var i=0; i<pan.length; ++i) {
        if(i>=15) {
          toRet += pan[i];
        }
        else {
          if(pan[i] !== ' ') {
            toRet += '\u25CF';
          }
          else {
            toRet += ' ';
          }
        }
      }

      $('#pan').val(toRet);

    },

    unmaskInput: function(e) {
      if(this.originalPan) {
        $(e.currentTarget).val(this.originalPan);
      }
    },

    render: function(){

      var data = {};
      _.extend(data, SessionObject, Constants); 

      var template = _.template($(registerTemplate).html());
      this.$el.html(template(data));

      //mask pan 
      $.mask.definitions['n'] = "[0-9\u25CF]"
      this.$('#pan').mask('?nnnn nnnn nnnn nnnn', {placeholder: " "});

      this.parentView.pauseCarousel();

      // this.$('[data-toggle="popover"]').popover({html: true}); 
      this.$('.city-tooltip').popover({html: true}).data('bs.popover').tip().addClass('city-popover');
      this.$('.password-tooltip').popover({html: true}); 

      this.$('input, textarea').placeholder();

      this.$form = this.$el.find('.create-profile-form');
      
      this.addDynamicMessageForValidator(ValidationSettings);
      this.$form.validate(ValidationSettings);

      this.loadCountries();

      var that = this;
      //wcag:
      _.defer(function(){
        that.$('.create-profile-container .popup-title').focus();
      });

      return this;

    },

    loadCountries : function() {
      var $countrySelect  = this.$('select#country');

      var countryOption = '';

      $.getJSON(Constants.countriesJsonPath, function(countries) {
        countryOption += '<option value=""></option>';

        $.each(countries, function(index, country) {
          countryOption += '<option value="' + country.name + '">' + country.name + '</option>';
        });
        
        $countrySelect.append(countryOption);

        $countrySelect.select2({
          dropdownParent: $('.form-group'),
          matcher: function(term, text) {
            if (text.toUpperCase().indexOf(term.toUpperCase()) == 0) {
              return true;
            }
           
            return false;
          }
        }).select2('val', 'United States');
      })
      .error(function(xhr) {
      });
      
    },

    countryChangeHandler: function(e) {
      var id = $(e.currentTarget).select2('data').id;

      this.$('#zip').val('');
      this.$('#city').val('');

      if(id === 'United States') {
        this.$('.zip-field').removeClass('hidden');
        this.$('.city-field').addClass('hidden');

        this.$('#zip').rules('remove', 'maxlength');
        this.$('#zip').rules('add', {
          required: true,
          maxlength: 5,
          digits: true,
          messages: {
            required: Constants.errorMsg.required,
            maxlength: Constants.errorMsg.billingInfoNotMatch,
            digits: Constants.errorMsg.billingInfoNotMatch
          }
        });

      }
      else if(id === 'Canada') {
        this.$('.zip-field').removeClass('hidden');
        this.$('.city-field').addClass('hidden');

        this.$('#zip').rules('remove', 'digits');
        this.$('#zip').rules('remove', 'maxlength');
        this.$('#zip').rules('add', {
          required: true,
          maxlength: 6,
          messages: {
            required: Constants.errorMsg.required,
            maxlength: Constants.errorMsg.billingInfoNotMatch
          }
        });
      }
      else {
        this.$('.zip-field').addClass('hidden');
        this.$('.city-field').removeClass('hidden');
      }
      
    },

    createProfileSubmit: function(e) {
      e.preventDefault();

      this.$('label.error').remove();
      this.$('.form-control').removeClass('error');
      this.$form.find('#s2id_country a.select2-choice').removeClass('error');

      //manually check if any required field empty
      var $missingFields = this.$form.find('.form-control:not(.select2-container).required:blank');

      if(!this.$form.find('.zip-field').hasClass('hidden')) {
        var $zip = this.$form.find('.zip-field').find('input');
        if($zip.val().trim()) {}
        else {
          $missingFields.push($zip[0]);
        }
      }
      if(!this.$form.find('.city-field').hasClass('hidden')) {
        var $city = this.$form.find('.city-field').find('input');
        if($city.val().trim()) {}
        else {
          $missingFields.push($city[0]);
        }
      }

      if($missingFields.length > 0) {

        $('<label id="fields-error" class="error required-missing" for="fields" style="display: inline-block;" aria-live="polite">'+Constants.errorMsg.required+'</label>').insertBefore('#pan');
        $missingFields.addClass('error');

        $missingFields.first().focus();
      }

      else {
        if(this.$form.valid()) {  //check if any required form missing      
          var data = this.$form.serializeObject();

          data.pan = this.$('#pan_copy').val().replace(/ /g, ''); //serializeObject will encodeURIComponent, space will turn to %20

          SessionObject.registerStep1(data, this.successCallback, this.failureCallback, this);
        }
        else {
          if(this.$form.find('#firstname').hasClass('error') || this.$form.find('#lastname').hasClass('error')
            || this.$form.find('#zip').hasClass('error') || this.$form.find('#city').hasClass('error') || this.$form.find('#country').hasClass('error')) {

            this.$form.find('#firstname').removeClass('valid').addClass('error');
            this.$form.find('#lastname').removeClass('valid').addClass('error');
            this.$form.find('#zip:visible').removeClass('valid').addClass('error');
            this.$form.find('#s2id_country a.select2-choice').addClass('error');
            this.$form.find('#city:visible').removeClass('valid').addClass('error');
          }
          else {
            this.$form.find('#s2id_country a.select2-choice').removeClass('error');
          }
        }
      }
    },

    successCallback: function(data, self) {
      self.$('.create-profile-container').hide();

      if(self.$('.security-questions-wrapper') && self.$('.security-questions-wrapper').length>0) {

      }
      else {
        self.childView = new RegisterSecurityQuestionsView({parentView: self});
        self.childView.render();
      }
      
      self.$('.security-questions-container').show();
    },

    failureCallback: function(data, self) {

      var errorObj = data;

      for(var key in errorObj) {
        if(key === 'pan') {
          self.$('#pan').removeClass('valid').addClass('error');
          self.$('#pan').closest('.form-group').after('<label id="pan-error" class="error" for="pan" style="display: inline-block;" aria-live="polite">' + errorObj.pan + '</label>');
        }
        else if(key === 'billingInfo') {
          self.$('#firstname').removeClass('valid').addClass('error');
          self.$('#lastname').removeClass('valid').addClass('error');
          self.$('#zip').removeClass('valid').addClass('error');
          self.$('#s2id_country a.select2-choice').addClass('error');

          self.$('#country').closest('.form-group').after('<label id="fields-error" class="error" for="fields" style="display: inline-block;" aria-live="polite">' + errorObj.billingInfo + '</label>');
        }
        else if(key === 'email') {
          self.$('#email').removeClass('valid').addClass('error');
          self.$('#email').closest('.form-group').after('<label id="email-error" class="error" for="email" style="display: inline-block;" aria-live="polite">' + errorObj.email + '</label>');
        }
        else {

        }
      }
    },

    addDynamicMessageForValidator : function(validatorSettings) {
      var errorMsg = Constants.errorMsg.invalidCreditCard.replace(/\{cardName\}/, SessionObject.bankConfig.CARD_NAME);
      // validatorSettings.messages.pan.digits = errorMsg;
      validatorSettings.messages.pan.minlength = errorMsg;
      validatorSettings.messages.pan.maxlength = errorMsg;
    },

    tooltipFocused: function(e) {
      $(e.currentTarget).parent().find('[data-toggle="popover"]').popover('show');
    },
    tooltipFocusedOut: function(e) {
      $(e.currentTarget).parent().find('[data-toggle="popover"]').popover('hide');
    },

    closeBtnKeydown: function(e) {  
      if(e.keyCode === 13) {
        $(e.currentTarget)[0].click();
      }
    },

    onClose: function() {
      if(this.childView) {
        this.childView.close();
      }

      if(SessionObject.prevFocus) {
        $('.' + SessionObject.prevFocus).focus();
      }

    }
    

  });

  return RegisterView;
  
});
