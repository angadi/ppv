// Filename: app.js
define( [
    'jquery',
    'router', // Request router.js
    'utils/Constants',
    'jquery.validate'
], function( $, Router, Constants ) {
    var initialize = function() {
        Constants.concierge = $( '#v-concierge-carousel-content' ).html();
        Constants.newComment = $( '#new-comment' ).html();
        $( '#v-concierge-carousel-content' ).html( '' );
        $('#new-comment').remove();
        Router.initialize();
    };
    return {
        initialize: initialize
    };
} );