// Filename: main.js
require.config( {
    paths: {
        jquery: 'vendor/jquery/jquery-1.12.4.min',
        bootstrap: 'vendor/bootstrap/bootstrap',

        'jquery.validate': 'vendor/jquery/jquery.validate',
        'jquery.validate.additional-methods': 'vendor/jquery/additional-methods',

        // NON-AMD
        'select2': 'vendor/jquery/select2.min',
        'jquery.lazyload': 'vendor/lazyload/jquery.lazyload',
        'jquery.placeholder': 'vendor/jquery/jquery.placeholder',
        'jquery-ui': 'vendor/jquery/jquery-ui',
        'jquery-sessionTimeout': 'vendor/jquery/jquery.sessionTimeout',
        'ntpagetag': 'vendor/tracking/ntpagetag',
        'jquery.scrollbar': 'vendor/customize_scrollbar/jquery.mCustomScrollbar.min'
    },
    shim: {
        bootstrap: {
            deps: [ 'jquery' ]
        },
        'jquery.lazyload': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.lazyload'
        },
        'jquery.placeholder': {
            deps: [ 'jquery' ],
            exports: 'jQuery.fn.placeholder'
        },
        'jquery-ui': {
            deps: [ 'jquery' ]
        },
        'jquery-sessionTimeout': {
            deps: [ 'jquery', 'jquery-ui' ]
        },
        'select2': {
            deps: [ 'jquery' ]
        },
        'ntpagetag': {
            exports: 'ntpagetag'
        },
        'jquery.scrollbar': {
            deps: [ 'jquery' ]
        }
    }
} );

require( [
    'app',
    'jquery-sessionTimeout'
], function( App ) {
	$.ajaxSetup({ cache: false });
    App.initialize();
    if ( window.isConciergePortal ) {} else {
        $.sessionTimeout( {
            'warnAfter': 3000
        } );
    }

} );