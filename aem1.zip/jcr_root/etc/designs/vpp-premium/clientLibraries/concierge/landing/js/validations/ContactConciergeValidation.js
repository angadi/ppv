define([
  'jquery',
  'utils/Constants'
], function($, Constants){
	return {
		settings : {
			ignore: '.ignore',
			errorClass: 'error',
			rules: {
				name: {
					maxlength: Constants.validations.maxLength
				},
				email: {					
					multiEmail: true,
					maxlength: Constants.validations.maxLength,
					atMostTwoEmails: 2
				},
				emailBody: {
					required: true,
					minlength: 1,
					preventPossibleCreditCard: true
				}
			},
			onkeyup: false,
			onfocusout: false,
			messages: {
				name: {
					maxlength: Constants.errorMsg.nameMaxLengthExceeded
				},
				email: {
					multiEmail: Constants.errorMsg.emailListIncorrectFormat,
					maxlength: Constants.errorMsg.emailMaxLengthExceeded,
					atMostTwoEmails: Constants.errorMsg.emailListMaxExceeded
				},
				emailBody: {
					required: Constants.errorMsg.emailBodyMinLength,
					minlength: Constants.errorMsg.emailBodyMinLength,
					preventPossibleCreditCard: Constants.errorMsg.emailBodyNoCreditCardNumber
				}
			},
			errorPlacement: function(error, element) {
				element.parents('.concierge-container').find('.error-container .page-heading').html(error.html());					
			},
			invalidHandler: function(form, validator) {
		        var errors = validator.numberOfInvalids();
		        if (errors) {  			       
		            validator.errorList[0].element.focus();
		        }
		    },
			submitHandler: function(form) {
				
			}
		}
	};
});
