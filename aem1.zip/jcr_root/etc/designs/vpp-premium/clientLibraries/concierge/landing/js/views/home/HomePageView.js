define(
		[ 'jquery', 'utils/Constants', 'views/home/HomeListView',
		//'jquery.lazyload',
		'jquery.scrollbar', 'bootstrap' ],
		function($, Constants, HomeListView) {

			var HomePageView = {
				genericCarousel : $('#page-content .main #carousel-generic.carousel'),

				init : function() {
					//element
					var component = $('#page-content .main');

					// variables
					var genericCarousel = component
							.find('#carousel-generic.carousel');
					var CNinput = component.find('.card-number-section input');
					var CNsubmit = component.find('.card-num-submit');
					var cardTxtField1 = component.find('#cardTxtField1');
					var cardNumberHdn = component.find('#cardNumberHdn');
					var errorLabel;
					var formControl;

					// events
					CNinput.keyup(panNumberTypeHandler);
					CNinput.change(panNumberTypeHandler);
					CNsubmit.click(cardNumberSubmitted);
					$(window).on('hashchange', function() {
						$('label.error').empty();
        		  		$('.form-control.required').removeClass('error');
            			$('#cardTxtField1').val('');
            			$('#cardTxtField2').val('');
		        	 	$('#cardTxtField3').val('');
        		    	$('#cardTxtField4').val('');
        			});

					render();
					//functions
					function render() {
						if (genericCarousel.length > 0) {
							$(genericCarousel).carousel({
								interval : 8000,
								pause : 'false'
							});
						}
						HomeListView();
						if ( window.isConciergePortal ) {
							var path = '/vpp-backend/v1/concierge/getBulletinMessages';

						$.ajax({
							type : "GET",
							url : path,
							async : false,
							success : function(result) {
                                if(result.status!=undefined && result.status.statusCode === '200'){
									renderMessages(result.response);
                                }
							},
							error : function(result) {

							}
						});
                           cardTxtField1.focus();
                		}
					}
					function renderMessages(messages) {
	                    var data = '';
	                    if (messages.length) {
	                        data += '<ul>';
	                        $.each(messages, function(i, message) {
	                            data += '<li>' + message.messageText + '</li>';
	                        });
	                        data += '</ul>';
	                    } else {
	                        data += '<div class="no-message">You have no new messages at this time.</div>';
	                    }
	                    $('.bulletin-inner-container').html(data);
	    
	                    component.find( '.scrollable-area' ).mCustomScrollbar( {
	                        theme: 'gray-scrollbar'
	                    } );

	                 }
					$('.slide-nav .closeBtn, .navbar-toggle').off('click').on(
							'click', function() {
								$('#wrapper').toggleClass('slide-nav-open');
							});

					function panNumberTypeHandler(e) {
						if (e.keyCode === 9 || event.keyCode == 16) { //if it's tab key
							return;
						}
						var $currentElement = $(e.currentTarget);
						if ($currentElement.val().length == $currentElement
								.prop("maxlength")) {
							$currentElement.parent().next().find("input")
									.focus();
						}
						cardNumberHdn.val(getCardNumber());
					}

					function getCardNumber() {
						var panNumber = '';
						CNinput.each(function() {
							panNumber += $(this).val();
						});
						return panNumber;
					}

					function cardNumberSubmitted(e) {
						e.preventDefault();
						errorLabel = component.find('label.error');
						formControl = component.find('.form-control');
						errorLabel.html('');
						formControl.removeClass('error');
						var pagePath = $('#currentPagePath').val();
						var missingFields = component
								.find('.form-control.required:blank');
						if (missingFields.length > 0) {
							component.find('.form-control.required:blank')
									.addClass('error');
							errorLabel.html(Constants.errorMsg.required);
						} else {
							var isNumber = true;
							CNinput
									.each(function() {
										if (/^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/
												.test($(this).val())) {
										} else {
											isNumber = false;
										}
									});

							if (isNumber) {
								console.log("Number" + getCardNumber());
								//  var data = {
								//  cardNumber: getCardNumber(),
								//  currentPagePath: pagePath,
								//csrfToken: window.csrfToken
								//   };
								conciergeCardNumberSubmitted();
							} else {
								errorLabel
										.html(Constants.errorMsg.conciergeCardNumberInvalid);
							}
						}
					}

					function conciergeCardNumberSubmitted() {
						//Code to get the userId
						var path = '/vpp-backend/v1/concierge/setCreditCardNumber';
						var uId =  $('#userId').val();


                        var postdata = {
							'conciergeUserId' : uId,
							'pan' : getCardNumber()
						};
						$.ajax({
							type : "POST",
							url : path,
                            cache : false,
							dataType : "json",
							async : false,
							contentType : "application/json; charset=utf-8",
							data : JSON.stringify(postdata),
							success : function(result) {
								console.log("success--" + result);
                                if(result.status!=undefined && result.status.statusCode === '200' ){
								conciergeCardNumberRedirect(result);
                                }else{
                                setConcgCreditNumberFailureCallback(result);
                               }

							},
							error : function(result) {
								console.log("Failure");
								setConcgCreditNumberFailureCallback(result);
							}
						});
						
						}
						///
					function conciergeCardNumberRedirect( data ) {
						var path = '/bin/conciergeRedirection';
						var pagePath = $('#currentPagePath').val();
						var fname="";
						if(data.response.firstName!=undefined){
                            fname=data.response.firstName;
                        }
						$.ajax({
							type : "GET",
							url : path,
                            cache:true,
							async : false,
							data : {currentPagePath : pagePath,
									cardNumber : getCardNumber(),
									cardId : data.response.cardHolderId,
                                    userId : data.response.userId,
                                    firstName : fname,
                                    issuer : data.response.issuer

                                   },
							success : function(result) {
								console.log("success--" + result);

								setConcgCreditNumberSuccessCallback(result);

							},
							error : function(result) {
								console.log("Failure");
								setConcgCreditNumberFailureCallback(result);
							}
						});

					}

					function setConcgCreditNumberSuccessCallback(data) {
						console.log("Data --" + data);
						window.location.href = data;
					}

					function setConcgCreditNumberFailureCallback(data) {
						component.find('.form-control.required').addClass(
								'error');
						component.find('label.error').html(
								Constants.errorMsg.conciergeCardNumberInvalid);
					}
				},

				signout : function() {

					$.ajax({
						type : "POST",
						url : "/vpp-backend/logout",
						async : false,
						success : function() {

						}
					});

					var cpath = $('#wrapper').find('#currentPagePath').val();
					$.ajax({
						type : "GET",
						url : "/bin/conciergeUserSignout",
						data : {
							currentPagePath : cpath
						},
						success : function(result) {
							location = result;

						}
					});
				},

				pauseCarousel : function() {
					this.genericCarousel.carousel('pause');
				},

				resumeCarousel : function() {
					this.genericCarousel.carousel('cycle');
				}

			};

			return HomePageView;
		});