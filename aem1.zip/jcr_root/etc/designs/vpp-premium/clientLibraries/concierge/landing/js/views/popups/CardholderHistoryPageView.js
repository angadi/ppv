define( [
    'jquery',
    'views/home/HomePageView',
    'views/popups/NewCommentPageView',
    'models/SessionObject',
    'utils/Constants',
    'jquery.scrollbar'
], function( $, HomePageView, NewCommentPageView, SessionObject, Constants ) {

    var ProfileImgPageView = function() {
        var dataRequest = $.ajax( {
            url: 'cardholder-history.html',
            dataType: 'html'
        } );
        dataRequest.done( function( data ) {
            $('#popup-section').html(data);
            ProfileImgPageViewRender();
        } );
    };
    var ProfileImgPageViewRender = function() {
        // element
        var component = $( '#popup-section');
        var profileClose = component.find('a.closeBtn.close-profile');
        var newComment = component.find('a.new-comment');
        var scrollableArea = component.find('.scrollable-area');
        var pageHeading = component.find('h1.page-heading');
        var globalValues = {};
        var childComponent = component.find('.update-security-questions-container');

        // events
        profileClose.click(closePopup);
        newComment.click(createNewComment);

        render();
        // functions
        function render( options ) {
            HomePageView.pauseCarousel();
            component.addClass( 'popup-open' );
            component.fadeIn();
            scrollableArea.mCustomScrollbar( {
                theme: 'gray-scrollbar'
            } );
            pageHeading.focus();
        }

        function createNewComment( e ) {
            e.preventDefault();

            NewCommentPageView( { closeSubview: closeSubview } );
        }

        function closePopup( e ) {
            component.fadeOut();
            HomePageView.resumeCarousel();
            childComponent.html('');
            $( '.navbar-customize .cardholder-history' ).focus();
            component.html('');
            component.removeClass( 'popup-open' );
        }

        function closeSubview( focusItem ) {
            ProfileImgPageView();
        }

    };

    return ProfileImgPageView;

} );