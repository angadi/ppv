define([
  'jquery',
  'validations/ContactConciergeValidation',
  'utils/Constants',
  'jquery.lazyload',
  'bootstrap'
], function($, ContactConciergeValidation, Constants){

  var ConciergePageView = function(){

    // element
    $('#v-concierge-carousel-content').html(Constants.concierge);
    var component = $('#v-concierge-carousel-content');
    //variables
    var conciergeClose = component.find('a.closeBtn.close-concierge');    
    var carouselGeneric = component.find('#carousel-generic.carousel');
    var parentCarousel = $('.hero-contianer .carousel');
    var emailConciergeLink = component.find('.contact-concierge-email');
    var emailConciergeBtn = component.find('.contact-concierge-send');
    var errorClose = component.find('.error-close');
    var txtareaEmailBody = component.find('textarea#emailBody');
    var contactConciergeConfirmationClose = component.find('.contact-concierge-confirmation-close');
    //events
    conciergeClose.click(closePopup);
    emailConciergeLink.click(emailConcierge);
    emailConciergeBtn.click(emailConciergeSubmit);
    errorClose.click(backToEmail);
    txtareaEmailBody.keyup(updateRemainingCharacters);
    contactConciergeConfirmationClose.click(closePopup);
    render();
    //functions
    function closePopup(e) {
       $('html,body').removeClass('profile-opened');
      $('body').css('height', '100%');
      $('.hero-contianer .carousel').carousel('cycle');

        component.removeClass('popup-open confirmation-open-open');
        component.addClass('hidden');
        component.fadeOut();
      
      
      //this.$el.removeClass('popup-open confirmation-open-open');
      //this.$el.fadeOut();

      //if(this.childView) {
        component.html('');
      //}

      $('.navbar-customize .concierge').focus();     
    }

    function render() { 
        parentCarousel.carousel('pause');
        component.find('.email-concierge form').validate(ContactConciergeValidation.settings);      
        //$('input, textarea').placeholder();
        $('[data-toggle="popover"]').popover({html: true}); 
        $('#wrapper').removeClass('slide-nav-open');
        component.find('.lazy').lazyload({
          threshold: 400
        });
        carouselGeneric.carousel({
          interval: 4000,
          pause : 'false'
        });
        carouselGeneric.on('slide.bs.carousel', function (e) {
            updateHighlight(e);
        });
        updateCSS();
        component.addClass('popup-open');
        component.removeClass('hidden');
        component.fadeIn();
         //wcag:       
        component.find('.carousel-text-container a').first().focus();  
        $(window).on("resize",updateCSS);
    }

    function updateCSS() {
      
      var windowWidth = $(window).width();
      var windowHeight = $(window).height();

      if(windowWidth < 768) { //mobile
        $('html,body').addClass('profile-opened');
        $('body').height(windowHeight);
        component.height(windowHeight);  
      }
      else {
        $('html,body').removeClass('profile-opened');
        $('body').css('height', '100%');
        component.css('height', '100%');  
      }
    }

    function focusToCloseBtn() {
      if (e.which === 9) {
          if(e.shiftKey === true)
          {
              conciergeClose.focus();
          }
          else
          {
              // User is tabbing forward
          }
      }
    }

    function updateHighlight(e) {
      var $divs = component.find('.welcome-text .slide-text');
      $divs.removeClass('active');

     // var totalSlides = this.$('.item').length;
      var activeIndex = $(e.relatedTarget).index();

      // if(activeIndex === totalSlides-1) { //last slide: email
        // this.$('.carousel-text-container').fadeOut();
      // }
      // else {
        $divs.eq(activeIndex).addClass('active');
      // }

    }

   function  emailConcierge(e) {
      e.preventDefault();      
      //component.addClass('confirmation-open').removeClass('confirmation-open-open');
      component.find('.concierge-container').addClass('email-concierge-opened');
      component.find('#carousel-generic').carousel('pause');
      component.find('.email-concierge').fadeTo('400', 1);
      //wcag:     
      component.find('.email-concierge #name').focus();
      updateCSS();
     
    }

    function callConcierge(e) {
      if($('html.lte-ie9') && $('html.lte-ie9').length>0) {
        e.preventDefault();
        return;
      }
    }

    function backToEmail(e) {
      e.preventDefault();
      component.find('.popup-container').hide();
      component.removeClass('confirmation-open confirmation-open-open');
      component.find('.popup-container.email-container').fadeTo('400', 1, function() {
        component.find('.error').first().focus();
      });
    }


    function onClose() { 
      //$(window).off("resize", updateCSS);

      $('html,body').removeClass('profile-opened');
      $('body').css('height', '100%');
      $('.hero-contianer .carousel').carousel('cycle');
      
      
      //this.$el.removeClass('popup-open confirmation-open-open');
      //this.$el.fadeOut();

      //if(this.childView) {
        this.childView.close();
      //}

      $('.navbar-customize .concierge').focus();
    }

    function  emailConciergeSubmit(e) {
      e.preventDefault();

      var $form = component.find('form:visible');
      component.find('#emailBody').rules('add', {
        maxlength: 4000
      });

      if($form.valid()) {
        //var emailBodyText = $form.find('#emailBody').val();
        //emailBodyText = $.trim(emailBodyText);
        successCallback();
        /*var postData = {
          'ccEmail': $form.find('#email').val(),
          'emailBody': emailBodyText,
          'phone': $form.find('#phone').val()
        };*/
        //SessionObject.emailConcierge(postData, this.successCallback, this.failureCallback, this);
      }
      else {
        component.find('.popup-container').hide();
        component.removeClass('confirmation-open').addClass('confirmation-open-open');
        component.find('.error-container').fadeTo('400', 1, function() {
          $('.error-close.blue-button').focus();
        });
      }
    }


    function successCallback(data, self) {
      component.find('.error').hide();
      component.find('.popup-container').hide();
      component.removeClass('confirmation-open').addClass('confirmation-open-open');
      component.find('.confirmation-container').fadeTo('400', 1, function() {
        $('.contact-concierge-confirmation-close.blue-button').focus();
      });
    }

    function failureCallback(data, self) {
      console.log('send email failed;');
    }

    function updateRemainingCharacters(e) {
      e.preventDefault();
      var remainingCount = 4000 - $(e.currentTarget).val().length;
      component.find('#email-body-count').html(remainingCount);

      if(remainingCount <= 10) {
        component.find('.note').addClass('error');
      }
      else {
        component.find('.note').removeClass('error');
      }
    }

    function tooltipFocused(e) {
      $(e.currentTarget).parent().find('[data-toggle="popover"]').popover('show');
    }
    function tooltipFocusedOut(e) {
      $(e.currentTarget).parent().find('[data-toggle="popover"]').popover('hide');
    }

    
    function circleInPopup(e) {
      if(component.find('.carousel-text-container a:visible') && component.find('.carousel-text-container a:visible').length>0) {
        component.find('.carousel-text-container a').first().focus();
      }
      else if(component.find('.email-concierge:visible') && component.find('.email-concierge:visible').length>0) {
        component.find('.email-concierge #name').focus();
      }
    }

    

    function circleInErrorBackToBlueBtn(e) {  
      component.find('a.error-close.blue-button').focus();
    }
    function circleInErrorBackToCloseBtn(e) {
      component.find('a.error-close.closeBtn').focus();
    }
    function circleInConfirmBackToBlueBtn(e) {
      component.find('a.contact-concierge-confirmation-close.blue-button').focus();
    }
    function circleInConfirmBackToCloseBtn(e) {
      component.find('a.contact-concierge-confirmation-close.closeBtn').focus();
    }

  };  

  return ConciergePageView;
  
});
