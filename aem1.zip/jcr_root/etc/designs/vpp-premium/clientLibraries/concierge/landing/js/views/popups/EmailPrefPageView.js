define( [
    'jquery',
    'collections/EmailPrefsCollection',
    'validations/EmailPrefValidation',
    'models/SessionObject',
    'utils/Constants',
    'utils/RoleConstants'
], function( $, EmailPrefsCollection, ValidationSetting, SessionObject, Constants, RoleConstants ) {

    var EmailPrefPageView = function(parentFun) {
        var datRequest = $.ajax( {
            url: 'profile-email.html',
            dataType: 'html'
        } );
        datRequest.done( function( data ) {
            $( '#wrapper #popup-section .update-security-questions-container' ).html( data );
            EmailPrefPageViewRender(parentFun);
        } );
    };

    var EmailPrefPageViewRender = function(parentFun) {
        // element
        var parentComponent = $( '#wrapper #popup-section' );
        var profileComponent = parentComponent.find('.profile-container');
        var component = $( '#wrapper .popup-section .update-security-questions-container' );

        // variables
        var emailForm = component.find( 'form' );
        var pageHeading = component.find( 'h1.page-heading' );
        var closePopupBtn = component.find( 'a.closeBtn.close-popup' );
        var backToProfileBtn = component.find( 'a.back-to-profile' );
        var checkboxLabel = component.find( '.checkbox-label' );
        var changeEmail = component.find( '.change-email-email' );
        var updatePswBtn = component.find( 'a.update-psw-btn' );
        var backToSecurityQuestionsBtn = component.find( 'a.back-to-security-questions' );
        var securityQuestionSubmit = component.find( 'a.security-questions-submit' );
        var securityQuestionConfirmationClose = component.find( 'a.security-questions-confirmation-close' );
        var securityQuestionConfirmationCloseBtn = component.find( 'a.security-questions-confirmation-close.closeBtn' );
        var securityQuestionConfirmationCloseBlueBtn = component.find( 'a.security-questions-confirmation-close.blue-button' );
        var backToSecurityQuestionsCloseBtn = component.find( 'a.back-to-security-questions.closeBtn' );
        var SecurityQuestionsSubmitBlueBtn = component.find( 'a.security-questions-submit.blue-button' );
        var password = component.find( '#password' );
        var inputPwdContainer = component.find('.input-psw-container');
        var closeBtn = component.find( 'a.closeBtn' );
        var globalvalues = {};

        // events
        closePopupBtn.click(backToProfile);
        backToProfileBtn.click(backToProfile);
        closePopupBtn.keydown(closeBtnKeydown);
        checkboxLabel.click(checkboxClicked);
        checkboxLabel.keydown(checkboxKeydown);
        changeEmail.keyup(updateBlueBtn);
        updatePswBtn.click(updateEmailPrefsClicked);
        backToSecurityQuestionsBtn.click(backToSecurityQuestions);
        securityQuestionSubmit.click(updateSecurityQuestions);
        securityQuestionConfirmationClose.click(backToProfile);
        securityQuestionConfirmationCloseBtn.blur(circleInErrorBackToBlueBtn);
        securityQuestionConfirmationCloseBlueBtn.blur(circleInErrorBackToCloseBtn);
        backToSecurityQuestionsCloseBtn.blur(circleInConfirmBackToBlueBtn);
        SecurityQuestionsSubmitBlueBtn.blur(circleInConfirmBackToCloseBtn);
        password.keydown(circleInConfirm);
        closeBtn.blur(circleInPopup);
        backToProfileBtn.keydown(focusToCloseBtn);

        render();
        //functions

        function render( options ) {
            $( window ).on( "resize", updateCSS );
            globalvalues.isEmailPrefsUpdated = false;
            globalvalues.isEmailUpdated = false;
            globalvalues.emailAddress = '';

            //hide previous screen
            profileComponent.hide();
            component.addClass( 'update-email-prefs-container' );
            $('input[type=checkbox]').addClass('input_hidden');
            $( 'input, textarea' ).placeholder();
            emailForm.validate( ValidationSetting );
            updateCSS();

            component.fadeTo( '400', 1, function() {
                pageHeading.focus();
            } );
        }

        function circleInPopup( e ) {
            pageHeading.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function circleInErrorBackToBlueBtn( e ) {
            securityQuestionConfirmationCloseBlueBtn.focus();
        }

        function circleInErrorBackToCloseBtn( e ) {
            securityQuestionConfirmationCloseBtn.focus();
        }

        function circleInConfirmBackToBlueBtn( e ) {
            password.focus();
        }

        function circleInConfirmBackToCloseBtn( e ) {
            backToSecurityQuestionsCloseBtn.focus();
        }

        function circleInConfirm( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    backToSecurityQuestionsCloseBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function backToProfile( e ) {
            e.preventDefault();

            /*if ( this.emailAddress ) {
                this.parentView.$( '.email-in-profile' ).html( this.getMaskedEmail( this.emailAddress ) );
                SessionObject.bankConfig.userEmailAddress = this.emailAddress;
            }*/
            parentFun.closeSubview( 'update-email-pref' );
        }

        function backToSecurityQuestions( e ) {
            e.preventDefault();

            password.val( '' );
            component.find( '.error' ).hide();
            inputPwdContainer.hide();
            this.$el.removeClass( 'confirmation-open' );

            this.$el.css( 'height', 'auto' );
            this.$( '.popup-container.update-email-pref-container' ).fadeTo( '400', 1 );
        }

        function updateBlueBtn( e ) {
            e.preventDefault();

            // Avoid revalidate the field when pressing one of the following keys
            // Shift       => 16
            // Ctrl        => 17
            // Alt         => 18
            // Caps lock   => 20
            // End         => 35
            // Home        => 36
            // Left arrow  => 37
            // Up arrow    => 38
            // Right arrow => 39
            // Down arrow  => 40
            // Insert      => 45
            // Num lock    => 144
            // AltGr key   => 225
            var excludedKeys = [
                16, 17, 18, 20, 35, 36, 37,
                38, 39, 40, 45, 144, 225
            ];

            if ( e.which === 9 && $( e.currentTarget ).val() === "" || $.inArray( e.keyCode, excludedKeys ) !== -1 ) {
                return;
            }

            var $missingFields = component.find( 'input[type="email"]:blank' );
            if ( $missingFields.length === 1 ) {
                component.find( '.update-psw-btn' ).addClass( 'grey-out' );
            } else if ( $missingFields.length === 0 ) { // 2 emails are filled
                globalvalues.isEmailUpdated = true;
                component.find( '.update-psw-btn' ).removeClass( 'grey-out' );
            } else { //2 email input is empty
                globalvalues.isEmailUpdated = false;

                if ( globalvalues.isEmailPrefsUpdated ) {
                    component.find( '.update-psw-btn' ).removeClass( 'grey-out' );
                } else {
                    component.find( '.update-psw-btn' ).addClass( 'grey-out' );
                }
            }
        }

        function getMaskedEmail( email ) {
            var toRet = '';
            if ( email ) {
                var arry = email.split( '@' );
                if ( arry.length === 2 ) {
                    toRet = SessionObject.getMaskCharacters() + '@' + arry[ 1 ];
                }
            }
            return toRet;
        }

        function checkboxClicked( e ) {
            if ( $( e.target ).hasClass( 'popup-link' ) ) {

            } else {
                e.preventDefault();

                this.isEmailPrefsUpdated = true;

                if ( $( e.currentTarget ).hasClass( 'unsubscribeAll' ) ) {

                    if ( !$( e.currentTarget ).hasClass( 'selected' ) ) { //going to check unsubscribeAll
                        $( e.currentTarget ).addClass( 'selected' );
                        this.$( '.checkbox-label.subscribe' ).removeClass( 'selected' );
                    }
                } else {
                    this.$( '.unsubscribeAll' ).removeClass( 'selected' );
                    $( e.currentTarget ).toggleClass( 'selected' );
                }

                if ( $( e.currentTarget ).hasClass( 'selected' ) ) {
                    $( e.currentTarget ).attr( 'aria-checked', 'true' );
                } else {
                    $( e.currentTarget ).attr( 'aria-checked', 'false' );
                }

                var $missingFields = this.$( 'input[type="email"]:blank' );
                if ( $missingFields.length === 1 ) {
                    this.$( '.update-psw-btn' ).addClass( 'grey-out' );
                } else {
                    this.$( '.update-psw-btn' ).removeClass( 'grey-out' );
                }
            }
        }

        function checkboxKeydown( e ) {
            if ( e.which == 32 ) {
                this.checkboxClicked( e );
            }
            // else if (e.which === 9 && $(e.currentTarget).closest('.form-group').index()===0) {
            //   if(e.shiftKey === true)
            //   {
            //       this.parentView.parentView.$('.closeBtn').focus();
            //   }
            //   else
            //   {
            //       // User is tabbing forward
            //   }
            // }
        }

        function updateEmailPrefsClicked( e ) {
            e.preventDefault();

            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }

            if ( emailForm.valid() ) {

                globalvalues.subscribeIdList = buildSubscribeIdList();

                if ( globalvalues.isEmailUpdated ) { //show password required view

                    globalvalues.emailAddress = $( '#newEmail' ).val();

                    //show password input
                    component.find( '.popup-container.update-email-pref-container' ).hide();
                    component.addClass( 'confirmation-open' );
                    component.css( 'height', '' );
                    inputPwdContainer.fadeTo( '400', 1, function() {
                        password.focus();
                    } );

                } else { //submit

                    var postData = {
                        subscribeIdList: globalvalues.subscribeIdList
                    };
                    successCallback();
                    //SessionObject.updateEmailPrefs( postData, this.successCallback, this.failureCallback, this );
                }
            }
        }

        function updateSecurityQuestions( e ) {
            e.preventDefault();

            if ( $( '#password' ).val().trim() === '' ) {
                $( '.passwordError' ).show();
            } else {
                $( '.passwordError' ).hide();

                var postData = {
                    emailAddress: globalvalues.emailAddress,
                    password: $( '#password' ).val(),
                    subscribeIdList: globalvalues.subscribeIdList
                };
                successCallback();
                //SessionObject.updateEmailPrefs( postData, this.successCallback, this.failureCallback, this );
            }

        }

        function buildSubscribeIdList() {
            var subscribeIdList = '';
            var prefContainerLabel = component.find( '.pref-container-left .form-group label' );
            var $item;

            if ( SessionObject.bankConfig.HAS_EMAIL_PREFERENCE ) {
                for ( var i = 0; i < prefContainerLabel.length; ++i ) {

                    $item = prefContainerLabel.eq( i );

                    if ( $item.hasClass( 'selected' ) ) {
                        subscribeIdList += $item.find( 'input' ).attr( 'id' );
                        subscribeIdList += ',';
                    }
                }
                $item = prefContainerLabel.eq( 0 );
                if ( $item.hasClass( 'selected' ) ) {
                    subscribeIdList += $item.find( 'input' ).attr( 'id' );
                }
            }

            return subscribeIdList;
        }

        function successCallback( data, self ) {
            $( '.error' ).hide();

            component.css( 'height', '' );

            component.find( '.popup-container' ).hide();
            component.removeClass( 'confirmation-open' ).addClass( 'confirmation-open-open' );
            component.find( '.confirmation-container' ).fadeTo( '400', 1, function() {
                $( '.security-questions-confirmation-close.blue-button' ).focus();
            } );
        }

        function failureCallback( data, self ) {
            $( '.error' ).hide();
            $( '.system-error' ).html( data.status );
            $( '.system-error' ).show();
        }

        function updateCSS( event ) {
            component.css( 'height', 'auto' );

            var windowHeight = $( window ).height();

            $( 'html,body' ).addClass( 'profile-opened' );
            $( 'body' ).height( windowHeight );
            parentComponent.height( windowHeight );

            if ( windowHeight < component.height() ) {
                parentComponent.addClass( 'scrollable' );
            } else {
                parentComponent.removeClass( 'scrollable' );
            }
        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                this.backToProfile( e );
            }
        }

        function closePopup( e ) {
            e.preventDefault();

            this.parentView.closePopup( e );
        }

        function onClose() {
            $( window ).off( "resize", this.updateCSS );

            $( 'html,body' ).removeClass( 'profile-opened' );
            $( 'body' ).css( 'height', '100%' );

            this.$el.removeClass( 'confirmation-open confirmation-open-open' );
            this.parentView.$el.removeClass( 'popup-open' );
            this.$el.fadeOut();

            if ( this.childView ) {
                this.childView.close();
            }
        }
    };

    return EmailPrefPageView;

} );