define([
    'jquery',
    'views/home/HomePageView',
    'utils/Constants',
    'jquery.scrollbar'
], function($, HomePageView, Constants) {

    var NewInquiryPageView = function() {
        //element
        var component = $('#v-new-inquiry');
        //variables
        var closeProfile = component.find('a.closeBtn.close-profile');
        var cancelBtn = component.find('a.cancel');
        var cardNumberInput = component.find('.card-number-section input');
        var cardNumberSubmit = component.find('.card-num-submit');
        //var parentCarousel = $('.hero-container .carousel');
        //events
        closeProfile.on('click', closePopup);
        cancelBtn.on('click', closePopup);
        cardNumberInput.on('keyup', panNumberTypeHandler);
        cardNumberInput.on('change', panNumberTypeHandler);
        cardNumberSubmit.on('click', cardNumberSubmitted);

		$('a#newInquiry').on('click', clearErrorData);
        $(window).on('hashchange', clearErrorData);

        /*initialize: function(options) {
          if(options && options.parentView) {
            this.parentView = options.parentView;
          }
        },*/
        render();
        function render() {
            //HomePageView.pauseCarousel();
            //console.log($('#carousel-generic').length);
            $('#carousel-generic').carousel('pause');
            component.addClass('popup-open');
            component.removeClass('hidden');
            component.fadeIn();
            /*that.$('.scrollable-area').mCustomScrollbar({
          theme: 'gray-scrollbar'
        });

        that.$('h1.page-heading').focus();

      return this;*/
        }

        function getCardNumber() {
            var panNumber = '';
            $('.card-number-section input').each(function() {
                panNumber += $(this).val();
            });
            return panNumber;
        }

        function panNumberTypeHandler(e) {
            if (e.keyCode === 9 || event.keyCode == 16) { //if it's tab key
                return;
            }
            //var that = this;
            var $currentElement = $(e.currentTarget);
            if ($currentElement.val().length == $currentElement.prop("maxlength")) {
                $currentElement.parent().next().find("input").focus();
            }
            $('#cardNumberHdn').val(getCardNumber());
        }

        function cardNumberSubmitted(e) {
            e.preventDefault();

            $('label.error').html('');
            $('.form-control').removeClass('error');

            var missingFields = $('.form-control.required:blank');
            if (missingFields.length > 0) {
                $('.form-control.required:blank').addClass('error');
                $('label.error').html(Constants.errorMsg.required);
            } else {
                var isNumber = true;
                $('.card-number-section input').each(function() {
                    if (/^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test($(this).val())) {} else {
                        isNumber = false;
                    }
                });
                if (isNumber) {
                    setConcgCreditNumberSuccessCallback();
                    /*var data = {
                      pan: getCardNumber(),
                      csrfToken: window.csrfToken
                    };
                    SessionObject.conciergeCardNumberSubmitted(data, this.setConcgCreditNumberSuccessCallback, this.setConcgCreditNumberFailureCallback, this); */
                } else {
                    $('label.error').html(Constants.errorMsg.conciergeCardNumberInvalid);
                }
            }
        }

        function setConcgCreditNumberSuccessCallback() {

            window.location.href = 'conciergeac.html';

        }

        function setConcgCreditNumberFailureCallback(data, self) {
            self.$('.form-control.required').addClass('error');
            self.$('label.error').html(Constants.errorMsg.conciergeCardNumberInvalid);
        }

        function closePopup() {
            HomePageView.resumeCarousel();
            component.removeClass('popup-open');
            component.addClass('hidden');
            component.fadeOut();
        }

        function onClose() {
            //this.$el.fadeOut();

            /*if (this.parentView) {
                this.parentView.resumeCarousel();
            }

            if (this.childView) {
                this.childView.close();
            }*/
            $('.navbar-customize .new-inquiry').focus();
        }

        function clearErrorData() {
			$('label.error').empty();
            $('.form-control.required').removeClass('error');
            $('#cardTxtField1').val('');
            $('#cardTxtField2').val('');
            $('#cardTxtField3').val('');
            $('#cardTxtField4').val('');
        }
    };

    return NewInquiryPageView;
});