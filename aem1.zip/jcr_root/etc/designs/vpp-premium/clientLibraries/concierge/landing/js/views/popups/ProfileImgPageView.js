define([
  'jquery',
  'utils/Constants'
], function($, Constants){

    var ProfileImgPageView = function( parentFun ) {
    	 var currentPagePath = $('#currentPagePath').val();
         var datRequest = $.ajax( {
             url: '/bin/profileOverlayHandlerPremium',
 			data : {currentPagePath : currentPagePath ,
 			popup : 'concierge_profile_image' },
           dataType: 'html'
         } );
        datRequest.done( function( data ) {
            $( '#wrapper #popup-section .update-security-questions-container' ).html( data );
            ProfileImgPageViewRender( parentFun );
        } );
    };
    var ProfileImgPageViewRender = function(parentFun){
      //element
      var component = $('#wrapper #popup-section .update-security-questions-container');
      var conciergeProfileComponent = $('.concierge-profile-container');
      //variables
      var closeProfile = component.find('a.closeBtn.close-popup');
      var backToProfileBtn = component.find('a.back-to-profile');
      var profileImageContainer = component.find('.profile-img-container');
      var updateProfileImageBtn = component.find('a.update-profile-img-btn');
      var securityQuestionsSubmit = component.find('a.security-questions-submit');
      var backToSecurityQuestionsBtn = component.find('a.back-to-security-questions');
      var securityQuestionsConfirmationClose = component.find('a.security-questions-confirmation-close');
      var closeBtn = component.find('a.closeBtn');
      var pageHeading = component.find('h1.page-heading');
      //events
      closeProfile.click(backToProfile);
      //closeProfile.keydown(closeBtnKeydown);
      backToProfileBtn.click(backToProfile);
      profileImageContainer.click(profileImgClicked);
      updateProfileImageBtn.click(updateProfileImg);
      securityQuestionsSubmit.click(updateSecurityQuestions);
      backToSecurityQuestionsBtn.click(backToSecurityQuestions);
      securityQuestionsConfirmationClose.click(backToProfile);
      closeBtn.blur(circleInPopup);
      backToProfileBtn.keydown(focusToCloseBtn);

      render();

      function render(){

        component.addClass('profile-img-container-opened').show();

        //hide previous screen
        conciergeProfileComponent.hide();

        /*SessionObject.getProfileImages(function(images) {
          var data = {
            images:  images
          };
          _.extend(data, options, SessionObject, Constants);

          var template = _.template($(profileImgPageTemplate).html());
          that.$el.html(template(data));

          that.$el.fadeTo('400', 1, function() {
            that.$('h1.page-heading').focus();
          });
        });*/
      }

      function circleInPopup(e) {
        pageHeading.focus();
      }

      function focusToCloseBtn(e) {
        if (e.which === 9) {
            if(e.shiftKey === true)
            {
                closeBtn.focus();
            }
            else
            {
                // User is tabbing forward
            }
        }
      }
      function backToProfile() {
        console.log('backToProfile');
        parentFun.closeSubview('update-profile-img');
      }

      function profileImgClicked(e) {
        e.preventDefault();

        component.find('.profile-img-container').removeClass('selected');
        $(e.currentTarget).addClass('selected');
        selectedImgId = component.find('.profile-img-container.selected').attr('profile-img-id');
        updateBlueBtn();
      }

      function updateBlueBtn() {
        component.find('.update-profile-img-btn').removeClass('grey-out');
      }

      function updateProfileImg(e) {
        e.preventDefault();

        if($(e.currentTarget).hasClass('grey-out')) {
          return false;
        }

        //show password input
        $('.popup-container.update-profile-img-container').hide();
        component.addClass('confirmation-open');
        component.css('height', '');
        component.find('.input-psw-container').fadeTo('400', 1, function() {
          $('#password').focus();
        });

      }

      function updateSecurityQuestions(e) {
        e.preventDefault();

        $('.error').hide();

        if(component.find('#password').val().trim() === '') {
          component.find('.passwordError').show();
        }
        else {
          component.find('.passwordError').hide();



		 		var postData = {
                    'conciergeId' : $('#userId').val() ,
                    'imageId': selectedImgId,
                    'password': component.find('#password').val()
                };


                var issuerName = $("#issuerName").val();
				var path = "/vpp-backend/v1/concierge/updateConciergeImage ";
				
                $.ajax({
                    type: "POST",
					url: path, 
					dataType: "json",
					async:false,
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify(postData),
					success: function(result){
						if(result.status!=undefined && result.status.statusCode === '200'){
							updateConcgProfileImgSuccessCallback();
						}else{
							updateConcgProfileImgFailureCallback(result);
						} 
					}
                });




          //updateConcgProfileImgSuccessCallback();
          //SessionObject.updateConcgProfileImg(postData, this.updateConcgProfileImgSuccessCallback, this.updateConcgProfileImgFailureCallback, this);
        }
      }

      function updateConcgProfileImgSuccessCallback() {
        $('.error').hide();
        // console.log('update security questions succeeded');

        component.find('.popup-container').hide();
        component.removeClass('confirmation-open').addClass('confirmation-open-open');
        component.find('.confirmation-container').fadeTo('400', 1, function() {
           $('.security-questions-confirmation-close.blue-button').focus();
        });
      }

      function updateConcgProfileImgFailureCallback(data) {
        component.find('.error').hide();
        component.find('.system-error').html(Constants.errorMsg.wrongPassword);
        component.find('.system-error').show();
      }

      function backToSecurityQuestions() {
        component.find('#password').val('');
        component.find('.error').hide();
        component.find('.input-psw-container').hide();
        component.removeClass('confirmation-open');
        component.css('height','auto');
        component.find('.update-profile-img-container').fadeTo('400', 1);
      }


  };

  return ProfileImgPageView;
});
