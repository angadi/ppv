define( [
    'jquery',
    'views/popups/EmailPrefPageView',
    'views/popups/UpdatePswView',
    'views/popups/UpdateSecurityQuestionsView',
    'models/UserModel',
    'models/SessionObject',
    'utils/Constants',
    'utils/RoleConstants'
], function( $, EmailPrefPageView, UpdatePswView, UpdateSecurityQuestionsView, UserModel, SessionObject, Constants, RoleConstants ) {
    var ProfilePageView = function() {
        var datRequest = $.ajax( {
            url: 'profile.html',
            dataType: 'html'
        } );
        datRequest.done( function( data ) {
            $( '#wrapper #popup-section' ).html( data );
            ProfilePageViewReder();
        } );
    };
    var ProfilePageViewReder = function() {
        // element
        var component = $( '#wrapper #popup-section' );
        var childComponent = component.find('.update-security-questions-container');

        // variables
        var profileCloseBtn= component.find('a.closeBtn.close-profile');
        var updateEmailPrefBtn = component.find('a.update-email-pref');
        var updatePswBtn = component.find('a.update-psw');
        var updateSecurityQuestionsBtn = component.find('a.update-security-questions');
        var closeBtn = component.find('a.closeBtn');
        var pageHeading =component.find('h1.page-heading');
        var parentFun = {
            'closeSubview': closeSubview
        };

        //events
        profileCloseBtn.click(closePopup);
        profileCloseBtn.keydown(closeBtnKeydown);
        updateEmailPrefBtn.click(updateEmailPref);
        updatePswBtn.click(updatePsw);
        updateSecurityQuestionsBtn.click(updateSecurityQuestions);
        closeBtn.blur(circleInPopup);
        updateEmailPrefBtn.keydown(focusToCloseBtn);
        pageHeading.keydown(focusToCloseBtn);

        render();
        // functions

        function render( options ) {
            updateCSS();
            /*if ( that.parentView ) {
                that.parentView.pauseCarousel();
            }*/
            component.addClass( 'popup-open' );
            component.fadeIn();
            pageHeading.focus();
            $( window ).on( "resize", updateCSS );
            $( 'html,body' ).removeClass( 'offer-detail-opened offer-detail-opened-overflow' );
            $( 'body' ).css( 'height', '100%' );
        }

        function circleInPopup( e ) {
            pageHeading.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function getMaskedEmail( email ) {
            var toRet = '';
            if ( email ) {
                var arry = email.split( '@' );
                if ( arry.length === 2 ) {
                    toRet = SessionObject.getMaskCharacters() + '@' + arry[ 1 ];
                }
            }
            return toRet;
        }

        function updateEmailPref( e ) {
            e.preventDefault();
            EmailPrefPageView(parentFun);
            //this.childView = new EmailPrefPageView( { parentView: this } );
            //this.childView.render( { catName: this.catName } );
        }

        function updatePsw( e ) {
            e.preventDefault();
            UpdatePswView( parentFun );
        }

        function updateSecurityQuestions( e ) {
            e.preventDefault();
            UpdateSecurityQuestionsView( parentFun );
        }

        function closeSubview( focusItem ) {
            childComponent.html('');
            childComponent.removeClass();
            childComponent.addClass('popup update-security-questions-container');
            component.removeClass( 'scrollable' );
            component.addClass( 'popup-open' );
            component.find( '.popup.profile-container' ).show();
            component.find( '.popup.profile-container' ).fadeTo( '400', 1, function() {
                updateCSS();
                if ( focusItem ) {
                    component.find( '.' + focusItem ).focus();
                }
            } );
        }

        function updateCSS( event ) {
            var windowWidth = $( window ).width();
            var windowHeight = $( window ).height();
            var ProfileContainerHeight = component.find( '.profile-container' ).height();
            $( 'html,body' ).addClass( 'profile-opened' );
            $( 'body' ).height( windowHeight );
            component.height( windowHeight );
            if ( windowHeight < ProfileContainerHeight ) {
                component.addClass( 'scrollable' );
            } else {
                component.removeClass( 'scrollable' );
            }
        }

        function closePopup( e ) {
            $( window ).off( "resize", updateCSS );
            $( 'html,body' ).removeClass( 'profile-opened' );
            $( 'body' ).css( 'height', '100%' );
            component.removeClass( 'popup-open scrollable' );
            component.fadeOut();
            /*if ( this.parentView ) {
                this.parentView.resumeCarousel();
            }
            if ( this.childView ) {
                this.childView.close();
            }*/
            $( '.navbar-customize .profile' ).focus();
        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                closePopup( e );
            }
        }
        return {
            'closeSubview' : closeSubview
        };
    };
    return ProfilePageView;
} );