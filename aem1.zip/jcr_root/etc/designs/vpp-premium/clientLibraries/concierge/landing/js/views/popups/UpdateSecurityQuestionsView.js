define( [
    'jquery',
    'validations/UpdateSecurityQuestionsValidation',
    'models/SecurityQuestionsModel',
    'models/SessionObject',
    'utils/Constants',
    'utils/RoleConstants',
    'jquery.placeholder',
    'select2',
], function( $, ValidationSettings, SecurityQuestionsModel, SessionObject, Constants, RoleConstants ) {

    var UpdateSecurityQuestionsView = function( parentFun ) {
        var currentPagePath = $('#currentPagePath').val();
		var datRequest = $.ajax( {
			url: '/bin/profileOverlayHandlerPremium',
			data : {currentPagePath : currentPagePath ,
			popup : 'profile_security_questions' },
            dataType: 'html'
        } );
        datRequest.done( function( data ) {
            $( '#wrapper #popup-section .update-security-questions-container' ).html( data );
            UpdateSecurityQuestionsViewReder( parentFun );
        } );
    };

    var UpdateSecurityQuestionsViewReder = function( parentFun ) {
        // element
        var parentComponent = $( '#wrapper #popup-section' );
        var profileComponent = parentComponent.find( '.profile-container' );
        var component = $( '#wrapper .popup-section .update-security-questions-container' );

        // variables
        var securityForm = component.find( 'form' );
        var pageHeading = component.find( 'h1.page-heading' );
        var closePopupBtn = component.find( 'a.closeBtn.close-popup' );
        var backToProfileBtn = component.find( 'a.back-to-profile' );
        var backToSecurityQuestionsBtn = component.find( 'a.back-to-security-questions' );
        var securityQuestionId1 = component.find( '#securityQuestionId1' );
        var securityQuestionId2 = component.find( '#securityQuestionId2' );
        var verifyUserBtn = component.find( 'a.verify-user' );
        var securityQuestionSubmit = component.find( 'a.security-questions-submit' );
        var securityQuestionConfirmationClose = component.find( 'a.security-questions-confirmation-close' );
        var securityQuestionConfirmationCloseBtn = component.find( 'a.security-questions-confirmation-close.closeBtn' );
        var securityQuestionConfirmationCloseBlueBtn = component.find( 'a.security-questions-confirmation-close.blue-button' );
        var backToSecurityQuestionsCloseBtn = component.find( 'a.back-to-security-questions.closeBtn' );
        var SecurityQuestionsSubmitBlueBtn = component.find( 'a.security-questions-submit.blue-button' );
        var password = component.find( '#password' );
        var formControl = component.find( 'input.form-control' );
        var inputPwdContainer = component.find( '.input-psw-container' );
        var closeBtn = component.find( 'a.closeBtn' );
        var globalvalues = {};

        // events
        closePopupBtn.click( backToProfile );
        closePopupBtn.keydown( closeBtnKeydown );
        backToProfileBtn.click( backToProfile );
        securityQuestionId1.on('select2-selecting', securityQuestionChangeHandler );
        securityQuestionId2.on('select2-selecting', securityQuestionChangeHandler );
        verifyUserBtn.click( verifyUser );
        securityQuestionSubmit.click( updateSecurityQuestions );
        backToSecurityQuestionsCloseBtn.click( backToSecurityQuestions );
        securityQuestionConfirmationClose.click( refreshProfile );
        securityQuestionConfirmationCloseBtn.blur( circleInErrorBackToBlueBtn );
        securityQuestionConfirmationCloseBlueBtn.blur( circleInErrorBackToCloseBtn );
        backToSecurityQuestionsCloseBtn.blur( circleInConfirmBackToBlueBtn );
        SecurityQuestionsSubmitBlueBtn.blur( circleInConfirmBackToCloseBtn );
        password.keydown( circleInConfirm );
        formControl.keyup( updateBlueBtn );
        closeBtn.blur( circleInPopup );
        backToProfileBtn.keydown( focusToCloseBtn );
        pageHeading.keydown( focusToCloseBtn );

        render();
        // functions
        function render( options ) {

            $( window ).on( "resize", updateCSSInSecurityQ );
            $( 'input, textarea' ).placeholder();

            securityForm.validate( ValidationSettings );
			globalvalues.originalQuestionIdStrings  = ["4", "5"];
			var questIds = $('#secQuestIds').val() ;
			if( questIds != undefined ){
				questIdArr = questIds.split(',');
				if(questIdArr.length == 2 ){
					globalvalues.originalQuestionIdStrings = questIdArr ;
				}
			}
            /*globalvalues.securityQuestionValues = {
                'securityQuestionId2': 4,
                'securityQuestionId1': 5
            };*/
            profileComponent.hide();

            //SessionObject.getSecurityQuestions( that.securityQuestionsCallback, that );
			globalvalues.securityQuestionsJSON = [];
			var securityQuestions = SecurityQuestionsModel.questions();
			securityQuestions.done(function(data){
				if( typeof(data) === "string"){
					try{
						data = JSON.parse(data);
					}catch(e){
						
					}
				}
				if (data.status != undefined) {
					if (data.status.statusCode === '200') {
						globalvalues.securityQuestionsJSON = data.response.securityQuestions ;
					}
				}
			});
            securityQuestionsCallback();

        }

        function securityQuestionsCallback() {

            var questions = '<option vaule=""></option>';
            globalvalues.securityQuestionsJSON.forEach( function( item ) {
                questions += '<option value="' + item.questionId + '">' + item.questionDescription + '</option>';
            } );

            securityQuestionId1.append( questions );
            securityQuestionId2.append( questions );

            component.find( '.securitySelectBox' ).select2( {
                placeholder: $(  '.securitySelectBox' ).siblings( 'label' ).html(),
                dropdownParent: $( '.form-group' ),
                minimumResultsForSearch: -1
            } );

            securityQuestionId1.select2( 'val', globalvalues.originalQuestionIdStrings[0] );
            securityQuestionId2.select2( 'val', globalvalues.originalQuestionIdStrings[1] );

            var secQues1selectedQuestion = securityQuestionId1.select2( 'data' );
            var secQues2selectedQuestion = securityQuestionId2.select2( 'data' );
            if ( !!secQues1selectedQuestion ) {
                securityQuestionId2.find( "option[value='" + secQues1selectedQuestion.id + "']" ).remove();
            }
            if ( !!secQues2selectedQuestion ) {
                securityQuestionId1.find( "option[value='" + secQues2selectedQuestion.id + "']" ).remove();
            }

            updateCSSInSecurityQ();

            //  that.$el.addClass('popup-open');
            // that.$el.fadeIn();

            //hide previous screen
            // self.parentView.$el.find('.popup').fadeOut('400', function() {
            component.fadeTo( '400', 1, function() {
                pageHeading.focus();
            } );
            // });

        }

        function circleInPopup( e ) {
            pageHeading.focus();
        }

        function focusToCloseBtn( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    closeBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function closeBtnKeydown( e ) {
            if ( e.keyCode === 13 ) {
                backToProfileBtn( e );
            }
        }

        function circleInErrorBackToBlueBtn( e ) {
            securityQuestionConfirmationCloseBlueBtn.focus();
        }

        function circleInErrorBackToCloseBtn( e ) {
            securityQuestionConfirmationCloseBtn.focus();
        }

        function circleInConfirmBackToBlueBtn( e ) {
            password.focus();
        }

        function circleInConfirmBackToCloseBtn( e ) {
            backToSecurityQuestionsCloseBtn.focus();
        }

        function circleInConfirm( e ) {
            if ( e.which === 9 ) {
                if ( e.shiftKey === true ) {
                    backToSecurityQuestionsCloseBtn.focus();
                } else {
                    // User is tabbing forward
                }
            }
        }

        function updateBlueBtn( e ) {
            e.preventDefault();

            // Avoid revalidate the field when pressing one of the following keys
            // Shift       => 16
            // Ctrl        => 17
            // Alt         => 18
            // Caps lock   => 20
            // End         => 35
            // Home        => 36
            // Left arrow  => 37
            // Up arrow    => 38
            // Right arrow => 39
            // Down arrow  => 40
            // Insert      => 45
            // Num lock    => 144
            // AltGr key   => 225
            var excludedKeys = [
                16, 17, 18, 20, 35, 36, 37,
                38, 39, 40, 45, 144, 225
            ];

            if ( e.which === 9 && $( e.currentTarget ).val() === "" || $.inArray( e.keyCode, excludedKeys ) !== -1 ) {
                return;
            }

            var $missingFields = component.find( 'input.form-control:blank:visible' );
            if ( $missingFields.length === 2 ) {
                verifyUserBtn.addClass( 'grey-out' );
            } else {
                verifyUserBtn.removeClass( 'grey-out' );
            }
        }

        function securityQuestionChangeHandler( e ) {
            var selectBoxIdToChange = '';
            if ( $( e.currentTarget ).prop( 'id' ) == 'securityQuestionId1' ) {
                selectBoxIdToChange = "#securityQuestionId2";
            } else {
                selectBoxIdToChange = "#securityQuestionId1";
            }
            removeOptionFromSelect( selectBoxIdToChange, e );
        }

        function removeOptionFromSelect( selectBoxToChange, optionValue ) {
            populateQuestionInSelectBox( selectBoxToChange, optionValue );
        }

        function populateQuestionInSelectBox( selectBoxSelector, valueToExclude ) {
            var excludeId = valueToExclude.choice.id;
            var oldSelectedValue = $( selectBoxSelector ).select2( 'data' ) ? $( selectBoxSelector ).select2( 'data' ).id : null;
            $( selectBoxSelector ).find( "option" ).remove();
            $( selectBoxSelector ).append( '<option value=""></option>' );

            globalvalues.securityQuestionsJSON.forEach( function( item ) {
                if ( item.questionId != excludeId ) {
                    var optionHtml = '<option value="' + item.questionId + '">' + item.questionDescription + '</option>';
                    $( selectBoxSelector ).append( optionHtml );
                }
            } );
            if ( oldSelectedValue == excludeId ) {
                $( selectBoxSelector ).select2( 'val', null );
            } else {
                $( selectBoxSelector ).select2( 'val', oldSelectedValue );
            }
        }

        function backToProfile( e ) {
            e.preventDefault();

            parentFun.closeSubview( 'update-security-questions' );
        }
        
        function refreshProfile(e) {
            e.preventDefault();

            window.location.reload();
        }


        function verifyUser( e ) {
            e.preventDefault();

            component.find( '.securityQ-container label.error' ).remove();

            if ( $( e.currentTarget ).hasClass( 'grey-out' ) ) {
                return false;
            }

            globalvalues.newQuestion1Id = component.find( "#securityQuestionId1" ).select2( 'data' ).id;
            globalvalues.newQuestion2Id = component.find( "#securityQuestionId2" ).select2( 'data' ).id;
            var showPopup = true;

            if ( $.inArray( globalvalues.newQuestion1Id, globalvalues.originalQuestionIdStrings ) < 0 ) { //this is a new question

                // Security quesiton cannot be empty
                if ( component.find( "#securityQuestionAnswer1" ).val() === "" ) {
                   component.find( "#securityQuestionAnswer1Error" ).show();
                    showPopup = false;
                } else {
                    globalvalues.newAnswer1 = component.find( "#securityQuestionAnswer1" ).val();
                    component.find( "#securityQuestionAnswer1Error" ).hide();
                }
            } else { //it's the old question
                component.find( "#securityQuestionAnswer1Error" ).hide();
                globalvalues.newAnswer1 = component.find( "#securityQuestionAnswer1" ).val().trim();
            }

            if ( $.inArray( globalvalues.newQuestion2Id, globalvalues.originalQuestionIdStrings ) < 0 ) { //this is a new question

                if ( component.find( "#securityQuestionAnswer2" ).val() === "" ) {
                    component.find( "#securityQuestionAnswer2Error" ).show();
                    showPopup = false;
                } else {
                    globalvalues.newAnswer2 = component.find( "#securityQuestionAnswer2" ).val();
                    component.find( "#securityQuestionAnswer2Error" ).hide();
                }
            } else {
                component.find( "#securityQuestionAnswer2Error" ).hide();
                globalvalues.newAnswer2 = component.find( "#securityQuestionAnswer2" ).val().trim();
            }

            if ( showPopup ) {

                if ( securityForm.valid() ) {
                    //show password input
                    component.find( '.popup-container.securityQ-container' ).hide();
                    component.addClass( 'confirmation-open' );
                    component.css( 'height', '' );
                    component.find( '.input-psw-container' ).fadeTo( '400', 1, function() {
                        $( '#password' ).focus();
                    } );
                }
            }
        }

        function updateSecurityQuestions( e ) {
            e.preventDefault();

            $( '.error' ).hide();

            if ( component.find( '#password' ).val().trim() === '' ) {
                component.find( '.passwordError' ).show();
            } else {
                component.find( '.passwordError' ).hide();

                var postData = {
					'userId' :  $('#userId').val() ,
                    'password': component.find( '#password' ).val(),
                    'securityQuestionId1': globalvalues.newQuestion1Id,
                    'securityQuestionAnswer1': globalvalues.newAnswer1,
                    'securityQuestionId2': globalvalues.newQuestion2Id,
                    'securityQuestionAnswer2': globalvalues.newAnswer2
                };
				
				var issuerName = $("#issuerName").val();
				var path = "/vpp-backend/v1/cnb/infinite/users/changeSecurityQuestions";
				
                $.ajax({
                    type: "POST",
					url: path, 
					dataType: "json",
					async:false,
					contentType: "application/json; charset=utf-8",
					data: JSON.stringify(postData),
					success: function(result){
						if(result.status!=undefined && result.status.statusCode === '200'){
							updateSecurityQuestionsSuccessCallback(result);
						}else{
							updateSecurityQuestionsFailureCallback(result);
						} 
					}
                });
          				
                //SessionObject.updateSecurityQuestions( postData, this.updateSecurityQuestionsSuccessCallback, this.updateSecurityQuestionsFailureCallback, this );
                //ajax call for changeSecurityQuestions
				//updateSecurityQuestionsSuccessCallback();
            }
        }

        function updateSecurityQuestionsSuccessCallback( data ) {
            component.find( '.error' ).hide();
            // console.log('update security questions succeeded');

            component.find( '.popup-container' ).hide();
            component.removeClass( 'confirmation-open' ).addClass( 'confirmation-open-open' );
            component.find( '.confirmation-container' ).fadeTo( '400', 1, function() {
                $( '.security-questions-confirmation-close.blue-button' ).focus();
            } );
        }

        function updateSecurityQuestionsFailureCallback( data ) {
            component.find( '.error' ).hide();
			if(data.status != undefined ){
				component.find( '.system-error' ).html( data.status.statusDescription );
			}
            component.find( '.system-error' ).show();
        }

        function backToSecurityQuestions( e ) {
            e.preventDefault();

            component.find( '#password' ).val( '' );
            component.find( '.error' ).hide();
            $( '.input-psw-container' ).hide();
            component.removeClass( 'confirmation-open' );
            component.css( 'height', 'auto' );
            component.find( '.popup-container.securityQ-container' ).fadeTo( '400', 1 );
        }

        function updateCSSInSecurityQ( event ) {
            var windowHeight = $( window ).height();
            $( 'html,body' ).addClass( 'profile-opened' );
            $( 'body' ).height( windowHeight );
            parentComponent.height( windowHeight );
        }

        function closePopup( e ) {
            e.preventDefault();

            //parentFun.closePopup( e );
            $( window ).off( "resize", updateCSSInSecurityQ );

            $( 'html,body' ).removeClass( 'profile-opened' );
            $( 'body' ).css( 'height', '100%' );

            component.removeClass( 'confirmation-open confirmation-open-open' );

            parentComponent.removeClass( 'popup-open' );
            component.fadeOut();

            component.html('');

        }
		
		function getCookie(cname) {
		   var name = cname + "=";
		   var ca = document.cookie.split(';');
		   for (var i = 0; i < ca.length; i++) {
			   var c = ca[i];
			   while (c.charAt(0) == ' ') {
				   c = c.substring(1);
			   }
			   if (c.indexOf(name) == 0) {
				   return c.substring(name.length, c.length);
			   }
		   }
		   return "";
		}

    };

    return UpdateSecurityQuestionsView;

} );