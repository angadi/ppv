/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
;(function ($, ns, channel, window, undefined) {

    var overlayClass = 'cq-Overlay',
        overlayComponentClass = 'cq-Overlay--component',
        overlayComponentNameClass = 'cq-Overlay--component-name',
        overlayContainerClass = 'cq-Overlay--container',
        overlayPlaceholderClass = 'cq-Overlay--placeholder',
        overlayDropTargetClass = 'cq-droptarget',
        overlayDraggableClass = 'cq-draggable',
        rootTitle = " [" + Granite.I18n.get("Root") + "]";

    function getComponentTitle(editable) {
        var component = ns.components.find({path: new RegExp("(.)*" + editable.type + "$")});

        component = component && component.length > 0 ? component[0] : null;

        if (component) {
            var title = component.getTitle();
            return (title && title.length > 0) ? title : "";
        }

        return "";
    }

    /**
     * @classdesc An Overlay is the editing visual interface between the user and the underlying content (which lives in the ContentFrame).
     *
     * It is the visual representation of an {@link Granite.author.Editable}
     *
     * @class
     * @alias Granite.author.ui.Overlay
     *
     * @param {Granite.author.Editable} editable    - The source editable of the current overlay
     * @param {HTMLElement} container               - The HTML element to which append the Overlay
     */
    ns.ui.Overlay = function (editable, container) {
        // never save reference for editable
        if (!editable || !container) { // allows the constructor to be used seamlessly as prototype
            return;
        }

        // Strategy: We always create an overlay even if the editable has 0px and no actions
        this.dom = this.render(editable);

        container.append(this.dom);
    };

    /**
     * Current position of the Overlay
     *
     * @todo To be removed as it is a static field when we are using instance field, should be a mistake. Not used locally
     * @ignore
     *
     * @type {Object}
     */
    ns.ui.Overlay.currentPos = null;

    /**
     * Returns a definition object based on the given {@link Granite.author.Editable} and used when rendering the Overlay
     *
     * @function Granite.author.ui.Overlay#prepareRendering
     *
     * @param {Granite.author.Editable} editable - The {@link Granite.author.Editable} instance for which to render an overlay
     * @returns {{disabled: boolean, container: boolean, orderable: boolean, draggable: boolean, dropTarget: boolean, placeholder: (false|String)}} - The definition object required by the {@link Granite.author.ui.Overlay#render} function
     */
    ns.ui.Overlay.prototype.prepareRendering = function (editable) {
        // if there are no actions the overlay is disabled
        var disabled = !editable.hasActionsAvailable();
        var orderable = editable.config.editConfig && editable.config.editConfig.orderable;

        var def = {
            disabled: disabled,
            container: editable.config.isContainer,
            orderable: orderable,
            draggable: orderable,
            dropTarget: !disabled && editable.config.isDropTarget,
            placeholder: editable.hasPlaceholder()
        };

        return def;
    };

    /**
     * Renders the name of the given editable
     *
     * @param editable
     * @param dom
     * @returns {*|HTMLElement}
     */
    ns.ui.Overlay.prototype.renderName = function (editable, dom) {
        var title = getComponentTitle(editable);
        var className = overlayComponentNameClass;

        if (editable.isNewSection()) {
            var parent = ns.editables.getParent(editable);

            if (parent) {
                var parentTitle = getComponentTitle(parent);
                dom.attr("title", editable.isRootNewSection() ? parentTitle + rootTitle : parentTitle);
            }

            return;
        }

        if (!ns.editables.getParent(editable)) {
            //custom code added to remove root
            if(rootTitle===" [Root]")
            {
                rootTitle="";
            }

            title += rootTitle;
        }

        dom.attr("title", title);

        if (title && title.length > 0) {
            var nameEl = dom.find("." + className);
            var domName = $("<span title=\"" + title + "\" class=\"" + className + "\">" + title + "</span>");

            if (nameEl.length > 0) {
                nameEl.replaceWith(domName);
            } else {
                dom.append(domName);
            }

            return domName;
        }
    };

    /**
     * Renders the {@link Granite.author.ui.Overlay} in the given container element
     *
     * @function Granite.author.ui.Overlay#render
     *
     * @param {Granite.author.Editable} editable - The {@link Granite.author.Editable} instance for which to render an overlay
     */
    ns.ui.Overlay.prototype.render = function (editable) {
        var placeholder;
        var cssClass = overlayClass + ' ' + overlayComponentClass;
        var attr = {
            "data-type": editable.getTypeName(),
            "data-path": editable.path,
            "tabindex": 0
        };

        this.renderDef = this.prepareRendering(editable);

        cssClass = this.renderDef.container ? cssClass + ' ' + overlayContainerClass : cssClass;
        cssClass = this.renderDef.orderable ? cssClass + ' ' + overlayDraggableClass : cssClass;
        cssClass = this.renderDef.disabled ? cssClass + ' is-disabled' : cssClass;
        attr.draggable = this.renderDef.draggable;

        cssClass = this.renderDef.dropTarget ? cssClass + ' ' + overlayDropTargetClass : cssClass;

        // placeholder use case
        placeholder = this.renderDef.placeholder;
        if (placeholder) {
            cssClass += ' ' + overlayPlaceholderClass;
            attr['data-text'] = placeholder;
            attr['title'] = placeholder;
        }

        // set class
        attr["class"] = cssClass;

        this.dom = $("<div/>", attr);

        this.renderName(editable, this.dom);

        return this.dom;
    };

    /**
     * Removes the {@link Granite.author.ui.Overlay} HTMLElement from its DOM container
     *
     * <p>Teardown function</p>
     *
     * @function Granite.author.ui.Overlay#remove
     */
    ns.ui.Overlay.prototype.remove = function () {
        this.dom.remove();
    };

    /**
     * Recreates the overlay for the given {@link Granite.author.Editable}
     *
     * @function Granite.author.ui.Overlay#recreate
     *
     * @param {Granite.author.Editable} editable - The {@link Granite.author.Editable} instance for which to render an overlay
     */
    ns.ui.Overlay.prototype.recreate = function (editable) {
        var dom = this.render(editable);

        this.dom.replaceWith(dom);
        this.dom = dom;
    };

    /**
     * Called to position the current {@link Granite.author.ui.Overlay} on top of the content of the page
     * that correspond to its associated {@link Granite.author.Editable} and the original content of the edited page located in the ContentFrame
     *
     * @function Granite.author.ui.Overlay#position
     *
     * @param {Granite.author.Editable} editable     - The {@link Granite.author.Editable} instance for which to render an overlay
     * @param {Granite.author.Editable} parent       - The {@link Granite.author.Editable} parent of the editable object
     */
    ns.ui.Overlay.prototype.position = function (editable, parent) {
        var estate = editable.getArea();

        if (estate) { // estate is set
            var parentCurrentPos = parent && parent.overlay ? parent.overlay.currentPos : null;
            if (this.currentPos && // compare to old position
                this.currentPos.top === estate.top &&
                this.currentPos.left === estate.left &&
                this.currentPos.width === estate.width &&
                this.currentPos.height === estate.height &&
                this.currentPos.parent.top === (parentCurrentPos ? parentCurrentPos.top : 0) &&
                this.currentPos.parent.left === (parentCurrentPos ? parentCurrentPos.left : 0)) {

                // abort if position didn't change -> decreases FOUT
                return;
            }

            this.dom.css({
                // the parent influences the position
                top: parentCurrentPos ? estate.top - parentCurrentPos.top : estate.top,
                left: parentCurrentPos ? estate.left - parentCurrentPos.left : estate.left,
                width: estate.width,
                height: estate.height
            });

            this.currentPos = estate;
            this.currentPos.parent = {
                top: parentCurrentPos ? parentCurrentPos.top : 0,
                left: parentCurrentPos ? parentCurrentPos.left : 0
            };
        }
    };

    /**
     * Toggle displays the current overlay
     *
     * @function Granite.author.ui.Overlay#setVisible
     *
     * @param {boolean} condition - Whether or not to display the current overlay
     */
    ns.ui.Overlay.prototype.setVisible = function (condition) {
        this.dom.toggleClass('is-hidden', condition === false);
    };

    /**
     * Toggle disables the current overlay
     *
     * @function Granite.author.ui.Overlay#setDisabled
     *
     * @param {boolean} condition - Whether or not to disable the current overlay
     */
    ns.ui.Overlay.prototype.setDisabled = function (condition) {
        this.dom.toggleClass('is-disabled', condition !== false);
    };

    /**
     * Toggle select the current overlay
     *
     * @function Granite.author.ui.Overlay#setSelected
     *
     * @param {boolean} condition - Whether or not to select the current overlay
     */
    ns.ui.Overlay.prototype.setSelected = function (condition) {
        this.dom.toggleClass('is-selected', condition !== false);
    };

    /**
     * Toggle activate the current overlay
     *
     * @function Granite.author.ui.Overlay#setActive
     *
     * @param {boolean} condition - Whether or not to activate the current overlay
     */
    ns.ui.Overlay.prototype.setActive = function (condition) {
        this.dom.toggleClass('is-active', condition !== false);
    };

    /**
     * Toggle disables the current overlay
     *
     * @function Granite.author.ui.Overlay#setHover
     *
     * @param {boolean} condition - Whether or not to disable the current overlay
     */
    ns.ui.Overlay.prototype.setHover = function (condition) {
        this.dom.toggleClass('is-hover', condition !== false);
    };

    /**
     * Is the current overlay visible
     *
     * @function Granite.author.ui.Overlay#isVisible
     *
     * @returns {boolean}
     */
    ns.ui.Overlay.prototype.isVisible = function () {
        return !this.dom.hasClass('is-hidden');
    };

    /**
     * Is the current overlay disabled
     *
     * @function Granite.author.ui.Overlay#isDisabled
     *
     * @returns {boolean}
     */
    ns.ui.Overlay.prototype.isDisabled = function () {
        return this.dom.hasClass('is-disabled');
    };

    /**
     * Is the current overlay selected
     *
     * @function Granite.author.ui.Overlay#isSelected
     *
     * @returns {boolean}
     */
    ns.ui.Overlay.prototype.isSelected = function () {
        return this.dom.hasClass('is-selected');
    };

    /**
     * Is the current overlay active
     *
     * @function Granite.author.ui.Overlay#isActive
     *
     * @returns {boolean}
     */
    ns.ui.Overlay.prototype.isActive = function () {
        return this.dom.hasClass('is-active');
    };

    /**
     * Is the current overlay hovered
     *
     * @function Granite.author.ui.Overlay#isHover
     *
     * @returns {boolean}
     */
    ns.ui.Overlay.prototype.isHover = function () {
        return this.dom.hasClass('is-hover');
    };

    /**
     * Reference for legacy API
     *
     * @deprecated
     */
    ns.Overlay = ns.ui.Overlay;

}(jQuery, Granite.author, jQuery(document), this));
