(function(document, $, ns) {
    "use strict";
	
	var MERCHANT_NAME_SELECTOR = '.merchant-name-validator';

    $.validator.register({
        selector: MERCHANT_NAME_SELECTOR,
        validate: function(el) {

            var fieldVal = el.val();
            var pattern = /[~"%&<>]/;
            var result = pattern.test(fieldVal) ;

            if(result){
				return Granite.I18n.get("Invalid characters  \" % & < > are not allowed .");
            }

        }
    });

    $(document).on("click", ".cq-dialog-submit", function(e) {
    	
    	var pagePath = window.location.href;
        $.ajax({
            url: "/bin/issuerOfferIdGeneration",
            cache: true,
            type: "POST",
            data: {
                pagePath: pagePath
            },
            success: function(data) {

            }
        });
        
    });
})(document, Granite.$, Granite.author);