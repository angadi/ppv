(function ($) {

    var DATEPICKER_SELECTOR = "form [data-validation='custom-validator-promotion-dates']";

    $.validator.register({
        selector: DATEPICKER_SELECTOR,
        validate: validate 
    });
 
    function validate($el){

    	var $form = $el.closest("form"),
        	$promoStartField = $form.find("[name='./promoStartDate']") ,
         	$promoEndField = $form.find("[name='./promoEndDate']") ,
            promoStartMilis  = new Date($promoStartField.val()).getTime(),
            promoEndMilis   = new Date($promoEndField.val()).getTime(),
            promoStartLabel = $promoStartField.closest(".coral-Form-fieldwrapper").find(".coral-Form-fieldlabel").html() ,
            currentLabel = $el.closest(".coral-Form-fieldwrapper").find(".coral-Form-fieldlabel").html() ;

        if(promoStartMilis >= promoEndMilis ){
            if(currentLabel == promoStartLabel ){
                return "Promotion Start Date cannot be later than Promotion End Date ";
            }else{
				return "Promotion End Date cannot be earlier than Promotion Start Date ";
            }
        }else{
            return null ;
        }
    }
}(jQuery));