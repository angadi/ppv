(function(ns, window, document, $, Granite, undefined) {
    'use strict';

    var RICHTEXT_SELECTOR = '.coral-RichText';

    $.validator.register({
        selector: RICHTEXT_SELECTOR,
        validate: function(el) {

            var $field = el.closest(".coral-Form-field"),
                maxLength = el.data('maxLength');
            if (null !== maxLength) {
                if (el.text().length > maxLength) {
                    return Granite.I18n.get("Maximum characters allowed are " + maxLength);
                }
            }
        },
    });


})(window.aemTouchUIValidation = window.aemTouchUIValidation || {}, window, document, Granite.$, Granite);