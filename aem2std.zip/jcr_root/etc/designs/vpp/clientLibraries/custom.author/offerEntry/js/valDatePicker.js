(function ($) {

    var DATEPICKER_SELECTOR = "form [data-validation='custom-validator-validity-dates']";

    $.validator.register({
        selector: DATEPICKER_SELECTOR,
        validate: validate 
    });
 
    function validate($el){
	
 		var $form = $el.closest("form"),
        	$valStartField = $form.find("[name='./valStartDate']") ,
         	$valEndField = $form.find("[name='./valEndDate']") ,
            valStartMilis  = new Date($valStartField.val()).getTime(),
            valEndMilis   = new Date($valEndField.val()).getTime(),
            valStartLabel = $valStartField.closest(".coral-Form-fieldwrapper").find(".coral-Form-fieldlabel").html() ,
            currentLabel = $el.closest(".coral-Form-fieldwrapper").find(".coral-Form-fieldlabel").html() ;

        if(valStartMilis >= valEndMilis ){
            if(currentLabel == valStartLabel ){
                return "Validity Start Date cannot be later than Validity End Date ";
            }else{
				return "Validity End Date cannot be earlier than Validity Start Date ";
            }
        }else{
            return null ;
        }
    }
}(jQuery));