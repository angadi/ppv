$(document).ready(function(){
	// Get the modal
	var modal = document.getElementById('myModal');

	// Get the button that opens the modal
	var btn;
    if($('#Button').is(':visible')){
		btn=document.getElementById('Button');
    }
    else{
        btn=document.getElementById('Mobilelink');
    }

	// Get the login cancel button element that closes the modal
	var loginCancel = document.getElementsByClassName("loginCancel")[0];

	// When the user clicks on the button, open the modal 
	if(btn){
		btn.onclick = function() {
			modal.style.display = "block";
			var count = $('.swiper-slide').length;
			if(count<3){
			var $select2Container =$('#myModal').find('.select2 input');
			$select2Container.focus();
			$('#myModal').find('a:last').on('keydown',function(e){
				if ($("this:focus") && (e.which == 9)) {
					e.preventDefault();
					$select2Container.focus();
				}
			});
			}
			else{
				$('#myModal').find('a:first').focus();
                $('#myModal').find('a:first').on('keydown',function(e){
					if ($("this:focus") && (e.which == 9)) {
                        if(e.shiftKey){
							e.preventDefault();
							$('#myModal').find('.loginBtns .loginConfirm').focus();
                        }
					}
				});

				$('#myModal').find('a:last').on('keydown',function(e){
					if ($("this:focus") && (e.which == 9)) {
                        if(e.shiftKey){
                        }
                        else{
							e.preventDefault();
							$('#myModal').find('a:first').focus();
                        }
					}
				});
			}
			if ((count <= 2) && (count > 1)) {
				$(".swiper-button-next,.swiper-button-prev").css("display", "none");
				var swiper = new Swiper('.swiper-container', {
					/*effect : 'coverflow',*/
					slidesPerView : 2,
					centeredSlides : false,
					loop : false,
					coverflow : {
						rotate : 0,
						stretch : 0,
						depth : 87,
						modifier : 6,
						slideShadows : false
					},
                    onTransitionEnd: function(swiper){
                        populateDropDown($(".swiper-slide-active img")[0]);
                    },
                    breakpoints: {
                        // when window width is <= 320px
                        320: {
                          slidesPerView: 2,
                          spaceBetween: 10,

                        },
                        // when window width is <= 480px
                        480: {
                          slidesPerView: 2,
                          spaceBetween: 10
                        },
                        // when window width is <= 640px
                        640: {
                          slidesPerView: 2,
                          spaceBetween: 10
                        }
                    }

				});

			} else if (count == 1) {

				$(".swiper-button-next,.swiper-button-prev").css("display", "none");
				var swiper = new Swiper('.swiper-container', {
					/*effect : 'coverflow',*/
					slidesPerView : 1,
					centeredSlides : true,
					loop : false,
					coverflow : {
						rotate : 0,
						stretch : 0,
						depth : 87,
						modifier : 6,
						slideShadows : false
					},
                    onTransitionEnd: function(swiper){
                        populateDropDown($(".swiper-slide-active img")[0]);
                    },
                    breakpoints: {
                        // when window width is <= 320px
                        320: {
                          slidesPerView: 1,
                          spaceBetween: 0,

                        },
                        // when window width is <= 480px
                        480: {
                          slidesPerView: 1,
                          spaceBetween: 0
                        },
                        // when window width is <= 640px
                        640: {
                          slidesPerView: 1,
                          spaceBetween: 0
                        }
                    }

				});

			}

			else {

				var swiper = new Swiper('.swiper-container', {
					nextButton : '.swiper-button-next',
					prevButton : '.swiper-button-prev',
					effect : 'coverflow',
					slidesPerView : 2.253,
					centeredSlides : true,
					loopedSlides : 3,
					loop : true,
					slideToClickedSlide : true,
					coverflow : {
						rotate : 0,
						stretch : 0,
						depth : 100,
						modifier : 4,
						slideShadows : false
					},
                    onTransitionEnd: function(swiper){
                        populateDropDown($(".swiper-slide-active img")[0]);
                    },
                    breakpoints: {
                        // when window width is <= 320px
                        320: {
                          slidesPerView: 2.253,
                          spaceBetween: 0,

                        },
                        // when window width is <= 480px
                        480: {
                          slidesPerView: 2.253,
                          spaceBetween: 0
                        },
                        // when window width is <= 640px
                        640: {
                          slidesPerView: 2.253,
                          spaceBetween: 0
                        }
                    }

				});
			}

		}
	}

	// When the user clicks on login cancel (x), close the modal
    if(loginCancel){
        loginCancel.onclick = function() {
            modal.style.display = "none";
        }
    }

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
	}  
});