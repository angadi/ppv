$(document).ready(function() {
     var pathname = $('#_currentPagePath').val();
     $.ajax({
         url: "/bin/cardArtLanding",
         cache: true,
         type: "GET",
         data: {
             pagePath: pathname
         },
         success: function(data) {
             $('#cardLogoImgId').attr('src', data);
         }

     });
     createJson(pathname);
 });

function createJson(pathname)
{
	var offersData = $("#offers_catpage");
		if( (offersData.length > 0) && (!$.isEmptyObject(offersData.data('offers')))){
			var offersOriginal = $("#offers_catpage").data("offers"),
			featuredOriginal = offersOriginal['featured_offers'], 
			moreOriginal = offersOriginal['more_offers'];

			var t = _.template($('#offerTemplate').html());
			totalFeaturedOffers = featuredOriginal.length;
			currentPagePath = $('#_currentPagePath').val();
			parentPagePath  = $('#_currentParentPagePath').val();
			currentPageName = $('#_currentPageName').val();
            var resultData = "", startTag = "<div class='row nonFeaturedOffersRow offerRow featuredofferspreview'>", endTag = "</div>", arrTotalIdx = totalFeaturedOffers - 1;
			if(totalFeaturedOffers > 0){
                for(var i=0;i<totalFeaturedOffers;i++){
    
                    tempObj = {};
                    tempObj = $.extend({}, featuredOriginal[i], {'currentPageName' : currentPageName , 'parentPagePath': parentPagePath, 'currentPagePath': currentPagePath, "offer_category": "featured_offers", 'onload': 'onFeatureOfferLoad(this)' });
                     if (i % 3 === 0 ) 
                     {
                         resultData = resultData + startTag;
    
                         
                     }
                    resultData = resultData + t(tempObj);
                    if ((i === arrTotalIdx) || (i % 3 === 2)) 
                    {
                        resultData = resultData + endTag;
    
                        $('' + resultData) .appendTo(".previewFeaturedWrap");
                        resultData = "";
                    }
                } 
            }
            else{
				$('.previewFeaturedWrap').remove();
                $('.featuredTitle').remove();
                $('.moreOfferTitle div').remove();
                $('.moreOfferTitle').html('<div class="offerContentTitle more-offer" style="padding-top:50px"></div>');
            }
			
		   offers = moreOriginal.slice(0);
		   if(offers.length === 0){
                 $('.moreOfferTitle').remove();
        		$('#loader').remove();
           }
           else{
		   	initializeLazyLoading();
           }
		}
    else{
		$('#loader').remove();
    }

}

function onFeatureOfferLoad(e){
    loadedFeaturedOffers++;
    if(totalFeaturedOffers === loadedFeaturedOffers){
        var offersToLoad =document.querySelectorAll('.featuredofferspreview .categoryImg.offerDisplay'), offersToLoadLength = offersToLoad.length, i = 0;
        for(i=0;i< offersToLoadLength; i++){
			offersToLoad[i].classList.remove('offerDisplay');
        }
    }
}

function onMoreOfferLoad(e){
    offersLoaded++;
    if(offersLoaded === offersToBeLoaded){
        var offersToLoad = document.querySelectorAll('.categoryImg.offerDisplay'), offersToLoadLength = offersToLoad.length, i = 0;
        for(i=0;i< offersToLoadLength; i++){
			offersToLoad[i].classList.remove('offerDisplay');
        }
    }
}

var LOADOFFERS = 15, scene = '', tempObj = {},currentPageName ='', offersLoaded = 0, offersToBeLoaded = 0, totalFeaturedOffers = 0, loadedFeaturedOffers = 0, parentPagePath='', currentPagePath='', offers = [];
function initializeLazyLoading() {

    var controller = new ScrollMagic.Controller();

    // create a scene
    scene = new ScrollMagic.Scene({
            triggerElement: ".previewoffer_wrapper #loader",
            triggerHook: "onEnter"
        })
        .on("enter", function(e) {
            if (!$(".previewoffer_wrapper #loader").hasClass("active")) {
                $(".previewoffer_wrapper #loader").addClass("active");
                	offersToBeLoaded = 0;
                	offersLoaded = 0;
                	setTimeout(addBoxes, 500, LOADOFFERS);
            }
        })
        .addTo(controller); // assign the scene to the controller
}


function addBoxes() {
    
    var childrenLength = $(".moreofferpreview .categoryImg").length,
        arrLength = offers.length, len = 0, e = 0;


    for (var t = childrenLength; t < arrLength; t++) {
        if (offers[t]) {
            e++;
            if (e == LOADOFFERS) {
                break;
            }
        } else {
            break;
        }
    }
    len = childrenLength + e;
	offersToBeLoaded = e;

    var startTag = "<div class='row nonFeaturedOffersRow offerRow'>", endTag = "</div>", resultData = "", arrTotalIdx = len - 1;  
    for (var i = childrenLength; i < len; i++) {
            var t = _.template($('#offerTemplate').html());
            tempObj = {};
            tempObj = $.extend({}, offers[i], {'currentPageName' : currentPageName ,'parentPagePath': parentPagePath, 'currentPagePath': currentPagePath, "offer_category": "more_offers", 'onload': 'onMoreOfferLoad(this)' });
              if (i % 3 === 0 ) 
              {
                 resultData = resultData + startTag;
    
              }
              resultData = resultData + t(tempObj);
              if ((i === arrTotalIdx) || (i % 3 === 2)) 
              {
                resultData = resultData + endTag;
                //$('.previewoffer_wrapper').prepend($('' + resultData));
				$('' + resultData) .appendTo(".moreofferpreview")
                resultData = "";
              }
    }

    // "loading" done -> revert to normal state
    scene.update(); // make sure the scene gets the new start position
    $("#loader").removeClass("active");

    if (len === offers.length) {
        $("#loader").hide().addClass('active');
        return false;
    }

}


function checkJsonObject(offerJson)
{
    $.each(offerJson, function(i, item) {
    if(item.offerTitle.trim().length==0 || item.thumbImage.trim().length==0 || item.offerShortDesc.trim().length==0 )
    {
		delete offerJson[i];
    }
     });
    return offerJson;
}

function setPreviewParameters(e) {
    localStorage.setItem("currentOffer", $(e).find('.currentOffer').val());
    localStorage.setItem("catPagePath", $(e).find('.catPagePath').val());
    localStorage.setItem("parentName", $(e).find('.parentName').val());
	localStorage.removeItem("isSearchPreview");
} 
