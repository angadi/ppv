$(document).ready(function() {
 var alreadyHighlight = "false";
 var isSearchPage = "";
 var catPath = localStorage.getItem("catPagePath");
 var catPageName = "";
 var hashPath = window.location.hash.substring(1) ;
 var hashPathArr = hashPath.split("/");
 if( hashPathArr.length == 2 ) {
 catPageName = hashPathArr[0];
        }

var currentcatPath = document.getElementsByName("highlight");
var currentcatPathcpy = document.getElementsByName("highlight");
 isSearchPage = document.getElementsByClassName("search_offer_preview");
for(var j = 0; j < currentcatPathcpy.length; j++)
{
   var classValue = currentcatPathcpy[j].getAttribute("class");
    if (classValue == "noPadding smPadding active")
    { alreadyHighlight = "true";

    }
}

for (var i = 0; i < currentcatPath.length; i++) {
    var currentPathCheck = currentcatPath[i].getAttribute("href");
    var splitUrl = currentPathCheck.split('/');
    var currentPath = splitUrl[splitUrl.length-1];
    var currPageName = currentPath.split('.')[0];

    if( alreadyHighlight == "false" && catPageName==currPageName && isSearchPage.length == 0)
    { currentcatPath[i].removeAttribute("class");
     currentcatPath[i].setAttribute("class","noPadding smPadding active");
    }

}
    var $menuLeft = $('.pushmenu-right');
    var $nav_list = $('#nav_list');
    if ($menuLeft && $nav_list && $menuLeft.length > 0 && $nav_list.length > 0) {
        $nav_list.click(function() {
            if ($(this).hasClass('active')) {
                $('body, #slide-nav .container').animate({
                    right: "0"
                }, 200);
            } else {
                $('body, #slide-nav .container').animate({
                    right: "87%"
                }, 200);
            }
            $(this).toggleClass('active');
            $('.pushmenu-push').toggleClass('pushmenu-push-toleft');
            $menuLeft.toggleClass('pushmenu-open');
        });
    }

 });
 
function removeMenu (e) {
	e.stopPropogation();
    $('#wrapper #slide-nav .top-nav-container .drop-down-wrapper ul').hide();
}
function addMenu () {
    $('#wrapper #slide-nav .top-nav-container .drop-down-wrapper ul').show();
}