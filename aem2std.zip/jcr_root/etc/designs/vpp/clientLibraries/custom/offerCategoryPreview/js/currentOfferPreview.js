//global variables
var currentIndex;
var totalIndex;
var previewData;
var checkClick;
var urlVal;
var isbenefit;

function assignGlobalVariables(data) {
    if( Object.keys(data).length!=0)
    {
    previewData = data;
    currentIndex = parseInt(previewData.currentOfferIndex);
    totalIndex = Object.keys(previewData.previewUrls).length;
    var catPageName = previewData.catPageName;
    $('.catPageName').html(catPageName);
    var catPagePath = previewData.catPagePath;
    $('.catPageName').attr('href', catPagePath);
	$('.headerBackBtn').attr('href', catPagePath);
    var disclaimerText = previewData.disclaimerText;
    if (disclaimerText != undefined) {
        $('.disclaimer_content').html(disclaimerText);
    }
    fillEachOfferData(previewData.currentOfferData);
    if (currentIndex === 0) {
        $('.prevOffer, .prev-offer-sign').hide();
    }
    if (currentIndex === totalIndex - 1) {
        $('.nextOffer, .next-offer-sign').hide();
    }
    }
}

function onClickPrevious() {
    checkClick = "previous";
    if (currentIndex !== 0) {

        currentIndex = currentIndex - 1;
        var previewUrl = previewData.previewUrls[currentIndex];

        getEachOfferDataAjax(previewUrl)
    }
    if (currentIndex < totalIndex - 1) {
        $('.nextOffer, .next-offer-sign').show();
    }
    if (currentIndex === 0) {
        $('.prevOffer, .prev-offer-sign').hide();
    }
    appendUrl();

}

function onClickNext() {
    checkClick = "next";
    if (currentIndex < totalIndex - 1) {

        currentIndex = currentIndex + 1;
        var previewUrl = previewData.previewUrls[currentIndex];
        getEachOfferDataAjax(previewUrl)
    }
    if (currentIndex !== 0) {
        $('.prevOffer, .prev-offer-sign').show();
    }
    if (currentIndex === totalIndex - 1) {
        $('.nextOffer, .next-offer-sign').hide();
    }
    appendUrl();

}

function getEachOfferDataAjax(previewUrl) {
    $.ajax({
        url: "/bin/getAllPreviewOfferPages",
        type: "POST",
        data: {
            currentOffer: previewUrl

        },
        success: function(data) {
            fillEachOfferData(data.currentOfferData);
            if(checkClick === 'next'){
                $('.nextOffer').focus();
            }
            else if('previous' === checkClick){
                $('.prevOffer').focus();
            }
        }
    });

}
function redeemModal() {
    $('#redeemModal').modal('show');
}
function fillEachOfferData(data) {
    if(data!=undefined || data!=null)
    {
    if(Object.keys(data).length!=0)
    {
    var offerId = data.offerId;
    var isSearchPreview = localStorage.getItem("isSearchPreview");
    if (isSearchPreview == undefined) {
        localStorage.setItem("currentOffer", offerId);
    }
    var offerTitle = data.offerTitle;
    var offerShortDesc = data.offerShortDesc;
    var pageType = data.pageType;
    var thumbImage = data.thumbImage;
    var offerCopy = data.offerCopy.replace("<a","<a target='_blank'");
    var heroImage = data.heroImage;
    var valStartDate = data.valStartDate;
    var valEndDate = data.valEndDate;
    var merchantLogo = data.merchantLogo;
    var visaTandC = data.visaTandC;
    var merchantTandC = data.merchantTandC;
    var redemptionInst = data.redemptionInst;
    var redemptionURL = data.redemptionURL;
    var redemptionTel = data.redemptionTel;
    var redemptionEmail = data.redemptionEmail;
    var merchantName = data.merchantName;
    var termsAndConditions = data.termsAndConditions;
    var tAndConditionsCount = parseInt(data.tAndConditionsCount);
    var heroImageAltText=data.heroImageAltText;

  /*  if (merchantName.length !== 0) {
        $('#offerName').html(merchantName);
        $('.offerDetailName').html(merchantName);
    } else {
        $('#offerName').html(offerTitle);
        $('.offerDetailName').html(offerTitle);
        merchantName=offerTitle;
    }  */  
    $('#offerName').html(offerTitle);
    $('.offerDetailName').html(offerTitle);
    if(heroImageAltText.length!==0)
    {
        $('.heroImageOfferPreview').attr('title', heroImageAltText);
    }
        else
        {
          $('.heroImageOfferPreview').attr('title', merchantName);
        }

    $('.offerDetailShortDesc').html(offerShortDesc);
    $('.heroImageOfferPreview').attr('src', heroImage);
    $('.offerDetailCopy').html(offerCopy);
    //merchant Logo
    if (merchantLogo.length !== 0) {

                $('.merchantLogo').show();
                $('.merchantLogo img').attr('src', merchantLogo);
                $('.merchantLogo img').attr('title', merchantName);
            } else {
                $('.merchantLogo').hide();
            }
            //offerDate
           if (pageType.length == 0 || pageType!="benefit") {
            $('.offerDetailValidDate').empty();
            if (valStartDate.length !== 0 && valEndDate.length !== 0) {
                $('p.offerDetailDate.offerDetailDateValidText').show();
             $('.offerDetailDateValidText').show();
                valStartDate = valStartDate.replace(/,/g, ", ");
                valEndDate = valEndDate.replace(/,/g, ", ");    
                valStartDate = removePrefixDateNumber(valStartDate);
                valEndDate = removePrefixDateNumber(valEndDate);
                $('.offerDetailValidDate').append(valStartDate + " - " + valEndDate);
            }
          else
            {
                $('.offerDetailDateValidText').hide();

            }
           }
        else{
            $('p.offerDetailDate.offerDetailDateValidText').hide();
          }

            //redemption conditions
            if (redemptionURL.length === 0 && redemptionTel.length === 0 && redemptionEmail.length === 0) {
                $('.redeemContent').hide();
                $('.merchantLogo').addClass('increasePadTop');
            } else if (redemptionURL.length !== 0) {
                $('.redeemContent').show();
                $('.merchantLogo').removeClass('increasePadTop');
                var urlVal = redemptionURL.trim();
                if (urlVal.indexOf('href') != -1) {
                    urlVal = redemptionURL.match(/href="(.*?)"/)[1];
                }
                $('.redeemContent').empty();
                var urlv = urlVal.trim();
                //if (urlVal.trim() == "https://www.eclaimsline.com" || urlVal.trim() == "https://cardbenefitservices.com") {
                if((true === /(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/|www\.)?(eclaimsline\.com)$/.test(urlv)) || (true === /(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/|www\.)?(cardbenefitservices\.com)$/.test(urlv))){
                    $('.redeemURLVal').val(urlVal);
                    $('.redeemContent').append("<a class='redeemBtnURL' href='javascript:checkExternalURL(this)'>" + "</a>");
                } else {
                    $('.redeemContent').append("<a class=\"" + "redeemBtnURL" + "\"" + "href=\"" + urlVal + "\"" + "target=\"" + "_blank" + "\"" + "></a>");
                }
                if (redemptionInst.length === 0) {
                    $('.redeemBtnURL').html("Redeem");
                } else {
                    $('.redeemBtnURL').html(redemptionInst);
                }
            } else if (redemptionURL.length === 0) {
                $('.redeemContent').show();
                $('.redeemContent').empty();

        $('.redeemContent').append("<a id='redeemButton' onclick='redeemModal();' href='javascript:void(0);' class='redeemBtnURL'>" + "</a>");
        if (redemptionInst.length === 0) {
            $('#redeemButton').html("Redeem");
        } else {
            $('#redeemButton').html(redemptionInst);
        }
        if (redemptionTel.length !== 0) {
            $('.redeemTelEmail').html(redemptionTel)
        } else if (redemptionTel.length === 0 && redemptionEmail.length !== 0) {
            $('.redeemTelEmail').html(redemptionEmail)
        }

    }
    //Terms and Conditions
    if (tAndConditionsCount === 0) {
        $('.tcContent').empty();
        $('.termsConditions').hide();
        $('.moreBtn').parent('li').addClass('hidden');
		$(".tcContent, .smSeperator, .wrapperMiddle").hide();
        $("#preview-page-content .offerDetailContent").css('padding-bottom',80);
        $(".previewOffer .morePlus, a.downloadBtn.printHide, .wrapperBottom").css('padding',0);

    } else {
        $('.termsConditions').show();
        if (termsAndConditions.length !== 0) {
            $('.tcContent').html(termsAndConditions.replace("<a","<a target='_blank'"));
        } else {
            $('.tcContent').html(visaTandC + merchantTandC.replace("<a","<a target='_blank'"));
        }
		$('.moreBtn').addClass('displayTc');
        $('.lessBtn').addClass('displayTc');
        $('.morePlus ul li a:eq(0)').removeClass().addClass('moreBtn displayTc');
        $('.morePlus ul li a:eq(1)').removeClass().addClass('lessBtn displayTc');
		$('.wrapperBottom').find('.row').removeClass('borderFocus');
        if (tAndConditionsCount <= 9) {
            $('.moreBtn').removeClass('displayTc').addClass('hideElem');
            $('.lessBtn').removeClass('displayTc').addClass('hideElem');
        } else {
            $('.moreBtn').parent('li').removeClass('hidden');
            $('.moreBtn').removeClass('hideElem').addClass('displayTc');
            $('.lessBtn').removeClass('hideElem').addClass('displayTc');
        }
    }
    }
    }

}

function removePrefixDateNumber(date){
	var arr = date.split(',');
	monthDate = arr[0].split(' ');
	validatedString = monthDate[0] + " " +monthDate[1].replace(/^0+/, '') +", " + arr[1];
	return validatedString;
}

function appendUrl() {
    var hrefVal = "#" + previewData.catPagePath.substring(previewData.catPagePath.lastIndexOf('/') + 1,previewData.catPagePath.lastIndexOf('.')) +"/" +  previewData.offerIdList[currentIndex];
    if (checkClick === "previous") {
        $('.prevOffer').attr('href', hrefVal);
    }
    if (checkClick === "next") {
        $('.nextOffer').attr('href', hrefVal);
    }

}




function checkExternalURL(e) {
    var modal = $('#redeemURLModal');
    btn = $('.redeemBtn');
    span = $('.close');
    var dynamicText=localStorage.getItem("selectedCardText");
    if(dynamicText!=undefined)
    {
		dynamicText = encodeURI(dynamicText);
		dynamicText = decodeURI(dynamicText);
		$('.dynamicText').html(dynamicText);
    }
   modal.modal('show');
}

function navigateURL(e) {

    var urlVal = $('.redeemURLVal').val();
    $('#modalContinueURL').attr('href', urlVal);
}


$( document ).ready( function() {
    /* offerPreview JS*/
    $( '.downloadBtn' ).click( function( e ) {
        e.preventDefault();
        var logoImgItem = $( '#logoAnchor img#logoImgDiv' );
        var links = $( "link" ).clone();
        var printHtml = '<!doctype html><html lang="en" style="height: 99%">' +
            '<head><title>Download Offer</title>' +
            '<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">' +
            '<meta charset="utf-8">';
        $.each( links, function( index, value ) {
            printHtml += value.outerHTML;
        } );
        printHtml += '<link rel="stylesheet" media="screen" href="/etc/designs/vpp/clientLibraries/custom/offerCategoryPreview/css/printcancel.css" type="text/css">';
        printHtml += '<style>.remainingTC.hideElem{display:block;}</style></head><body style="height: 99%" onload="window.print();">';
        printHtml += '<div id="wrapper">';
        printHtml += '<div class="container maxWidthHeader">' +
            '<a id="logoAnchor" class="navbar-brand navBarBrand" href="#" role="presentation">' +
            '<img id="logoAnchor" class="navbar-brand navBarBrand" src="' + logoImgItem.attr( 'src' ) + '" alt="' + logoImgItem.attr( 'alt' ) + '">' +
            '</a></div>';
        printHtml += '<div id="page-content" class="maxWidth container" style="padding-top: 10px;"><div class="main">';
        printHtml += '<div id="content" class="offerDetailWrapper"  style="padding-top: 0px;">';
        printHtml += '<div class="offerDetailTop" style="padding: 0 15px;">' +
            '<div class="offerDetailContainer" style="padding-top: 0;">' +
            $( '#p-des' ).html() +
            '</div>' +
            '</div>';
        printHtml += '<div class="offerDetailMiddle">' +
            '<div class="offerDetailMiddleNavRow">' +
            '<div class="offerDetailMiddleNav" style="padding: 0 15px;">' +
            $( '.termsConditions' ).html() +
            '</div>' +
            '</div>' +
            '</div>';
        printHtml += '<div class="smSeperator smLiImgHide" style="border: none;"></div>';
        printHtml += '<div class = "offerDetailBottom TCWrapperDiv">' +
            '<div class="offerDetailBottomRow">' +
            '<div class="TCWrapper">' +
            $( '.tcContent' ).html() +
            '</div>' +
            '</div>' +
            '</div>';
        // end of offerDetailWrapper
        printHtml += '</div>';
        // end of main, page-content
        printHtml += '</div></div>';
        printHtml += '<footer class="printPage">' + $( 'footer' ).html() + '</footer>';
        //end of wrapper
        printHtml += '</div>';
        printHtml += '</body></html>';
        var w = window.open();
        w.document.write( printHtml );
        w.document.close();
        w.focus();
    } );
} );