function linkChange(comp,value){ 
var panel = comp.findParentByType('panel') ;
var linkType = panel.getComponent("linkType");
var footerInternalLink = panel.getComponent("footerInternalLink");
var footerExternalLink = panel.getComponent("footerExternalLink");
var linkTypeValue = panel.getComponent("linkType").getValue();
if("internal"==linkTypeValue)
{

footerInternalLink.show();
footerExternalLink.hide();

}
else
{

footerInternalLink.hide();
footerExternalLink.show();
}

}



function onLoadLinkChange(dlg)
{
    var multifiledSetVariable=dlg.getField("./footerLinkMap");
    var count=multifiledSetVariable.items.getCount();
    for (i=0;i<count-1;i++)
    {

     var fieldValue=multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[1].getValue() ;
     if(fieldValue=="external")
     {
      multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[3].show() ;
     multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[2].hide() ;

     }

     }

}
