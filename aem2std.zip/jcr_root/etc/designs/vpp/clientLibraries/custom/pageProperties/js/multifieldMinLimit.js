(function (document, $, ns) {
 "use strict";
 
$(document).on("click", ".cq-dialog-submit", function (e) {

var footerLinkLength=$("[class='coral-Form-fieldset'][data-name='./footerLinkMap']").length;



if(footerLinkLength===0)
{
    e.stopPropagation();
    e.preventDefault();
    $(window).adaptTo("foundation-ui").alert("Invalid Inputs","You must create at least one set of Footer Link"); 
}


    });
})(document, Granite.$, Granite.author);