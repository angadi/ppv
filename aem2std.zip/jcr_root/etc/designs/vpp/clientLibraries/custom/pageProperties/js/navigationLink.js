function navigationLinkChange(comp,value){ 
var panel = comp.findParentByType('panel') ;
var linkType = panel.getComponent("navigationLinkType");
var navigationInternalLink = panel.getComponent("navigationInternalLink");
var navigationExternalLink = panel.getComponent("navigationExternalLink");
var linkTypeValue = panel.getComponent("navigationLinkType").getValue();
if("internal"==linkTypeValue)
{

navigationInternalLink.show();
navigationExternalLink.hide();

}
else
{

navigationInternalLink.hide();
navigationExternalLink.show();
}

}



function onLoadNavigationLinkChange(dlg)
{
    //changing issuer logo links
    var issuerLogoLinkType=dlg.getField("./issuerLogoLinkType");
    var issuerLogoInternalLink=dlg.getField("./issuerLogoInternalLink");
    var issuerLogoExternalLink=dlg.getField("./issuerLogoExternalLink");
     var issuerLogoLinkTypeVal=dlg.getField("./issuerLogoLinkType").getValue();
    if(issuerLogoLinkTypeVal==="external")
    {
        issuerLogoInternalLink.hide();
        issuerLogoExternalLink.show();
    }


    //for multi-field
    var multifiledSetVariable=dlg.getField("./navigationLinksMap");
    var count=multifiledSetVariable.items.getCount();
    for (i=0;i<count-1;i++)
    {
     var fieldValue=multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[1].getValue() ;
     if(fieldValue==="external")
     {
      multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[3].show() ;
     multifiledSetVariable.items.items[i].items.items[0].items.items[0].items.items[2].hide() ;

     }

     }
}

function issuerLogoLinkChange(comp,value)
{ 
var panel = comp.findParentByType('panel') ;
var issuerLogolinkType = panel.getComponent("issuerLogoLinkType");
var issuerLogoInternalLink = panel.getComponent("issuerLogoInternalLink");
var issuerLogoExternalLink = panel.getComponent("issuerLogoExternalLink");
var issuerLogolinkTypeValue = panel.getComponent("issuerLogoLinkType").getValue();
if("external"===issuerLogolinkTypeValue)
{
issuerLogoInternalLink.hide();
issuerLogoExternalLink.show();
}
else
{
issuerLogoInternalLink.show();
issuerLogoExternalLink.hide();

}

}
function navigatonLinkCheckOnLoad(dlg)
{
    var optionVal=dlg.getField("./navigationLinkButtonOption").getValue();
    if(optionVal==="no")
    {
    dlg.getField("./issuerLogoReference").hide();
    dlg.getField("./issuerLogoLinkType").hide();
        dlg.getField("./issuerLogoInternalLink").hide();
        dlg.getField("./issuerLogoExternalLink").hide();
        dlg.getField("./issuerLogoTarget").hide();
          dlg.getField("./issuerName").hide();
          dlg.getField("./navigationLinksMap").hide();

    }
    else
    {
      dlg.getField("./issuerLogoReference").show();
       dlg.getField("./issuerLogoLinkType").show();
        if(dlg.getField("./issuerLogoLinkType").getValue()==="internal")
        {
            dlg.getField("./issuerLogoInternalLink").show();
            dlg.getField("./issuerLogoExternalLink").hide();
        }
        else
        {
            dlg.getField("./issuerLogoExternalLink").show();
            dlg.getField("./issuerLogoInternalLink").hide();
        }

        dlg.getField("./issuerLogoTarget").show();
          dlg.getField("./issuerName").show();
          dlg.getField("./navigationLinksMap").show();

    }
}
function navigatonLinkCheckOnSelection(comp,value)
{

 var panel = comp.findParentByType('panel') ;
    var dlg = comp.findParentByType("dialog");
var linkTypeVal = panel.getComponent("navigationLinkButtonOption").getValue();
    if(linkTypeVal==="yes")
    {
         panel.getComponent("issuerLogoReference").show();
        panel.getComponent("issuerLogoLinkType").show();
        if(panel.getComponent("issuerLogoLinkType").getValue()==="internal")
        {
            panel.getComponent("issuerLogoInternalLink").show();
            panel.getComponent("issuerLogoExternalLink").hide();
        }
        else
        {
             panel.getComponent("issuerLogoInternalLink").hide();
            panel.getComponent("issuerLogoExternalLink").show();
        }


        panel.getComponent("issuerLogoTarget").show();
        panel.getComponent("issuerName").show();
        panel.getComponent("navigationLinksMap").show();

        dlg.doLayout();
    }else{
		 panel.getComponent("issuerLogoReference").hide();
        panel.getComponent("issuerLogoLinkType").hide();
        panel.getComponent("issuerLogoInternalLink").hide();
        panel.getComponent("issuerLogoExternalLink").hide();
        panel.getComponent("issuerLogoTarget").hide();
        panel.getComponent("issuerName").hide();
        panel.getComponent("navigationLinksMap").hide();

    }

}