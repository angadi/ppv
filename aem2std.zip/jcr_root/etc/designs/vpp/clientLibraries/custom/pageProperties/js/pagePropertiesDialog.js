function useButtonOption(dlg){ 

	var headerTitleText = dlg.getField("./headerTitleText");
	var headerLinkText = dlg.getField("./headerLinkText");
	var buttonLabel = dlg.getField("./buttonLabel");
	var useButtonOptionVal = dlg.getField("./useButtonOption").getValue();

	if(useButtonOptionVal === true){
		buttonLabel.enable();
		headerTitleText.disable();
		headerLinkText.disable();
		buttonLabel.show();
		headerTitleText.hide();
		headerLinkText.hide();
	}else{
		buttonLabel.disable();
		headerTitleText.enable();
		headerLinkText.enable();
		buttonLabel.hide();
		headerTitleText.show();
		headerLinkText.show();
		
	}

} 