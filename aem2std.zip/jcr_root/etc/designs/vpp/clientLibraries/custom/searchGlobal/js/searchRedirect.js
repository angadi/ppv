function fetchRedirectUrl(){

	var templateName = $('.templateName').val(),
    	currentPagePath = $('.currentPagePath').val(),
   		parentPagePath  = $('.parentPagePath').val(),
		queryParam = $('.search').val(),
		redirectUrl = parentPagePath ,
    	searchPageName = "offer-search";
    if(templateName === 'landing_page'){
		redirectUrl = currentPagePath ;
    }
   // redirectUrl = redirectUrl +"/" + searchPageName + ".html?query=" + queryParam;
	redirectUrl = redirectUrl +"/" + searchPageName + ".html";
    if(queryParam.length != 0 ){
        localStorage.setItem("queryParam",queryParam);
        window.open(redirectUrl,"_self");
    }

}