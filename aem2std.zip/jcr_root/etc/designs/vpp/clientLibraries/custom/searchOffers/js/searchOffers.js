$(document).ready(function() {
     var pathname = $('#_currentPagePath').val();
     $.ajax({
         url: "/bin/cardArtLanding",
         cache: true,
         type: "GET",
         data: {
             pagePath: pathname
         },
         success: function(data) {
             $('#cardLogoImgId').attr('src', data);
         }

     });

	getAllValidOffers(pathname);

 });


function getAllValidOffers(pathname){
    $.ajax({
         url: "/bin/getLandingPageOffers",
         cache: true,
         type: "POST",
        data : { currentPagePath : pathname } ,
         success: function(data) {
             searchQueryInOffers(data);
	     }
     });
}

function searchQueryInOffers(offerdata) {

    var searchString = localStorage.getItem("queryParam");
    var resultJsonArr = [];
    if(searchString != undefined ){
    	var searchArr = searchString.match(/("[^"]+"|[^"\s]+)/g);
    }
    if(searchArr === null || offerdata == undefined || searchArr == undefined ){
        showSearchResult([]);
    }
    if(offerdata.length == 0 ){
    	showSearchResult([]);
    }
    var _ = window._;
    for (var i = 0; i < searchArr.length; i++) {
        var resultOffers = JSON.search(offerdata, "//*[contains(offerTitle, \"" +searchArr[i] + "\")] | //*[contains(offerShortDesc, \"" +searchArr[i] + "\")]");
        for(var item in resultOffers){
			resultJsonArr.push(resultOffers[item]) ;
        }

    }
    var uniqResultOffers = _.uniq(resultJsonArr,function(item){ return item.offerId });
     showSearchResult(uniqResultOffers);

}