var finalArr = [];
function showSearchResult(searchJSON)
{
	var keyword="";
    keyword=localStorage.getItem("queryParam");
	if(keyword!=undefined )
    {	
		keyword = encodeURI(keyword);
		keyword = decodeURI(keyword);
        $('#keyword').empty();
        $('#keyword').html(keyword);
    }
	
    if(searchJSON.length===0)
    {
		$("#loader").hide();
        //$('.offers').append("<div class='errorMsg noOfferErrorMsg'>No matched offer found.</div>");
        $('.noOfferErrorMsg').removeClass('hidden');
    }
    else
    {
    var resultData="";
    var srcVal="";
    var offerTitle="";
    var shortDesc="";
    var offerId="";
    var previewURL="";
    finalArr = [];
	var offerValidity = true ; 
    $('#search_result_data').empty();
    var searchPreviewUrl=$('.search_offer_preview').val();
    localStorage.setItem("catPagePath",$('.landing_page').val());
	localStorage.setItem("isSearchPreview","yes");
    $.each(searchJSON, function(key, value) 
     {
         srcVal=value.thumbImage;
		 offerTitle=value.offerTitle;
         shortDesc=value.offerShortDesc;
         offerId=value.offerId;
         previewURL=value.previewURL;
		 offerValidity = true ; 
      /*if (key % 3 == 0 ) 
      {
         resultData=resultData+startTag;

      }*/
		if( offerTitle === undefined || shortDesc === undefined || srcVal === undefined){
			offerValidity = false;
        }else if ( offerTitle.trim() == "" || shortDesc.trim() == "" || srcVal == "failure"){
			offerValidity = false;
        }
        if(offerValidity){
            resultData = appendSearchResultData(srcVal,offerTitle,shortDesc,searchPreviewUrl,offerId,previewURL);
            finalArr.push(resultData);
        }
      /*   if (key % 3 == 2 ) 
      {
          resultData=resultData+endTag;
      }*/

     });
	 initializeLazyLoading();
   //$('.offers').append(resultData);
    }
}
var LOADOFFERS = 15, scene = "",  searchOffersLoaded = 0, searchOffersToBeLoaded = 0;
function initializeLazyLoading() {

    var controller = new ScrollMagic.Controller();

    // create a scene
    scene = new ScrollMagic.Scene({
            triggerElement: ".offerListWrapper #loader",
            triggerHook: "onEnter"
        })
        .on("enter", function(e) {
            if (!$(".offerListWrapper #loader").hasClass("active")) {
                $(".offerListWrapper #loader").addClass("active");
               searchOffersLoaded = 0;searchOffersToBeLoaded = 0;
                // simulate ajax call to add content using the function below
                setTimeout(addBoxes, 500, LOADOFFERS);
            }
        })
        .addTo(controller); // assign the scene to the controller

}

    // pseudo function to add new content. In real life it would be done through an ajax request.
    function addBoxes() {

        var childrenLength = $(".offerListWrapper .offers .categoryImg").length,
            arrLength = finalArr.length, len = 0,  e = 0;

        for (var t = childrenLength; t < arrLength; t++) {
            if (finalArr[t]) {
                e++;
                if (e == LOADOFFERS) {
                    break;
                }
            } else {
                break;
            }
        }
        len = childrenLength + e;
        searchOffersToBeLoaded = e;
       /* for (var i = childrenLength; i < len; i++) {
            $("" + finalArr[i])
                .appendTo(".offerListWrapper .offers .search-results");
        }*/
    var startTag = "<div class='row nonFeaturedOffersRow offerRow'>", endTag = "</div>", resultData = "", arrTotalIdx = len - 1;
    for (var i = childrenLength; i < len; i++) {
              if (i % 3 === 0 ) 
              {
                 resultData = resultData + startTag;
    
              }
              resultData = resultData + finalArr[i];
              if ((i === arrTotalIdx) || (i % 3 === 2)) 
              {
                resultData = resultData + endTag;
                $("" + resultData).appendTo(".offerListWrapper .offers .search-results");
                resultData = "";
              }
    }

        // "loading" done -> revert to normal state
        scene.update(); // make sure the scene gets the new start position
        $("#loader").removeClass("active");

        if (len === finalArr.length) {
            $("#loader").hide().addClass('active');
            return false;
        }

    }

function appendSearchResultData(srcVal,offerTitle,shortDesc,searchPreviewUrl,offerId,previewURL)
{

var htmlData="<div class='col-sm-4 col-xs-12 categoryImg offerDisplay' role='presentation'>"+
              "<a class='imgAnchor' href='"+searchPreviewUrl+"#all/"+offerId+"' target='_self' onclick='setSearchPreviewParameters(this);'>"+ 		
               "<img onload='onSearchOfferLoad(this)' class='offerImg img-responsive lazy' src='"+srcVal+"'style='display: block;'/>"+
              " <span class='textWrapper' title='"+offerTitle+"'>"+
                   "<span class='caption' style='table-layout: fixed;'>"+
                       "<span class='col-xs-11 titleWrapper'>"+
                        "<span class='title'>"+offerTitle+"</span>"+
                       " <span class='shortDesc'>"+shortDesc+"</span>"+
                       "</span>"+
                       "<span class='caption-btn col-xs-1'>"+
                        "<img class='captionImg featuredCaptionImg img-responsive' src='/content/dam/vppImages/standard/Others/tile_arrow.png' />"+
                       "</span>"+
                   "</span>"+
               "</span>	"+	
                   "<input type='hidden' class='currentOffer' value='"+previewURL+"'/>"+
          " </a>"+
"</div> ";

return htmlData;

}

function onSearchOfferLoad(){
    console.log("Loaded...");
    searchOffersLoaded++;
    if(searchOffersLoaded === searchOffersToBeLoaded){
        var searchOffersToLoad = document.querySelectorAll('.categoryImg.offerDisplay'), searchOffersToLoadLength = searchOffersToLoad.length, i = 0;
        for(i=0;i< searchOffersToLoadLength; i++){
			searchOffersToLoad[i].classList.remove('offerDisplay');
        }
    }
}

function setSearchPreviewParameters(e)
{
    localStorage.setItem("currentOffer", $(e).find('.currentOffer').val());
}
