var checkClick = "false";


function populateDropDown(e) {
    var src = e.src;
    if (src.indexOf("/content")!==-1) {
        var index = src.indexOf("/content");
        src = src.substring(index);
    }
    checkClick = "true";

    populateOptions(src);

}

function populateActiveDropDown() {
    var count = $('.swiper-slide').length;

    if ((count === 2 && checkClick === "false") || count > 2|| count===1) {
        var src = $('.swiper-slide-active img').attr('src');
        populateOptions(src);
    }
}

function populateOptions(src) {

    $("#getDropDownValues").empty();
    var valuesOfCardMap = $('.valueproperty').val();
    //formating json 
    valuesOfCardMap = valuesOfCardMap.replace(/}\"/g, "}");
    valuesOfCardMap = valuesOfCardMap.replace(/\"{/g, "{");
    valuesOfCardMap = valuesOfCardMap.replace(/\\"/g, "\"");
    valuesOfCardMap = "[" + valuesOfCardMap + "]";
    var jsonObj = JSON.parse(valuesOfCardMap);

    $("#getDropDownValues").append("<option value=\"" + "select" + "\"" + "selected style=\"" + "display:none;" + "\">" + "Please select a card" + "</option>");


    //json iteration
    $.each(jsonObj, function(key, value) {

        var cardImageVal = jsonObj[key].cardImage;
        if (src == cardImageVal) {
            $.each(jsonObj[key].cardLinks, function(innerKey, innerValue) {

                $("#getDropDownValues").append("<option value=\"" + jsonObj[key].cardLinks[innerKey].link + "\"" + ">" +
                    jsonObj[key].cardLinks[innerKey].linkText + "</option>");
            })
        }
    })

}

function openSelectedUrl() {
    var hrefVal = $('#getDropDownValues').val();
    if (hrefVal === null || hrefVal === "select") {
        hrefVal = "#";
    } else {
        hrefVal = hrefVal + ".html";
    }

    $('a.loginConfirm').attr('href', hrefVal);
}