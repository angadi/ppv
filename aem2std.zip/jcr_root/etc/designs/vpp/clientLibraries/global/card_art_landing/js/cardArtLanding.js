$( document ).ready(function() {

    var btn = document.getElementById("cardLogoId");
	var isClick=document.getElementById("isClickId");
    var altText=document.getElementById("cardLogoAltText");
      
    if(btn !=null){

     $('#cardLogoImgId').attr('src', btn.value);

     $('#cardLogoImgIdResponsive').attr('src', btn.value);
     //alt text
     $('#cardLogoImgId').attr('title', altText.value);

     $('#cardLogoImgIdResponsive').attr('title', altText.value);   


    if(isClick.value=='true'){
        }else{
	document.getElementById('Button').style.pointerEvents = 'none';

    }
}

}); 