$(document).ready(function(){

		  $(".owl-carousel").owlCarousel({
			items:3,
			autoplay:true,
			nav:true,
			loop:true,
			navText: ["<img src='/content/dam/vppImages/standard/Others/Tiles_left_arrow.png'>","<img src='/content/dam/vppImages/standard/Others/Tiles_right_arrow.png'>"],
			responsive : {
				// breakpoint from 0 up
				0 : {
					items : 1,
					nav:true
				},
				// breakpoint from 480 up
				480 : {
					items : 1,
					nav:true
				},
				// breakpoint from 768 up
				768 : {
					items : 3,
					nav:true
				},
                991:{
					items : 3,
					nav:true
                }
			},
            onInitialized: function(){
            $(".owl-nav").removeClass("disabled");
            },
            onChange: function(){
            $(".owl-nav").removeClass("disabled");
            },
            onChanged: function(){
            $(".owl-nav").removeClass("disabled");
            }
		  });


        /* offerPreview JS*/
       		$('.downloadBtn').click(function(){
                console.log("in donwload");
				$('.redeemContactWrap').css('display','none');
				$('.moreBtn').css('display','none');
				window.print();
			});


		/*More or less functionality*/
			 $('body').on('click', '.displayTc', function(e){
			var me_ = $(this);
			if(me_.hasClass('moreBtn')){//more visible
			  me_.removeClass('moreBtn').addClass('lessBtn');
			  me_.parent().next().find('a').removeClass('lessBtn').addClass('lessbnImage');
			  $('.remainingTC').removeClass('hideElem');
			}
			else{//less visible
			  me_.parent().prev().find('a').removeClass('lessBtn').addClass('moreBtn');
			  me_.addClass('lessBtn').removeClass('lessbnImage');
			  $('.remainingTC').addClass('hideElem');
			}
		});

			if($('#wrapper').find('.top-nav-container').length>0){
				$('#page-content').addClass('padTop');
			}
			$('.search-icon').click(function(e) {
				var me_ = $(this),
					formGroup = me_.prev("form");
				me_.hide();
				formGroup.animate({
					width: 'show'
				}, function() {
					formGroup.find("#search").focus();
					formGroup.find("#submit").show();
				});
			});
			$(".homeExitNav .search-form .form-group #search").blur(function(e) {
				var me_ = $(this),
					formGroup = me_.parents("form");
				formGroup.animate({
					width: 'hide'
				}, function() {
					formGroup.next(".search-icon").show();
				});
			});
			$(".homeExitNav .search-form form").submit(function(e) {
				e.preventDefault();
			});		
});