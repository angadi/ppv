var checkClick = "false";


function populateDropDown(e) {
    var src = e.src;
    if (src.indexOf("/content")!==-1) {
        var index = src.indexOf("/content");
        src = src.substring(index);
    }
    checkClick = "true";

    populateOptions(src);

}

function populateActiveDropDown() {
    var count = $('.swiper-slide').length;

    if ((count === 2 && checkClick === "false") || count > 2|| count===1) {
        var src = $('.swiper-slide-active img').attr('src');
        populateOptions(src);
    }
}

function formatJSON(valuesOfCardMap){
    var jsonObj = {};
    if(valuesOfCardMap){
        valuesOfCardMap = valuesOfCardMap.replace(/}\"/g, "}");
        valuesOfCardMap = valuesOfCardMap.replace(/\"{/g, "{");
        valuesOfCardMap = valuesOfCardMap.replace(/\\"/g, "\"");
        valuesOfCardMap = "[" + valuesOfCardMap + "]";
    	jsonObj = JSON.parse(valuesOfCardMap);
    }
  	return jsonObj;
}

function populateOptions(src) {
	$("#getDropDownValues").select2("destroy");
    //$("#getDropDownValues").empty();
	var jsonObj = formatJSON($('.valueproperty').val()), data = [];

    //$("#getDropDownValues").append("<option value=\"" + "select" + "\"" + "selected style=\"" + "display:none;" + "\">" + "Please select a card" + "</option>");


    //json iteration
    $.each(jsonObj, function(key, value) {

        var cardImageVal = jsonObj[key].cardImage;
        if (src == cardImageVal) {
            data = [];
            if(jsonObj[key].cardLinks){
                for(var i=0; i<jsonObj[key].cardLinks.length; i++){
                    data.push({'id': jsonObj[key].cardLinks[i].link, 'text':jsonObj[key].cardLinks[i].linkText });
                }
            }
            /*$.each(jsonObj[key].cardLinks, function(innerKey, innerValue) {

                $("#getDropDownValues").append("<option value=\"" + jsonObj[key].cardLinks[innerKey].link + "\"" + ">" +
                    jsonObj[key].cardLinks[innerKey].linkText + "</option>");
            })*/
        }
    });
	
    $("#getDropDownValues").val('').select2({
        minimumResultsForSearch: -1,
        placeholder: "Please select a card",
        allowClear : true,
        data:data
    });

}

function openSelectedUrl() {
    var hrefVal = $('#getDropDownValues').select2('data');
    var dropDownVal=hrefVal;
    if(hrefVal)
        hrefVal = hrefVal.id;
    if (hrefVal === null || hrefVal === "select") {
        hrefVal = "javascript:void(0)";
    } else {
        hrefVal = hrefVal + ".html";
    }   
    var check=$('#checkLanding').val();
    if(check=="cardArtLanding")
    {
		var selectedCardText;
        if(dropDownVal)
        {
        selectedCardText = dropDownVal.text;
		localStorage.setItem("selectedCardText",selectedCardText);
        }
    }

    $('a.loginConfirm').attr('href', hrefVal);
}