visa.components.concierge = function($) {
    var $components = $('.concierge_carousel');

    $components.each(function (){
        create(this);
    });

    function create(component) {
        var $conciergelink = $('a.concierge');
        var $concHref = $($conciergelink).attr('href');
        var $items = $(component).find('.carousel-inner .item');
        var $carouselGeneric = $(component).find('#carousel-generic');
        var $closeContainer = $(component).find('.close-container');
        updateItemBg();
        if($concHref && $concHref.charAt(0) === "#"){
            $conciergelink.click(openConcierge);
            $closeContainer.click(closeConcierge);
        }
        function updateItemBg() {
            if($items.length != 0){
                var itemImage;
                var imgUrl;
                $items.each(function($index) {
                    itemImage = $(this).find('.heroImg');
                    imgUrl = $(itemImage).data('original');
                    if($index === 0){
                        $(this).addClass('active');
                    }
                    $(itemImage).css('background','url(' + imgUrl +')');
                });
                $($carouselGeneric).addClass('carousel slide');
            }
        }

        function openConcierge() {
            $('.concierge_carousel').addClass('popup-open');
            $($carouselGeneric).carousel({interval: 4000});
        }

        function closeConcierge() {
            $('.concierge_carousel').removeClass('popup-open');
        }

    }
    return {
        create: create
    };
} (jQuery);