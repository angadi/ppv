visa.components.header = function($) {
    var $components = $('.c-header');

    $components.each(function (){
        create(this);
    });

    function create(component) {
        var $nav = $(component).find('.navbar-customize');
        var $navbarToggle = $($nav).find('.navbar-toggle');
        var $navbarMenu = $($nav).find('.nav.smLiImgHide');
        var $slideNav = $(component).find('.slide-nav');
        var $closeBtn = $($slideNav).find('.closeBtn');
        var $slideNavBlock = $(component).find('.slide-nav-popup-block');

        //wcag
        updateCSS();
        $(window).on("resize", updateCSS);

        $slideNav.click(checkSubnav);
        $slideNavBlock.click(closeSubnav);
        $navbarToggle.click(openSubnav);
        $closeBtn.click(closeSubnav);

        function openSubnav() {
            $(component).addClass('slide-nav-open');
        }

        function closeSubnav() {
            $(component).removeClass('slide-nav-open');
        }

        function checkSubnav(e) {
            e.stopPropagation();
            if ($(e.target).is('a') && $(component).hasClass('slide-nav-open')) {
                closeSubnav();
            }
        }

        function updateCSS() {
            var windowWidth = $(window).width();

            if(windowWidth<=1099) {
                $($slideNav).find('[aria-hidden]').attr('aria-hidden', 'false');
                $($slideNav).find('[tabindex]').attr('tabindex', '0');

                $($navbarMenu).find('[aria-hidden]').attr('aria-hidden', 'true');
                $($navbarMenu).find('[tabindex]').attr('tabindex', '-1');
            }
            else {
                $($slideNav).find('[aria-hidden]').attr('aria-hidden', 'true');
                $($slideNav).find('[tabindex]').attr('tabindex', '-1');

                $($navbarMenu).find('[aria-hidden]').attr('aria-hidden', 'false');
                $($navbarMenu).find('[tabindex]').attr('tabindex', '0');
            }
        }

    }
    return {
        create: create
    };
} (jQuery);

