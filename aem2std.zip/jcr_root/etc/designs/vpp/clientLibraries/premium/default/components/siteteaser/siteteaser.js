(function(){
    try{
		var c360 = document.getElementsByClassName("c-360-wrapper"), 
            i=0, 
            c360_length = c360 ? c360.length : undefined,
            defaultPreviewImage = '/content/dam/vppImages/premium/suntrust/teaser_assets/loading-background.jpg',
            viewer = "",
            c360img = "";
        function error(){
            console.log("Error in Pannelleum.");
        }
		if(c360_length && c360_length > 0){
			for(i = 0; i< c360_length; i++){
			   c360img =  c360[i].dataset.img360;
				viewer = pannellum.viewer(c360[i], {
					"type": "equirectangular",
					"autoLoad": true,
					"autoRotate": 2,
					"preview": defaultPreviewImage,
					"panorama": c360img
				});
				viewer.on("error", error);
				viewer = "";
			}
		}
		c360 = i = c360img = c360_length = viewer = undefined;
    }
    catch(e){
        console.log("Error in Pannelleum");
    }
})();