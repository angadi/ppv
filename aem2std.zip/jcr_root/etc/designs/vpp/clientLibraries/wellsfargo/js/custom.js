$(document).ready(function(){
		if($(".owl-carousel").length > 0){
		  $(".owl-carousel").owlCarousel({
			items:3,
			autoplay:true,
			nav:true,
			loop:true,
			navText: ["<img src='/content/dam/vppImages/standard/Others/Tiles_left_arrow.png'>","<img src='/content/dam/vppImages/standard/Others/Tiles_right_arrow.png'>"],
			responsive : {
				// breakpoint from 0 up
				0 : {
					items : 1,
					nav:true
				},
				// breakpoint from 480 up
				480 : {
					items : 1,
					nav:true
				},
				// breakpoint from 768 up
				768 : {
					items : 3,
					nav:true
				},
                991:{
					items : 3,
					nav:true
                }
			},
            onInitialized: function(){
				$(".owl-nav").removeClass("disabled");
				setTimeout(setArrowPosition, 100);
            },
            onChange: function(){
				$(".owl-nav").removeClass("disabled");
            },
            onChanged: function(){
				$(".owl-nav").removeClass("disabled");
            },
            onResized: function(){
				setArrowPosition();
            }
		  });
		}
		function setArrowPosition(){
			var item = $(".owl-item .defaultPageCatLink.imgAnchor:eq(0)"), arrowimgHeight = 49, topAlignment = 0;;
			if(item){
				var itemHeight = (item.height() / 2);
				if(itemHeight)
					topAlignment = itemHeight - 49;
				$("#carouselcontainer .owl-prev,#carouselcontainer .owl-next").css({"top": topAlignment + "px"});
			}
		}


		/* More or less functionality */
		$('body').on('click','.displayTc',function(e) {
			var me_ = $(this);
			if (me_.hasClass('moreBtn')) {// more visible
				me_.removeClass('moreBtn').addClass('lessBtn');
				$('.wrapperBottom').find('.row').addClass('borderFocus');
				me_.parent().next().find('a').removeClass('lessBtn').addClass('lessbnImage');
				$('.remainingTC').removeClass('hideElem');
			} else {// less visible
				me_.parent().prev().find('a').removeClass('lessBtn').addClass('moreBtn');
				me_.addClass('lessBtn').removeClass('lessbnImage');
				$('.wrapperBottom').find('.row').removeClass('borderFocus');
				$('.remainingTC').addClass('hideElem');
			}
		});

			if($('#wrapper').find('.top-nav-container').length>0){
				$('#page-content').addClass('padTop');
			}
			$('.search-icon').click(function(e) {
				var me_ = $(this),
					formGroup = me_.prev("form");
					formGroup.find("#search").val("");
				me_.hide();
				formGroup.animate({
					width: 'show'
				}, function() {
					formGroup.find("#search").focus();
					formGroup.find("#submit").show();
				});
			});
			$(".homeExitNav .search-form .form-group #search").blur(function(e) {
				var me_ = $(this),
					formGroup = me_.parents("form");
				formGroup.animate({
					width: 'hide'
				}, function() {
					formGroup.next(".search-icon").show();
				});
			});
			$(".homeExitNav .search-form form").submit(function(e) {
				e.preventDefault();
			});	
			
			var btn = document.getElementById("cardLogoId");
			var isClick = document.getElementById("isClickId");
			var altText = document.getElementById("cardLogoAltText");

			if (btn != null) {

				$('#cardLogoImgId').attr('src', btn.value);

				$('#cardLogoImgIdResponsive').attr('src', btn.value);
				//alt text
				$('#cardLogoImgId').attr('title', altText.value);

				$('#cardLogoImgIdResponsive').attr('title', altText.value);			
				if (isClick.value == 'true') {
	                $('#cardLogoImgIdLink').remove();
					$('#cardLogoImgIdResponsiveLink').remove();
				} else { 
					$('#Button').remove()
                    $('#cardLogoImgIdResponsive').remove();
                    $('#cardLogoImgIdLink').attr('src', btn.value);
                    $('#cardLogoImgIdLink').attr('title', altText.value);
                    $('#cardLogoImgIdResponsiveLink').attr('src', btn.value);
                    $('#cardLogoImgIdResponsiveLink').attr('title', altText.value);	 
					}
			}
			/***** Initialize First Drop_down Value ****/
			var dropDownJSON = $('.valueproperty').val();
			if(dropDownJSON && dropDownJSON !== ""){
				var jsonObj = formatJSON(dropDownJSON), data = [];
				if(jsonObj && jsonObj[0].cardLinks && jsonObj[0].cardLinks.length > 0){

						for(var i=0; i<jsonObj[0].cardLinks.length; i++){
							data.push({'id': jsonObj[0].cardLinks[i].link, 'text':jsonObj[0].cardLinks[i].linkText });
						}

				}

				$("#getDropDownValues").select2({
					data:data,
					minimumResultsForSearch: -1,
					placeholder: "Please select a card",
					allowClear : true
				});
			
			}
			/* card art modal hide on background click*/
			$(".loginPopupWrapperDiv").on('click',function(e){
                if(e.target != this){return;}else{
                    if($('#myModal').is(":visible")){
                        $("#myModal").hide();
                    }
                }
            });
});