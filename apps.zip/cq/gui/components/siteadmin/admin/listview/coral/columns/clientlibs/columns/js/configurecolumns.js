/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2016 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(document, Granite, $) {
  "use strict";

  var ui = $(window).adaptTo("foundation-ui");

  var collectionSelector = ".foundation-collection";
  var columnsSelector = "[type='checkbox']";
  var selectedColumnSelector = "[type='checkbox']:checked";
  var configureColumnsDialogSelector = ".aem-configure-columns-dialog";
  var configureColumnsFormSelector = "#aem-configure-columns";
  var configureColumnsColumnChooserSelector = ".aem-ColumnChooser";
  var configureColumnsConfirmSelector = ".aem-configure-columns-confirm";
  var removeCustomAnalyticsColumnSelector = '.aem-listview-remove-column';
  var pathConfigSelector = ".manage-columns-for-path-container";
  var pathConfigSelectSelector = ".manage-columns-for-path-select";
  var hasAnalyticsConfigSelector = "[name='hasAnalyticsConfig']";
  var addCustomAnalyticsColumnsSelector = ".aem-add-custom-analytics-data-container";

  var columnsQuota = 0; // max number of columns that fit to the available space
  var totalSelectableColumns = 0; // the number of columns potentially selectable
  var initialSelection = [];
  var isSetup = false;

  function reloadContent() {
    var isSearchResult = $("#granite-omnisearch-result").size() > 0;
    var searchForm = $(".granite-omnisearch-form");

    if (isSearchResult) {
      // re-submits the search form, and by doing so content is updated
      searchForm.submit();
      if ($(configureColumnsDialogSelector).length > 0) {
          $(configureColumnsDialogSelector)[0].open = false;
      }
    } else {
      window.location.reload();
    }
  }

  function updateCookieFromSelected() {
    var configureColumnsForm = $(configureColumnsFormSelector);
    var $selectedColumns = configureColumnsForm.find(selectedColumnSelector);
    var $columnChooser = $(configureColumnsColumnChooserSelector);
    var cookieConfig = $columnChooser.data("columnsCookie");
    var cookieValue = "";

    if (!cookieConfig) {
      return;
    }

    for (var i = 0; i < $selectedColumns.length; i++) {
      cookieValue += $($selectedColumns[i]).val() + ",";
    }

    $.cookie(cookieConfig.name, cookieValue, cookieConfig);
  }

  function updateCookieAndReload() {
    updateCookieFromSelected();
    reloadContent();
  }

  function isTableLayout() {
    var $collection = getCurrentCollectionOfInterest();
    return ($collection && $collection.length > 0 && $collection.first().hasClass("foundation-layout-table"));
  }

  function getSelection(containerElementOrSelector) {
    var container = containerElementOrSelector || configureColumnsFormSelector;
    var selection = [];
    var $items = $(container).find(selectedColumnSelector);

    for (var i = 0 ; i < $items.length; i++) {
       // console.log($($items[i]).val());
            selection.push($($items[i]).val());

    }

    return selection;
  }

  function updateDialogTitle(totalSelected, maximum) {
    var totalSelector = "span";
    var $title = $(configureColumnsDialogSelector + " .coral-Dialog-title");
    var $total = $title.find(totalSelector);

    if ($total.length < 1) {
      $title.append("<span></span>");
      $total = $title.find(totalSelector);
    }

    $total.html("(" + totalSelected + "/" + maximum + ")");
  }

  function updateCheckboxStates() {
    var totalSelected = $(configureColumnsFormSelector).find(selectedColumnSelector).length;

    $(configureColumnsFormSelector).find(columnsSelector).each(function(index, checkboxItem) {
      var $item = $(checkboxItem);

		//console.log(url);
       // console.log($item.is(":checked"));


      if (totalSelected >= columnsQuota) {
        if (!$item.is(":checked")) {
              $item.attr("disabled", "disabled");
        } else {
          $item.removeAttr("disabled");
        }
      } else {
        $item.removeAttr("disabled");

      }
        var url=$(this).get(0).baseURI;
        var itemname=$item.attr('value');
		
		 if(itemname=='language'){
           		$item.removeAttr("checked");
          		$item.attr("disabled","disabled");
    		}
		
        if(url.includes('/digital-shelf-product-asset')){
					if(itemname=='campaignName')
						$item.attr("disabled","disabled");
        			if(itemname=='expirationDate')
                        $item.attr("disabled","disabled");
           }
        if(url.includes('/campaign')){
			 if(itemname=='fileName')
                $item.attr("disabled","disabled");
            if(itemname=='assetStatus')
				$item.attr("disabled","disabled");
            if(itemname=='errorCode')
                $item.attr("disabled","disabled");
            if(itemname=='errorMessage')
                $item.attr("disabled","disabled");
        }

    });
  }

  function togglePathConfig() {
    var $configureColumnsForm = $(configureColumnsFormSelector);
    var $pathConfig = $configureColumnsForm.find(pathConfigSelector);

    if ($(pathConfigSelectSelector).length > 0) {
      Coral.commons.ready($(pathConfigSelectSelector)[0], function() {
        var $pathConfigOptions = $(pathConfigSelectSelector).find('coral-select-item');

        $pathConfig.toggle($pathConfigOptions && $pathConfigOptions.length > 1);
      });
    }
  }

  function toggleAddCustomAnalyticsColumns() {
    if (!isTableLayout()) {
      return;
    }

    var $configureColumnsForm = $(configureColumnsFormSelector);
    var $addCustomAnalyticsColumns = $configureColumnsForm.find(addCustomAnalyticsColumnsSelector);
    var hasAnalyticsConfig = $(hasAnalyticsConfigSelector).val();

    // shows add custom analytics columns button if Adobe Analytics config is available
    $addCustomAnalyticsColumns.toggle(hasAnalyticsConfig && hasAnalyticsConfig == "true");
  }

  function toggleConfirmAction(enable) {
    $(configureColumnsFormSelector).closest(configureColumnsDialogSelector).find(configureColumnsConfirmSelector)[0].disabled = !enable;
  }

  function calculateColumnsQuota() {
    var total = 0;
    var maxNumberColumns = 6;
    var minNumberColumns = 2;
    var minColumnWidth = 100; /* px */
    var numberDefaultColumns = 2; /* the select and order columns are static */

    var columnsQuotaConfig = $(configureColumnsFormSelector).data("totalColumns");
    var availableWidth = $(collectionSelector).first().width();

    if (!isNaN(columnsQuotaConfig)) {
      total = parseInt(columnsQuotaConfig);
    } else {
      total = Math.floor(availableWidth / minColumnWidth) - numberDefaultColumns;
      if (total < minNumberColumns) {
        total = minNumberColumns;
      } else if (total > maxNumberColumns) {
        total = maxNumberColumns;
      }
    }

    return total;
  }

  function resetDialog() {
    // restores the initial selection
    var $columnSelectors = $(configureColumnsFormSelector).find(columnsSelector);

    $columnSelectors.each(function(index) {
      var $current = $(this);
      var $container = $current.closest("li");

      if ($.inArray($current.val(), initialSelection) >= 0) {

		$current.prop("checked", true);
        $container.addClass("selected");

      } else {
        $current.prop("checked", false);
        $container.removeClass("selected");
      }
    });

    columnsQuota = calculateColumnsQuota();
    toggleConfirmAction(false);
    updateDialogTitle(initialSelection.length, totalSelectableColumns);
    updateCheckboxStates();
  }

  function onColumnSelected(event) {
    var $checkbox = $(event.target);
    var totalSelected = $(configureColumnsFormSelector).find(selectedColumnSelector).length;

    if (totalSelected > columnsQuota && totalSelected > initialSelection.length) {
      return false;
    }

    var currentSelection = getSelection();
    var selectionChanged = false;

    if (currentSelection.length != initialSelection.length) {
      selectionChanged = true;
    } else {
      for (var i = 0; i < currentSelection.length; i++) {
        if ($.inArray(currentSelection[i], initialSelection) < 0) {
          selectionChanged = true;
          break;
        }
      }
    }

    toggleConfirmAction(selectionChanged);

    var $item = $checkbox.closest("li");
    $item.toggleClass("selected", $checkbox.is(":checked"));

    updateCheckboxStates();
    updateDialogTitle(totalSelected, totalSelectableColumns);
  }

  function onManageColumnsForPathChange(event) {
    var select = event.target;
    var selectedContentPath = select.value;
    var $columnChooser = $(configureColumnsFormSelector).find(configureColumnsColumnChooserSelector);
    var componentPath = $columnChooser.data("component-path");

    ui.wait($columnChooser[0]);

    // updates configure columns dialog columns
    Granite.$.ajax({
      type: "GET",
      url: componentPath + ".html" + selectedContentPath,
      success: function(data, status, request) {
        ui.clearWait();
        $(configureColumnsFormSelector).find(hasAnalyticsConfigSelector).remove();
        $columnChooser.replaceWith(data);

        $(configureColumnsFormSelector + " " + columnsSelector).off("change").on("change", onColumnSelected);
        $(removeCustomAnalyticsColumnSelector).off("click").on("click", onRemoveCustomAnalyticsColumn);
        toggleConfirmAction(false);

        setup();
      },
      error: function() {
        ui.notify("", Granite.I18n.get("Error occurred while loading configured columns."), "error");
        ui.clearWait();
      }
    });
  }

  function removeCustomAnalyticsColumn(config) {
    Granite.$.ajax({
      type: "DELETE",
      url: config.configPath + '/jcr:content.customdata.config?metric=' + config.metricId + '&contentpath=' + config.contentPath,
      success: function(data, status, request) {
        ui.notify("", Granite.I18n.get('Successfully removed metric {0}.', config.metricId), "success");

        // if the item is checked, remove from cookies and do a refresh
        var $removedContainer = config.$activator.closest("li");

        if ($removedContainer.hasClass("selected")) {
          $removedContainer.remove();
          updateCookieAndReload();
        } else {
          $removedContainer.remove();
        }
      },
      error: function() {
        ui.notify("", Granite.I18n.get('Error occurred while removing custom metric {0}.', config.metricId), "error");
      }
    });
  }

  function onRemoveCustomAnalyticsColumn(event) {
    var $target = $(event.target);
    var $activator = $target.closest("a");
    var $metricsConfigurator = $(configureColumnsColumnChooserSelector);
    var config = {
      configPath: $metricsConfigurator.data("analyticscfg"),
      contentPath: $metricsConfigurator.data("contentpath"),
      metricId: $activator.data("metric"),
      $activator: $activator
    };

    removeCustomAnalyticsColumn(config);
  }

  function hideColumns($collection) {
    if (!isTableLayout()) {
      return;
    }	

    // re-sets the hidden attribute to ensure newly-loaded result columns are hidden

    $collection.find('col').each(function() {

      var hidden = $(this).get(0).hidden;

		$(".foundation-collection-item.foundation-collection-navigator.coral-Table-row").click(function () {
      			  		var addressValue = $(this).attr("data-item-title");

                 localStorage.setItem("addressValue",addressValue);
    		});

            var addressValue=localStorage.getItem("addressValue");
			
			  if($(this).get(0).dataset.foundationLayoutTableColumnName=='language'){
            hidden=true;
        }

        if(addressValue=="digital-shelf-product-asset" || $(this).get(0).baseURI.includes('digital-shelf-product-asset')){
			if($(this).get(0).dataset.foundationLayoutTableColumnName=='fileName'){
                hidden=false;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='assetStatus'){
                hidden=false;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='errorCode' ){
                hidden=false;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='errorMessage'){
                hidden=false;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='campaignName'){
                hidden=true;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='expirationDate'){
                hidden=true;
            }

        }

        if(addressValue=='Campaign' || $(this).get(0).baseURI.includes('campaign')){
			if($(this).get(0).dataset.foundationLayoutTableColumnName=='fileName'){
                hidden=true;
            }
			if($(this).get(0).dataset.foundationLayoutTableColumnName=='assetStatus'){
                hidden=true;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='errorCode' ){
                hidden=true;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='errorMessage'){
                hidden=true;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='campaignName'){
                hidden=false;
            }
            if($(this).get(0).dataset.foundationLayoutTableColumnName=='expirationDate'){
                hidden=false;
            }
        }


      if (hidden) {
        // we show and hide in succession to bypass the value must change constraint
        $(this).get(0).hidden = false;
        $(this).get(0).hidden = true;
      }

    });
      localStorage.removeItem("addressValue");
  }

  function setupListeners() {
    var $dialog = $(configureColumnsDialogSelector);

    if ($dialog.length > 0) {
      Coral.commons.ready($dialog[0], function() {
        $dialog[0].off("coral-overlay:beforeopen").on("coral-overlay:beforeopen", function(event) {
          if (event.target !== $dialog[0]) {
            return;
          }

          resetDialog();
        });
      });

      if ($(pathConfigSelectSelector).length > 0) {
        Coral.commons.ready($(pathConfigSelectSelector)[0], function() {
          $(pathConfigSelectSelector)[0].off("change").on("change", onManageColumnsForPathChange);
        });
      }

      $(configureColumnsFormSelector + " " + columnsSelector).off("change").on("change", onColumnSelected);
      $(removeCustomAnalyticsColumnSelector).off("click").on("click", onRemoveCustomAnalyticsColumn);

      $(configureColumnsConfirmSelector).off("click").on("click", function(event) {
        event.preventDefault();
        updateCookieAndReload();

        return false;
      });

      $(".aem-add-custom-analytics-data").off("click").on("click", function(event) {
        event.preventDefault();

        // hides the configure columns dialog
        var $addCustomAnalyticsColumnsToggle = $(this);
        var $dialog = $addCustomAnalyticsColumnsToggle.closest(configureColumnsDialogSelector);

        if ($dialog.length > 0) {
          $dialog[0].open = false;
        }
      });
    }
  }

  function setup() {
    var $configureColumnsForm = $(configureColumnsFormSelector);

    if (!isTableLayout() || $configureColumnsForm.length === 0) {
      return;
    }

    // caches columns information and initialises selections
    columnsQuota = calculateColumnsQuota();
    totalSelectableColumns = $configureColumnsForm.find(columnsSelector).length;
    initialSelection = getSelection(configureColumnsFormSelector);

    // updates the UI based on the selection
    var totalSelected = $configureColumnsForm.find(selectedColumnSelector).length;
    updateDialogTitle(totalSelected, totalSelectableColumns);
    toggleAddCustomAnalyticsColumns();
    togglePathConfig();
    updateCheckboxStates();
  }

    function getCurrentCollectionOfInterest() {
        var $searchCollection = $('#granite-omnisearch-result');
        return $searchCollection.length === 1 ? $searchCollection : $('.foundation-collection');
    }

  $(document).on("foundation-contentloaded", function (event) {
    var $collection = getCurrentCollectionOfInterest();
    if (!isTableLayout() || $(configureColumnsFormSelector).length === 0) {
      hideColumns($collection);
      return;
    }

    setup();
    setupListeners();
    hideColumns($collection);

    isSetup = true;
  });

})(document, Granite, Granite.$);