package com.dhl.aem.platform.constants;

/**
 * @author shiabhis
 *
 *This is a Constants file which holds DHL Project level constants
 *
 */
public class DHLConstants {

    public static final String JCR_CONTENT   =   "/jcr:content/";
    public static final String SLASH         =   "/";
    public static final int BYTE_CONVERTER   =   1024;
    public static final String METADATA      =   "metadata";
    public static final String ASSET_FORMAT  =   "dc:format";
    public static final String ASSET_SIZE    =   "dam:size";
    public static final String ASSET_DOWNLOAD_ITEM    =   "downloadItem";
    public static final String BYTE          =   "B";
    public static final String KILOBYTE      =   "KB";
    public static final String SPACE         =   " ";
    public static final String LEFT_BRACKET  =   "(";
    public static final String RIGHT_BRACKET =   ")";
   
    public static final String MEGABYTE      =   "MB";


}



