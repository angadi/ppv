package com.dhl.aem.platform.exception;

import org.apache.commons.lang3.StringUtils;

/**
 * DHL runtime exception used as a  catch and re throw mechanism
 * 
 * @author
 */
public class DHLException extends RuntimeException {

    private static final long serialVersionUID = -4745446972422691049L;

    /**
     * Constructs an exception with a root cause.
     * 
     * @param t the root cause
     */
    public DHLException(Throwable t) {
        super(t);

        if (t != null) {
            if (this.getStackTrace() == null) {
                this.setStackTrace(t.getStackTrace());
            }
        }
    }

    /**
     * Constructs an exception with the specified message and root cause.
     * 
     * @param msg the detail message
     * @param t the root cause
     */
    public DHLException(String msg, Throwable t) {
        super(msg + (StringUtils.isEmpty(t.getMessage()) ? "" : "\nActual message: " + t.getMessage()), t);

        if (t != null) {
            if (this.getStackTrace() == null) {
                this.setStackTrace(t.getStackTrace());
            }
        }
    }

    /**
     * Constructs an exception with the specified message and no root cause.
     * 
     * @param msg the detail message
     */
    public DHLException(String msg) {
        super(msg);
    }
}
