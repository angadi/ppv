package com.dhl.aem.platform.exception;


public class SendMailException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String message = null;
	 
    public SendMailException() {
        super();
    }
 
    public SendMailException(String message) {
        super(message);
        this.message = message;
    }
 
    public SendMailException(Throwable cause) {
        super(cause);
    }
 
    @Override
    public String toString() {
        return message;
    }
 
    @Override
    public String getMessage() {
        return message;
    } 

}
