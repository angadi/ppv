package com.dhl.aem.platform.helpers;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.AlertBarModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author shankar
 *This Helper gets active message from multifield
 */

public class AlertBarHelper extends WCMUse {
    private static final Logger log = LoggerFactory.getLogger(AlertBarHelper.class);

    private AlertBarModel alertBar;
    DHLUtil dhl=new DHLUtil();

    @Override
    public void activate() throws Exception {

        log.info("AlertBarHelper activate Method started: --->>>>>  THIS IS THE UPDATE VERSION STARTED");
        alertBar = getResource().adaptTo(AlertBarModel.class);
        Map<String,String> map=  dhl.getAlertMessage(alertBar.getAlertConfig());
        log.info("msg"+map.get("linkedMessage").toString());
       // log.info("id "+map.get("id"));
        alertBar.setTargetPage(dhl.getUrl(map.get("targetPage").toString()));
        alertBar.setLinkedMessage(map.get("linkedMessage").toString());;
        alertBar.setId(map.get("id"));
        alertBar.setNewTabm(map.get("newTabm"));
        log.info("AlertBarHelper activate Method started: --->>>>>  THIS IS THE UPDATE VERSION ENDED");

    }


    public AlertBarModel getAlertBar() {

        return alertBar;
    }













}