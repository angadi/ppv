package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.models.BreadCrumbModel;
import com.dhl.aem.platform.utils.DHLUtil;
import com.adobe.cq.sightly.WCMUse;
import com.day.cq.wcm.api.Page;

/**
 * @author gankashy This Helper class is required to generate the parent links
 *         for the current page. This helper gets called when the Bread Crumb
 *         component is invoked.
 */
public class BreadCrumbHelper extends WCMUse {

    private static final Logger log = LoggerFactory
            .getLogger(BreadCrumbHelper.class);
    Page page = null;
    private String pageLink = null;
    private String path = null;
    Page homePage = null;
    String TITLE = "jcr:title";
    private static final int STARTING_PAGE_LEVEL = 3;
    private String hideinNav = "hideInNav";
    private String breadcrumbLink = "";
    private Page rootPage;
    private int depth;

    @Inject
    private ResourceResolver resourceResolver;

    @Override
    public void activate() throws Exception {

        // TODO Auto-generated method stub
        Object breadCrumb = getCurrentStyle().get("breadcrumbLink");
        if (breadCrumb != null)
        {
            breadcrumbLink = breadCrumb.toString();
            Resource resourcebreadcrumb = getResourceResolver().getResource(breadcrumbLink);
            rootPage = resourcebreadcrumb.adaptTo(Page.class);
            depth = rootPage.getDepth();
        }


        page = getCurrentPage();
        if (breadCrumb == null)
        {
            if (page.getPath().contains("master"))
            {
                depth = 4;
            }
            else
            {
                depth = 3;
            }
        }

        log.info("Page Path is" + page);
        getLinksPath(page, getResource(), depth);

    }

    public List<BreadCrumbModel> getLinks() {

        return links;
    }

    private List<BreadCrumbModel> links = null;

    public void setLinks(List<BreadCrumbModel> links) {

        this.links = links;
    }

    public List<BreadCrumbModel> getLinksPath(Page currentPage,
            Resource resource, int startingLevel) {

        if (page.getDepth() > STARTING_PAGE_LEVEL)
        {
            String title = "";
            resourceResolver = resource.getResourceResolver();
            links = new ArrayList<BreadCrumbModel>();
            DHLUtil dhl = new DHLUtil();
            if (page != null) {
                log.info("Entered Page method" + page);
                int currentLevel = currentPage.getDepth();
                log.info("level Depth" + currentLevel);
                int n = currentLevel;
                Resource pageResource1 = null;
                for (int i = (startingLevel - 1); i < currentLevel; i++) {
                    BreadCrumbModel nav = new BreadCrumbModel();
                    if (currentLevel != -1) {
                        Page homePage = currentPage.getAbsoluteParent(i);
                        if (homePage != null) {
                            path = homePage.getPath();
                            pageResource1 = resourceResolver.getResource(path
                                    + "/jcr:content");
                            String navigationTitle = pageResource1.getValueMap().get("navtitle", "")
                                    .toString();
                            String isTrue = pageResource1.getValueMap()
                                    .get(hideinNav, "").toString();
                            log.info("Home Page is " + path);
                            if (!isTrue.equals("true")) {
                                if (!(i == (n - 1))) {
                                    pageLink = dhl.getUrl(path);

                                    nav.setUrl(pageLink);
                                    if (i == STARTING_PAGE_LEVEL) {
                                        if (!StringUtils.isEmpty(homePage
                                                .getTitle())) {
                                            if (!navigationTitle.isEmpty())
                                            {
                                                title = navigationTitle;
                                            }
                                            else
                                            {
                                                title = homePage.getTitle();
                                            }

                                            nav.setLabel(title);
                                            log.info("title is" + title);
                                        }
                                    }
                                    else if (!StringUtils.isEmpty(homePage
                                            .getTitle())) {
                                        if (!navigationTitle.isEmpty())
                                        {
                                            nav.setLabel(navigationTitle);
                                        }
                                        else
                                        {
                                            nav.setLabel(homePage.getTitle());
                                        }

                                    }
                                }
                            }
                            if (i == (n - 1)) {
                                nav.setUrl("");
                                if (!StringUtils.isEmpty(homePage.getTitle())) {
                                    if (!navigationTitle.isEmpty())
                                    {
                                        nav.setLabel(navigationTitle);
                                    }
                                    else
                                    {
                                        nav.setLabel(homePage.getTitle());
                                    }
                                }
                            }
                        }
                        links.add(nav);

                    }

                }
            }
            setLinks(links);
        }

        return links;

    }

}
