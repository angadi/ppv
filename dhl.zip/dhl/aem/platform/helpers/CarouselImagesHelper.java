package com.dhl.aem.platform.helpers;


import com.adobe.cq.sightly.WCMUse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CarouselImagesHelper extends WCMUse {

 private static final Logger log = LoggerFactory.getLogger(CarouselImagesHelper.class);
 private String[] images;
 
  
 
 public String[] getImages() {
		return images;
	}

     
     
	@Override
    public void activate() throws Exception {
		images=(String[]) getProperties().get("carouselImages");
		log.info("the values from dialog are"+images);
		
		 }
		
		
		
	}

