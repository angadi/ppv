package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.ContentLinkListModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * This helper Reads values from the ContentLinkListModel and returns it back to the Sightly HTML
 * 
 * @author Shankar
 *
 */
public class ContentLinkListHelper extends WCMUse {

private static final Logger log = LoggerFactory.getLogger(ContentLinkListHelper.class);
    
    private ContentLinkListModel contentLinkListModel; 
    
    private ArrayList<ContentLinkListModel> contentLinkListModelList;
    
     
    
    @Override
    public void activate() throws Exception {

        log.info("ContentLinkListHelper initialized ");
        contentLinkListModel = getResource().adaptTo(ContentLinkListModel.class);
        //log.info("content button"+contentLinkListModel.getButtonLinkList().size());
          ContentLinkListModel contentLinkListInstance;
          Map<String, String> renditionList;
          contentLinkListModelList=  contentLinkListModel.getContentLinkListModelList();
          Iterator<ContentLinkListModel> it=contentLinkListModelList.iterator();
          while(it.hasNext()){
              contentLinkListInstance=it.next();
              renditionList = DHLUtil.getRenditionList(contentLinkListInstance.getImageSrc(), getResource());
              log.info("renditionList content link list model "+renditionList.size());
              contentLinkListInstance.setRenditionList(renditionList);
              }
          
           
    }

    
    public ContentLinkListModel getContentLinkListModel() {
    
        return contentLinkListModel;
    }


    
    public ArrayList<ContentLinkListModel> getContentLinkListModelList() {
    
        return contentLinkListModelList;
    }


    
    

    
     
         
      
}
