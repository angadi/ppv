package com.dhl.aem.platform.helpers;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;

import com.adobe.cq.sightly.WCMUse;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CountryListHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(CountryListHelper.class);
    Map<String, String> countryListMap = new HashMap<String, String>();

    public Map<String, String> getCountryListMap() {

        return countryListMap;
    }

    public ArrayList<String> getCountryNameList() {

        return countryNameList;
    }


    ArrayList<String> countryNameList = new ArrayList<String>();


    @Override
    public void activate() throws Exception {

        countryListMap = generateCountryListMap(getResourceResolver());


    }


    private Map<String, String> generateCountryListMap(ResourceResolver resourceResolver)
            throws RepositoryException {

        Node node = null;
        String sqlStatement = null;

        Session session = resourceResolver.adaptTo(Session.class);
        javax.jcr.query.QueryManager queryManager = session.getWorkspace().getQueryManager();


        sqlStatement = "select * from nt:base where jcr:path like '/content/dhl/country-list/jcr:content/parsysPath/%'";

        javax.jcr.query.Query query = queryManager.createQuery(sqlStatement, Query.SQL);


        javax.jcr.query.QueryResult result = query.execute();


        javax.jcr.NodeIterator nodeIter = result.getNodes();


        while (nodeIter.hasNext()) {
            node = nodeIter.nextNode();
            String countryName = node.getProperty("countryName").getValue().toString();
            countryNameList.add(countryName);
            Collections.sort(countryNameList);
            String countryLink = node.getProperty("countryLink").getValue().toString();
            countryListMap.put(countryName, countryLink);


        }

        return countryListMap;
    }


}
