package com.dhl.aem.platform.helpers;


import com.adobe.cq.sightly.WCMUse;

import com.dhl.aem.platform.models.CtaModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author gankashy
 *         Helper reads Value from the odel class and forwards it to the CTA Component
 */
public class CtaHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(CtaHelper.class);
    private CtaModel ctaModel;


    @Override
    public void activate() throws Exception {

        log.info("The Link path is" + getProperties().get("callToAction"));
        ctaModel = getResource().adaptTo(CtaModel.class);

        log.info("current Path " + ctaModel);
    }


    // returns the list of values text,pathfield and color combination
    public CtaModel getCtaModel() {

        return ctaModel;
    }


}
