package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.CtaListModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author gankashy
 *         This helper reads values from the CtaListModel and returns to sightly..
 */
public class CtaListHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(CtaListHelper.class);
    private ArrayList<HashMap<String, String>> ctaList;


    @Override
    public void activate() throws Exception {

        log.info("CtaListHelper activate Method started");
        CtaListModel ctaListModel = getResource().adaptTo(CtaListModel.class);
        ctaList = ctaListModel.getCtaList();
        log.info("CtaListHelper activate Method Ended");
    }

    //retuns an arrayList of HashMap Type
    public ArrayList<HashMap<String, String>> getCtaList() {

        if (ctaList != null)
        {
            return ctaList;
        }
        return null;
    }

}
