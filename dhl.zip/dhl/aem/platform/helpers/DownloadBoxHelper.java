package com.dhl.aem.platform.helpers;
import java.util.ArrayList;
import java.util.Map;
import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.DownloadBoxModel;
import com.dhl.aem.platform.utils.DHLUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author shiabhis
 * 
 * This is a helper file which acts as a controller which gets the value from FE 
 * and sends to business layer which is a model over here
 *
 */
public class DownloadBoxHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(DownloadBoxHelper.class);
    private ArrayList<Map<String, String>> downloadList;
    private ArrayList<Map<String, String>> downloadListFinal;
    private ArrayList<Map<String, String>> renditionList;
    DownloadBoxModel downloadBoxModel;

    @Override
    public void activate() throws Exception {

        log.info("Download Box activate Method started");
        downloadBoxModel = getResource().adaptTo(DownloadBoxModel.class);
        downloadList = downloadBoxModel.getDownloadList();
        downloadListFinal =DHLUtil.getSizeTypeOfAsset(downloadList, getResource());
        downloadBoxModel.setDownloadListFinal(downloadListFinal);
        log.info("Download Box activate Method Ended");
    }
    
    public DownloadBoxModel getDownloadBoxModel() {
    
        return downloadBoxModel;
    }
  
}
