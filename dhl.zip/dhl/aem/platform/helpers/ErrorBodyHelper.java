package com.dhl.aem.platform.helpers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.ErrorBodyModel;
import com.dhl.aem.platform.utils.DHLUtil;


public class ErrorBodyHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(ErrorBodyModel.class);
    private ErrorBodyModel errorBodyModel;


    @Override
    public void activate() throws Exception {

        log.info("Error body model activate Method started");
        errorBodyModel = getResource().adaptTo(ErrorBodyModel.class);
//        errorBodyModel.setRenditionList(DHLUtil.getRenditionList(errorBodyModel.getImageSrc(), getResource()));
        
        log.info("Error body model activate Method Ended");
    }


    public ErrorBodyModel getErrorBodyModel() {

        return errorBodyModel;
    }


}

