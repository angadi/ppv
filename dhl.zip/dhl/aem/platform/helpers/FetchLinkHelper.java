
package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.Map;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.utils.DHLUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author shiabhis
 *
 *This class is a Helper class which acts as a controller which takes input as 
 *item.links(multifield inside multifield) and take string as input and returns list of map
 *)
 *
 */

public class FetchLinkHelper extends WCMUse {

 private static final Logger log = LoggerFactory.getLogger(LinkListBigHelper.class);
     ArrayList<Map<String, String>> results = new ArrayList<Map<String,String>>();
    
    public ArrayList<Map<String, String>> getResults() {
    
        return results;
    }
    
   
    @Override
    public void activate() throws Exception {
        log.info("FetchLinkHelper activate Method started");
        String multiLinkData = get("multiLinkData", String.class);
        results = DHLUtil.getMultiLinkJsonData(multiLinkData);
        log.info("result final is "+results);
        log.info("FetchLinkHelper activate Method Ended ");
    }
   

}

