package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.FooterLegalModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author shankar
 *         This helper Reads values from the design dialog and returns it back to the Sightly HTML
 */

public class FooterLegalHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(FooterLegalHelper.class);


    private ArrayList<Map<String, String>> footerLegalList;
    DHLUtil dhl = new DHLUtil();

    @Override
    public void activate() throws Exception {

        log.info("FooterLegalHelper initialized ");

        Object obj = getCurrentStyle().get("legalConfig");
        if (obj instanceof String) {
            String values[] = new String[1];
            values[0] = obj.toString();
            footerLegalList = (ArrayList<Map<String, String>>) dhl
                    .getMultiFieldPanelValuesMap(values);
        }
        else if (obj instanceof String[]) {
            String values[] = (String[]) obj;
            footerLegalList = (ArrayList<Map<String, String>>) dhl
                    .getMultiFieldPanelValuesMap(values);
        }

    }


    public ArrayList<HashMap<String, String>> getFooterLegalList() {

        if (footerLegalList != null) {
            return dhl.getMultifieldPaths(footerLegalList, "targetPage");
        }
        return null;

    }


}
