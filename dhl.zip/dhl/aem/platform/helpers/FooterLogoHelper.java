package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.FooterLogoModel;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author shankar
 *This helper Reads values from the design dialog and returns it back to the Sightly HTML
 */

public class FooterLogoHelper extends WCMUse {


    private static final Logger log = LoggerFactory.getLogger(FooterLogoHelper.class);
    
    
    private FooterLogoModel footerLogoModel;

    private ArrayList<FooterLogoModel> footerLogoList;

    DHLUtil dhl = new DHLUtil();

    @Override
    public void activate() throws Exception {

        log.info("FooterLogoHelper initialized ");

        Object obj=getCurrentStyle().get("logoConfig");
        if(obj instanceof String){
            String values[]=new String[1];
            values[0]=obj.toString();
            footerLogoList = dhl.getMultiFieldsPanelValues(values, FooterLogoModel.class);
        }else if(obj instanceof String[]){
            String values[]=(String[])obj;
            footerLogoList = dhl.getMultiFieldsPanelValues(values, FooterLogoModel.class);
        }
       


        FooterLogoModel footerModel;
        Map<String, String> renditionList;

        Iterator<FooterLogoModel> it = footerLogoList.iterator();
        while (it.hasNext()) {
            footerModel = it.next();
            renditionList = DHLUtil.getRenditionList(footerModel.getImageSrc(), getResource());
            log.info("renditionList Footer logo model "+renditionList.size());
            footerModel.setRenditionList(renditionList);
            footerModel.setTargetPage(dhl.getUrl(footerModel.getTargetPage()));
        }

    }

    public FooterLogoModel getFooterLogoModel(){
        return footerLogoModel;
    }

    public ArrayList<FooterLogoModel> getFooterLogoList() {


        return footerLogoList;
    }
}
