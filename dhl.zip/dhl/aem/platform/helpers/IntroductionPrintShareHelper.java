package com.dhl.aem.platform.helpers;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.IntroductionPrintShareModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author gankashy
 *         This helper class reads from corresponding model and gets called from Introduction Print Share Component
 */
public class IntroductionPrintShareHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(IntroductionPrintShareHelper.class);
    private IntroductionPrintShareModel introductionPrintShare;


    @Override
    public void activate() throws Exception {

        log.info("TeaserHelper activate Method started");
        introductionPrintShare = getResource().adaptTo(IntroductionPrintShareModel.class);

    }

    //returns a type of IntroductionPrintShareModel 
    public IntroductionPrintShareModel getIntro() {

        log.info("Model called is" + introductionPrintShare);
        return introductionPrintShare;
    }


}
