package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.Map;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.LinkListBigModel;
import com.dhl.aem.platform.utils.DHLUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author shiabhis
 *
 *This class is a Helper class which acts as a controller which takes input from component
 *front end and sends it to model layer to serve the business logic.
 *
 */

public class LinkListBigHelper extends WCMUse {

 private static final Logger log = LoggerFactory.getLogger(LinkListBigHelper.class);
     private LinkListBigModel linkListBigModel;
   
    @Override
    public void activate() throws Exception {
        log.info("LinkListBigHelper activate Method started");
        linkListBigModel = getResource().adaptTo(LinkListBigModel.class);
        log.info("LinkListBigHelper activate Method Ended");
    }
    public LinkListBigModel getLinkListBigModel() {
    
        return linkListBigModel;
    }

}

