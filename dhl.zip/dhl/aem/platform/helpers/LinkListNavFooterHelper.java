package com.dhl.aem.platform.helpers;


import java.util.ArrayList;
import java.util.Map;

import javax.script.Bindings;
import javax.servlet.http.HttpServletResponse;

import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.scripting.SlingBindings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.FooterLogoModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author Shiabhis
 *
 *         helper class for linked list navigation footer
 *
 */

public class LinkListNavFooterHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(LinkListNavFooterHelper.class);
    private ArrayList<Map<String, String>> navLinkList;
    HttpServletResponse response =null;

    @Override
    public void activate() throws Exception {

        log.info("LinkListNavFooterHelper activate Method started");
        Object obj = getCurrentStyle().get("linkListConfig");
        DHLUtil dhlUtil = new DHLUtil();
        if(obj instanceof String[]){
            String values[]=(String[])obj;
            navLinkList = (ArrayList<Map<String, String>>)dhlUtil.getMultiFieldPanelValuesMap(values);
        }
        else if(obj instanceof String){
            String values[]=new String[1];
            values[0]=obj.toString();
           navLinkList = (ArrayList<Map<String, String>>)dhlUtil.getMultiFieldPanelValuesMap(values);
        }
        log.info("ggg "+navLinkList);
        log.info("LinkListNavFooterHelper activate Method Ended");
        
               
        
    }

    public ArrayList<Map<String, String>> getNavLinkList() {

        return navLinkList;
    }
    
    
    
  

}

