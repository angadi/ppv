package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;

import com.adobe.cq.sightly.WCMUse;

import com.dhl.aem.platform.models.LinkedListModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author gankashy
 *         This helper reads value from the LinkedListModel
 */
public class LinkedListHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(LinkedListHelper.class);
    private ArrayList<HashMap<String, String>> linkedAccordianList;

    @Override
    public void activate() throws Exception {

        log.info("LinkedListHelper activate Method started");
        LinkedListModel linkedListModel = getResource().adaptTo(LinkedListModel.class);
        linkedAccordianList = linkedListModel.getLinkedAccordianList();
        log.info("LinkedListHelper activate Method Ended");
    }


    // returns the value of type ArrayList..
    public ArrayList<HashMap<String, String>> getLinkedAccordianList() {

        if (linkedAccordianList != null)
        {
            return linkedAccordianList;
        }
        return null;
    }

    public void setLinkedAccordianList(ArrayList<HashMap<String, String>> linkedAccordianList) {

        this.linkedAccordianList = linkedAccordianList;
    }


}
