package com.dhl.aem.platform.helpers;

import java.util.Map;

import com.adobe.cq.sightly.WCMUse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.models.LinkedTeaserModel;
import com.dhl.aem.platform.utils.DHLUtil;




/**
 * @author gankashy
 *This Helper reads values from the LinkedTeaserModel
 */
public class LinkedTeaserHelper extends WCMUse {

    
    private static final Logger log = LoggerFactory.getLogger(LinkedTeaserHelper.class);
    private LinkedTeaserModel linkedTeaser;

    @Override
    public void activate() throws Exception {
        log.info("LinkedTeaserHelper activate Method started");
        linkedTeaser = getResource().adaptTo(LinkedTeaserModel.class);
        Map<String,String> renditionList=DHLUtil.getRenditionList(linkedTeaser.getImageSrc(), getResource());
        linkedTeaser.setRenditionList(renditionList);
        log.info("LinkedTeaserHelper activate Method Ended");
    }
    //returns the value of type LonkedTeaserModel
    public LinkedTeaserModel getLinkedTeaser(){
        return linkedTeaser;
    }
}

