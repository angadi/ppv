package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.LinklistDateTitleModel;
import com.dhl.aem.platform.services.PageContentService;
import com.dhl.aem.platform.services.impl.PageContentServiceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * This Helper fetches values from pageContentService,sets it in the LinklistDateTitleModel and returns it back to the
 * Sightly HTML
 * 
 * @author kashyap puddipeddi
 *
 */

public class LinklistDateTitleHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(LinklistDateTitleHelper.class);

    Map<String, String> pageContentMap = new HashMap<String, String>();
    Map<String, String> pageUrlMap = new HashMap<String, String>();
    ArrayList<String> keyList = new ArrayList<String>();
    LinklistDateTitleModel dateTitle;

    @Override
    public void activate() throws Exception {


        String rootPage = (String) getProperties().get("rootPath");


        PageContentService pageContentService = new PageContentServiceImpl();

        pageContentMap = pageContentService.getPageContent(rootPage, getPageManager());


        keyList = pageContentService.keyList();

        pageUrlMap = pageContentService.getPageUrl(rootPage, getPageManager());

        dateTitle = getResource().adaptTo(LinklistDateTitleModel.class);

        dateTitle.setPageContentMap(pageContentMap);
        dateTitle.setKeyList(keyList);
        dateTitle.setPageUrlMap(pageUrlMap);


    }

    public LinklistDateTitleModel getDateTitle() {

        return dateTitle;
    }
}
