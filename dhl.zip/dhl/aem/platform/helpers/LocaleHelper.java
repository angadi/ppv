package com.dhl.aem.platform.helpers;

import java.util.ArrayList;

import com.adobe.cq.sightly.WCMUse;
import com.day.cq.wcm.api.Page;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LocaleHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(LocaleHelper.class);
    private String locale;


    @Override
    public void activate() throws Exception {
        log.info("current page " +getCurrentPage());
        final Page currentPage = getCurrentPage();
        locale = currentPage.getLanguage(false).toString();
        log.info("current Language " +locale);
    }

    public String getLocale() {

        return locale;
    }

}

