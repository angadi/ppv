package com.dhl.aem.platform.helpers;

import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.utils.DHLUtil;


public class MapUrlHelper extends  WCMUse {

    private static final Logger log = LoggerFactory.getLogger(MapUrlHelper.class);
    
    public String mappedUrl;
    DHLUtil dhl=new DHLUtil();
    @Override
    public void activate() throws Exception {

        log.info("MapUrlHelper initialized");
        String url = get("url", String.class);
        String targetUrl=dhl.getUrl(url);
        mappedUrl=getMapURL(getRequest(), targetUrl);
        log.info("final url :: "+mappedUrl);
    }

    public  String getMapURL(SlingHttpServletRequest slingRequest, String url) {
         
        String mappedURL = url;
        if (slingRequest!=null && url!=null) {
         log.info("Mapping URL..");
         org.apache.sling.api.resource.ResourceResolver resolver = slingRequest.getResourceResolver();
         mappedURL = resolver.map(slingRequest, url);
          
        }
        log.info("Mapped URL: " + mappedURL);
         
        return mappedURL;
       }


}
