package com.dhl.aem.platform.helpers;

import com.adobe.cq.sightly.WCMUse;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import com.dhl.aem.platform.models.MarketingStageModel;
import com.dhl.aem.platform.utils.DHLUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * This Helper Reads values from the Marketing Stage Model and returns it back to the Sightly HTML
 * 
 * @author kashyap puddipeddi modified by Ganesh.Kashyap
 *
 */
public class MarketingStageHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(MarketingStageHelper.class);

    private ArrayList<MarketingStageModel> links;


    @Override
    public void activate() throws Exception {

        log.info("HeroStageHelper Activate");

        MarketingStageModel hm;
        Map<String, String> renditionList;
        MarketingStageModel heroStageModel = getResource().adaptTo(MarketingStageModel.class);
        links = heroStageModel.getLinks();
        Iterator<MarketingStageModel> it = links.iterator();
        while (it.hasNext()) {
            hm = it.next();
            renditionList = DHLUtil.getRenditionList(hm.getImageSrc(), getResource());
            hm.setRenditionList(renditionList);
        }


    }


    /**
     * @returns the ArrayList of Marketing Stage Model type
     */
    public ArrayList<MarketingStageModel> getLinks() {

        log.info("Links Value is" + links);
        return links;
    }


}
