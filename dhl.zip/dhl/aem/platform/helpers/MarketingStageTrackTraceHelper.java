package com.dhl.aem.platform.helpers;
import com.adobe.cq.sightly.WCMUse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dhl.aem.platform.models.MarketingStageTrackTraceModel;


/**
 * @author shiabhis
 * 
 *This Helper is for Marketing Track & Trace Component
 *It takes all the input fields from Author dialog  and sends it to Model for buisness logic implementation
 *
 */
public class MarketingStageTrackTraceHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(MarketingStageTrackTraceHelper.class);
    private MarketingStageTrackTraceModel marketingStageTrackTraceModel;

    @Override
    public void activate() throws Exception {
        log.info("MarketingStageTrackTraceHelper activate Method started");
        marketingStageTrackTraceModel = getResource().adaptTo(MarketingStageTrackTraceModel.class);
        log.info("MarketingStageTrackTraceHelper activate Method Ended");
    }

    
    public MarketingStageTrackTraceModel getMarketingStageTrackTraceModel() {
    
        return marketingStageTrackTraceModel;
    }
    
}
