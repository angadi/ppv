package com.dhl.aem.platform.helpers;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.PageManager;
import com.dhl.aem.platform.utils.DHLUtil;
import com.dhl.aem.vo.NavigationHeaderVO;

/**
 * @author gankashy This helper Reads values from the design dialog and returns
 *         it back to the Sightly HTML
 */

public class NavigationChildHelper extends WCMUse {

    private static final Logger log = LoggerFactory
            .getLogger(NavigationChildHelper.class);

    private List<NavigationHeaderVO> linkedChildren = new LinkedList<NavigationHeaderVO>();

    private String hideinNav = "hideInNav";

    DHLUtil dhl = new DHLUtil();
    private static String name;
    NavigationHeaderHelper nav = new NavigationHeaderHelper();

    @Override
    public void activate() throws Exception {

        String multiLinkData = get("multiLinkData", String.class);

        buildLinkAndChildren(multiLinkData, getResource(), getPageManager(), 1);

        Object obj1 = getCurrentStyle().get("levelPage");
        if (obj1 != null)
        {
            name = obj1.toString();
        }

    }

    public List<NavigationHeaderVO> buildLinkAndChildren(String path,
            Resource resource, PageManager pm, int level) {

        if (path != null) {
            path = path.replace(".html", "");
            Page page = pm.getPage(path);
            String title = page.getTitle();
            ResourceResolver resourceResolver1;
            resourceResolver1 = resource.getResourceResolver();
            Resource pageResource1 = null;
            pageResource1 = resourceResolver1
                    .getResource(path + "/jcr:content");
            log.info("resource is" + pageResource1);
            String isTrue = pageResource1.getValueMap().get(hideinNav, "")
                    .toString();
            String navigationTitle = pageResource1.getValueMap().get("navtitle", "")
                    .toString();
            if (title == null) {
                title = page.getName();
            }
            String pathFinal = null;
            pathFinal = page.getPath();
            Iterator<Page> children1 = page.listChildren(new PageFilter());
            log.info("The current Page is" + pathFinal);

            Page page1 = page.getParent();
            String parentTitle = page1.getTitle();
            pathFinal = dhl.getUrl(pathFinal);
            log.info("pathFinal" + pathFinal);
            Boolean isChild = children1.hasNext();
            if (!navigationTitle.isEmpty())
            {
                title = navigationTitle;
            }
            if (level == 1) {
                if (isChild)
                {
                    title = name;
                    linkedChildren.add(new NavigationHeaderVO(pathFinal, title,
                            level, page, resource, parentTitle));
                }
            }
            if (!isTrue.equals("true")) {
                if (level == 2) {
                    linkedChildren.add(new NavigationHeaderVO(pathFinal, title,
                            level, page, resource, parentTitle));
                }

            }
            Iterator<Page> children = page.listChildren(new PageFilter());
            log.info("List of Children" + children);
            while (children.hasNext()) {
                Page child = children.next();
                String childPath = child.getPath();
                buildLinkAndChildren(childPath, resource, pm, level + 1);

            }
        }
        return linkedChildren;
    }

    public List<NavigationHeaderVO> getLinkedChildren() {

        return linkedChildren;
    }

}
