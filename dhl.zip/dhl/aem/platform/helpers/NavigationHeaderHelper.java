package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;

import com.dhl.aem.platform.models.NavigationHeaderModel;
import com.dhl.aem.platform.utils.DHLUtil;
import com.dhl.aem.vo.NavigationHeaderVO;

/**
 * @author gankashy This helper Reads values from the design dialog and returns
 *         it back to the Sightly HTML
 */

public class NavigationHeaderHelper extends WCMUse {

    private static final Logger log = LoggerFactory
            .getLogger(NavigationHeaderHelper.class);

    private NavigationHeaderModel navigationHeaderModel;

    private List<NavigationHeaderVO> secondaryNavigationList;

    private List<NavigationHeaderVO> links = new LinkedList<NavigationHeaderVO>();
    private Page rootPage;

    
    @Inject
    private ResourceResolver resourceResolver;
    private String hideinNav = "hideInNav";
    private ArrayList<Map<String, String>> headerList;
    private Page currentPage;
    private String templateName;
    private String cqTemplate = "cq:template";
    
    private String firstLevel = "";
    private String homePageLink = "";


    DHLUtil dhl = new DHLUtil();

    @Override
    public void activate() throws Exception {

        Object firstLevelPath = getCurrentStyle().get("firstLevelNavLink");
        Object homePagePath = getCurrentStyle().get("homePageLink");
        if (homePageLink != null)
        {
            homePageLink = homePagePath.toString();
        }
        if (firstLevelPath != null) {
            firstLevel = firstLevelPath.toString();
            firstLevel.replace(".html", "");
        }
        log.info("FirstLevlPage is" + firstLevel);
        Resource resourceHome = getResourceResolver().getResource(firstLevel);
        Object obj = getCurrentStyle().get("metanavconfig");
        if (obj instanceof String) {
            String values[] = new String[1];
            values[0] = obj.toString();
            headerList = (ArrayList<Map<String, String>>) dhl
                    .getMultiFieldPanelValuesMap(values);

        }
        else if (obj instanceof String[]) {
            String values[] = (String[]) obj;
            headerList = (ArrayList<Map<String, String>>) dhl
                    .getMultiFieldPanelValuesMap(values);
        }
        currentPage = getCurrentPage();

        rootPage = resourceHome.adaptTo(Page.class);
        if (rootPage != null) {
            buildLink(rootPage, 0, getResource());

        }

        pageTemplate(currentPage, getResource());
        //getHomePage(currentPage, getResource());
    }

    /*
     * public String getHomePage(Page page, Resource resource) {
     * if(currentPage.getDepth()>HOME_PAGE_LEVEL)
     * {
     * rootPage = currentPage.getAbsoluteParent(HOME_PAGE_LEVEL);
     * if(rootPage.getPath().contains("master"))
     * {
     * rootPage = currentPage.getAbsoluteParent(HOME_PAGE_LEVEL+1);
     * }
     * Iterator<Page> children = rootPage.listChildren();
     * while (children.hasNext())
     * {
     * Page Child1 = children.next();
     * log.info("Page Name inside Home is" + Child1.getName());
     * String templatePath = pageTemplate(Child1, resource);
     * log.info("Template Path is" + templatePath);
     * if (templatePath.equals("/apps/dhl/templates/homepage-template"))
     * {
     * homePage = Child1.getPath();
     * if (homePage != null) {
     * homePage = dhl.getUrl(homePage);
     * log.info("Inside Loop Page Home Page is" + homePage);
     * }
     * }
     * }
     * }
     * log.info("FinaleValue of Home page is" + homePage);
     * return homePage;
     * }
     * public String getFinalHomePage() {
     * finalHomePage = homePage;
     * return finalHomePage;
     * }
     */


    public String getHomePageLink() {

        if (homePageLink != null)
        {
            homePageLink = dhl.getUrl(homePageLink);
        }
        return homePageLink;
    }

    public ArrayList<HashMap<String, String>> getHeaderList() {

        if (headerList != null) {
            return dhl.getMultifieldPaths(headerList, "targetLink");
        }
        return null;

    }


    public NavigationHeaderModel getNavigationHeaderModel() {

        return navigationHeaderModel;
    }

    public List<NavigationHeaderVO> getSecondaryNavigationList() {

        return secondaryNavigationList;
    }

    public List<NavigationHeaderVO> buildLink(Page page, int level,
            Resource resource) {

        if (page != null) {
            int pageLevel = page.getDepth();
            log.info("Depth of the Page is" + pageLevel);
           
                String title = page.getTitle();
                log.info("Page.get title" + title);
                resourceResolver = resource.getResourceResolver();

                String path = page.getPath();
                Resource pageResource1 = null;
                pageResource1 = resourceResolver.getResource(path + "/jcr:content");
                log.info("resource is" + pageResource1);
                String navigationTitle = pageResource1.getValueMap().get("navtitle", "")
                        .toString();
                String isTrue = pageResource1.getValueMap().get(hideinNav, "")
                        .toString();
                if (title == null) {
                    title = page.getName();
                }
                if (!navigationTitle.isEmpty())
                {
                    title = navigationTitle;
                }
                String pathFinal = null;
                Page page1 = page.getParent();
                String parentTitle = page1.getTitle();
                pathFinal = page.getPath();
                pathFinal = dhl.getUrl(pathFinal);
                if (!isTrue.equals("true")) {
                    if (level == 1) {
                        links.add(new NavigationHeaderVO(pathFinal, title, level,
                                page, resource, parentTitle));
                    }
                }
                Iterator<Page> children = page.listChildren(new PageFilter());
                log.info("List of Children" + children);
                while (children.hasNext()) {
                    Page child = children.next();
                    if (level == 0) {
                        buildLink(child, level + 1, resource);
                    }
                }
            }
        
        setLinks(links);
        log.info("Links final is" + links);
        return links;
    }

    public List<NavigationHeaderVO> getLinks() {

        return links;
    }

    public void setLinks(List<NavigationHeaderVO> links) {

        this.links = links;
    }

    public String pageTemplate(Page page, Resource resource) {

        resourceResolver = resource.getResourceResolver();
        Resource resource1 = null;
        String path = page.getPath();
        resource1 = resourceResolver.getResource(path + "/jcr:content");
        templateName = resource1.getValueMap().get(cqTemplate, "").toString();
        return templateName;

    }

    public String getTemplateName() {

        return templateName;
    }


}
