package com.dhl.aem.platform.helpers;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.AlertBarModel;


public class PageHeadLineHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(PageHeadLineHelper.class);
    public String cutomeRteText;
    
    @Override
    public void activate() throws Exception {
        log.info("PageHeadLineHelper activate Method started: --->>>>>");
        String rteData = get("rteText", String.class);
        cutomeRteText=rteData;
    }

    
    public String getCutomeRteText() {
    
        if(cutomeRteText!=null){
        cutomeRteText=cutomeRteText.replaceAll("<p>", "<p class=\"has-rte\">");

        cutomeRteText = cutomeRteText.replaceAll("<a href=\"/content",
                "<a class=\"link link-internal link-red has-icon\" href=\"/content");
        cutomeRteText = cutomeRteText.replaceAll("<a href=\"http:",
                "<a class=\"link link-external link-red has-icon\" href=\"http:");
        cutomeRteText = cutomeRteText.replaceAll("<a href=\"https:",
                "<a class=\"link link-external link-red has-icon\" href=\"https:");
        
        }
        return cutomeRteText;
    }

    
    

       
}
