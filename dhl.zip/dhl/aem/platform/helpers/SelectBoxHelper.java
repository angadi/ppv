package com.dhl.aem.platform.helpers;


import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.SelectBoxModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SelectBoxHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(SelectBoxHelper.class);
    private SelectBoxModel selectBoxModel;


    @Override
    public void activate() throws Exception {

        
        selectBoxModel = getResource().adaptTo(SelectBoxModel.class);

      
    }


    
    public SelectBoxModel getSelectBoxModel() {
    
        return selectBoxModel;
    }





}
