package com.dhl.aem.platform.helpers;
import com.adobe.cq.sightly.WCMUse;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.sling.api.SlingHttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.PageManager;

import com.dhl.aem.platform.models.SiteMapModel;

public class SiteMapHelper  extends WCMUse {
	private SlingHttpServletRequest request;
	private static final Logger log = LoggerFactory.getLogger(SiteMapHelper.class);
	private String rootPath;
	private List<SiteMapModel> links = new LinkedList<SiteMapModel>();
    private Page rootPage;

   
    private Map<String, String> mapOfLinks;
   
 
	@Override
    public void activate() throws Exception  {
		rootPath = getProperties().get("basepath", ""); 
		log.info("Sightly value is"+getProperties().get("name"));
		log.info("the root page is " +rootPath);
		request = getRequest();
		log.info("the request is"+request);
		
		
		log.info("Inside class");
      
        mapOfLinks = new HashMap<String, String>();
        log.info("Map  of Links class");
        
            rootPage = null;
            rootPage = request.getResourceResolver().adaptTo(PageManager.class).getPage(rootPath);
            log.info("Null path"+rootPage);
            if (rootPage != null) {
            	log.info("HI"+rootPage);
            	buildLinkAndChildren(rootPage, 0);
            
        }
        
    }
     
        
        
        public  List<SiteMapModel> buildLinkAndChildren(Page page, int level) {
            if (page != null) {
                String title = page.getTitle();
                if (title == null) {
                    title = page.getName();
                }
                String pathFinal = null;
                pathFinal = page.getPath();
                log.debug("Inside method"+title);
                links.add(new SiteMapModel(pathFinal, title, level));
                Iterator<Page> children = page.listChildren(new PageFilter());
                while (children.hasNext()) {
                    Page child = children.next();
                    buildLinkAndChildren(child, level + 1);
                }
            }
            setLinks(links);
            return links;
        }
        
        
        public  List<SiteMapModel> getLinks() {
        	log.info("Final value is" + links);
            return links;
        }

        public void setLinks(List<SiteMapModel> links) {
            this.links = links;
        }
        
        
     /*   private String getPathLink(Page page) {
            String pagePath = page.getPath();
            actualResource = null;
            actualResource = request.getResourceResolver().getResource(pagePath + "/jcr:content");
            if (actualResource != null) {
                valueMap = actualResource.getValueMap();
                if (!valueMap.isEmpty()) {
                    
                        path = pagePath;
                        mapOfLinks.put(path, path);
                    
                }
            }
            return path;
        }*/



}
