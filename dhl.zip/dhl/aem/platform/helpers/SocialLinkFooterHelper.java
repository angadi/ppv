package com.dhl.aem.platform.helpers;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.SocialLinkFooterModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author Ajay
 *
 *         This class is a Helper class which acts as a controller which takes input from social link component
 *         front end and sends it to model layer to serve the business logic.
 *
 */

public class SocialLinkFooterHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(SocialLinkFooterHelper.class);
    private SocialLinkFooterModel socialModel;
    private ArrayList<SocialLinkFooterModel> socialLinkList;
    Map<String, String> renditionList;
    DHLUtil dhl = new DHLUtil();


    @Override
    public void activate() throws Exception {

        log.info("SocialLinkFooterHelper activate initialized");

        Object obj = getCurrentStyle().get("linkConfig");
        if (obj instanceof String) {
            String values[] = new String[1];
            values[0] = obj.toString();


            //   dhl.getMultiFieldPanelValues(values, SocialLinkFooterModel.class);
            socialLinkList = dhl.getMultiFieldPanelValues(values, SocialLinkFooterModel.class);

        }
        else if (obj instanceof String[]) {
            String values[] = (String[]) obj;


            socialLinkList = dhl.getMultiFieldsPanelValues(values, SocialLinkFooterModel.class);

        }


        Iterator<SocialLinkFooterModel> itr = socialLinkList.iterator();
        while (itr.hasNext()) {
            socialModel = itr.next();
            renditionList = DHLUtil.getRenditionList(socialModel.getImageSrc(), getResource());
            socialModel.setRenditionList(renditionList);


        }


        // socialLink = getResource().adaptTo(SocialLinkFooterModel.class);
        log.info("SocialLinkFooterHelper activate Method Ended " + socialLinkList);


    }


   


    public ArrayList<SocialLinkFooterModel> getSocialLinkList() {

        return socialLinkList;
    }


    


}

