package com.dhl.aem.platform.helpers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.StageGenericModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * This helper Reads values from the  Model and returns it back to the Sightly HTML
 * 
 * @author Shankar
 *
 */
public class StageGenericHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(StageGenericHelper.class);

    private StageGenericModel stageGenericModel; 

    @Override
    public void activate() throws Exception {


        log.info("StageGenericHelper initialized ");
        stageGenericModel = getResource().adaptTo(StageGenericModel.class);
        log.info("headline helpr"+stageGenericModel.getHeadline());
        stageGenericModel.setRenditionList(DHLUtil.getRenditionList(stageGenericModel.getImageSrc(), getResource()));

        log.info("stage model rendition "+stageGenericModel.getRenditionList().size());
    }


    public StageGenericModel getStageGenericModel() {

        return stageGenericModel;
    }





}
