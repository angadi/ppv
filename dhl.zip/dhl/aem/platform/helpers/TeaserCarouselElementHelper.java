package com.dhl.aem.platform.helpers;

import java.util.Map;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.TeaserCarouselElementModel;
import com.dhl.aem.platform.utils.DHLUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author gankashy
 *         This helper gets called from teaser-carousel-element component and fetches value from teaser Carousel element
 *         model
 */

public class TeaserCarouselElementHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(TeaserCarouselElementHelper.class);

    private TeaserCarouselElementModel teaser;


    @Override
    public void activate() throws Exception {

        log.info("TeaserHelper activate Method started");
        teaser = getResource().adaptTo(TeaserCarouselElementModel.class);
        Map<String, String> renditionList = DHLUtil.getRenditionList(teaser.getImageSrc(), getResource());
        teaser.setRenditionList(renditionList);

    }

    //returns the value of type TeaserCarouselElementModel
    public TeaserCarouselElementModel getTeaser() {

        log.info("the value is final " + teaser);
        return teaser;
    }

}
