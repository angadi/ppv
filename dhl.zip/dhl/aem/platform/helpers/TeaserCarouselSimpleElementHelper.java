package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.HashMap;

import com.adobe.cq.sightly.WCMUse;

import com.dhl.aem.platform.models.TeaserCarouselSimpleElementModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author gankashy This helper gets called from teaser-carousel-element
 *         component and fetches value from teaser Carousel element model
 */

public class TeaserCarouselSimpleElementHelper extends WCMUse {

	private static final Logger log = LoggerFactory
			.getLogger(TeaserCarouselSimpleElementHelper.class);

	private TeaserCarouselSimpleElementModel teasersimple;
	private ArrayList<HashMap<String, String>> listItem;

	@Override
	public void activate() throws Exception {

		log.info("TeaserHelper activate Method started");
		teasersimple = getResource().adaptTo(
				TeaserCarouselSimpleElementModel.class);
		listItem = teasersimple.getListOfIcons();
	}

	public ArrayList<HashMap<String, String>> getListItem() {
		log.info("List of Itemssss " + listItem);
		return listItem;
	}

	// returns the value of type TeaserCarouselElementModel
	public TeaserCarouselSimpleElementModel getTeaser() {

		log.info("the value is final " + teasersimple);
		return teasersimple;
	}

}
