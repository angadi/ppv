package com.dhl.aem.platform.helpers;
import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.TeaserContainerModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TeaserContainerHelper extends WCMUse {
    private static final Logger log = LoggerFactory.getLogger(TeaserCarouselElementHelper.class);
    private TeaserContainerModel teasercontainer;
    
   
    @Override
    public void activate() throws Exception {

        log.info("TeaserHelper activate Method started");
        teasercontainer = getResource().adaptTo(TeaserContainerModel.class);
        log.info("claass is " +teasercontainer);



    }
    
    public TeaserContainerModel getTeaserContainerModel() {
        log.info("Model called is"+teasercontainer);
        return teasercontainer;
    }


    
    
}