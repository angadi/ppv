package com.dhl.aem.platform.helpers;

import com.adobe.cq.sightly.WCMUse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dhl.aem.platform.models.TeaserFactsModel;


/**
 * This Helper Reads values from the Teaser Facts Model and returns it back to the Sightly HTML
 * 
 * @author kashyap puddipeddi
 *
 */


public class TeaserFactsHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(TeaserFactsHelper.class);
    private TeaserFactsModel teaserFacts;

    @Override
    public void activate() throws Exception {

        log.info("TeaserHelper activate Method started");
        teaserFacts = getResource().adaptTo(TeaserFactsModel.class);
        log.info("TeaserHelper activate Method Ended");
    }

    public TeaserFactsModel getTeaserFacts() {

        return teaserFacts;
    }
}
