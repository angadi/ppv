package com.dhl.aem.platform.helpers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.MarketingStageModel;
import com.dhl.aem.platform.models.TeaserImageModel;
import com.dhl.aem.platform.utils.DHLUtil;

/**
 * This helper Reads values from the Teaser Image Model and returns it back to the Sightly HTML
 * 
 * @author Shankar
 *
 */

public class TeaserImageHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(TeaserImageHelper.class);
    
    private TeaserImageModel teaserImageModel; 
    
    private ArrayList<TeaserImageModel> teaserImageList;
    
    @Override
    public void activate() throws Exception {

        log.info("TeaserImageHelper initialized ");
          teaserImageModel = getResource().adaptTo(TeaserImageModel.class);
          log.info("the object is "+teaserImageModel.getLinkedHeadline());
          log.info("TeaserImageHelper destroyed ");
          TeaserImageModel tm;
          Map<String, String> renditionList;
          teaserImageList=teaserImageModel.getTeaserImageList();
          Iterator<TeaserImageModel> it = teaserImageList.iterator();
          while (it.hasNext()) {
              tm = it.next();
              renditionList = DHLUtil.getRenditionList(tm.getImageSrc(), getResource());
              log.info("renditionList teaser image model "+renditionList.size());
              tm.setRenditionList(renditionList);
          }
         
      
    }
    
    public TeaserImageModel getTeaserImageModel(){
        return teaserImageModel;
    }

    
    public ArrayList<TeaserImageModel> getTeaserImageList() {
    
        return teaserImageList;
    }

    
     
    
    

}
