package com.dhl.aem.platform.helpers;

import java.util.Map;

import com.adobe.cq.sightly.WCMUse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.models.TeaserLargeModel;
import com.dhl.aem.platform.utils.DHLUtil;


public class TeaserLargeHelper extends WCMUse {

    private static final Logger log = LoggerFactory.getLogger(TeaserLargeHelper.class);
    private TeaserLargeModel teaser;

    @Override
    public void activate() throws Exception {

        log.info("TeaserHelper activate Method started");
        Map<String, String> renditionList;
        teaser = getResource().adaptTo(TeaserLargeModel.class);
        if (getProperties().get("imageSrc") != null) {
            renditionList = DHLUtil.getRenditionList(teaser.getImageSrc(), getResource());
            teaser.setRenditionList(renditionList);
        }
        log.info("TeaserHelper activate Method Ended");
    }

    public TeaserLargeModel getTeaser() {

        return teaser;
    }
}
