package com.dhl.aem.platform.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.dhl.aem.platform.utils.DHLUtil;

/**
* @author Shankar 
*This Model reads values from dialog and returns the values to the helper
*/
@Model(adaptables = Resource.class)
public class AlertBarModel {
    
    private String id;
    
    @Inject  @Optional
    private String isActiveComponet;
    
    @Inject @Optional
    private String linkedHeadline;
    
    @Inject @Optional
    private String targetUrl;
    
    @Inject @Optional
    private String[] alertConfig;
    
    private String isActive;
    
    private String newTabm;
                      
    private String linkedMessage;
    
    private String targetPage;
    
    DHLUtil dhl = new DHLUtil();

    
    
    
    
    
    public String getId() {
    
        return id;
    }


    
    public void setId(String id) {
    
        this.id = id;
    }


    public String getIsActiveComponet() {
    
        return isActiveComponet;
    }

    
    public void setIsActiveComponet(String isActiveComponet) {
    
        this.isActiveComponet = isActiveComponet;
    }

    
    public String getLinkedHeadline() {
    
        return linkedHeadline;
    }

    
    public void setLinkedHeadline(String linkedHeadline) {
    
        this.linkedHeadline = linkedHeadline;
    }

    
    public String getTargetUrl() {
    
        String link="";
        if(targetUrl != null && !targetUrl.isEmpty())
        {
            link=dhl.getUrl(targetUrl);
        }
        return link;
    }

    
    public void setTargetUrl(String targetUrl) {
    
        this.targetUrl = targetUrl;
    }

    
    public String[] getAlertConfig() {
    
        return alertConfig;
    }

    
    public void setAlertConfig(String[] alertConfig) {
    
        this.alertConfig = alertConfig;
    }

    
    public String getIsActive() {
    
        return isActive;
    }

    
    public void setIsActive(String isActive) {
    
        this.isActive = isActive;
    }

    
    public String getLinkedMessage() {
    
        return linkedMessage;
    }

    
    public void setLinkedMessage(String linkedMessage) {
    
        this.linkedMessage = linkedMessage;
    }

    
    public String getTargetPage() {
    
        String link="";
        if(targetPage != null && !targetPage.isEmpty())
        {
            link=dhl.getUrl(targetPage);
        }
        return link;
    }

    
    public void setTargetPage(String targetPage) {
    
        this.targetPage = targetPage;
    }



	public String getNewTabm() {
		return newTabm;
	}



	public void setNewTabm(String newTabm) {
		this.newTabm = newTabm;
	}
    
      
    

}
