package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;

/**
* @author Shankar 
*This Model reads values from dialog and returns the values to the helper
*/
@Model(adaptables = Resource.class)
public class ContentLinkListModel {
    
    private static final Logger log = LoggerFactory.getLogger(ContentLinkListModel.class);
    
    @Inject
    @Optional
    private String headline;
    
    @Inject
    @Optional
    private String headlineLink;
    
    @Inject
    @Optional
    private String introductionCopy;
   
    /*Multifield config*/
    @Inject
    private String[] linkListConfig;
    
    private String productHeadline;
    
    private String copy;
    
    private String imageSrc;
    
    private String altText;
    
    private String previewText;
    
    @Inject
    @Optional
    private String[]  buttonConfig;
    
     
    private String buttonText;

     
    private String buttonLink;
    
    private String newTabm;

    
    private ArrayList<ContentLinkListModel> contentLinkListModelList;
    
    private ArrayList<ContentLinkListModel> buttonLinkList;
    
    private Map<String, String> renditionList;

    DHLUtil dhl = new DHLUtil();
    public String getHeadline() {
    
        return headline;
    }

    
    public void setHeadline(String headline) {
    
        this.headline = headline;
    }

    
    public String getHeadlineLink() {
        String link="";
        if(headlineLink != null && !headlineLink.isEmpty())
        {
            link=dhl.getUrl(headlineLink);
        }
        return link;
        
    }

    
    public void setHeadlineLink(String headlineLink) {
    
        this.headlineLink = headlineLink;
    }

    
    public String getIntroductionCopy() {
    
        return introductionCopy;
    }

    
    public void setIntroductionCopy(String introductionCopy) {
    
        this.introductionCopy = introductionCopy;
    }

    
    public String[] getLinkListConfig() {
    
        return linkListConfig;
    }

    
    public void setLinkListConfig(String[] linkListConfig) {
    
        this.linkListConfig = linkListConfig;
    }

    
    public String getProductHeadline() {
    
        return productHeadline;
    }

    
    public void setProductHeadline(String productHeadline) {
    
        this.productHeadline = productHeadline;
    }

    
    public String getCopy() {
    if(copy!=null && !copy.isEmpty()){
        copy=copy.replace("&quot;", "\"");
        copy=copy.replaceAll("<p>", "<p class=\"has-rte\">");
        copy = copy.replaceAll("<a href=\"/content",
                "<a class=\"link link-internal link-red has-icon\" href=\"/content");
        copy = copy.replaceAll("<a href=\"http:",
                "<a class=\"link link-external link-red has-icon\" href=\"http:");
        copy = copy.replaceAll("<a href=\"https:",
                "<a class=\"link link-external link-red has-icon\" href=\"https:");

        copy= copy.replaceAll("<ul>", "<ul class=\"list\">");
        copy= copy.replaceAll("<ol>", "<ol class=\"list\">");
        copy = copy.replaceAll("<li>", "<li><span>");
        copy = copy.replaceAll("</li>", "</span></li>");
        
        return copy;
    }else{
        return copy;
    }
        
    }

    
    public void setCopy(String copy) {
    
        this.copy = copy;
    }

    
    public String getImageSrc() {
    
        return imageSrc;
    }

    
    public void setImageSrc(String imageSrc) {
    
        this.imageSrc = imageSrc;
    }

    
    public String getAltText() {
    
        return altText;
    }

    
    public void setAltText(String altText) {
    
        this.altText = altText;
    }

    
    public String getButtonText() {
    
        return buttonText;
    }

    
    public void setButtonText(String buttonText) {
    
        this.buttonText = buttonText;
    }

    
    public String getButtonLink() {
        String link="";
        if(buttonLink != null && !buttonLink.isEmpty())
        {
            link=dhl.getUrl(buttonLink);
        }
        return link;
         
    }

    
    public void setButtonLink(String buttonLink) {
    
        this.buttonLink = buttonLink;
    }

    
    public ArrayList<ContentLinkListModel> getContentLinkListModelList() {
    
        String[] values = linkListConfig;
        DHLUtil dhlUtil = new DHLUtil();
        if (values != null)
        {
            contentLinkListModelList = dhlUtil.getMultiFieldsPanelValues(values, ContentLinkListModel.class);
            log.info(" linkListConfig in get size" + contentLinkListModelList.size());
        }
        return contentLinkListModelList;
    }

    
    public void setContentLinkListModelList(ArrayList<ContentLinkListModel> contentLinkListModelList) {
    
        this.contentLinkListModelList = contentLinkListModelList;
    }


    
    public Map<String, String> getRenditionList() {
    
        return renditionList;
    }


    
    public void setRenditionList(Map<String, String> renditionList) {
    
        this.renditionList = renditionList;
    }


    
   

    
    public ArrayList<ContentLinkListModel> getButtonLinkList() {
    
        String[] values = buttonConfig;
        DHLUtil dhlUtil = new DHLUtil();
        if (values != null)
        {
            buttonLinkList = dhlUtil.getMultiFieldsPanelValues(values, ContentLinkListModel.class);
            log.info(" buttonConfig in get size" + buttonLinkList.size());
            Collections.reverse(buttonLinkList);
        }
       
               
        return buttonLinkList;
    }


    
    public void setButtonLinkList(ArrayList<ContentLinkListModel> buttonLinkList) {
    
        this.buttonLinkList = buttonLinkList;
    }


    
    public String[] getButtonConfig() {
    
        return buttonConfig;
    }


    
    public void setButtonConfig(String[] buttonConfig) {
    
        this.buttonConfig = buttonConfig;
    }


	public String getNewTabm() {
		return newTabm;
	}


	public void setNewTabm(String newTabm) {
		this.newTabm = newTabm;
	}


	public String getPreviewText() {
		return previewText;
	}


	public void setPreviewText(String previewText) {
		this.previewText = previewText;
	}
    
    
    
}
