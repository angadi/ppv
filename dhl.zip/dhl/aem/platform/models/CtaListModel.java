package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author gankashy
 *         This Model reads values of multifield and returns the values to the helper
 */
@Model(adaptables = Resource.class)
public class CtaListModel {

    private static final Logger log = LoggerFactory.getLogger(CtaListModel.class);
    @Inject
    private String[] buttons;

    private ArrayList<Map<String, String>> ctaList;

    DHLUtil dhlUtil = new DHLUtil();

    public String[] getButtons() {

        return buttons;
    }


    public void setButtons(String[] buttons) {

        this.buttons = buttons;
    }

    // returns the arraylist of HashMap type.
    public ArrayList<HashMap<String, String>> getCtaList() {

        if (ctaList != null) {
            return dhlUtil.getMultifieldPaths(ctaList, "buttonLink");
        }
        return null;

    }

    public void setCtaList(ArrayList<Map<String, String>> ctaList) {

        this.ctaList = ctaList;
    }


    @PostConstruct
    protected void init() throws Exception {


        ctaList = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(buttons);
    }

}
