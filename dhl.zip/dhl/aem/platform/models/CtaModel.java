package com.dhl.aem.platform.models;

import java.util.ArrayList;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author gankashy
 *         This component reads the value of button Text,Path field and color combination and sends the response to
 *         helper class.
 */
@Model(adaptables = Resource.class)
public class CtaModel {

    @Inject
    @Optional
    private String callToAction;

    @Inject
    @Optional
    private String buttonText;

    @Inject
    @Optional
    private String color;

    //returns the String of text
    public String getButtonText() {

        return buttonText;
    }

    public void setButtonText(String buttonText) {

        this.buttonText = buttonText;
    }

    //returns the Color Combination 
    public String getColor() {

        return color;
    }

    public void setColor(String color) {

        this.color = color;
    }

    private static final Logger log = LoggerFactory.getLogger(CtaModel.class);

    //returns the pathfield
    public String getCallToAction() {

        String link = callToAction;
        DHLUtil dhl = new DHLUtil();
        String path1 = dhl.getUrl(link);
        log.info("the returned path is " + path1);
        return path1;

    }

    public void setCallToAction(String callToAction) {

        this.callToAction = callToAction;
    }


}
