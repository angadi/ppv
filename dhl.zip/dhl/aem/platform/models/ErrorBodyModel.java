/**
 * 
 */
package com.dhl.aem.platform.models;

import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

/**
 * @author ajakumar1
 *
 */
public class ErrorBodyModel {
    
    @Inject
    private String heading;
    
    @Inject
    private String body;
    
    
    @Inject
    private String imageSrc;


    private Map<String,String> renditionList ;
    
    

    public String getHeading() {
        if (null != heading && !heading.isEmpty()) {
            return heading;
        }
        else {
            return StringUtils.EMPTY;
        }

    }

    
    public void setHeading(String heading) {
    
        this.heading = heading;
    }

    
    public String getBody() {
        if (null != body && !body.isEmpty()) {
            return body;
        }
        else {
            return StringUtils.EMPTY;
        }
    }

    
    public void setBody(String body) {
    
        this.body = body;
    }

    
    public String getImageSrc() {
    
        return imageSrc;
    }

    
    public void setImageSrc(String imageSrc) {
    
        this.imageSrc = imageSrc;
    }
    
  

    public Map<String, String> getRenditionList() {
    
        return renditionList;
    }


    
    public void setRenditionList(Map<String, String> renditionList) {
    
        this.renditionList = renditionList;
    }

    

}
