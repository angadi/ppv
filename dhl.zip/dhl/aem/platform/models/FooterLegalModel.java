package com.dhl.aem.platform.models;

import javax.inject.Inject;

/**
 * @author Shankar
 *         This Model reads values from dialog and returns the values to the helper
 */
public class FooterLegalModel {


    // @Inject
    private String[] legalConfig;

    private String link;

    private String targetPage;

    @Inject
    private String headline;

    @Inject
    private String copyrightLinktext;

    @Inject
    private String copyrightLink;


    public String[] getLegalConfig() {

        return legalConfig;
    }


    public void setLegalConfig(String[] legalConfig) {

        this.legalConfig = legalConfig;
    }


    public String getLink() {

        return link;
    }


    public void setLink(String link) {

        this.link = link;
    }


    public String getTargetPage() {

        return targetPage;
    }


    public void setTargetPage(String targetPage) {

        this.targetPage = targetPage;
    }


    public String getHeadline() {

        return headline;
    }


    public void setHeadline(String headline) {

        this.headline = headline;
    }


    public String getCopyrightLinktext() {

        return copyrightLinktext;
    }


    public void setCopyrightLinktext(String copyrightLinktext) {

        this.copyrightLinktext = copyrightLinktext;
    }


    public String getCopyrightLink() {

        return copyrightLink;
    }


    public void setCopyrightLink(String copyrightLink) {

        this.copyrightLink = copyrightLink;
    }


}
