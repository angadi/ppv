package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;

/**
* @author Shankar 
*This Model reads values from dialog and returns the values to the helper
*/
@Model(adaptables = Resource.class)
public class FooterLogoModel {

    private static final Logger log = LoggerFactory.getLogger(FooterLogoModel.class);
    
    @Inject
    private String[] logoConfig;
    @Inject
    private String headline;
    
    private String imageSrc;
    
    private String altText;
    
    private String targetPage;
    
    private String newTabm;

    private ArrayList<FooterLogoModel> footerLogoList;
    
    Map<String, String> renditionList;
    
    DHLUtil dhl = new DHLUtil();
    
    
    public String[] getLogoConfig() {
    
        return logoConfig;
    }

    
    public void setLogoConfig(String[] logoConfig) {
    
        this.logoConfig = logoConfig;
    }

    
    public String getHeadline() {
    
        return headline;
    }

    
    public void setHeadline(String headline) {
    
        this.headline = headline;
    }

    
    public String getImageSrc() {
    
        return imageSrc;
    }

    
    public void setImageSrc(String imageSrc) {
    
        this.imageSrc = imageSrc;
    }

    
    public String getAltText() {
    
        return altText;
    }

    
    public void setAltText(String altText) {
    
        this.altText = altText;
    }

    
    public String getTargetPage() {
    
        return targetPage;
    }

    
    public void setTargetPage(String targetPage) {
    
        this.targetPage = targetPage;
    }


    
    public ArrayList<FooterLogoModel> getFooterLogoList() {
    
        String[] values = logoConfig;
         
        if (values != null)
        {
            footerLogoList = dhl.getMultiFieldsPanelValues(values, FooterLogoModel.class);
            log.info("in get logo size" + footerLogoList.size());
        }
        return footerLogoList;
    }


    
    public void setFooterLogoList(ArrayList<FooterLogoModel> footerLogoList) {
    
        this.footerLogoList = footerLogoList;
    }


    
    public Map<String, String> getRenditionList() {
    
        return renditionList;
    }


    
    public void setRenditionList(Map<String, String> renditionList) {
    
        this.renditionList = renditionList;
    }


	public String getNewTabm() {
		return newTabm;
	}


	public void setNewTabm(String newTabm) {
		this.newTabm = newTabm;
	}
    
    
    
}
