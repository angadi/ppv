package com.dhl.aem.platform.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * The Model program reads the value performs logical operations and returns back the
 * values using setters and getters
 * 
 *
 * @author Ganesh.Kashyapa.D
 * @since 2015-06-12
 */

@Model(adaptables = Resource.class)
public class IntroductionPrintShareModel {

    private static final Logger log = LoggerFactory.getLogger(IntroductionPrintShareModel.class);
    @Inject
    @Optional
    private String headLine;
    @Inject
    @Optional
    private String rteLight;
    @Inject
    @Optional
    private String headlineLink;
    @Inject
    @Optional
    private String buttonText;
    @Inject
    @Optional
    private String buttonLink;
    @Inject
    @Optional
    private String headlineColor;


    public String getHeadlineColor() {

        return headlineColor;
    }


    public void setHeadlineColor(String headlineColor) {

        this.headlineColor = headlineColor;
    }


    DHLUtil dhl = new DHLUtil();


    public String getHeadLine() {

        return headLine;
    }


    public void setHeadLine(String headLine) {

        this.headLine = headLine;
    }


    public String getRteLight() {

        return  rteLight.replaceAll("<p>", "<p class=\"has-rte\">");
    }


    public void setRteLight(String rteLight) {

        this.rteLight = rteLight;
    }


    //returns the HeadLine Link after checking whether its external or internal link
    public String getHeadlineLink() {

        String link = "";
        if (headlineLink != null && !headlineLink.isEmpty())
        {
            link = dhl.getUrl(headlineLink);
        }
        log.info("Link is" + link);
        return link;
    }


    public void setHeadlineLink(String headlineLink) {

        this.headlineLink = headlineLink;

    }


    public String getButtonText() {

        return buttonText;
    }


    public void setButtonText(String buttonText) {

        this.buttonText = buttonText;
    }

    //returns the button Link after checking whether its external or internal link
    public String getButtonLink() {

        String bLink = "";
        if (buttonLink != null && !buttonLink.isEmpty())
        {
            bLink = dhl.getUrl(buttonLink);
        }
        log.info("Link is" + bLink);
        return bLink;

    }


    public void setButtonLink(String buttonLink) {

        this.buttonLink = buttonLink;
    }

}
