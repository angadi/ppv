package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author shiabhis
 *
 *         This class is a model class which maps the element of Link List Big
 *         component recieved from Helper class and implements the buisness logic
 *         and sends back to Helper.
 *
 */
@Model(adaptables = Resource.class)
public class LinkListBigModel {

    @Inject
    private String[] categories;
    @Inject
    private String headLine;
    @Inject
    @Optional
    private String copy;
    @Inject
    @Optional
    private String buttonText;
    @Inject
    @Optional
    private String targetLink;

    DHLUtil dhlUtil = new DHLUtil();
    private ArrayList<Map<String, String>> categorieList;

    public String getHeadLine() {

        if (null != headLine && !headLine.isEmpty()) {
            return headLine;
        }
        else {
            return StringUtils.EMPTY;
        }

    }


    public void setHeadLine(String headLine) {

        this.headLine = headLine;
    }


    public String getCopy() {

        if (null != copy && !copy.isEmpty()) {
            return copy;
        }
        else {
            return StringUtils.EMPTY;
        }
    }


    public void setCopy(String copy) {

        this.copy = copy;
    }


    public String getButtonText() {

        if (null != buttonText && !buttonText.isEmpty()) {
            return buttonText;
        }
        else {
            return StringUtils.EMPTY;
        }
    }


    public void setButtonText(String buttonText) {

        this.buttonText = buttonText;
    }


    public String getTargetLink() {

        String link = targetLink;
        if (link != null && !link.isEmpty())
        {

            String finalLink = dhlUtil.getUrl(link);
            return finalLink;
        }
        else
        {
            return StringUtils.EMPTY;
        }

    }


    public void setTargetLink(String targetLink) {

        this.targetLink = targetLink;
    }

    public ArrayList<Map<String, String>> getCategorieList() {

        return categorieList;
    }


    public void setCategorieList(ArrayList<Map<String, String>> categorieList) {

        this.categorieList = categorieList;
    }


    public String[] getCategories() {

        return categories;
    }

    public void setCategories(String[] categories) {

        this.categories = categories;
    }


    @PostConstruct
    protected void init() throws Exception {

        /* This logic is to map the categories multifield to return the Json */
        categorieList = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(categories);

    }

}
