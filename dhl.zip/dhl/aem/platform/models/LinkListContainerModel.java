package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author gankashy
 *         This Model reads values of multifield and returns the values to the helper
 */
@Model(adaptables = Resource.class)
public class LinkListContainerModel {

    private static final Logger log = LoggerFactory.getLogger(LinkListContainerModel.class);
    @Inject
    private String[] buttonlist;

    private ArrayList<Map<String, String>> buttons;

    DHLUtil dhlUtil = new DHLUtil();

    public String[] getButtonlist() {

        return buttonlist;
    }


    public void setButtonlist(String[] buttonlist) {

        this.buttonlist = buttonlist;
    }

    // returns the arraylist of HashMap type.
    public ArrayList<HashMap<String, String>> getButtons() {
        
        Collections.reverse(buttons);
        if (buttons != null) {
            return dhlUtil.getMultifieldPaths(buttons, "buttonLink");
        }
        return null;

    }

    public void setButtons(ArrayList<Map<String, String>> buttons) {

        this.buttons = buttons;
    }


    @PostConstruct
    protected void init() throws Exception {


        buttons = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(buttonlist);
    }

}
