package com.dhl.aem.platform.models;

import java.util.ArrayList;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author Ajay
 *
 *         Model class for Link List Navigation footer
 * 
 * 
 *
 */
@Model(adaptables = Resource.class)
public class LinkListNavFooterModel {

     

    @Inject
    @Optional
    private String headLine;


    @Inject
    private String[] linkListConfig;


    @Inject
    private String link;


    @Inject
    private String linkText;

    @Inject
    private boolean enableAccordion;


    private ArrayList<LinkListNavFooterModel> navLinkList;


    DHLUtil dhlUtil = new DHLUtil();


    public String[] getLinkListConfig() {

        return linkListConfig;
    }


    public void setLinkListConfig(String[] linkListConfig) {

        this.linkListConfig = linkListConfig;
    }


    public boolean isEnableAccordion() {

        return enableAccordion;
    }


    public void setEnableAccordion(boolean enableAccordion) {

        this.enableAccordion = enableAccordion;
    }

    public String getHeadLine() {

        return headLine;
    }

    public void setHeadLine(String headLine) {

        this.headLine = headLine;
    }


    public String getLink() {

        if (link != null && !link.isEmpty()) {
            link = dhlUtil.getUrl(link);
            return link;
        }
        else {
            return StringUtils.EMPTY;
        }
    }

    public void setLink(String link) {

        this.link = link;
    }

    public String getLinkText() {

        return linkText;
    }

    public void setLinkText(String linkText) {

        this.linkText = linkText;
    }


    public ArrayList<LinkListNavFooterModel> getNavLinkList() {

        String[] values = linkListConfig;

        if (values != null) {
            navLinkList = dhlUtil.getMultiFieldsPanelValues(values, LinkListNavFooterModel.class);

        }


        return navLinkList;
    }


    public void setNavLinkList(ArrayList<LinkListNavFooterModel> navLinkList) {

        this.navLinkList = navLinkList;
    }


}
