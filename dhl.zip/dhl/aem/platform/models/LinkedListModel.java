package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author gankashy
 *         This Model reads multifield values from the dialog and retuns it to helper..
 */
@Model(adaptables = Resource.class)
public class LinkedListModel {

    private static final Logger log = LoggerFactory.getLogger(LinkedListModel.class);
    @Inject
    private String[] linkedAccordian;
    DHLUtil dhlUtil = new DHLUtil();
    private ArrayList<Map<String, String>> linkedAccordianList;

    public ArrayList<HashMap<String, String>> getLinkedAccordianList() {

        if (linkedAccordianList != null)
        {
            return dhlUtil.getMultifieldPaths(linkedAccordianList, "link");
        }
        return null;
    }

    public void setLinkedAccordianList(ArrayList<Map<String, String>> linkedAccordianList) {

        this.linkedAccordianList = linkedAccordianList;
    }


    @PostConstruct
    protected void init() throws Exception {


        linkedAccordianList = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(linkedAccordian);
    }


}
