package com.dhl.aem.platform.models;

import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

/**
 * @author gankashy This helper reads values from the dialog and returns to
 *         corresponding helper class.
 */
@Model(adaptables = Resource.class)
public class LinkedTeaserModel {

	@Inject
	@Optional
	private String imageSrc;
	@Inject @Optional
	private String altText;
	@Inject
	private String headLine;
	
	@Inject @Optional
	private String rteLight;

	
    public String getRteLight() {
    if(rteLight!=null){
    	rteLight=rteLight.replaceAll("<p>", "<p class=\"has-rte\">");
    }
        return rteLight;
    }

    
    public void setRteLight(String rteLight) {
    
        this.rteLight = rteLight;
    }

    private Map<String, String> renditionList;

	public Map<String, String> getRenditionList() {

		return renditionList;
	}

	public void setRenditionList(Map<String, String> renditionList) {

		this.renditionList = renditionList;
	}

	public String getImageSrc() {

		return imageSrc;
	}

	public void setImageSrc(String imageSrc) {

		this.imageSrc = imageSrc;
	}

	public String getHeadLine() {

		return headLine;
	}

	public void setHeadLine(String headLine) {

		this.headLine = headLine;
	}


	public String getAltText() {

		return altText;
	}

	public void setAltText(String altText) {

		this.altText = altText;
	}

}
