package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;


/**
 * The Linklist date title Model program reads the values from the component resource and services,returns it to the
 * helper.
 * 
 *
 * @author Kashyap Pudipeddi
 * @since 2015-07-09
 */
@Model(adaptables = Resource.class)
public class LinklistDateTitleModel {


    @Inject
    String headLine;
    @Inject
    String copy;
    @Inject
    String buttonText;
    @Inject
    String buttonLink;
    @Inject
    @Optional
    String icon;


    public String getHeadLine() {

        return headLine;
    }


    public void setHeadLine(String headLine) {

        this.headLine = headLine;
    }


    public String getCopy() {

        return copy;
    }


    public void setCopy(String copy) {

        this.copy = copy;
    }


    public String getButtonText() {

        return buttonText;
    }


    public void setButtonText(String buttonText) {

        this.buttonText = buttonText;
    }


    public String getButtonLink() {

        return buttonLink;
    }


    public void setButtonLink(String buttonLink) {

        this.buttonLink = buttonLink;
    }


    public String getIcon() {

        return icon;
    }


    public void setIcon(String icon) {

        this.icon = icon;
    }


    private Map<String, String> pageContentMap;

    private ArrayList<String> keyList;

    private Map<String, String> pageUrlMap;


    public Map<String, String> getPageUrlMap() {

        return pageUrlMap;
    }


    public void setPageUrlMap(Map<String, String> pageUrlMap) {

        this.pageUrlMap = pageUrlMap;
    }


    public ArrayList<String> getKeyList() {

        return keyList;
    }


    public void setKeyList(ArrayList<String> keyList) {

        this.keyList = keyList;
    }


    public Map<String, String> getPageContentMap() {

        return pageContentMap;
    }


    public void setPageContentMap(Map<String, String> pageContentMap) {

        this.pageContentMap = pageContentMap;
    }


    @PostConstruct
    protected void init() throws Exception {

    }

}
