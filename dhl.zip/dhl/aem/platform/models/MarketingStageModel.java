package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.dhl.aem.platform.utils.DHLUtil;

/**
 * The Marketing Stage Model program reads the value widget CTA and returns the value.
 * 
 *
 * @author Kashyap Pudipeddi
 * @since 2015-06-12
 */
@Model(adaptables = Resource.class)
public class MarketingStageModel {

    @Inject
    @Optional
    private String[] heroConfig;

    private String imageSrc;
    private String targetPage;
    private String overLine;
    private String headLine;
    private String altText;
    private String buttontext;
    private String newTab;

    public String getButtontext() {

        return buttontext;
    }


    public void setButtontext(String buttontext) {

        this.buttontext = buttontext;
    }


    private ArrayList<MarketingStageModel> links;
    private Map<String, String> renditionList;


    // returns the Image
    public String getImageSrc() {

        return imageSrc;
    }


    public void setImageSrc(String imageSrc) {

        this.imageSrc = imageSrc;
    }


    //returns the OverLine Text
    public String getOverLine() {

        return overLine;
    }


    public void setOverLine(String overLine) {

        this.overLine = overLine;
    }


    //returns the Headline Text
    public String getHeadLine() {

        return headLine;
    }


    public void setHeadLine(String headLine) {

        this.headLine = "headLine";
    }


    //returns the Page Path after checking for Internal or external URL
    public String getTargetPage() {

        DHLUtil dhl = new DHLUtil();
        String path1 = "";
        if (targetPage != null && !targetPage.isEmpty())
        {
            path1 = dhl.getUrl(targetPage);
        }
        return path1;
    }


    public void setTargetPage(String targetPage) {

        this.targetPage = targetPage;
    }


    //returns the Alt Text of the Image
    public String getAltText() {

        return altText;
    }


    public void setAltText(String altText) {

        this.altText = altText;
    }

    //Returns the Multifield Value of all the above mentioned 
    public ArrayList<MarketingStageModel> getLinks() {

        String[] values = heroConfig;
        DHLUtil dhlUtil = new DHLUtil();
        if (values != null)
        {
            links = dhlUtil.getMultiFieldsPanelValues(values, MarketingStageModel.class);
        }
        return links;
    }


    public Map<String, String> getRenditionList() {

        return renditionList;
    }


    //returns the rendition of the Images
    public void setRenditionList(Map<String, String> renditionList) {

        this.renditionList = renditionList;
    }

    
    
    public String getNewTab() {
		return newTab;
	}


	public void setNewTab(String newTab) {
		this.newTab = newTab;
	}


	@PostConstruct
    protected void init() throws Exception {

    }

}
