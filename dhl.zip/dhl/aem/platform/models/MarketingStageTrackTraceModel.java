package com.dhl.aem.platform.models;
import java.util.ArrayList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.dhl.aem.platform.utils.DHLUtil;

   
    /**
     * @author shiabhis
     * 
     *This Model is for Marketing Track & Trace Component
     *It takes all the input fields from Author and after processing business logic returns as an object
     *
     */
    @Model (adaptables=Resource.class)
    public class MarketingStageTrackTraceModel {

        
        public void setTrackShipmentType1(String[] trackShipmentType1) {
        
            this.trackShipmentType1 = trackShipmentType1;
        }




        
        public void setTrackShipmentType2(String[] trackShipmentType2) {
        
            this.trackShipmentType2 = trackShipmentType2;
        }


        /**
         * Input fields getting mapped from Component dialogs through Injection
         */
        @Inject 
        private String[]  trackShipmentType1;
        @Inject 
        private String[]  trackShipmentType2;
        @Inject 
        private String faqLinkPath1;
        @Inject 
        private String faqLinkPath2;
        @Inject 
        private String faqLinkPath;
        
        public ArrayList<Map<String, String>> getShipmentList1() {
        
            return shipmentList1;
        }



        
        public void setShipmentList1(ArrayList<Map<String, String>> shipmentList1) {
        
            this.shipmentList1 = shipmentList1;
        }


        
        public ArrayList<Map<String, String>> getShipmentList2() {
        
            return shipmentList2;
        }





        
        public void setShipmentList2(ArrayList<Map<String, String>> shipmentList2) {
        
            this.shipmentList2 = shipmentList2;
        }


        DHLUtil dhlUtil=new DHLUtil();

        private ArrayList<Map<String, String>> shipmentList1;
        private ArrayList<Map<String, String>> shipmentList2;
        


        
        public String getFaqLinkPath1() {
        
            String link = faqLinkPath1;
            if (link != null && !link.isEmpty())
            {

                String finalLink = dhlUtil.getUrl(link);
                return finalLink;
            }
            else
            {
                return StringUtils.EMPTY;
            }

        }


        
        public void setFaqLinkPath1(String faqLinkPath1) {
        
            this.faqLinkPath1 = faqLinkPath1;
        }


        
        public String getFaqLinkPath2() {
        

            String link = faqLinkPath2;
            if (link != null && !link.isEmpty())
            {

                String finalLink = dhlUtil.getUrl(link);
                return finalLink;
            }
            else
            {
                return StringUtils.EMPTY;
            }        }


        
        public void setFaqLinkPath2(String faqLinkPath2) {
        
            this.faqLinkPath2 = faqLinkPath2;
        }


        
        public String getFaqLinkPath() {
        

            String link = faqLinkPath;
            if (link != null && !link.isEmpty())
            {

                String finalLink = dhlUtil.getUrl(link);
                return finalLink;
            }
            else
            {
                return StringUtils.EMPTY;
            }        }


        
        public void setFaqLinkPath(String faqLinkPath) {
        
            this.faqLinkPath = faqLinkPath;
        }


        @PostConstruct
        protected void init() throws Exception {
            shipmentList1 = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(trackShipmentType1);
            shipmentList2 = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(trackShipmentType2);
        }
        
    }

