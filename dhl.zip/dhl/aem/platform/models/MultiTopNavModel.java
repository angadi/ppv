package com.dhl.aem.platform.models;

import java.util.*;
import org.apache.sling.api.resource.*;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.dhl.aem.platform.utils.DHLUtil;

import javax.annotation.PostConstruct;
import javax.inject.*;

@Model(adaptables = Resource.class)
public class MultiTopNavModel {

    @Inject
    @Optional
    private String[] primarynav;

    @Inject
    @Optional
    private ResourceResolver resourceResolver;

    private ArrayList<MultiTopNavModel> menuItems;

    private String[] paths;

    private String menuTitle;

    private String menuLink;

    private ArrayList<MultiTopNavModel> meganav;

    private String subMenuPath;

    private ArrayList<MultiTopNavModel> subMenuList;

    private ArrayList<MultiTopNavModel> extralink;

    public String[] getPaths() {

        return paths;
    }

    public void setPaths(String[] paths) {

        this.paths = paths;
    }

    public String getMenuTitle() {

        return menuTitle;
    }

    public void setMenuTitle(String menuTitle) {

        this.menuTitle = menuTitle;
    }

    public String getMenuLink() {

        return menuLink;
    }

    public void setMenuLink(String menuLink) {

        this.menuLink = menuLink;
    }

    public ArrayList<MultiTopNavModel> getMeganav() {

        return meganav;
    }

    public void setMeganav(ArrayList<MultiTopNavModel> meganav) {

        this.meganav = meganav;
    }

    public String getSubMenuPath() {

        return subMenuPath;
    }

    public void setSubMenuPath(String subMenuPath) {

        this.subMenuPath = subMenuPath;
    }

    public ArrayList<MultiTopNavModel> getSubMenuList() {

        return subMenuList;
    }

    public void setSubMenuList(ArrayList<MultiTopNavModel> subMenuList) {

        this.subMenuList = subMenuList;
    }

    public ArrayList<MultiTopNavModel> getExtralink() {

        return extralink;
    }

    public void setExtralink(ArrayList<MultiTopNavModel> extralink) {

        this.extralink = extralink;
    }

    public ArrayList<MultiTopNavModel> getMenuItems() {

        String[] values = primarynav;
        DHLUtil dhlUtil = new DHLUtil();
        menuItems = dhlUtil.getTopNavMultiFieldPanelValues(resourceResolver, values);
        return menuItems;
    }

    public void setMenuItems(ArrayList<MultiTopNavModel> menuItems) {

        this.menuItems = menuItems;
    }

    @PostConstruct
    protected void init() throws Exception {

    }

}
