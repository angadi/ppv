package com.dhl.aem.platform.models;

import java.util.ArrayList;

import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;

import org.apache.sling.models.annotations.Model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.utils.DHLUtil;

/**
 * @author gankashy This Model reads values from dialog and returns the values to
 *         the helper
 */
@Model(adaptables = Resource.class)
public class NavigationHeaderModel {

	private static final Logger log = LoggerFactory
			.getLogger(NavigationHeaderModel.class);

	@Inject
	private String[] metanavconfig;
	@Inject
	private String metanavtext;

	private String targetLink;

	private ArrayList<NavigationHeaderModel> navigationList;

	Map<String, String> renditionList;

	DHLUtil dhl = new DHLUtil();

	public String[] getMetanavconfig() {
		return metanavconfig;
	}

	public void setMetanavconfig(String[] metanavconfig) {
		this.metanavconfig = metanavconfig;
	}

	public String getMetanavtext() {
		return metanavtext;
	}

	public void setMetanavtext(String metanavtext) {
		this.metanavtext = metanavtext;
	}

	public String getTargetLink() {
		return targetLink;
	}

	public void setTargetLink(String targetLink) {
		this.targetLink = targetLink;
	}

	public ArrayList<NavigationHeaderModel> getNavigationList() {

		String[] values = metanavconfig;

		if (values != null) {
			navigationList = dhl.getMultiFieldsPanelValues(values,
					NavigationHeaderModel.class);
			log.info("in get logo size" + navigationList.size());
		}
		return navigationList;
	}

	public void setNavigationList(
			ArrayList<NavigationHeaderModel> navigationList) {

		this.navigationList = navigationList;
	}

	public Map<String, String> getRenditionList() {

		return renditionList;
	}

	public void setRenditionList(Map<String, String> renditionList) {

		this.renditionList = renditionList;
	}

}
