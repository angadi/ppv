package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author gankashy
 *         This component reads the value of button Text,Path field and color combination and sends the response to
 *         helper class.
 */
@Model(adaptables = Resource.class)
public class SelectBoxModel {

    @Inject
    String[] selectBox;

    private ArrayList<Map<String, String>> selectOptionsList;

    @PostConstruct
    protected void init() throws Exception {

        DHLUtil dhlUtil = new DHLUtil();
        selectOptionsList = (ArrayList<Map<String, String>>) dhlUtil.getMultiFieldPanelValuesMap(selectBox);
    }


    public ArrayList<Map<String, String>> getSelectOptionsList() {

        return selectOptionsList;
    }


    public void setSelectOptionsList(ArrayList<Map<String, String>> selectOptionsList) {

        this.selectOptionsList = selectOptionsList;
    }

}
