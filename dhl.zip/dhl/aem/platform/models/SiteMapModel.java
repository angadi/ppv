package com.dhl.aem.platform.models;

public class SiteMapModel{

    /** The path. is String - Test comment */
    private String path;

    /** The title. */
    private String title;

    /** The level. */
    private int level;

   

    /**
     * Instantiates a new link vo.
     * 
     * @param path
     *            the path
     * @param title
     *            the title
     * @param level
     *            the level
     * @param navigationTitle
     *            the navigation title
     */
    public  SiteMapModel(String path, String title, int level) {
        this.path = path;
        this.title = title;
        this.level = level;
       
    }

    /**
     * Gets the path.
     * 
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * Gets the level.
     * 
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * Gets the title.
     * 
     * @return the title
     */
    public String getTitle() {
        return title;
    }

  
  
}

