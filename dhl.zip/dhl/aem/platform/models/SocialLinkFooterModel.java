package com.dhl.aem.platform.models;

import java.util.ArrayList;
import java.util.Map;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import com.dhl.aem.platform.utils.DHLUtil;


/**
 * @author Ajay
 *
 *         Model class for Social Links Navigation footer
 *        
 *        
 *
 */
@Model(adaptables = Resource.class)
public class SocialLinkFooterModel {

   // enable for logging
   // private static final Logger log = LoggerFactory.getLogger(SocialLinkFooterModel.class);
    
    @Inject
    private String[] linkConfig;
    
    @Inject
    @Optional
    private String imageSrc;

   
    @Inject
    @Optional
    private String altText;


    @Inject
    @Optional
    private String link;
    
    private String page;

  


    Map<String, String> renditionList;

    
    private ArrayList<SocialLinkFooterModel> socialLinkList;

    DHLUtil dhl = new DHLUtil();

    

    public Map<String, String> getRenditionList() {

        return renditionList;
    }


    public void setRenditionList(Map<String, String> renditionList) {

        this.renditionList = renditionList;
    }



    
    public String getImageSrc() {
    
        return imageSrc;
    }


    
    public void setImageSrc(String imageSrc) {
    
        this.imageSrc = imageSrc;
    }
    
    

    public String getAltText() {

        return altText;
    }


    public void setAltText(String altText) {

        this.altText = altText;
    }


    public String[] getLinkConfig() {

        return linkConfig;
    }


    public void setLinkConfig(String[] linkConfig) {

        this.linkConfig = linkConfig;
    }

    
    
    public String getPage() {
    
        return page;
    }


    
    public void setPage(String page) {
    
        this.page = page;
    }
    

    public String getLink() {

        if (link != null && !link.isEmpty()) {
            link = dhl.getUrl(link);
            return link;
        }
        else {
            return StringUtils.EMPTY;
        }

    }


    public void setLink(String link) {

        this.link = link;
    }


    public ArrayList<SocialLinkFooterModel> getSocialLinkList() {

        String[] values = linkConfig;

        if (values != null) {
            socialLinkList = dhl.getMultiFieldsPanelValues(values, SocialLinkFooterModel.class);

        }
        return socialLinkList;
    }


    public void setSocialLinkList(ArrayList<SocialLinkFooterModel> socialLinkList) {

        this.socialLinkList = socialLinkList;
    }


}
