package com.dhl.aem.platform.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.felix.scr.annotations.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhl.aem.platform.exception.SendMailException;
import com.dhl.aem.platform.services.SendEmailFormService;

@Service(value = Servlet.class)
@Component(immediate = true)
@Properties({
	@Property(name = "sling.servlet.paths", value = "/bin/sendEmail"),
	@Property(name = "service.description", value = "Servlet To Send The Generic Email"),
	@Property(name = "label", value = "GenericEmailServlet ") })
public class SendMailServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final long emptyStream = 0L;

	@Reference
	private SendEmailFormService sendEmailFormService;

	private static final Logger log = LoggerFactory
			.getLogger(SendMailServlet.class);

	protected void doPost(final SlingHttpServletRequest request,
			final SlingHttpServletResponse response) throws IOException,
			ServletException {

		File uploadedFile = null;
		String fileName = null;



		try

		{

			String redirectUrl = request.getAttribute("redirect").toString() + ".html" + "?q=1";



			String hidden = request.getParameter("dhlHidden");

			if (!hidden.isEmpty()) {

				response.sendError(403, "Site is hacked by a bot");
			}

			Map<String, String> requestMap = sendEmailFormService.getParametersMap(request);

			Map<String, String> errorMap = sendEmailFormService.validate(requestMap);

			if(errorMap.size()!=0){
				String currentPagePath = request.getAttribute("currentPagePath").toString() + ".html";


				HttpSession session = request.getSession();


				session.setAttribute("errorMap",errorMap);
				response.sendRedirect(currentPagePath);


			}
			else {
				requestMap = sendEmailFormService.xssCheckFilter(requestMap);
				Enumeration requestParameter = request.getParameterNames();

				while (requestParameter.hasMoreElements()) {
					String element = (String) requestParameter.nextElement();
					boolean formField = request.getRequestParameter(element).isFormField();
					if (!formField) {


						if(request.getRequestParameter(element).getSize()!=emptyStream) {


							if(request.getRequestParameter(element).getSize()<=10485760 && !FilenameUtils.getExtension(request.getRequestParameter(element).getFileName()).equals("exe"))

							{

								InputStream stream = request.getRequestParameter(element).getInputStream();
								uploadedFile = sendEmailFormService.stream2file(stream);
								fileName = request.getRequestParameter(element).getFileName();


							}

						}
					}
				}


				String emailBody = sendEmailFormService.getEmailBody(request,requestMap);

				String htmlEmailBody = sendEmailFormService.emailConstruct(emailBody);

				if (uploadedFile != null) {

					sendEmailFormService.sendEmailWithAttachment(htmlEmailBody,request, uploadedFile,fileName);

				}

				else {

					sendEmailFormService.sendMail(htmlEmailBody, request);
				}
				HttpSession session = request.getSession();


				session.setAttribute("requestMap",requestMap);


				response.sendRedirect(redirectUrl);
			}
		}

		catch(SendMailException sendMailException) {
			String errorRedirect = request.getAttribute("errorRedirect").toString() + ".html";
			log.error(sendMailException.getMessage(), sendMailException); 
			response.sendRedirect(errorRedirect);
		}

		catch(Exception e){
			String errorRedirect = request.getAttribute("errorRedirect").toString() + ".html";
			log.error(e.getMessage(),e); 
			response.sendRedirect(errorRedirect);
		}
	}
}