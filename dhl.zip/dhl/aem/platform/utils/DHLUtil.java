package com.dhl.aem.platform.utils;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Session;

import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.Primitives;
import com.adobe.cq.sightly.WCMUse;
import com.dhl.aem.platform.models.MultiTopNavModel;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.SlingHttpServletRequest;

import com.dhl.aem.platform.constants.DHLConstants;
import com.dhl.aem.platform.exception.DHLException;
import com.day.cq.wcm.api.AuthoringUIMode;
import com.adobe.granite.asset.api.Asset;
import com.adobe.granite.asset.api.AssetManager;
import com.dhl.aem.platform.services.GlobalSettingService;
import com.dhl.aem.platform.services.RenditionService;

public class DHLUtil extends WCMUse {

    static Logger log = LoggerFactory.getLogger(DHLUtil.class);
    private String url;
    private String port;
    private String currentMode;
    private boolean isTouch = false;
    private boolean isClassic = false;
    private static final String damPath = "/content/dam";
    private static final String hyperText = "http";
    private static final String securedHyperText = "http";
    private static final String dotHtml = ".html";
    private static final String contentPath = "/content";
    private Map<String,String> openGraphIds;
    
    /**
     * @return the port
     */
    public String getPort() {

        return port;
    }

    /**
     * @param port
     *        the port to set
     */
    public void setPort(String port) {

        this.port = port;
    }

    public String getUrl(String path) {

        if (path == null || path.equals("")) {
            return "";
        }
        else if (path.startsWith(securedHyperText) || path.startsWith(hyperText)
                || path.startsWith(damPath)) {
            return path;
        }
        else if (path.startsWith(contentPath)
                && path.indexOf(dotHtml) == -1) {
            return path + dotHtml;
        }
        else {
            return path;
        }
    }

    /*
     * public void setUrl(String url) {
     * this.url = url;
     * }
     */

    public String getCompleteUrl() {

        if (this.port == null || this.port.equals("") || this.port.equals("80")) {
            return this.url;
        }
        else {
            return this.url + ":" + this.port;
        }
    }

    public String getCurrentMode() {

        return currentMode;
    }

    public void setCurrentMode(String currentMode) {

        this.currentMode = currentMode;
    }

    public boolean isTouch() {

        if (this.currentMode.equals("TOUCH")) {
            return true;
        }
        else {
            return false;
        }
    }

    public void setTouch(boolean isTouch) {

        this.isTouch = isTouch;
    }

    public boolean isClassic() {

        if (this.currentMode.equals("CLASSIC")) {
            return true;
        }
        else {
            return false;
        }
    }

    public void setClassic(boolean isClassic) {

        this.isClassic = isClassic;
    }

    @Override
    public void activate() throws Exception {

        log.info("DHLUtil activate Method started");
        url = get("url", String.class);
        port = get("port", String.class);
        AuthoringUIMode mode = AuthoringUIMode.fromRequest(getRequest());
       // currentMode = mode.name();
        openGraphIds=getOpenGraphIds();
        log.info("DHLUtil activate Method Ended");
    }

    public List<Map<String, String>> getMultiFieldPanelValuesMap(String[] items) {

        List<Map<String, String>> results = new ArrayList<Map<String, String>>();
        if (items != null) {
            String[] values = items;
            for (String value : values) {
                try {
                    value = value.replace("[\"", "[").replace("\"]", "]").replace("\\n", "").replace("}\"", "}")
                            .replace("\"{", "{");

                    value = value.replace("\\", "");
                    JSONObject parsed = new JSONObject(value);
                    if (parsed != null) {
                        Map<String, String> columnMap = new HashMap<String, String>();
                        for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
                            String key = iter.next();
                            String innerValue = parsed.getString(key);
                            columnMap.put(key, innerValue);
                        }

                        results.add(columnMap);
                    }
                }
                catch (JSONException e) {

                }
            }
        }

        for (Map<String, String> mp : results) {

            for (Map.Entry<String, String> entry : mp.entrySet())
            {
                log.info("the map values are ======" + entry.getKey() + "/" + entry.getValue());
            }
        }

        return results;
    }


    public <T> ArrayList<T> getMultiFieldsPanelValues(String[] items, Class<T> classOfT) {

        ArrayList<T> results = new ArrayList<T>();
        if (items != null) {
            String[] values = items;
            for (String value : values) {
                try {
                    Object item = new Object();
                    Gson gson = new GsonBuilder().create();
                    item = gson.fromJson(value, classOfT);
                    results.add(Primitives.wrap(classOfT).cast(item));

                }
                catch (Exception e) {
                    log.trace("[DHLUtil]:getMultiFieldsPanelValues exception", e.getCause());
                    log.error("[DHLUtil]:getMultiFieldsPanelValues exception", e.getMessage());
                }

            }
        }
        return results;
    }

    public <T> ArrayList<T> getMultiFieldPanelValues(String[] items, Class<T> classOfT) {

        ArrayList<T> results = new ArrayList<T>();
        if (items != null) {
            String[] values = items;
            for (String value : values) {
                String ss = value.replace("[\"", "[").replace("\"]", "]").replace("\\", "").replace("}\"", "}")
                        .replace("\"{", "{");
                try {
                    Object item = new Object();
                    Gson gson = new GsonBuilder().create();
                    item = gson.fromJson(ss, classOfT);
                    results.add(Primitives.wrap(classOfT).cast(item));
                }
                catch (Exception e) {
                    log.error("[DHLUtil]:getMultiFieldPanelValues exception", e.getMessage());
                }

            }
        }
        log.info("[DHLUtil]:getMultiFieldPanelValues: Output Items :" + results);
        return results;
    }


    public ArrayList<MultiTopNavModel> getTopNavMultiFieldPanelValues(
            ResourceResolver resourceResolver, String[] paths) {

        log.info("DHLUtil started");
        ArrayList<MultiTopNavModel> menus = new ArrayList<MultiTopNavModel>();
        log.info("DHLUtil entered");
        if (paths != null) {
            String[] values = paths;
            for (String value : values) {
                String ss = value.replace("[\"", "[").replace("\"]", "]")
                        .replace("\\", "").replace("}\"", "}")
                        .replace("\"{", "{");
                try {
                    MultiTopNavModel menu = new MultiTopNavModel();
                    JSONObject parsed = new JSONObject(ss);
                    Gson gson = new GsonBuilder().create();
                    menu = gson.fromJson(ss, MultiTopNavModel.class);
                    if (menu.getMeganav() != null
                            && menu.getMeganav().size() > 0) {
                        Iterator<MultiTopNavModel> subMenuIterator = menu
                                .getMeganav().iterator();
                        while (subMenuIterator.hasNext()) {
                            MultiTopNavModel menu1 = subMenuIterator.next();
                            if (menu1.getSubMenuPath() != null
                                    && !menu1.getSubMenuPath()
                                    .equalsIgnoreCase("")) {
                                Resource rootRes = resourceResolver
                                        .getResource(
                                                menu1.getSubMenuPath());
                                Page rootPage = rootRes == null ? null
                                        : rootRes.adaptTo(Page.class);
                                if (rootPage != null) {
                                    Iterator<Page> children = rootPage
                                            .listChildren(new PageFilter());
                                    ArrayList<MultiTopNavModel> subMenuList = new ArrayList<MultiTopNavModel>();
                                    while (children.hasNext()) {
                                        MultiTopNavModel subMenu = new MultiTopNavModel();
                                        Page child = children.next();
                                        if (!child.isHideInNav()) {
                                            subMenu.setMenuTitle(child
                                                    .getTitle());
                                            subMenu.setMenuLink(child.getPath()
                                                    + dotHtml);
                                            subMenuList.add(subMenu);
                                        }
                                    }
                                    menu1.setSubMenuList(subMenuList);
                                }
                            }
                        }
                    }
                    menus.add(menu);
                }
                catch (JSONException e) {
                    throw new DHLException(
                            "There was an issue creating ArrayList from the JSON data: "
                                    + paths[0], e);
                }
            }
        }
        log.info("DHLUtil Ended");
        return menus;
    }


    /**
     * Converts the date from String to dateformat
     */

    public static Date getParsedDate(String date) throws ParseException {

        SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");
        Date parsedDate = null;

        parsedDate = formatter.parse(date);


        return parsedDate;
    }


    /**
     * Returns the datelist in descending order
     */

    public static ArrayList<Date> compareDate(ArrayList<Date> dateList) {

        Collections.sort(dateList, new Comparator<Date>() {

            @Override
            public int compare(Date o1, Date o2) {

                return o1.compareTo(o2);
            }
        });
        Collections.reverse(dateList);

        // TODO Auto-generated method stub
        return dateList;
    }


    /**
     * Returns the formatted datelist
     */

    public static ArrayList<String> getFormattedDate(ArrayList<Date> sortedDateList) {

        ArrayList<String> formattedDateList = new ArrayList<String>();
        SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");

        for (Date sortedDate : sortedDateList) {
            String lastDate = formatter.format(sortedDate);
            formattedDateList.add(lastDate);


        }

        return formattedDateList;
    }


    /* Method to generate renditions */
    public static Map<String, String> getRenditionList(String assetPath, Resource rs) {

        log.info("DHLUtil getRenditionList() initiated");
        String renditionType;
        AssetManager assetManager;
        Asset asset;
        BundleContext bundleContext = FrameworkUtil.getBundle(RenditionService.class).getBundleContext();
        ServiceReference factoryRef = bundleContext.getServiceReference(RenditionService.class.getName());
        RenditionService renditionService = (RenditionService) bundleContext.getService(factoryRef);
        Map<String, String> renditionMap = renditionService.getRenditionConfig();

        Map<String, String> renditionList = new HashMap<String, String>();
        try {

            assetManager = rs.getResourceResolver().adaptTo(AssetManager.class);
            asset = assetManager.getAsset(assetPath);
            log.info("asset name" + asset.getName());
            Iterator<? extends com.adobe.granite.asset.api.Rendition> it = asset.listRenditions();
            while (it.hasNext()) {
                renditionType = it.next().getPath().toString();

                for (Entry<String, String> entry : renditionMap.entrySet()) {
                    if (renditionType.contains(entry.getValue())) {
                        log.info("renditionType" + renditionType);
                        log.info("customeRenditionPath" + getCustomRenditionPath(asset.getName(), renditionType));
                        log.info("Util KEY Value -------::" + entry.getKey() + "value" + entry.getValue());
                        renditionList.put(entry.getKey(), getCustomRenditionPath(asset.getName(), renditionType));
                    }
                }

            }

        }
        catch (DHLException dhe) {
            dhe.printStackTrace();
        }
        catch (Exception dhe) {
            dhe.printStackTrace();
        }
        return renditionList;

    }

    public static String getCustomRenditionPath(String assetName, String renditionPath) {

        log.info("inside getCustomRenditionPath  ");
        String replacePath = renditionPath.substring(renditionPath.indexOf(assetName));
        log.info("renditionPath" + renditionPath);
        log.info("replacePath" + replacePath);
        String[] fileDetails = assetName.split("\\.");
        String ImageFileName = fileDetails[0];
        String ImageExt = fileDetails[1];
        String renditionName = replacePath.substring(replacePath.lastIndexOf("/")).replace("/", "");
        String renditionDetails[] = renditionName.split("\\.");
        String renditionSize = renditionDetails[2] + "." + renditionDetails[3];
        log.info("renditionSize" + renditionSize);
        String customRenditionName = ImageFileName + ".web." + renditionSize + "." + ImageExt;
        String customRenditionPath = renditionPath.replace(replacePath, customRenditionName);

        log.info("customRenditionPath" + customRenditionPath);
        return customRenditionPath;
    }

    /* This method is for the conversion of strings to lais of map(multifield inside multifield) */
    public static ArrayList<Map<String, String>> getMultiLinkJsonData(String value) {

        log.info("inside getMultiLinkJsonData  " + value);
        value = value.replace("[", "").replace("]", "").replace("},", "}~@#!");
        ArrayList<Map<String, String>> results = new ArrayList<Map<String, String>>();
        String strvalue[] = value.split("~@#!");
        try {
            for (String strJson : strvalue) {
                JSONObject parsed = new JSONObject(strJson);
                if (parsed != null) {
                    Map<String, String> columnMap = new HashMap<String, String>();
                    for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
                        String key = iter.next();
                        String innerValue = parsed.getString(key);
                        columnMap.put(key, innerValue);
                    }
                    results.add(columnMap);
                }

            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        return results;
    }


    public Map<String, String> getAlertMessage(String[] values) {

        Map<String, String> activeMap = null;
        try {
            DHLUtil util = new DHLUtil();
            List<Map<String, String>> list = util.getMultiFieldPanelValuesMap(values);

            Iterator<Map<String, String>> it = list.iterator();

            while (it.hasNext()) {
                Map<String, String> mp = it.next();
                for (Entry<String, String> entry : mp.entrySet()) {
                    if (entry.getKey().toString().equals("isActive")
                            && entry.getValue().toString().equalsIgnoreCase("true")) {
                        activeMap = mp;


                        log.info("MSG KEY Value -------::KEY->" + entry.getKey() + ":value->" + entry.getValue());
                    }


                }
            }


        }
        catch (Exception e) {
            e.printStackTrace();
            log.info("Error occurred", e);
        }

        return activeMap;
    }

    public ArrayList<HashMap<String, String>> getMultifieldPaths(ArrayList<Map<String, String>> linkedList,
            String fieldName)
            {

        HashMap<String, String> map;
        ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();

        for (int a = 0; a < linkedList.size(); a++)
        {
            map = new HashMap<String, String>();
            String hmKey = "";
            String hmData = "";
            Map<String, String> tmpData = (Map<String, String>) linkedList.get(a);
            Set<String> key = tmpData.keySet();
            Iterator it = key.iterator();
            while (it.hasNext()) {
                hmKey = (String) it.next();
                hmData = tmpData.get(hmKey);
                log.info("String is" + hmData);
                if (hmKey.equals(fieldName))
                {
                    hmData = getUrl(hmData);
                    log.info("PathField after update  is" + hmData);
                }
                log.info("Key Value is" + hmKey);
                log.info("The data is" + hmData);
                map.put(hmKey, hmData);

            }

            list.add(map);
        }

        return list;
            }

    /* Method to generate Asset Size and Type Uploaded to DAM and returns list of MAP */

    public static ArrayList<Map<String, String>> getSizeTypeOfAsset(ArrayList<Map<String, String>> downloadList,
            Resource rs) {

        log.info("DHLUtil getSizeTypeOfAsset() initiated ");
        ArrayList<Map<String, String>> localDownloadList = new ArrayList<Map<String, String>>();
        Session session = null;
        Node assetMetaNode;
        try {
            session = rs.getResourceResolver().adaptTo(Session.class);
            Iterator<Map<String, String>> it = downloadList.iterator();
            while (it.hasNext()) {
                Map<String, String> mp = it.next();
                if (mp.get(DHLConstants.ASSET_DOWNLOAD_ITEM).toString().contains(".")) {
                    assetMetaNode = session.getNode((mp.get(DHLConstants.ASSET_DOWNLOAD_ITEM).toString())
                            + DHLConstants.JCR_CONTENT + DHLConstants.METADATA);
                    String assetType = assetMetaNode.getProperty(DHLConstants.ASSET_FORMAT).getString();
                    if(assetType!=null)
                    {
                    if(assetType.contains("vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    {
                    	assetType="xlsx";
                    }
                    if(assetType.contains("vnd.ms-excel"))
                    {
                    	assetType="ms-excel";
                    }
                    	
                    }
                    
                    Property assetSize = assetMetaNode.getProperty(DHLConstants.ASSET_SIZE);
                    double assetSizeUpdated = 0d;
                    DecimalFormat df = new DecimalFormat("0.0");
                    String assetSizeType = DHLConstants.BYTE;
                    ;
                    if (assetSize.getLong() < (1024)) {
                        assetSizeUpdated = (double) assetSize.getLong();
                    }
                    if (assetSize.getLong() > 1024 && assetSize.getLong() < (1024 * 1024)) {
                        assetSizeType = DHLConstants.KILOBYTE;
                        assetSizeUpdated = (double) assetSize.getLong() / 1024L;
                    }
                    if (assetSize.getLong() > (1024 * 1024)) {
                        assetSizeType = DHLConstants.MEGABYTE;
                        assetSizeUpdated = ((double) assetSize.getLong() / (1024 * 1024));
                    }
                    if (assetType.contains("/")) {
                        String strSplit[] = assetType.split("/");
                        assetType = strSplit[1];
                    }

                    String strMetaData = assetType + DHLConstants.SPACE + DHLConstants.LEFT_BRACKET
                            + df.format(assetSizeUpdated) + assetSizeType + DHLConstants.RIGHT_BRACKET;
                    mp.put(DHLConstants.METADATA, strMetaData);
                    localDownloadList.add(mp);
                }
            }
        }
        catch (DHLException dhe) {
            dhe.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        /*
         * finally {
         * if(null!=session && session.isLive()) {
         * session.logout();
         * }
         * }
         */

        return localDownloadList;
    }

    /* Method to get OG ids  */
    public static Map<String, String> getOpenGraphIds() {

        log.info("DHLUtil getOpenGraphIds initiated");
        BundleContext bundleContext = FrameworkUtil.getBundle(GlobalSettingService.class).getBundleContext();
        ServiceReference factoryRef = bundleContext.getServiceReference(GlobalSettingService.class.getName());
        GlobalSettingService globalSettingService = (GlobalSettingService) bundleContext.getService(factoryRef);
        Map<String, String> idMap = globalSettingService.getOpenGraphIds();
         
 
        return idMap;

    }

}
