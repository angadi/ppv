package com.dhl.aem.platform.utils;

/**
 * Environment Mode
 */

public enum Environment {
	LOCAL,DEV,QA,PROD;
}
