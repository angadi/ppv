package com.dhl.aem.platform.utils;


/**
 * 
 * Basic APIs for Site Settings and unified configuration management
 * 
 * 
 * 
 */
public final class PropertiesServiceUtils {

    private PropertiesServiceUtils() {
    }



    /**
     * 
     * @param obj
     * @param defaultValue
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T castToType(final Object obj, final T defaultValue) {
        if (obj != null) {
            if (defaultValue == null) {
                return (T) obj;
            } else {
                if (defaultValue.getClass().isInstance(obj)) {
                    return (T) defaultValue.getClass().cast(obj);
                }
                if (obj instanceof String && defaultValue instanceof Boolean) {
                    return (T) Boolean.valueOf((String) obj);
                }
            }
        }
        return defaultValue;
    }



  
}
