package com.dhl.aem.platform.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


public class Test {

    public static void main(String[] args) {

        // TODO Auto-generated method stub
        
        String s="/content/dam/TEST_A.png/jcr:content/renditions/cq5dam.web.800.392.png";
        int ss=s.lastIndexOf(".");
        System.out.println(s.substring(s.lastIndexOf(".")+1));
        List<String> items = new ArrayList<String>();

        items.add("one");
        items.add("two");
        items.add("three");

        Stream<String> stream = items.stream();
        //stream.
        //.forEach(p -> System.out.println(p));
    }

}
