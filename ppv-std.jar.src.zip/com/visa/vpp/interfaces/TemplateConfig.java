package com.visa.vpp.interfaces;

public abstract interface TemplateConfig
{
  public abstract String[] getAuthorTemplatePaths();
  
  public abstract String[] getApproverTemplatePaths();
  
  public abstract String[] getAdminTemplatePaths();
}


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\interfaces\TemplateConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */