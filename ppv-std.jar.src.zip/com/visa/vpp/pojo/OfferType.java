/*    */ package com.visa.vpp.pojo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OfferType
/*    */ {
/*    */   private String value;
/*    */   
/*    */ 
/*    */   private String key;
/*    */   
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 17 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 21 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 25 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 29 */     this.key = key;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\pojo\OfferType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */