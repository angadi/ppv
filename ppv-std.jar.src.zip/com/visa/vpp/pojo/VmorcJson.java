/*     */ package com.visa.vpp.pojo;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VmorcJson
/*     */ {
/*     */   private List<RedemptionCountry> redemptionCountries;
/*     */   private String language;
/*     */   private String programName;
/*     */   private String promotionToDate;
/*     */   private String eventSubTitle;
/*     */   private List<CardPaymentTypeList> cardPaymentTypeList;
/*  22 */   private List<CardProductList> cardProductList = null;
/*     */   private String offerStatus;
/*     */   private Map<String, String> offerCopy;
/*     */   private Map<String, String> offerShortDescription;
/*     */   private Map<String, String> fAQs;
/*     */   private String offerId;
/*     */   private String offerContentId;
/*     */   private List<ImageList> imageList;
/*     */   private Map<String, String> redemptionTelephone;
/*     */   private String isOfferEvent;
/*     */   private List<OfferType> offerType;
/*     */   private String lastModifiedDatetime;
/*     */   private String offerSourceContact;
/*     */   private String redemptionEmail;
/*     */   private String validityToDate;
/*     */   private List<PromotionChannelList> promotionChannelList;
/*     */   private List<PromotingCountry> promotingCountries;
/*     */   private String offerTitle;
/*     */   private String merchantName;
/*     */   private String redemptionFormatInstructions;
/*     */   private String redemptionCode;
/*     */   private String languageId;
/*     */   private String validityFromDate;
/*     */   private List<CategorySubcategoryList> categorySubcategoryList;
/*     */   private String promotionFromDate;
/*     */   private Map<String, String> visaTerms;
/*     */   private String redemptionUrl;
/*     */   private Map<String, String> merchantTerms;
/*     */   private String featuredOfferIndicator;
/*     */   private List<MerchantList> merchantList;
/*     */   private String programId;
/*     */   
/*     */   public String getOfferId()
/*     */   {
/*  56 */     return this.offerId;
/*     */   }
/*     */   
/*     */   public void setOfferId(String offerId) {
/*  60 */     this.offerId = offerId;
/*     */   }
/*     */   
/*     */   public String getOfferContentId() {
/*  64 */     return this.offerContentId;
/*     */   }
/*     */   
/*     */   public void setOfferContentId(String offerContentId) {
/*  68 */     this.offerContentId = offerContentId;
/*     */   }
/*     */   
/*     */   public String getOfferTitle() {
/*  72 */     return this.offerTitle;
/*     */   }
/*     */   
/*     */   public void setOfferTitle(String offerTitle) {
/*  76 */     this.offerTitle = offerTitle;
/*     */   }
/*     */   
/*     */   public String getMerchant() {
/*  80 */     return this.merchantName;
/*     */   }
/*     */   
/*     */   public void setMerchant(String merchantName) {
/*  84 */     this.merchantName = merchantName;
/*     */   }
/*     */   
/*     */   public String getRedemptionFormatInstructions() {
/*  88 */     return this.redemptionFormatInstructions;
/*     */   }
/*     */   
/*     */   public void setRedemptionFormatInstructions(String redemptionFormatInstructions) {
/*  92 */     this.redemptionFormatInstructions = redemptionFormatInstructions;
/*     */   }
/*     */   
/*     */   public Map<String, String> getOfferShortDescription() {
/*  96 */     return this.offerShortDescription;
/*     */   }
/*     */   
/*     */   public void setOfferShortDescription(Map<String, String> offerShortDescription) {
/* 100 */     this.offerShortDescription = offerShortDescription;
/*     */   }
/*     */   
/*     */   public List<ImageList> getImageList() {
/* 104 */     return this.imageList;
/*     */   }
/*     */   
/*     */   public void setImageList(List<ImageList> imageList) {
/* 108 */     this.imageList = imageList;
/*     */   }
/*     */   
/*     */   public List<RedemptionCountry> getRedemptionCountries() {
/* 112 */     return this.redemptionCountries;
/*     */   }
/*     */   
/*     */   public void setRedemptionCountries(List<RedemptionCountry> redemptionCountries) {
/* 116 */     this.redemptionCountries = redemptionCountries;
/*     */   }
/*     */   
/*     */   public Map<String, String> getOfferCopy() {
/* 120 */     return this.offerCopy;
/*     */   }
/*     */   
/*     */   public void setOfferCopy(Map<String, String> offerCopy) {
/* 124 */     this.offerCopy = offerCopy;
/*     */   }
/*     */   
/*     */   public String getLanguage() {
/* 128 */     return this.language;
/*     */   }
/*     */   
/*     */   public void setLanguage(String language) {
/* 132 */     this.language = language;
/*     */   }
/*     */   
/*     */   public String getProgramName() {
/* 136 */     return this.programName;
/*     */   }
/*     */   
/*     */   public void setProgramName(String programName) {
/* 140 */     this.programName = programName;
/*     */   }
/*     */   
/*     */   public String getPromotionToDate() {
/* 144 */     return this.promotionToDate;
/*     */   }
/*     */   
/*     */   public void setPromotionToDate(String promotionToDate) {
/* 148 */     this.promotionToDate = promotionToDate;
/*     */   }
/*     */   
/*     */   public String getEventSubTitle() {
/* 152 */     return this.eventSubTitle;
/*     */   }
/*     */   
/*     */   public void setEventSubTitle(String eventSubTitle) {
/* 156 */     this.eventSubTitle = eventSubTitle;
/*     */   }
/*     */   
/*     */   public List<CardPaymentTypeList> getCardPaymentTypeList() {
/* 160 */     return this.cardPaymentTypeList;
/*     */   }
/*     */   
/*     */   public void setCardPaymentTypeList(List<CardPaymentTypeList> cardPaymentTypeList) {
/* 164 */     this.cardPaymentTypeList = cardPaymentTypeList;
/*     */   }
/*     */   
/*     */   public String getOfferStatus() {
/* 168 */     return this.offerStatus;
/*     */   }
/*     */   
/*     */   public void setOfferStatus(String offerStatus) {
/* 172 */     this.offerStatus = offerStatus;
/*     */   }
/*     */   
/*     */   public Map<String, String> getfAQs() {
/* 176 */     return this.fAQs;
/*     */   }
/*     */   
/*     */   public void setfAQs(Map<String, String> fAQs) {
/* 180 */     this.fAQs = fAQs;
/*     */   }
/*     */   
/*     */   public Map<String, String> getRedemptionTelephone() {
/* 184 */     return this.redemptionTelephone;
/*     */   }
/*     */   
/*     */   public void setRedemptionTelephone(Map<String, String> redemptionTelephone) {
/* 188 */     this.redemptionTelephone = redemptionTelephone;
/*     */   }
/*     */   
/*     */   public String getIsOfferEvent() {
/* 192 */     return this.isOfferEvent;
/*     */   }
/*     */   
/*     */   public void setIsOfferEvent(String isOfferEvent) {
/* 196 */     this.isOfferEvent = isOfferEvent;
/*     */   }
/*     */   
/*     */   public List<OfferType> getOfferType() {
/* 200 */     return this.offerType;
/*     */   }
/*     */   
/*     */   public void setOfferType(List<OfferType> offerType) {
/* 204 */     this.offerType = offerType;
/*     */   }
/*     */   
/*     */   public String getLastModifiedDatetime() {
/* 208 */     return this.lastModifiedDatetime;
/*     */   }
/*     */   
/*     */   public void setLastModifiedDatetime(String lastModifiedDatetime) {
/* 212 */     this.lastModifiedDatetime = lastModifiedDatetime;
/*     */   }
/*     */   
/*     */   public String getOfferSourceContact() {
/* 216 */     return this.offerSourceContact;
/*     */   }
/*     */   
/*     */   public void setOfferSourceContact(String offerSourceContact) {
/* 220 */     this.offerSourceContact = offerSourceContact;
/*     */   }
/*     */   
/*     */   public String getRedemptionEmail() {
/* 224 */     return this.redemptionEmail;
/*     */   }
/*     */   
/*     */   public void setRedemptionEmail(String redemptionEmail) {
/* 228 */     this.redemptionEmail = redemptionEmail;
/*     */   }
/*     */   
/*     */   public String getValidityToDate() {
/* 232 */     return this.validityToDate;
/*     */   }
/*     */   
/*     */   public void setValidityToDate(String validityToDate) {
/* 236 */     this.validityToDate = validityToDate;
/*     */   }
/*     */   
/*     */   public List<PromotionChannelList> getPromotionChannelList() {
/* 240 */     return this.promotionChannelList;
/*     */   }
/*     */   
/*     */   public void setPromotionChannelList(List<PromotionChannelList> promotionChannelList) {
/* 244 */     this.promotionChannelList = promotionChannelList;
/*     */   }
/*     */   
/*     */   public List<PromotingCountry> getPromotingCountries() {
/* 248 */     return this.promotingCountries;
/*     */   }
/*     */   
/*     */   public void setPromotingCountries(List<PromotingCountry> promotingCountries) {
/* 252 */     this.promotingCountries = promotingCountries;
/*     */   }
/*     */   
/*     */   public String getRedemptionCode() {
/* 256 */     return this.redemptionCode;
/*     */   }
/*     */   
/*     */   public void setRedemptionCode(String redemptionCode) {
/* 260 */     this.redemptionCode = redemptionCode;
/*     */   }
/*     */   
/*     */   public String getLanguageId() {
/* 264 */     return this.languageId;
/*     */   }
/*     */   
/*     */   public void setLanguageId(String languageId) {
/* 268 */     this.languageId = languageId;
/*     */   }
/*     */   
/*     */   public String getValidityFromDate() {
/* 272 */     return this.validityFromDate;
/*     */   }
/*     */   
/*     */   public void setValidityFromDate(String validityFromDate) {
/* 276 */     this.validityFromDate = validityFromDate;
/*     */   }
/*     */   
/*     */   public List<CategorySubcategoryList> getCategorySubcategoryList() {
/* 280 */     return this.categorySubcategoryList;
/*     */   }
/*     */   
/*     */   public void setCategorySubcategoryList(List<CategorySubcategoryList> categorySubcategoryList) {
/* 284 */     this.categorySubcategoryList = categorySubcategoryList;
/*     */   }
/*     */   
/*     */   public String getPromotionFromDate() {
/* 288 */     return this.promotionFromDate;
/*     */   }
/*     */   
/*     */   public void setPromotionFromDate(String promotionFromDate) {
/* 292 */     this.promotionFromDate = promotionFromDate;
/*     */   }
/*     */   
/*     */   public Map<String, String> getVisaTerms() {
/* 296 */     return this.visaTerms;
/*     */   }
/*     */   
/*     */   public void setVisaTerms(Map<String, String> visaTerms) {
/* 300 */     this.visaTerms = visaTerms;
/*     */   }
/*     */   
/*     */   public String getRedemptionUrl() {
/* 304 */     return this.redemptionUrl;
/*     */   }
/*     */   
/*     */   public void setRedemptionUrl(String redemptionUrl) {
/* 308 */     this.redemptionUrl = redemptionUrl;
/*     */   }
/*     */   
/*     */   public Map<String, String> getMerchantTerms() {
/* 312 */     return this.merchantTerms;
/*     */   }
/*     */   
/*     */   public void setMerchantTerms(Map<String, String> merchantTerms) {
/* 316 */     this.merchantTerms = merchantTerms;
/*     */   }
/*     */   
/*     */   public String getFeaturedOfferIndicator() {
/* 320 */     return this.featuredOfferIndicator;
/*     */   }
/*     */   
/*     */   public void setFeaturedOfferIndicator(String featuredOfferIndicator) {
/* 324 */     this.featuredOfferIndicator = featuredOfferIndicator;
/*     */   }
/*     */   
/*     */   public List<MerchantList> getMerchantList() {
/* 328 */     return this.merchantList;
/*     */   }
/*     */   
/*     */   public void setMerchantList(List<MerchantList> merchantList) {
/* 332 */     this.merchantList = merchantList;
/*     */   }
/*     */   
/*     */   public String getProgramId() {
/* 336 */     return this.programId;
/*     */   }
/*     */   
/*     */   public void setProgramId(String programId) {
/* 340 */     this.programId = programId;
/*     */   }
/*     */   
/*     */   public List<CardProductList> getCardProductList() {
/* 344 */     return this.cardProductList;
/*     */   }
/*     */   
/*     */   public void setCardProductList(List<CardProductList> cardProductList) {
/* 348 */     this.cardProductList = cardProductList;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\pojo\VmorcJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */