/*     */ package com.visa.vpp.scheduler;
/*     */ 
/*     */ import com.day.cq.replication.Replicator;
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(metatype=true, label="Category Page scheduler", description="Category Pag scheduler to validate offers")
/*     */ @Service({Runnable.class})
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="scheduler.expression", value={"0 30 12 1/1 * ? *"}, description="Cron-job expression"), @org.apache.felix.scr.annotations.Property(name="scheduler.concurrent", boolValue={false}, description="Whether or not to schedule this task concurrently")})
/*     */ public class CategoryPageScheduler
/*     */   implements Runnable
/*     */ {
/*  52 */   private final Logger logger = LoggerFactory.getLogger(getClass());
/*     */   
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */   @Reference
/*     */   private Replicator replicator;
/*     */   
/*     */   @Reference
/*     */   private SlingSettingsService settingsService;
/*     */   
/*     */ 
/*     */   public void run()
/*     */   {
/*  67 */     this.logger.debug("CategoryPageScheduler is now running");
/*     */     
/*  69 */     boolean isAuthor = VppUtil.isAuthorMode(this.settingsService);
/*     */     
/*  71 */     if (isAuthor) {
/*  72 */       this.logger.debug("isAuthor1 ::" + isAuthor);
/*  73 */       ArrayList<String> issuerNmaes = getChildNodes("etc/vpp-tools/offers");
/*  74 */       ArrayList<String> languageNames = null;
/*  75 */       Iterator<String> it = issuerNmaes.iterator();
/*  76 */       while (it.hasNext()) {
/*  77 */         String name = (String)it.next();
/*  78 */         this.logger.debug("issuer name ::" + name);
/*  79 */         languageNames = getChildNodes("etc/vpp-tools/offers/" + name);
/*  80 */         Iterator<String> langIterator = languageNames.iterator();
/*  81 */         while (langIterator.hasNext()) {
/*  82 */           String langName = (String)langIterator.next();
/*  83 */           validateOffers("etc/vpp-tools/offers/" + name + "/" + langName);
/*     */         }
/*     */       }
/*     */     } else {
/*  87 */       this.logger.debug("isAuthor ::" + isAuthor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void validateOffers(String languagePath)
/*     */   {
/* 100 */     this.logger.debug("issuer languagePath " + languagePath);
/* 101 */     ArrayList<String> fileNames = null;
/* 102 */     JSONObject aemOfferJson = getJsonObject(languagePath, "aem_offers.json");
/*     */     
/*     */ 
/* 105 */     JSONObject vmorcOfferJson = getJsonObject(languagePath, "vmorc_offers.json");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */     ResourceResolver resolver = null;
/* 113 */     Session session = null;
/* 114 */     fileNames = getChildNodes(languagePath);
/* 115 */     Iterator<String> it = fileNames.iterator();
/*     */     try {
/* 117 */       JSONObject updatedAemOfferJson = new JSONObject(aemOfferJson.toString());
/* 118 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 119 */       session = (Session)resolver.adaptTo(Session.class);
/* 120 */       while (it.hasNext()) {
/* 121 */         String name = (String)it.next();
/* 122 */         boolean isFile = isFile(languagePath + "/" + name);
/* 123 */         boolean isFolder = isFolder(languagePath + "/" + name);
/* 124 */         this.logger.debug("=======================Start json file process**===============");
/*     */         
/* 126 */         if ((isFile) && (!name.equals("vmorc_offers.json")) && 
/* 127 */           (!name.equals("aem_offers.json"))) {
/* 128 */           this.logger.debug("landing page json   ::" + name);
/* 129 */           JSONObject landingPageJson = getJsonObject(languagePath, name);
/* 130 */           JSONObject updatedLandingPageJson = new JSONObject(landingPageJson.toString());
/* 131 */           Iterator<String> iterator = landingPageJson.keys();
/*     */           
/*     */ 
/* 134 */           while (iterator.hasNext()) {
/* 135 */             String jsonObjKey = (String)iterator.next();
/*     */             
/* 137 */             JSONObject categoryJson = landingPageJson.getJSONObject(jsonObjKey);
/* 138 */             JSONObject updatedCatJson = new JSONObject(categoryJson.toString());
/* 139 */             this.logger.debug("jsonObjKey :: " + jsonObjKey);
/* 140 */             Iterator<String> catIterator = categoryJson.keys();
/* 141 */             while (catIterator.hasNext()) {
/* 142 */               String childJson = (String)catIterator.next();
/* 143 */               this.logger.debug("childJson ::" + childJson);
/* 144 */               JSONObject offerJson = categoryJson.getJSONObject(childJson);
/* 145 */               String offerSource = offerJson.get("offerSource").toString();
/* 146 */               this.logger.debug("offersource :: " + offerJson.get("offerSource"));
/* 147 */               this.logger.debug("offerId :: " + offerJson.get("offerId"));
/* 148 */               String offerId = offerJson.get("offerId").toString();
/* 149 */               if ("AEM".equals(offerSource)) {
/* 150 */                 boolean isValid = isValidAemOffer(offerJson, aemOfferJson);
/*     */                 
/* 152 */                 this.logger.debug("isValid ::" + isValid);
/* 153 */                 if (!isValid) {
/* 154 */                   this.logger.debug("aem landing json update:: remove offer from landing json  ");
/* 155 */                   if (updatedCatJson.has(offerId)) {
/* 156 */                     updatedCatJson.remove(offerId);
/* 157 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/*     */                   }
/*     */                   
/* 160 */                   this.logger.debug("remove offer from aem src ");
/*     */                   
/* 162 */                   if (aemOfferJson.has(offerId)) {
/* 163 */                     this.logger.debug("removed offer from aem src ");
/* 164 */                     updatedAemOfferJson.remove(offerId);
/*     */                   }
/*     */                   
/* 167 */                   updateNode(jsonObjKey, offerId);
/* 168 */                   this.logger.debug("node updated");
/*     */                 }
/*     */               }
/* 171 */               if ("VMORC".equals(offerSource)) {
/* 172 */                 this.logger.debug("inside vmorc validation");
/* 173 */                 if (vmorcOfferJson.has(offerId)) {
/* 174 */                   this.logger.debug("inside landing VMORC offer:: ");
/*     */                   
/*     */ 
/* 177 */                   JSONObject formatVmorcOffer = VppJsonUtil.getCurrOfferData(vmorcOfferJson, offerId);
/* 178 */                   boolean isModified = VppJsonUtil.areEqual(offerJson, formatVmorcOffer);
/* 179 */                   this.logger.debug("isModified ::" + isModified);
/* 180 */                   if (!isModified) {
/* 181 */                     VppUtil.updateCurrentCategoryPage(jsonObjKey, offerId, formatVmorcOffer, session);
/*     */                     
/* 183 */                     this.logger.debug("before vmorc updatedCatJson");
/* 184 */                     updatedCatJson.put(offerId, formatVmorcOffer);
/* 185 */                     this.logger.debug("after vmorc updatedCatJson");
/*     */                     
/* 187 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/*     */                   }
/*     */                 }
/*     */                 else
/*     */                 {
/* 192 */                   this.logger.debug("vmorc landing update before ");
/* 193 */                   if (updatedCatJson.has(offerId)) {
/* 194 */                     updatedCatJson.remove(offerId);
/* 195 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/* 196 */                     this.logger.debug("vmorc landing update after ");
/* 197 */                     updateNode(jsonObjKey, offerId);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 206 */             this.logger.debug("isModifiedCatPage ::" + isModifiedCatPage(jsonObjKey));
/* 207 */             if (!isModifiedCatPage(jsonObjKey)) {
/* 208 */               this.logger.debug("is not modified page and publish page::");
/* 209 */               if (session.nodeExists(jsonObjKey)) {
/* 210 */                 VppUtil.replicateResource(session, jsonObjKey, this.replicator);
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 216 */           this.logger.debug("update final landingpage json langpath:: " + languagePath + " name" + name);
/* 217 */           VppJsonUtil.createUpdateJsonFile(languagePath, name, session, updatedLandingPageJson);
/* 218 */           VppUtil.replicateResource(session, "/" + languagePath + "/" + name, this.replicator);
/*     */         }
/* 220 */         if (isFolder) {
/* 221 */           this.logger.debug("inside landing folder::  " + languagePath + "/" + name);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */           ArrayList<String> catFiles = getChildNodes(languagePath + "/" + name);
/* 228 */           if ((null != catFiles) && (catFiles.size() > 0)) {
/* 229 */             Iterator<String> catIteratorObj = catFiles.iterator();
/* 230 */             while (catIteratorObj.hasNext()) {
/* 231 */               String catFileName = (String)catIteratorObj.next();
/* 232 */               this.logger.debug("cat file name :: " + catFileName);
/*     */               
/* 234 */               JSONObject catJsonSrc = VppJsonUtil.getOfferJson(session, languagePath + "/" + name, catFileName);
/* 235 */               JSONObject updatedCatJsonSrc = new JSONObject(catJsonSrc.toString());
/*     */               
/* 237 */               Iterator<String> catJsonIterator = catJsonSrc.keys();
/* 238 */               while (catJsonIterator.hasNext()) {
/* 239 */                 String catJson = (String)catJsonIterator.next();
/* 240 */                 this.logger.debug("catJson ::" + catJson);
/* 241 */                 JSONObject catOfferJson = catJsonSrc.getJSONObject(catJson);
/* 242 */                 JSONObject catOfferJsonSrc = new JSONObject(catOfferJson.toString());
/* 243 */                 Iterator<String> catOfferIter = catOfferJson.keys();
/* 244 */                 while (catOfferIter.hasNext())
/*     */                 {
/* 246 */                   String catOffer = (String)catOfferIter.next();
/* 247 */                   this.logger.debug("catOffer :: " + catOffer);
/* 248 */                   JSONObject catOfferJsonObj = catOfferJson.getJSONObject(catOffer);
/* 249 */                   this.logger.debug("catOfferJsonObj :: " + catOfferJsonObj.toString());
/*     */                   
/* 251 */                   String catOfferSource = catOfferJsonObj.get("offerSource").toString();
/* 252 */                   this.logger.debug("catoffersource :: " + catOfferJsonObj
/* 253 */                     .get("offerSource"));
/* 254 */                   this.logger.debug("catofferId :: " + catOfferJsonObj.get("offerId"));
/* 255 */                   String offerId = catOfferJsonObj.get("offerId").toString();
/* 256 */                   if ("AEM".equals(catOfferSource)) {
/* 257 */                     boolean isValid = isValidAemOffer(catOfferJsonObj, aemOfferJson);
/*     */                     
/* 259 */                     if (!isValid) {
/* 260 */                       this.logger.debug("updatedCatJsonSrc update before ");
/* 261 */                       catOfferJsonSrc.remove(offerId);
/* 262 */                       updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/* 263 */                       this.logger.debug("updatedCatJsonSrc after remove");
/* 264 */                       this.logger.debug("aem json before removal");
/* 265 */                       if (aemOfferJson.has(offerId)) {
/* 266 */                         updatedAemOfferJson.remove(offerId);
/*     */                       }
/* 268 */                       this.logger.debug("aem json after removal");
/* 269 */                       updateNode(catJson, offerId);
/*     */                     }
/*     */                   }
/*     */                   
/* 273 */                   if ("VMORC".equals(catOfferSource)) {
/* 274 */                     if (vmorcOfferJson.has(offerId)) {
/* 275 */                       this.logger.debug("inside landing VMORC offer:: ");
/*     */                       
/* 277 */                       JSONObject formatVmorcOffer = VppJsonUtil.getCurrOfferData(vmorcOfferJson, offerId);
/* 278 */                       boolean isModified = VppJsonUtil.areEqual(formatVmorcOffer, catOfferJsonObj);
/* 279 */                       this.logger.debug("isModified ::" + isModified);
/* 280 */                       if (!isModified) {
/* 281 */                         VppUtil.updateCurrentCategoryPage(catJson, offerId, formatVmorcOffer, session);
/*     */                         
/* 283 */                         this.logger.debug("before vmorc updatedCatJson");
/* 284 */                         catOfferJsonSrc.put(offerId, formatVmorcOffer);
/* 285 */                         updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/*     */                         
/* 287 */                         this.logger.debug("after vmorc updatedCatJson");
/*     */                       }
/*     */                     }
/*     */                     else
/*     */                     {
/* 292 */                       this.logger.debug("is file vmorc:: remove vmorc from cat json file ");
/* 293 */                       if (catOfferJson.has(offerId)) {
/* 294 */                         catOfferJsonSrc.remove(offerId);
/* 295 */                         updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/* 296 */                         this.logger.debug("updatedCatJsonSrc in loop::" + updatedCatJsonSrc.toString());
/* 297 */                         updateNode(catJson, offerId);
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/* 305 */               this.logger.debug("updatedCatJsonS final::" + updatedCatJsonSrc.toString());
/* 306 */               this.logger.debug("update category file json :: " + languagePath + "/" + name + "/" + catFileName);
/*     */               
/* 308 */               VppJsonUtil.createUpdateJsonFile(languagePath + "/" + name, catFileName, session, updatedCatJsonSrc);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 316 */         VppJsonUtil.createUpdateJsonFile(languagePath, "aem_offers.json", session, updatedAemOfferJson);
/*     */         
/* 318 */         this.logger.debug("=======================end  json file process===============");
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 322 */       this.logger.error("JSONException in validating offer :: " + e);
/*     */     } catch (Exception e) {
/* 324 */       this.logger.error("Exception in File process" + e);
/*     */     } finally {
/* 326 */       if (resolver != null) {
/* 327 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getChildNodes(String path)
/*     */   {
/* 342 */     ResourceResolver resolver = null;
/* 343 */     Session session = null;
/* 344 */     ArrayList<String> childNames = new ArrayList();
/* 345 */     String type = null;
/*     */     try
/*     */     {
/* 348 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 349 */       session = (Session)resolver.adaptTo(Session.class);
/* 350 */       Node rootNode = session.getRootNode();
/* 351 */       if (rootNode.hasNode(path)) {
/* 352 */         Node parentNode = rootNode.getNode(path);
/* 353 */         NodeIterator nodes = parentNode.getNodes();
/* 354 */         while (nodes.hasNext()) {
/* 355 */           Node node = nodes.nextNode();
/* 356 */           type = node.getProperty("jcr:primaryType").getString();
/* 357 */           if ((type.equals("nt:file")) || 
/* 358 */             (type.equals("nt:folder"))) {
/* 359 */             childNames.add(node.getName());
/*     */           }
/*     */         }
/*     */       }
/* 363 */       if (childNames.size() == 0) {
/* 364 */         childNames = null;
/*     */       }
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 368 */       this.logger.error("Path Not Found Exception Occured  :" + e);
/*     */     } catch (RepositoryException e) {
/* 370 */       this.logger.error("node creation exception" + e);
/*     */     } finally {
/* 372 */       if (resolver != null) {
/* 373 */         resolver.close();
/*     */       }
/*     */     }
/* 376 */     return childNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getJsonObject(String filePath, String fileName)
/*     */   {
/* 388 */     ResourceResolver resolver = null;
/* 389 */     Session session = null;
/* 390 */     JSONObject offerJson = null;
/*     */     try
/*     */     {
/* 393 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 394 */       session = (Session)resolver.adaptTo(Session.class);
/* 395 */       offerJson = VppJsonUtil.getOfferJson(session, filePath, fileName);
/*     */     }
/*     */     catch (Exception e) {
/* 398 */       this.logger.error("exception" + e);
/*     */     } finally {
/* 400 */       if (resolver != null)
/*     */       {
/* 402 */         resolver.close();
/*     */       }
/*     */     }
/* 405 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFile(String filePath)
/*     */   {
/* 416 */     ResourceResolver resolver = null;
/* 417 */     Session session = null;
/* 418 */     Node node = null;
/* 419 */     boolean isFile = false;
/*     */     try
/*     */     {
/* 422 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 423 */       session = (Session)resolver.adaptTo(Session.class);
/* 424 */       Node rootNode = session.getRootNode();
/* 425 */       if (rootNode.hasNode(filePath)) {
/* 426 */         node = rootNode.getNode(filePath);
/* 427 */         String type = node.getProperty("jcr:primaryType").getString();
/*     */         
/* 429 */         if (type.equals("nt:file")) {
/* 430 */           isFile = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 435 */       this.logger.error("exception" + e);
/*     */     } finally {
/* 437 */       if (resolver != null)
/*     */       {
/* 439 */         resolver.close();
/*     */       }
/*     */     }
/* 442 */     return isFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFolder(String filePath)
/*     */   {
/* 453 */     ResourceResolver resolver = null;
/* 454 */     Session session = null;
/* 455 */     Node node = null;
/* 456 */     boolean isFolder = false;
/*     */     try
/*     */     {
/* 459 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 460 */       session = (Session)resolver.adaptTo(Session.class);
/* 461 */       Node rootNode = session.getRootNode();
/* 462 */       if (rootNode.hasNode(filePath)) {
/* 463 */         node = rootNode.getNode(filePath);
/* 464 */         String type = node.getProperty("jcr:primaryType").getString();
/* 465 */         if (type.equals("nt:folder")) {
/* 466 */           isFolder = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 471 */       this.logger.error("exception" + e);
/*     */     } finally {
/* 473 */       if (resolver != null)
/*     */       {
/* 475 */         resolver.close();
/*     */       }
/*     */     }
/* 478 */     return isFolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isValidAemOffer(JSONObject aemOfferJson, JSONObject aemJsonSource)
/*     */   {
/* 489 */     boolean isValid = false;
/*     */     
/* 491 */     if (null != aemOfferJson) {
/*     */       try {
/* 493 */         String offerId = aemOfferJson.get("offerId").toString();
/*     */         
/* 495 */         if (aemJsonSource.has(offerId)) {
/* 496 */           JSONObject srcAemOffer = aemJsonSource.getJSONObject(offerId);
/* 497 */           this.logger.debug("srcAemOffer :: " + srcAemOffer.toString());
/* 498 */           String promoEndDate = srcAemOffer.get("promoEndDate").toString();
/*     */           
/* 500 */           String promoStartDate = srcAemOffer.get("promoStartDate").toString();
/*     */           
/* 502 */           isValid = VppJsonUtil.checkPromotionDateValidity(promoStartDate, promoEndDate);
/*     */           
/* 504 */           this.logger.debug("isValidAemOffer isValid:: " + isValid);
/*     */         }
/*     */       }
/*     */       catch (JSONException e) {
/* 508 */         this.logger.error("JSON Exception " + e);
/*     */       }
/*     */     }
/* 511 */     return isValid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateNode(String path, String offerid)
/*     */   {
/* 524 */     this.logger.debug("initialize updateNode1" + path);
/* 525 */     ResourceResolver resolver = null;
/* 526 */     Session session = null;
/* 527 */     Node node = null;
/*     */     try {
/* 529 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 530 */       session = (Session)resolver.adaptTo(Session.class);
/*     */       
/* 532 */       node = VppUtil.getCatgoryOfferNode(session, path, offerid);
/*     */       
/* 534 */       if (null != node) {
/* 535 */         this.logger.debug("node path ===========>>>" + node.getPath());
/* 536 */         node.remove();
/* 537 */         session.save();
/*     */       }
/*     */     } catch (Exception e) {
/* 540 */       this.logger.error("repository exception " + e);
/*     */     } finally {
/* 542 */       if (resolver != null)
/*     */       {
/* 544 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isModifiedCatPage(String path)
/*     */   {
/* 558 */     this.logger.debug("initialize isModifiedCatPage");
/* 559 */     ResourceResolver resolver = null;
/* 560 */     Session session = null;
/* 561 */     Node jcrNode = null;
/* 562 */     boolean isModified = false;
/*     */     try {
/* 564 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 565 */       session = (Session)resolver.adaptTo(Session.class);
/* 566 */       if (session.nodeExists(path + "/" + "jcr:content")) {
/* 567 */         jcrNode = session.getNode(path + "/" + "jcr:content");
/* 568 */         if (jcrNode.hasProperty("catApprovalStatus"))
/*     */         {
/* 570 */           if (jcrNode.getProperty("catApprovalStatus").getString().equalsIgnoreCase("MODIFIED")) {
/* 571 */             isModified = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 576 */       this.logger.error("repository exception " + e);
/*     */     } finally {
/* 578 */       if (resolver != null)
/*     */       {
/* 580 */         resolver.close();
/*     */       }
/*     */     }
/* 583 */     return isModified;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     this.replicator = paramReplicator;
/*     */   }
/*     */   
/*     */   protected void unbindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     if (this.replicator == paramReplicator) {
/*     */       this.replicator = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     this.settingsService = paramSlingSettingsService;
/*     */   }
/*     */   
/*     */   protected void unbindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     if (this.settingsService == paramSlingSettingsService) {
/*     */       this.settingsService = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\scheduler\CategoryPageScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */