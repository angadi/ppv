/*     */ package com.visa.vpp.scheduler;
/*     */ 
/*     */ import com.day.cq.commons.jcr.JcrUtil;
/*     */ import com.day.cq.replication.Replicator;
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.WCMException;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.visa.vpp.pojo.CardPaymentTypeList;
/*     */ import com.visa.vpp.pojo.CardProductList;
/*     */ import com.visa.vpp.pojo.CategorySubcategoryList;
/*     */ import com.visa.vpp.pojo.ImageList;
/*     */ import com.visa.vpp.pojo.MerchantImage;
/*     */ import com.visa.vpp.pojo.MerchantList;
/*     */ import com.visa.vpp.pojo.VmorcJson;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.NameValuePair;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.Credentials;
/*     */ import org.apache.http.auth.UsernamePasswordCredentials;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*     */ import org.apache.http.client.methods.CloseableHttpResponse;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.impl.client.BasicCredentialsProvider;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ import org.apache.http.message.BasicNameValuePair;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.commons.osgi.PropertiesUtil;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.osgi.service.component.ComponentContext;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(metatype=true, label="VMORC scheduler", description="VMORC scheduler to get offer/events/benefits")
/*     */ @Service({Runnable.class})
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="scheduler.expression", value={"0 0 12 1/1 * ? *"}, description="Cron-job expression"), @org.apache.felix.scr.annotations.Property(name="scheduler.concurrent", boolValue={false}, description="Whether or not to schedule this task concurrently"), @org.apache.felix.scr.annotations.Property(name="proxy.host", value={"internet.visa.com"}, description="proxy host"), @org.apache.felix.scr.annotations.Property(name="proxy.port", intValue={80}, description="proxy port"), @org.apache.felix.scr.annotations.Property(name="username", value={""}, description="proxy username"), @org.apache.felix.scr.annotations.Property(name="password", value={""}, description="proxy password"), @org.apache.felix.scr.annotations.Property(name="proxy.enabled", boolValue={false}, description="proxy enabled or disabled"), @org.apache.felix.scr.annotations.Property(name="scheduler.disable", boolValue={false}, description="enable or disable cron job"), @org.apache.felix.scr.annotations.Property(name="service.url", value={""}, description="web service url to be called"), @org.apache.felix.scr.annotations.Property(name="token.generation.url", value={"https://qa.vpp.tacpoint.net/vpp_api_service/oauth/token.do"}, description="token generation url"), @org.apache.felix.scr.annotations.Property(name="grant.type", value={"client_credentials"}, description="grant type for token generation"), @org.apache.felix.scr.annotations.Property(name="client.id", value={"AEMclient"}, description="client id to be passed"), @org.apache.felix.scr.annotations.Property(name="client.secret", value={"1X10i4567479mM109S91tSL9N6G4y84J"}, description="client secrete key")})
/*     */ public class VmorcScheduler
/*     */   implements Runnable
/*     */ {
/* 108 */   private final Logger logger = LoggerFactory.getLogger(getClass());
/*     */   
/*     */   private static String PROXY_HOST;
/*     */   
/*     */   private static int PROXY_PORT;
/*     */   
/*     */   private static String USERNAME;
/*     */   
/*     */   private static String PASSWORD;
/*     */   
/*     */   private static boolean PROXY_ENABLED;
/*     */   
/*     */   private static boolean SCHEDULER_DISABLED;
/*     */   
/*     */   private static String SERVICE_URL;
/*     */   
/*     */   private static String GRANT_TYPE;
/*     */   
/*     */   private static String CLIENT_ID;
/*     */   
/*     */   private static String CLIENT_SECRET_KEY;
/*     */   
/*     */   private static String TOKEN_GENERATION_URL;
/*     */   
/*     */   private static final String PROGRAM_LIST_MAP = "programInfo";
/*     */   
/*     */   private static final String PROXY_HOST_PROPERTY = "proxy.host";
/*     */   
/*     */   private static final String PROXY_HOST_DEFAULT = "internet.visa.com";
/*     */   private static final String PROXY_PORT_PROPERTY = "proxy.port";
/*     */   private static final int PROXY_PORT_DEFAULT = 80;
/*     */   private static final String USERNAME_PROPERTY = "username";
/*     */   private static final String PASSWORD_PROPERTY = "password";
/*     */   private static final String PROXY_ENABLED_PROPERTY = "proxy.enabled";
/*     */   private static final String SCHEDULER_DISABLED_PROPERTY = "scheduler.disable";
/*     */   private static final String SERVICE_URL_PROPERTY = "service.url";
/*     */   private static final String SERVICE_URL_DEFAULT = "https://qa.vpp.tacpoint.net/vpp_api_service/v1";
/* 145 */   private static String TOKEN_GENERATION_URL_DEFAULT = "https://qa.vpp.tacpoint.net/vpp_api_service/oauth/token.do";
/*     */   
/* 147 */   private static String CLIENT_SECRET_KEY_DEFAULT = "1X10i4567479mM109S91tSL9N6G4y84J";
/* 148 */   private static String CLIENT_ID_DEFAULT = "AEMclient";
/* 149 */   private static String GRANT_TYPE_DEFAULT = "client_credentials";
/*     */   
/*     */   private static final String RESPONSE = "response";
/*     */   private static final String PROGRAM_ID = "programId";
/*     */   private static final String VMORC_PROGRAM_NODE = "VMORC_Offer_Program_List/jcr:content/vmorcProgramList";
/*     */   private static final String AUTHORIZATION = "Authorization";
/*     */   private static final String BEARER = "Bearer";
/* 156 */   private static String GRANT_TYPE_PROPERTY = "grant.type";
/* 157 */   private static String CLIENT_ID_PROPERTY = "client.id";
/*     */   
/* 159 */   private static String CLIENT_SECRET_KEY_PROPERTY = "client.secret";
/*     */   
/* 161 */   private static String TOKEN_GENERATION_URL_PROPERTY = "token.generation.url";
/*     */   
/* 163 */   private static String PIXEL = " px";
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private SlingSettingsService settingsService;
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private Replicator replicator;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void activate(ComponentContext context)
/*     */   {
/* 184 */     Dictionary<String, ?> props = context.getProperties();
/* 185 */     PROXY_HOST = PropertiesUtil.toString(props.get("proxy.host"), "internet.visa.com");
/* 186 */     PROXY_PORT = PropertiesUtil.toInteger(props.get("proxy.port"), 80);
/* 187 */     USERNAME = PropertiesUtil.toString(props.get("username"), "  ");
/* 188 */     PASSWORD = PropertiesUtil.toString(props.get("password"), "  ");
/* 189 */     PROXY_ENABLED = PropertiesUtil.toBoolean(props.get("proxy.enabled"), false);
/* 190 */     SERVICE_URL = PropertiesUtil.toString(props.get("service.url"), "https://qa.vpp.tacpoint.net/vpp_api_service/v1");
/* 191 */     GRANT_TYPE = PropertiesUtil.toString(props.get(GRANT_TYPE_PROPERTY), GRANT_TYPE_DEFAULT);
/* 192 */     CLIENT_ID = PropertiesUtil.toString(props.get(CLIENT_ID_PROPERTY), CLIENT_ID_DEFAULT);
/*     */     
/* 194 */     CLIENT_SECRET_KEY = PropertiesUtil.toString(props.get(CLIENT_SECRET_KEY_PROPERTY), CLIENT_SECRET_KEY_DEFAULT);
/* 195 */     TOKEN_GENERATION_URL = PropertiesUtil.toString(props.get(TOKEN_GENERATION_URL_PROPERTY), TOKEN_GENERATION_URL_DEFAULT);
/*     */     
/* 197 */     SCHEDULER_DISABLED = PropertiesUtil.toBoolean(props.get("scheduler.disable"), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 206 */     this.logger.debug("VMORCScheduler is now running");
/* 207 */     this.logger.debug("SERVICE_URL11 " + SERVICE_URL);
/* 208 */     this.logger.debug("SCHEDULER_DISABLED " + SCHEDULER_DISABLED);
/*     */     
/* 210 */     List<VmorcJson> vmorcList = null;
/* 211 */     boolean isAuthor = VppUtil.isAuthorMode(this.settingsService);
/* 212 */     if ((isAuthor) && (!SCHEDULER_DISABLED)) {
/* 213 */       List<String> issuerList = getChildPage("/content/vpp/standard");
/* 214 */       Iterator<String> itIssuer = issuerList.iterator();
/* 215 */       while (itIssuer.hasNext()) {
/* 216 */         String issuer = (String)itIssuer.next();
/* 217 */         String issuerName = issuer.replaceAll("/content/vpp/standard", "");
/* 218 */         this.logger.debug("issuerName name:: " + issuerName);
/* 219 */         String programIds = getProgramIds(issuer + "/en_us");
/*     */         
/* 221 */         if (!"".equals(programIds)) {
/* 222 */           vmorcList = getVmorcList(issuerName, programIds);
/* 223 */           if (vmorcList != null) {
/*     */             try {
/* 225 */               createOfferNode(vmorcList, issuer + "/en_us");
/*     */             }
/*     */             catch (JSONException e) {
/* 228 */               this.logger.error("error parsing json" + e);
/*     */             }
/*     */           } else {
/* 231 */             this.logger.debug("vmorcList is null");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<VmorcJson> getVmorcList(String issuerCardType, String programIds)
/*     */   {
/* 249 */     this.logger.debug("inside getVMORCList  :: ");
/*     */     
/* 251 */     CloseableHttpClient client = null;
/* 252 */     CloseableHttpResponse response = null;
/* 253 */     List<VmorcJson> offerList = null;
/*     */     
/* 255 */     StringBuffer offerJson = new StringBuffer("");
/* 256 */     BufferedReader br = null;
/*     */     try {
/* 258 */       if (PROXY_ENABLED) {
/* 259 */         HttpHost proxy = new HttpHost(PROXY_HOST, PROXY_PORT);
/* 260 */         Credentials credentials = new UsernamePasswordCredentials(USERNAME, PASSWORD);
/* 261 */         AuthScope authScope = new AuthScope(PROXY_HOST, PROXY_PORT);
/* 262 */         CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
/* 263 */         credentialsProvider.setCredentials(authScope, credentials);
/*     */         
/* 265 */         client = HttpClientBuilder.create().setProxy(proxy).setDefaultCredentialsProvider(credentialsProvider).build();
/*     */       }
/*     */       else {
/* 268 */         client = HttpClientBuilder.create().build();
/*     */       }
/* 270 */       this.logger.debug("URL :: " + new StringBuffer(SERVICE_URL).append(issuerCardType)
/* 271 */         .append("/allproduct/offers/offers.do?programList=").append(programIds).toString());
/* 272 */       HttpGet getRequest = new HttpGet(SERVICE_URL + issuerCardType + "/allproduct/offers/offers.do?programList=" + programIds);
/*     */       
/*     */ 
/* 275 */       String token = getAccessToken();
/* 276 */       this.logger.debug("token :: " + token);
/*     */       
/* 278 */       getRequest.setHeader("Authorization", "Bearer " + token);
/* 279 */       response = client.execute(getRequest);
/*     */       
/* 281 */       if (response.getStatusLine().getStatusCode() != 200) {
/* 282 */         this.logger.error("[VPPERROR] VMORC CRON FAILED");
/* 283 */         this.logger.error("Failed : HTTP error code :  :: " + response.getStatusLine().getStatusCode());
/*     */         
/* 285 */         throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
/*     */       }
/* 287 */       if ((response.getEntity() != null) && (null != response.getEntity().getContent())) {
/* 288 */         this.logger.debug("response.getEntity is not null");
/* 289 */         br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF8"));
/* 290 */         String output; while ((output = br.readLine()) != null) {
/* 291 */           offerJson = offerJson.append(output);
/*     */         }
/* 293 */         this.logger.debug("offerJson :: " + offerJson.toString());
/*     */       } else {
/* 295 */         this.logger.debug("response.getEntity is null"); }
/*     */       JsonParser jsonParser;
/* 297 */       Gson gson; if ((!offerJson.toString().equals("")) && (offerJson.indexOf("200") != -1)) {
/* 298 */         jsonParser = new JsonParser();
/* 299 */         JsonObject responseObject = jsonParser.parse(offerJson.toString()).getAsJsonObject();
/* 300 */         JsonArray offerArray = responseObject.get("response").getAsJsonArray();
/* 301 */         gson = new GsonBuilder().setPrettyPrinting().create();
/* 302 */         offerList = new ArrayList();
/* 303 */         for (JsonElement offer : offerArray) {
/* 304 */           VmorcJson vmorcoffer = (VmorcJson)gson.fromJson(offer, VmorcJson.class);
/* 305 */           offerList.add(vmorcoffer);
/*     */         }
/*     */       }
/* 308 */       return offerList;
/*     */     } catch (RuntimeException e) {
/* 310 */       this.logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/* 311 */       throw e;
/*     */     } catch (Exception e) {
/* 313 */       this.logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/* 314 */       this.logger.error("Exception while parsing JSON :: " + e);
/*     */     } finally {
/* 316 */       if (br != null) {
/*     */         try {
/* 318 */           br.close();
/*     */         } catch (Exception e) {
/* 320 */           this.logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/* 321 */           this.logger.error("Exception while closing reader :: " + e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 326 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getChildPage(String path)
/*     */   {
/* 337 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 338 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 339 */     Page rootPage = pageManager.getPage(path);
/* 340 */     List<String> pageList = new ArrayList();
/* 341 */     if (null != rootPage) {
/* 342 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 343 */       while (rootPageIterator.hasNext()) {
/* 344 */         Page childPage = (Page)rootPageIterator.next();
/* 345 */         String childPath = childPage.getPath();
/* 346 */         pageList.add(childPath);
/*     */       }
/* 348 */       return pageList;
/*     */     }
/* 350 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void createOfferNode(List<VmorcJson> vmorcList, String offerPath)
/*     */     throws JSONException
/*     */   {
/* 360 */     this.logger.debug("inside createOfferNode ::");
/* 361 */     Session session = null;
/* 362 */     Page vmorcListPage = null;
/* 363 */     ArrayList<String> cardPayList = null;
/* 364 */     ArrayList<String> categoryList = null;
/* 365 */     ArrayList<String> cardProductList = null;
/* 366 */     ImageList heroImage = null;
/* 367 */     ImageList thumbImage = null;
/* 368 */     MerchantImage merchantLogoImage = null;
/*     */     
/* 370 */     String defaultHeroImgPath = "failure";
/* 371 */     String defaultLogoImgPath = "failure";
/* 372 */     String defaultThumbImgPath = "failure";
/* 373 */     String heroSize = null;
/* 374 */     String thumbSize = null;
/* 375 */     String logoSize = null;
/* 376 */     String heroSizeHeight = null;
/* 377 */     String thumbSizeHeight = null;
/* 378 */     String logoSizeHeight = null;
/* 379 */     ResourceResolver resolver = null;
/* 380 */     PageManager pageManager = null;
/* 381 */     JSONObject vmorcJson = new JSONObject();
/*     */     try
/*     */     {
/* 384 */       HashMap<String, String> imageMap = getImageDimension(offerPath);
/* 385 */       if ((imageMap != null) && (imageMap.size() > 0)) {
/* 386 */         defaultHeroImgPath = (String)imageMap.get("fileReferenceHeroImage");
/* 387 */         defaultLogoImgPath = (String)imageMap.get("fileReferenceLogoImage");
/* 388 */         defaultThumbImgPath = (String)imageMap.get("fileReferenceThumbImage");
/* 389 */         heroSize = (String)imageMap.get("hero_image_size");
/* 390 */         thumbSize = (String)imageMap.get("thumb_image_size");
/* 391 */         logoSize = (String)imageMap.get("logo_image_size");
/*     */       }
/*     */       
/* 394 */       if ((heroSize != null) && (!heroSize.equals(""))) {
/* 395 */         heroSize = heroSize.split("_")[0] + PIXEL;
/* 396 */         heroSizeHeight = ((String)imageMap.get("hero_image_size")).split("_")[1] + PIXEL;
/*     */       }
/* 398 */       if ((thumbSize != null) && (!thumbSize.equals(""))) {
/* 399 */         thumbSize = thumbSize.split("_")[0] + PIXEL;
/* 400 */         thumbSizeHeight = ((String)imageMap.get("thumb_image_size")).split("_")[1] + PIXEL;
/*     */       }
/* 402 */       if ((logoSize != null) && (!logoSize.equals(""))) {
/* 403 */         logoSize = logoSize.split("_")[0] + PIXEL;
/* 404 */         logoSizeHeight = ((String)imageMap.get("logo_image_size")).split("_")[1] + PIXEL;
/*     */       }
/* 406 */       this.logger.debug("defaultHeroImgPath " + defaultHeroImgPath);
/* 407 */       this.logger.debug("defaultLogoImgPath " + defaultLogoImgPath);
/* 408 */       this.logger.debug("defaultThumbImgPath " + defaultThumbImgPath);
/* 409 */       this.logger.debug("heroSize " + heroSize + " X " + heroSizeHeight);
/* 410 */       this.logger.debug("thumbSize " + thumbSize + " X " + thumbSizeHeight);
/* 411 */       this.logger.debug("logoSize " + logoSize + " X " + logoSizeHeight);
/* 412 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 413 */       session = (Session)resolver.adaptTo(Session.class);
/* 414 */       pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/*     */       
/* 416 */       if (session.nodeExists(offerPath + "/" + "VMORC_OFFER_LIST")) {
/* 417 */         this.logger.debug(" offerListNode is   present");
/*     */         
/* 419 */         Node existingNodeList = session.getNode(offerPath + "/" + "VMORC_OFFER_LIST");
/* 420 */         existingNodeList.remove();
/* 421 */         session.save();
/* 422 */         this.logger.debug(" offerListNode is   deleted");
/* 423 */         vmorcListPage = pageManager.create(offerPath, "VMORC_OFFER_LIST", "/apps/vpp/components/pages/blank_page", "VMORC_OFFER_LIST", true);
/*     */         
/* 425 */         this.logger.debug(" offerListNode is newly created after  deleted");
/*     */       } else {
/* 427 */         this.logger.debug(" offerListNode not exists? :: ");
/* 428 */         this.logger.debug(" vmorcListPage new page created");
/* 429 */         vmorcListPage = pageManager.create(offerPath, "VMORC_OFFER_LIST", "/apps/vpp/components/pages/blank_page", "VMORC_OFFER_LIST", true);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 434 */       Iterator<VmorcJson> it = vmorcList.iterator();
/*     */       
/* 436 */       VppUtil.deactivateResource(session, offerPath + "/" + "VMORC_OFFER_LIST", this.replicator);
/*     */       
/* 438 */       VppUtil.replicateResource(session, offerPath + "/" + "VMORC_OFFER_LIST", this.replicator);
/*     */       
/*     */ 
/* 441 */       while (it.hasNext()) {
/* 442 */         VmorcJson vm = (VmorcJson)it.next();
/*     */         
/*     */ 
/* 445 */         JSONObject aemJson = new JSONObject();
/* 446 */         if (vmorcListPage != null) {
/* 447 */           Node vmorcListNode = session.getNode(offerPath + "/" + "VMORC_OFFER_LIST");
/* 448 */           Node pageNode = JcrUtil.createUniqueNode(vmorcListNode, vm.getOfferId(), "cq:Page", session);
/*     */           
/*     */ 
/* 451 */           Node contentNode = JcrUtil.createUniqueNode(pageNode, "jcr:content", "cq:PageContent", session);
/*     */           
/*     */ 
/* 454 */           JcrUtil.setProperty(contentNode, "sling:resourceType", "vpp/components/pages/offer_page");
/*     */           
/* 456 */           JcrUtil.setProperty(contentNode, "cq:template", "/apps/vpp/templates/offer_creation");
/*     */           
/*     */ 
/* 459 */           Node componentNode = JcrUtil.createUniqueNode(contentNode, "offer_creation", "nt:unstructured", session);
/*     */           
/* 461 */           JcrUtil.setProperty(componentNode, "sling:resourceType", "vpp/components/content/offer_page_creation");
/*     */           
/*     */ 
/* 464 */           if (vm.getIsOfferEvent() == "true") {
/* 465 */             JcrUtil.setProperty(contentNode, "pageType", "event");
/*     */           }
/*     */           else {
/* 468 */             JcrUtil.setProperty(contentNode, "pageType", "offer");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 473 */           aemJson.put("offerSource", "VMORC");
/* 474 */           JcrUtil.setProperty(contentNode, "jcr:title", vm.getOfferTitle());
/* 475 */           JcrUtil.setProperty(componentNode, "offerTitle", vm.getOfferTitle());
/*     */           
/* 477 */           aemJson.put("offerTitle", vm.getOfferTitle());
/*     */           
/* 479 */           JcrUtil.setProperty(componentNode, "merchantName", vm.getMerchant());
/*     */           
/* 481 */           aemJson.put("merchantName", vm.getMerchant());
/*     */           
/* 483 */           JcrUtil.setProperty(contentNode, "offerId", vm.getOfferId());
/*     */           
/* 485 */           aemJson.put("offerId", vm.getOfferId());
/*     */           
/* 487 */           aemJson.put("previewURL", pageNode
/* 488 */             .getPath() + ".html" + "?wcmmode=disabled");
/* 489 */           JcrUtil.setProperty(componentNode, "offerShortDesc", vm
/* 490 */             .getOfferShortDescription().get("text"));
/*     */           
/* 492 */           aemJson.put("offerShortDesc", vm
/* 493 */             .getOfferShortDescription().get("text"));
/* 494 */           JcrUtil.setProperty(componentNode, "benefitTypeCode", " ");
/* 495 */           JcrUtil.setProperty(componentNode, "offerCopy", vm
/* 496 */             .getOfferCopy().get("richText"));
/* 497 */           String merchantName = ((MerchantList)vm.getMerchantList().get(0)).getMerchant();
/*     */           
/* 499 */           Iterator<ImageList> imageListIterator = vm.getImageList().iterator();
/*     */           
/* 501 */           while (imageListIterator.hasNext()) {
/* 502 */             ImageList imageObj = (ImageList)imageListIterator.next();
/*     */             
/* 504 */             if ((imageObj.getImageFileWidth().equals(heroSize)) && (imageObj.getImageFileHeight().equals(heroSizeHeight))) {
/* 505 */               heroImage = imageObj;
/* 506 */               break;
/*     */             }
/*     */           }
/* 509 */           if (null != heroImage) {
/* 510 */             JcrUtil.setProperty(componentNode, "heroImage", heroImage
/* 511 */               .getFileLocation());
/* 512 */             JcrUtil.setProperty(componentNode, "validHeroImg", "VALID");
/*     */             
/* 514 */             if (!merchantName.equals("")) {
/* 515 */               JcrUtil.setProperty(componentNode, "heroImageAltText", merchantName);
/*     */             }
/*     */             else {
/* 518 */               JcrUtil.setProperty(componentNode, "heroImageAltText", vm
/* 519 */                 .getOfferTitle());
/*     */             }
/* 521 */             heroImage = null;
/*     */           }
/*     */           else {
/* 524 */             JcrUtil.setProperty(componentNode, "heroImage", defaultHeroImgPath);
/*     */             
/* 526 */             JcrUtil.setProperty(componentNode, "validHeroImg", defaultHeroImgPath);
/*     */           }
/*     */           
/* 529 */           Iterator<ImageList> imageListIterator1 = vm.getImageList().iterator();
/* 530 */           while (imageListIterator1.hasNext()) {
/* 531 */             ImageList imageObj = (ImageList)imageListIterator1.next();
/*     */             
/* 533 */             if ((imageObj.getImageFileWidth().equals(thumbSize)) && (imageObj.getImageFileHeight().equals(thumbSizeHeight))) {
/* 534 */               thumbImage = imageObj;
/* 535 */               break;
/*     */             }
/*     */           }
/* 538 */           if (null != thumbImage) {
/* 539 */             JcrUtil.setProperty(componentNode, "thumbImage", thumbImage
/* 540 */               .getFileLocation());
/* 541 */             aemJson.put("thumbImage", thumbImage.getFileLocation());
/* 542 */             if (!merchantName.equals("")) {
/* 543 */               JcrUtil.setProperty(componentNode, "thumbnailImageAltText", merchantName);
/*     */             }
/*     */             else {
/* 546 */               JcrUtil.setProperty(componentNode, "thumbnailImageAltText", vm
/* 547 */                 .getOfferTitle());
/*     */             }
/* 549 */             thumbImage = null;
/*     */           }
/*     */           else {
/* 552 */             JcrUtil.setProperty(componentNode, "thumbImage", defaultThumbImgPath);
/*     */             
/* 554 */             aemJson.put("thumbImage", defaultThumbImgPath);
/*     */           }
/*     */           
/* 557 */           JcrUtil.setProperty(componentNode, "valStartDate", 
/* 558 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/* 559 */             .getValidityFromDate()));
/*     */           
/* 561 */           JcrUtil.setProperty(componentNode, "valEndDate", 
/* 562 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/* 563 */             .getValidityToDate()));
/*     */           
/*     */ 
/* 566 */           JcrUtil.setProperty(componentNode, "promoStartDate", 
/* 567 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/* 568 */             .getPromotionFromDate()));
/*     */           
/*     */ 
/* 571 */           JcrUtil.setProperty(componentNode, "promoEndDate", 
/* 572 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/* 573 */             .getPromotionToDate()));
/*     */           
/*     */ 
/* 576 */           categoryList = new ArrayList();
/*     */           
/* 578 */           Iterator<CategorySubcategoryList> categoryIterator = vm.getCategorySubcategoryList().iterator();
/* 579 */           while (categoryIterator.hasNext()) {
/* 580 */             CategorySubcategoryList rc = (CategorySubcategoryList)categoryIterator.next();
/* 581 */             categoryList.add(rc.getValue());
/*     */           }
/*     */           
/* 584 */           JcrUtil.setProperty(componentNode, "categories", categoryList
/* 585 */             .toArray(new String[0]));
/* 586 */           JSONArray categoryJsonArr = new JSONArray(categoryList);
/*     */           
/*     */ 
/* 589 */           aemJson.put("categories", categoryJsonArr);
/* 590 */           cardProductList = new ArrayList();
/* 591 */           Iterator<CardProductList> cardProductIterator = vm.getCardProductList().iterator();
/* 592 */           while (cardProductIterator.hasNext()) {
/* 593 */             CardProductList rc = (CardProductList)cardProductIterator.next();
/* 594 */             cardProductList.add(rc.getValue());
/*     */           }
/* 596 */           JcrUtil.setProperty(componentNode, "cardProducts", cardProductList
/* 597 */             .toArray(new String[0]));
/*     */           
/* 599 */           JSONArray cardProdJsonArr = new JSONArray(cardProductList);
/* 600 */           aemJson.put("cardProducts", cardProdJsonArr);
/* 601 */           JcrUtil.setProperty(componentNode, "faqs", vm
/* 602 */             .getfAQs().get("richText"));
/*     */           
/*     */ 
/* 605 */           JcrUtil.setProperty(componentNode, "visaTandC", vm
/* 606 */             .getVisaTerms().get("richText"));
/*     */           
/* 608 */           JcrUtil.setProperty(componentNode, "merchantTandC", vm
/* 609 */             .getMerchantTerms().get("richText"));
/*     */           
/*     */ 
/* 612 */           JcrUtil.setProperty(componentNode, "merchantName", 
/* 613 */             ((MerchantList)vm.getMerchantList().get(0)).getMerchant());
/*     */           
/* 615 */           aemJson.put("merchantName", 
/* 616 */             ((MerchantList)vm.getMerchantList().get(0)).getMerchant());
/*     */           
/* 618 */           Iterator<MerchantImage> merchantLogoIterator = ((MerchantList)vm.getMerchantList().get(0)).getMerchantImages().iterator();
/* 619 */           while (merchantLogoIterator.hasNext()) {
/* 620 */             MerchantImage imageObj = (MerchantImage)merchantLogoIterator.next();
/*     */             
/* 622 */             if ((imageObj.getImageFileWidth().equals(logoSize)) && (imageObj.getImageFileHeight().equals(logoSizeHeight))) {
/* 623 */               merchantLogoImage = imageObj;
/*     */             }
/*     */           }
/* 626 */           if (null != merchantLogoImage) {
/* 627 */             JcrUtil.setProperty(componentNode, "merchantLogo", merchantLogoImage
/* 628 */               .getFileLocation());
/* 629 */             JcrUtil.setProperty(componentNode, "validMerchLogoImg", "VALID");
/*     */             
/*     */ 
/* 632 */             if (!merchantName.equals("")) {
/* 633 */               JcrUtil.setProperty(componentNode, "merchantLogoAltText", merchantName);
/*     */             }
/*     */             
/* 636 */             merchantLogoImage = null;
/*     */           }
/*     */           else {
/* 639 */             JcrUtil.setProperty(componentNode, "merchantLogo", defaultLogoImgPath);
/*     */             
/* 641 */             JcrUtil.setProperty(componentNode, "validMerchLogoImg", defaultLogoImgPath);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 646 */           JcrUtil.setProperty(componentNode, "redemptionInst", vm
/* 647 */             .getMerchantTerms().get("richText"));
/*     */           
/* 649 */           JcrUtil.setProperty(componentNode, "redemptionInst", vm
/* 650 */             .getRedemptionFormatInstructions());
/*     */           
/*     */ 
/* 653 */           JcrUtil.setProperty(componentNode, "redemptionEmail", vm
/* 654 */             .getRedemptionEmail());
/*     */           
/*     */ 
/* 657 */           JcrUtil.setProperty(componentNode, "redemptionURL", vm
/* 658 */             .getRedemptionUrl());
/*     */           
/* 660 */           JcrUtil.setProperty(componentNode, "redemptionTel", vm
/* 661 */             .getRedemptionTelephone().get("richText"));
/*     */           
/* 663 */           String lastModifiedDate = "";
/* 664 */           lastModifiedDate = VppUtil.convertGmtToDate("E, dd MMM yyyy HH:mm:ss z", "yyyy-MM-dd'T'HH:mm:ss", vm
/* 665 */             .getLastModifiedDatetime());
/* 666 */           JcrUtil.setProperty(componentNode, "offerLastModified", lastModifiedDate);
/* 667 */           aemJson.put("offerLastModified", lastModifiedDate);
/* 668 */           List<CardPaymentTypeList> cardPaymentList = vm.getCardPaymentTypeList();
/* 669 */           Iterator<CardPaymentTypeList> cardListIterator = cardPaymentList.iterator();
/* 670 */           cardPayList = new ArrayList();
/* 671 */           while (cardListIterator.hasNext()) {
/* 672 */             CardPaymentTypeList cardPaymentType = (CardPaymentTypeList)cardListIterator.next();
/* 673 */             cardPayList.add(cardPaymentType.getValue());
/*     */           }
/*     */           
/* 676 */           JcrUtil.setProperty(componentNode, "cardPayment", cardPayList
/* 677 */             .toArray(new String[0]));
/*     */           
/* 679 */           JSONArray cardPayJsonArr = new JSONArray(cardPayList);
/* 680 */           aemJson.put("cardPayment", cardPayJsonArr);
/* 681 */           session.save();
/* 682 */           vmorcJson.put(vm.getOfferId(), aemJson);
/*     */         }
/*     */         
/* 685 */         VppUtil.replicateResource(session, offerPath + "/" + "VMORC_OFFER_LIST" + "/" + vm
/* 686 */           .getOfferId(), this.replicator);
/*     */       }
/*     */       
/* 689 */       createJsonFile(vmorcJson.toString(), offerPath);
/*     */     } catch (RepositoryException e) {
/* 691 */       this.logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/*     */     } catch (WCMException e) {
/* 693 */       this.logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/*     */     } finally {
/* 695 */       if (resolver != null) {
/* 696 */         this.logger.debug("resolver closed ");
/* 697 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProgramIds(String path)
/*     */   {
/* 710 */     this.logger.debug("####### getProgramIds path ->######### : " + path);
/* 711 */     ArrayList<Map<String, String>> programMapList = null;
/* 712 */     ArrayList<String> programArray = null;
/* 713 */     String programId = "";
/* 714 */     String[] programList = null;
/* 715 */     ResourceResolver resolver = null;
/* 716 */     Session session = null;
/* 717 */     Node progrmNode = null;
/*     */     try {
/* 719 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 720 */       session = (Session)resolver.adaptTo(Session.class);
/* 721 */       if (session.nodeExists(path + "/" + "VMORC_Offer_Program_List/jcr:content/vmorcProgramList")) {
/* 722 */         progrmNode = session.getNode(path + "/" + "VMORC_Offer_Program_List/jcr:content/vmorcProgramList");
/* 723 */         programArray = new ArrayList();
/* 724 */         if (progrmNode.hasProperty("programInfo")) {
/* 725 */           Property currentProp = progrmNode.getProperty("programInfo");
/* 726 */           if (currentProp.isMultiple()) {
/* 727 */             this.logger.debug(" programinfo is multiple");
/* 728 */             Value[] values = currentProp.getValues();
/* 729 */             for (int i = 0; i < values.length; i++) {
/* 730 */               programArray.add(values[i].getString());
/*     */             }
/*     */           } else {
/* 733 */             this.logger.debug(" programinfo is single");
/* 734 */             programArray.add(currentProp.getValue().getString());
/*     */           }
/*     */         }
/*     */       }
/* 738 */       if (null != programArray) {
/* 739 */         programList = (String[])programArray.toArray(new String[0]);
/*     */         
/* 741 */         programMapList = (ArrayList)VppUtil.getMultiFieldPanelValuesMap(programList);
/*     */       }
/*     */       
/* 744 */       if (null != programMapList) {
/* 745 */         Iterator<Map<String, String>> programIterator = programMapList.iterator();
/* 746 */         while (programIterator.hasNext()) {
/* 747 */           Map<String, String> programMap = (Map)programIterator.next();
/* 748 */           this.logger.debug(" program ids ma ::" + (String)programMap.get("programId"));
/* 749 */           if (programId.equals("")) {
/* 750 */             programId = (String)programMap.get("programId");
/*     */           } else {
/* 752 */             programId = programId + "," + (String)programMap.get("programId");
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 757 */       this.logger.error("node creation exception" + e);
/*     */     } finally {
/* 759 */       if (resolver != null) {
/* 760 */         this.logger.debug("resolver closed ");
/* 761 */         resolver.close();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 766 */     return programId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createJsonFile(String jsonData, String path)
/*     */   {
/* 778 */     String[] payLoadArr = path.split("/");
/* 779 */     StringBuilder sb = new StringBuilder("etc/vpp-tools/offers");
/* 780 */     sb.append("/");
/* 781 */     sb.append(payLoadArr[4]);
/* 782 */     sb.append("/");
/* 783 */     sb.append(payLoadArr[5]);
/* 784 */     String offerJsonLocation = "";
/* 785 */     offerJsonLocation = sb.toString();
/* 786 */     this.logger.debug("offerJSONLocation:: " + offerJsonLocation);
/* 787 */     ResourceResolver resolver = null;
/* 788 */     Session session = null;
/*     */     try
/*     */     {
/* 791 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 792 */       session = (Session)resolver.adaptTo(Session.class);
/* 793 */       Node rootNode = session.getRootNode();
/* 794 */       if (rootNode.hasNode(offerJsonLocation)) {
/* 795 */         Node folderPathNode = rootNode.getNode(offerJsonLocation);
/* 796 */         Node fileNode = null;
/* 797 */         Node fileJcrNode = null;
/* 798 */         if (folderPathNode.hasNode("vmorc_offers.json")) {
/* 799 */           fileNode = folderPathNode.getNode("vmorc_offers.json");
/* 800 */           fileJcrNode = fileNode.getNode("jcr:content");
/* 801 */           this.logger.debug("Update Operation :VMORC JSON Updated");
/*     */         } else {
/* 803 */           fileNode = folderPathNode.addNode("vmorc_offers.json", "nt:file");
/*     */           
/* 805 */           fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 806 */           this.logger.debug("Create Operation : VMORC JSON Created");
/*     */         }
/* 808 */         if (fileJcrNode != null) {
/* 809 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 810 */           fileJcrNode.setProperty("jcr:data", jsonData);
/*     */         }
/*     */       }
/*     */       
/* 814 */       session.save();
/*     */     } catch (PathNotFoundException e) {
/* 816 */       this.logger.error("Path Not Found Exception Occured in UpdateOfferJSON createJsonFile() :" + e);
/*     */     } catch (RepositoryException e) {
/* 818 */       this.logger.error("node creation exception" + e);
/*     */     } finally {
/* 820 */       if (resolver != null) {
/* 821 */         this.logger.debug("resolver closed ");
/* 822 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getAccessToken()
/*     */   {
/* 836 */     this.logger.debug("inside getAccessToken  :: ");
/*     */     
/* 838 */     CloseableHttpClient client = null;
/* 839 */     CloseableHttpResponse response = null;
/*     */     
/* 841 */     String accessToken = null;
/* 842 */     StringBuilder offerJson = new StringBuilder("");
/* 843 */     BufferedReader br = null;
/*     */     try {
/* 845 */       if (PROXY_ENABLED) {
/* 846 */         HttpHost proxy = new HttpHost(PROXY_HOST, PROXY_PORT);
/* 847 */         Credentials credentials = new UsernamePasswordCredentials(USERNAME, PASSWORD);
/* 848 */         AuthScope authScope = new AuthScope(PROXY_HOST, PROXY_PORT);
/* 849 */         CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
/* 850 */         credentialsProvider.setCredentials(authScope, credentials);
/*     */         
/* 852 */         client = HttpClientBuilder.create().setProxy(proxy).setDefaultCredentialsProvider(credentialsProvider).build();
/*     */       }
/*     */       else {
/* 855 */         client = HttpClientBuilder.create().build();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 860 */       List<NameValuePair> urlParameters = new ArrayList();
/* 861 */       urlParameters.add(new BasicNameValuePair("grant_type", GRANT_TYPE));
/* 862 */       urlParameters.add(new BasicNameValuePair("client_id", CLIENT_ID));
/* 863 */       urlParameters.add(new BasicNameValuePair("client_secret", CLIENT_SECRET_KEY));
/* 864 */       HttpPost postRequest = new HttpPost(TOKEN_GENERATION_URL);
/* 865 */       postRequest.setEntity(new UrlEncodedFormEntity(urlParameters));
/*     */       
/* 867 */       response = client.execute(postRequest);
/*     */       
/* 869 */       if (response.getStatusLine().getStatusCode() != 200) {
/* 870 */         this.logger.error("Failed : HTTP error code :  :: " + response.getStatusLine().getStatusCode());
/*     */         
/* 872 */         throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
/*     */       }
/* 874 */       br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF8"));
/* 875 */       String output; while ((output = br.readLine()) != null) {
/* 876 */         offerJson = offerJson.append(output);
/*     */       }
/* 878 */       this.logger.debug("offerJSON :: " + offerJson);
/* 879 */       JSONObject jsonObj; if (!offerJson.toString().equals("")) {
/* 880 */         jsonObj = new JSONObject(offerJson.toString());
/* 881 */         this.logger.debug("access_token :: " + jsonObj.get("access_token").toString());
/* 882 */         accessToken = jsonObj.get("access_token").toString();
/*     */       }
/*     */       
/* 885 */       return accessToken;
/*     */     }
/*     */     catch (RuntimeException e) {
/* 888 */       this.logger.error("RuntimeException  :: " + e);
/*     */     }
/*     */     catch (Exception e) {
/* 891 */       this.logger.error("Exception while parsing JSON :: " + e);
/*     */     } finally {
/* 893 */       if (br != null) {
/*     */         try {
/* 895 */           br.close();
/*     */         } catch (Exception e) {
/* 897 */           this.logger.error("Exception while closing reader :: " + e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 902 */     return accessToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HashMap<String, String> getImageDimension(String path)
/*     */   {
/* 912 */     this.logger.debug("####### getImageDimension path ->######### : " + path);
/* 913 */     HashMap<String, String> dimensionMap = null;
/*     */     
/* 915 */     ResourceResolver resolver = null;
/* 916 */     Session session = null;
/* 917 */     Node progrmNode = null;
/*     */     try {
/* 919 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 920 */       session = (Session)resolver.adaptTo(Session.class);
/* 921 */       if (session.nodeExists(path + "/" + "VMORC_Offer_Program_List/jcr:content/imageDimension")) {
/* 922 */         progrmNode = session.getNode(path + "/" + "VMORC_Offer_Program_List/jcr:content/imageDimension");
/* 923 */         dimensionMap = new HashMap();
/* 924 */         if (progrmNode.hasProperty("fileReferenceHeroImage"))
/*     */         {
/* 926 */           Property currentProp = progrmNode.getProperty("fileReferenceHeroImage");
/* 927 */           dimensionMap.put("fileReferenceHeroImage", currentProp
/* 928 */             .getValue().getString());
/* 929 */           this.logger.debug("hero image" + currentProp.getValue().getString());
/*     */           
/* 931 */           String heroImage = progrmNode.getProperty("fileReferenceHeroImage").getString();
/* 932 */           Resource res = resolver.getResource(heroImage);
/* 933 */           String heroImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 934 */           this.logger.debug("Current Hero Image Width_Height  : " + heroImgWidthHeight);
/* 935 */           dimensionMap.put("hero_image_size", heroImgWidthHeight);
/*     */         }
/*     */         
/* 938 */         if (progrmNode.hasProperty("fileReferenceThumbImage"))
/*     */         {
/* 940 */           Property currentProp = progrmNode.getProperty("fileReferenceThumbImage");
/* 941 */           dimensionMap.put("fileReferenceThumbImage", currentProp
/* 942 */             .getValue().getString());
/* 943 */           this.logger.debug("FILE_REFERENCE_THUMB_IMAGE " + currentProp.getValue().getString());
/*     */           
/* 945 */           String thumbImage = progrmNode.getProperty("fileReferenceThumbImage").getString();
/* 946 */           Resource resThumb = resolver.getResource(thumbImage);
/* 947 */           String thumbImgWidthHeight = VppUtil.getImageWidthHeight(resThumb);
/* 948 */           this.logger.debug("Current thumb Image Width_Height  : " + thumbImgWidthHeight);
/* 949 */           dimensionMap.put("thumb_image_size", thumbImgWidthHeight);
/*     */         }
/* 951 */         if (progrmNode.hasProperty("fileReferenceLogoImage"))
/*     */         {
/* 953 */           Property currentProp = progrmNode.getProperty("fileReferenceLogoImage");
/* 954 */           dimensionMap.put("fileReferenceLogoImage", currentProp
/* 955 */             .getValue().getString());
/* 956 */           this.logger.debug("FILE_REFERENCE_LOGO_IMAGE" + currentProp.getValue().getString());
/*     */           
/* 958 */           String logoImage = progrmNode.getProperty("fileReferenceLogoImage").getString();
/* 959 */           Resource resThumb = resolver.getResource(logoImage);
/* 960 */           String thumbImgWidthHeight = VppUtil.getImageWidthHeight(resThumb);
/* 961 */           this.logger.debug("Current logo Image Width_Height  : " + thumbImgWidthHeight);
/* 962 */           dimensionMap.put("logo_image_size", thumbImgWidthHeight);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 967 */       this.logger.error("node creation exception" + e);
/*     */     } finally {
/* 969 */       if (resolver != null) {
/* 970 */         this.logger.debug("resolver closed ");
/* 971 */         resolver.close();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 976 */     return dimensionMap;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     this.settingsService = paramSlingSettingsService;
/*     */   }
/*     */   
/*     */   protected void unbindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     if (this.settingsService == paramSlingSettingsService) {
/*     */       this.settingsService = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     this.replicator = paramReplicator;
/*     */   }
/*     */   
/*     */   protected void unbindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     if (this.replicator == paramReplicator) {
/*     */       this.replicator = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\scheduler\VmorcScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */