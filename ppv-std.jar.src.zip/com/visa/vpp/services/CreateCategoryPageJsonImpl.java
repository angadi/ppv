/*     */ package com.visa.vpp.services;
/*     */ 
/*     */ import com.visa.vpp.interfaces.CreateCategoryPageJson;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service
/*     */ @Component
/*     */ public class CreateCategoryPageJsonImpl
/*     */   implements CreateCategoryPageJson
/*     */ {
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*  35 */   private Logger logger = LoggerFactory.getLogger(CreateCategoryPageJsonImpl.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JSONObject getCreateCategoryPageJson(String catJcrPath)
/*     */   {
/*  44 */     this.logger.debug("catJcrPath" + catJcrPath);
/*  45 */     JSONObject catPageJson = new JSONObject();
/*     */     
/*  47 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*  48 */     Session session = (Session)resolver.adaptTo(Session.class);
/*     */     try {
/*  50 */       Node rootNode = session.getRootNode();
/*  51 */       if (rootNode.hasNode(catJcrPath.substring(1))) {
/*  52 */         Node catJcrPathNode = rootNode.getNode(catJcrPath.substring(1));
/*     */         
/*  54 */         if (catJcrPathNode.hasNode("featured_offers")) {
/*  55 */           JSONArray featuredOfferArray = new JSONArray();
/*  56 */           Node featuredOfferNode = catJcrPathNode.getNode("featured_offers");
/*  57 */           NodeIterator nodeIt = featuredOfferNode.getNodes();
/*  58 */           while (nodeIt.hasNext()) {
/*  59 */             Node childOfferNode = nodeIt.nextNode();
/*  60 */             JSONObject featuredOfferChildJson = offerNodeData(childOfferNode);
/*  61 */             if ((featuredOfferChildJson.length() != 0) && 
/*  62 */               (featuredOfferChildJson.has("offerId"))) {
/*  63 */               featuredOfferArray.put(featuredOfferChildJson);
/*     */             }
/*     */           }
/*  66 */           catPageJson.put("featured_offers", featuredOfferArray);
/*     */         }
/*     */         
/*  69 */         if (catJcrPathNode.hasNode("more_offers")) {
/*  70 */           JSONArray moreOfferArray = new JSONArray();
/*  71 */           Node moreOfferNode = catJcrPathNode.getNode("more_offers");
/*  72 */           NodeIterator nodeIt = moreOfferNode.getNodes();
/*  73 */           while (nodeIt.hasNext()) {
/*  74 */             Node childOfferNode = nodeIt.nextNode();
/*  75 */             JSONObject moreOfferChildJson = offerNodeData(childOfferNode);
/*  76 */             if ((moreOfferChildJson.length() != 0) && (moreOfferChildJson.has("offerId"))) {
/*  77 */               moreOfferArray.put(moreOfferChildJson);
/*     */             }
/*     */           }
/*  80 */           catPageJson.put("more_offers", moreOfferArray);
/*     */         }
/*  82 */         this.logger.debug("catPageJson" + catPageJson);
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/*  86 */       this.logger.debug("RepositoryException in getCreateCategoryPageJson() of CreateCategoryPageJsonImpl" + e
/*  87 */         .getMessage());
/*     */     } catch (JSONException e) {
/*  89 */       this.logger.debug("JSONException in getCreateCategoryPageJson() of CreateCategoryPageJsonImpl" + e
/*  90 */         .getMessage());
/*     */     }
/*  92 */     return catPageJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject offerNodeData(Node childNode)
/*     */   {
/* 102 */     JSONObject offerNodeJson = new JSONObject();
/* 103 */     String offerId = propertyValue(childNode, "offerId");
/* 104 */     String offerShortDesc = propertyValue(childNode, "offerShortDesc");
/* 105 */     String pageType = propertyValue(childNode, "pageType");
/* 106 */     String merchantName = propertyValue(childNode, "merchantName");
/* 107 */     String offerSource = propertyValue(childNode, "offerSource");
/* 108 */     String offerTitle = propertyValue(childNode, "offerTitle");
/* 109 */     String previewUrl = propertyValue(childNode, "previewURL");
/* 110 */     String thumbImage = propertyValue(childNode, "thumbImage");
/* 111 */     String offerLastModified = propertyValue(childNode, "offerLastModified");
/* 112 */     this.logger.debug("merchantName  :::: " + merchantName);
/*     */     try {
/* 114 */       if ((offerId.trim().length() != 0) && (offerShortDesc.trim().length() != 0) && 
/* 115 */         (offerTitle.trim().length() != 0) && (!thumbImage.trim().equalsIgnoreCase("failure"))) {
/* 116 */         offerNodeJson.put("offerId", offerId);
/* 117 */         offerNodeJson.put("offerShortDesc", offerShortDesc);
/* 118 */         offerNodeJson.put("pageType", pageType);
/* 119 */         offerNodeJson.put("merchantName", "wajeeth1");
/* 120 */         offerNodeJson.put("offerSource", offerSource);
/* 121 */         offerNodeJson.put("offerTitle", offerTitle);
/* 122 */         offerNodeJson.put("previewURL", previewUrl);
/* 123 */         offerNodeJson.put("thumbImage", thumbImage);
/* 124 */         offerNodeJson.put("offerLastModified", offerLastModified);
/*     */       }
/*     */     } catch (JSONException e) {
/* 127 */       this.logger.error("JSONException in offerNodeData() of CategoryPageJsonForLazyLoading " + e
/* 128 */         .getMessage());
/*     */     }
/* 130 */     return offerNodeJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String propertyValue(Node node, String propertyName)
/*     */   {
/* 141 */     String propertyValue = "";
/*     */     try {
/* 143 */       if (node.hasProperty(propertyName)) {
/* 144 */         propertyValue = node.getProperty(propertyName).getValue().getString();
/* 145 */         this.logger.debug(propertyName + ":" + propertyValue);
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 148 */       this.logger.debug("RepositoryException in propertyValue() of CreateCategoryPageJsonImpl" + e
/* 149 */         .getMessage());
/*     */     }
/* 151 */     return propertyValue;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\services\CreateCategoryPageJsonImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */