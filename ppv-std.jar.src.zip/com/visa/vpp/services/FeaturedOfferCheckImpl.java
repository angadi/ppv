/*    */ package com.visa.vpp.services;
/*    */ 
/*    */ import com.visa.vpp.interfaces.FeaturedOfferCheck;
/*    */ import com.visa.vpp.utill.VppJsonUtil;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service
/*    */ @Component
/*    */ public class FeaturedOfferCheckImpl
/*    */   implements FeaturedOfferCheck
/*    */ {
/*    */   @Reference
/*    */   private ResourceResolverFactory resolverFactory;
/* 32 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String checkFeaturedOffers(String pagePath)
/*    */   {
/* 42 */     this.logger.debug("pagePath" + pagePath);
/* 43 */     String checkFeaturedOffers = "true";
/*    */     
/* 45 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 46 */     Session session = (Session)resolver.adaptTo(Session.class);
/*    */     try {
/* 48 */       Node rootNode = session.getRootNode();
/* 49 */       if (rootNode.hasNode(pagePath.substring(1))) {
/* 50 */         Node featuredOfferNode = rootNode.getNode(pagePath.substring(1));
/* 51 */         if (featuredOfferNode.hasNodes()) {
/* 52 */           this.logger.debug("it has featured offer nodes");
/* 53 */           checkFeaturedOffers = "false";
/*    */         }
/*    */       }
/*    */       
/* 57 */       this.logger.debug("checkFeaturedOffers" + checkFeaturedOffers);
/*    */     } catch (RepositoryException e) {
/* 59 */       this.logger.error("RepositoryException" + e.getMessage());
/*    */     } finally {
/* 61 */       VppJsonUtil.closeResolver(resolver);
/*    */     }
/*    */     
/* 64 */     return checkFeaturedOffers;
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\services\FeaturedOfferCheckImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */