/*    */ package com.visa.vpp.services;
/*    */ 
/*    */ import com.visa.vpp.interfaces.TemplateConfig;
/*    */ import java.util.Map;
/*    */ import org.apache.felix.scr.annotations.Activate;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.commons.osgi.PropertiesUtil;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component(metatype=true, label="Template Configurations", description="This service provides configuration details of the Templates to be used by users")
/*    */ @Service({TemplateConfig.class})
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="authorTemplatePaths", label="Templates Allowed for Authors", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to authors here"), @org.apache.felix.scr.annotations.Property(name="approverTemplatePaths", label="Templates Allowed for Approver", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to approvers here"), @org.apache.felix.scr.annotations.Property(name="adminTemplatePaths", label="Templates Allowed for Admins", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to admins here")})
/*    */ public class TemplateConfigImpl
/*    */   implements TemplateConfig
/*    */ {
/* 42 */   private static final Logger LOG = LoggerFactory.getLogger(TemplateConfigImpl.class);
/*    */   private String[] authorTemplatePaths;
/*    */   private String[] approverTemplatePaths;
/*    */   private String[] adminTemplatePaths;
/*    */   
/*    */   @Activate
/*    */   protected void activate(Map<String, Object> properties)
/*    */   {
/* 50 */     LOG.info("[*** AEM ConfigurationService]: activating configuration service");
/* 51 */     readProperties(properties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void readProperties(Map<String, Object> properties)
/*    */   {
/* 61 */     this.authorTemplatePaths = PropertiesUtil.toStringArray(properties.get("authorTemplatePaths"));
/*    */     
/* 63 */     this.approverTemplatePaths = PropertiesUtil.toStringArray(properties.get("approverTemplatePaths"));
/*    */     
/* 65 */     this.adminTemplatePaths = PropertiesUtil.toStringArray(properties.get("adminTemplatePaths"));
/*    */   }
/*    */   
/*    */   public String[] getAuthorTemplatePaths() {
/* 69 */     return this.authorTemplatePaths;
/*    */   }
/*    */   
/*    */   public String[] getApproverTemplatePaths() {
/* 73 */     return this.approverTemplatePaths;
/*    */   }
/*    */   
/*    */   public String[] getAdminTemplatePaths() {
/* 77 */     return this.adminTemplatePaths;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\services\TemplateConfigImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */