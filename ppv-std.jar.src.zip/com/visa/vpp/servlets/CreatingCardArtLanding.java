/*     */ package com.visa.vpp.servlets;
/*     */ 
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/cardArtLanding"}, methods={"GET"}, metatype=false)
/*     */ public class CreatingCardArtLanding
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   private static final Logger logger = LoggerFactory.getLogger(CreatingCardArtLanding.class);
/*     */   
/*     */   private static final String PAGE_PATH = "pagePath";
/*     */   private static final String CARD_ART_LANDING_PATH = "/jcr:content/cardArtLanding";
/*     */   private static final String JCR_CONTENT = "jcr:content";
/*     */   private static final String CARD_ART_LANDING = "cardArtLanding";
/*     */   private static final String UNSTRUCTURED = "nt:unstructured";
/*     */   private static final String BUTTON_LABEL1 = "buttonLabel1";
/*     */   private static final String BUTTON_LABEL2 = "buttonLabel2";
/*     */   private static final String CARD_LOGO = "cardLogo";
/*     */   private static final String CARD_LOGO_ALT_TEXT = "cardLogoAltText";
/*     */   private static final String IS_CLICKABLE = "isClickable";
/*     */   private static final String TITLE = "title";
/*     */   private static final String SLING_RESOURCE_TYPE = "sling:resourceType";
/*     */   private static final String CARD_IMAGE_MAP = "cardImageMapnested";
/*     */   private static final String CARD_IMAGE_MAP_ORIG = "cardImageMap";
/*     */   private static final String ALT_TEXT = "alttext";
/*     */   private static final String LINK = "link";
/*     */   private static final String LINK_NAME = "linkName";
/*     */   private static final String LINK_REFERENCE = "linkReference";
/*     */   private static final String LINK_TEXT = "linkText";
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  66 */     String pagePath = request.getParameter("pagePath");
/*     */     
/*  68 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*  69 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  70 */     pagePath = xssApi.encodeForHTML(pagePath);
/*  71 */     String buttonLabel1 = "";
/*  72 */     String buttonLabel2 = "";
/*  73 */     String cardLogo = "";
/*  74 */     String cardLogoAltText = "";
/*  75 */     String isClickable = "";
/*  76 */     String title = "";
/*  77 */     String slingResourceType = "";
/*     */     try {
/*  79 */       logger.debug("inside Creating CardARtLanding");
/*  80 */       Session session = (Session)resolver.adaptTo(Session.class);
/*  81 */       if (session.nodeExists(pagePath)) {
/*  82 */         Node pageNode = session.getNode(pagePath);
/*  83 */         Node parentNode = pageNode.getParent();
/*  84 */         String parentPath = parentNode.getPath();
/*  85 */         if (session.nodeExists(parentPath + "/jcr:content/cardArtLanding")) {
/*  86 */           Node parentJcr = session.getNode(parentPath + "/jcr:content/cardArtLanding");
/*  87 */           if (pageNode.hasNode("jcr:content")) {
/*  88 */             Node childNode = pageNode.getNode("jcr:content");
/*  89 */             if (childNode.hasNode("cardArtLanding")) {
/*  90 */               childNode.getNode("cardArtLanding").remove();
/*     */             }
/*  92 */             Node cardArtLandingNode = childNode.addNode("cardArtLanding", "nt:unstructured");
/*  93 */             if (parentJcr.hasProperty("buttonLabel1")) {
/*  94 */               buttonLabel1 = parentJcr.getProperty("buttonLabel1").getValue().getString();
/*  95 */               cardArtLandingNode.setProperty("buttonLabel1", buttonLabel1);
/*     */             }
/*  97 */             if (parentJcr.hasProperty("buttonLabel2")) {
/*  98 */               buttonLabel2 = parentJcr.getProperty("buttonLabel2").getValue().getString();
/*  99 */               cardArtLandingNode.setProperty("buttonLabel2", buttonLabel2);
/*     */             }
/* 101 */             if (parentJcr.hasProperty("cardLogo")) {
/* 102 */               cardLogo = parentJcr.getProperty("cardLogo").getValue().getString();
/* 103 */               cardArtLandingNode.setProperty("cardLogo", cardLogo);
/*     */             }
/* 105 */             if (parentJcr.hasProperty("cardLogoAltText")) {
/* 106 */               cardLogoAltText = parentJcr.getProperty("cardLogoAltText").getValue().getString();
/* 107 */               cardArtLandingNode.setProperty("cardLogoAltText", cardLogoAltText);
/*     */             }
/* 109 */             if (parentJcr.hasProperty("isClickable")) {
/* 110 */               isClickable = parentJcr.getProperty("isClickable").getValue().getString();
/* 111 */               cardArtLandingNode.setProperty("isClickable", isClickable);
/*     */             }
/* 113 */             if (parentJcr.hasProperty("title")) {
/* 114 */               title = parentJcr.getProperty("title").getValue().getString();
/* 115 */               cardArtLandingNode.setProperty("title", title);
/*     */             }
/* 117 */             if (parentJcr.hasProperty("sling:resourceType")) {
/* 118 */               slingResourceType = parentJcr.getProperty("sling:resourceType").getValue().getString();
/* 119 */               cardArtLandingNode.setProperty("sling:resourceType", slingResourceType);
/*     */             }
/* 121 */             if (parentJcr.hasProperty("cardImageMapnested")) {
/* 122 */               if (parentJcr.getProperty("cardImageMapnested").isMultiple()) {
/* 123 */                 Value[] values = parentJcr.getProperty("cardImageMapnested").getValues();
/* 124 */                 cardArtLandingNode.setProperty("cardImageMapnested", values);
/*     */               } else {
/* 126 */                 String cardImageMap = parentJcr.getProperty("cardImageMapnested").getValue().getString();
/* 127 */                 cardArtLandingNode.setProperty("cardImageMapnested", cardImageMap);
/*     */               }
/*     */             }
/* 130 */             if (parentJcr.hasNode("cardImageMap")) {
/* 131 */               Node parentCardImageMapNode = parentJcr.getNode("cardImageMap");
/* 132 */               if (cardArtLandingNode.hasNode("cardImageMap")) {
/* 133 */                 cardArtLandingNode.getNode("cardImageMap").remove();
/*     */               }
/* 135 */               Node cardIMageMapNode = cardArtLandingNode.addNode("cardImageMap", "nt:unstructured");
/* 136 */               NodeIterator iterator = parentCardImageMapNode.getNodes();
/* 137 */               while (iterator.hasNext()) {
/* 138 */                 Node parentImageMapNode = iterator.nextNode();
/*     */                 
/* 140 */                 Node cardLandingNode = cardIMageMapNode.addNode(parentImageMapNode.getName(), "nt:unstructured");
/* 141 */                 if (parentImageMapNode.hasProperty("alttext")) {
/* 142 */                   String alt = parentImageMapNode.getProperty("alttext").getValue().getString();
/* 143 */                   cardLandingNode.setProperty("alttext", alt);
/*     */                 }
/* 145 */                 if (parentImageMapNode.hasProperty("link")) {
/* 146 */                   String link = parentImageMapNode.getProperty("link").getValue().getString();
/* 147 */                   cardLandingNode.setProperty("link", link);
/*     */                 }
/* 149 */                 if (parentImageMapNode.hasProperty("linkName"))
/*     */                 {
/* 151 */                   String linkName = parentImageMapNode.getProperty("linkName").getValue().getString();
/* 152 */                   cardLandingNode.setProperty("linkName", linkName);
/*     */                 }
/* 154 */                 if (parentImageMapNode.hasProperty("linkReference"))
/*     */                 {
/* 156 */                   String linkReference = parentImageMapNode.getProperty("linkReference").getValue().getString();
/* 157 */                   cardLandingNode.setProperty("linkReference", linkReference);
/*     */                 }
/* 159 */                 if (parentImageMapNode.hasProperty("linkText"))
/*     */                 {
/* 161 */                   String linkText = parentImageMapNode.getProperty("linkText").getValue().getString();
/* 162 */                   cardLandingNode.setProperty("linkText", linkText);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 169 */         session.save();
/*     */       } else {
/* 171 */         logger.debug("path is not found so card art node is not created!!");
/*     */       }
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 175 */       logger.error("PathNotFoundException" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 177 */       logger.error("RepositoryException" + e.getMessage());
/*     */     } finally {
/* 179 */       VppJsonUtil.closeResolver(resolver);
/*     */     }
/* 181 */     response.setContentType("application/text");
/* 182 */     response.getWriter().write(cardLogo);
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\servlets\CreatingCardArtLanding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */