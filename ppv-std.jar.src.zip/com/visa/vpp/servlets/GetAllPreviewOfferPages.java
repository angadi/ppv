/*     */ package com.visa.vpp.servlets;
/*     */ 
/*     */ import com.visa.vpp.services.GetOfferDataImpl;
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.ItemNotFoundException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/getAllPreviewOfferPages"}, methods={"POST"}, metatype=false)
/*     */ public class GetAllPreviewOfferPages
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURRENT_OFFER = "currentOffer";
/*     */   private static final String CURRENT_OFFER_DATA = "currentOfferData";
/*     */   private static final String CURRENT_OFFER_INDEX = "currentOfferIndex";
/*     */   private static final String CURRENT_PREVIEW_URL = "currentPreviewUrl";
/*     */   private static final String CURR_OFFER_ID = "currOfferId";
/*     */   private static final String CURR_PAGE_PATH = "currPagePath";
/*     */   private static final String CAT_PAGE_NAME = "catPageName";
/*     */   private static final String PREVIEW_URLS = "previewUrls";
/*     */   private static final String OFFER_ID_LIST = "offerIdList";
/*     */   private static final String CAT_PAGE_PATH = "catPagePath";
/*     */   private static final String PARENT_NAME = "parentName";
/*     */   private static final String IS_SEARCH_PREVIEW = "isSearchPreview";
/*     */   private static final String SEARCH_ALL = "ALL";
/*     */   private static final String NOTIFICATION_TEXT = "optionalParsys/notification_text";
/*     */   private static final String DISCLAIMER_TEXT = "disclaimerText";
/*  63 */   private static final Logger log = LoggerFactory.getLogger(GetAllPreviewOfferPages.class);
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  75 */     JSONObject offerData = getOfferData(request);
/*  76 */     response.setContentType("application/json");
/*  77 */     response.setCharacterEncoding("UTF-8");
/*  78 */     response.getWriter().write(offerData.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getOfferData(SlingHttpServletRequest request)
/*     */   {
/*  91 */     Session session = null;
/*  92 */     JSONObject allOffers = new JSONObject();
/*  93 */     ResourceResolver resolver = null;
/*     */     try {
/*  95 */       GetOfferDataImpl getCurrentOffer = new GetOfferDataImpl();
/*  96 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*  97 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  98 */       String currentOffer = request.getParameter("currentOffer");
/*  99 */       currentOffer = xssApi.encodeForHTML(currentOffer);
/* 100 */       String catPagePath = request.getParameter("catPagePath");
/* 101 */       catPagePath = xssApi.encodeForHTML(catPagePath);
/* 102 */       String parentName = request.getParameter("parentName");
/* 103 */       parentName = xssApi.encodeForHTML(parentName);
/* 104 */       String isSearchPreview = request.getParameter("isSearchPreview");
/* 105 */       isSearchPreview = xssApi.encodeForHTML(isSearchPreview);
/* 106 */       String currOfferId = request.getParameter("currOfferId");
/* 107 */       currOfferId = xssApi.encodeForHTML(currOfferId);
/* 108 */       String currPagePath = request.getParameter("currPagePath");
/* 109 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/* 110 */       String catPageName = request.getParameter("catPageName");
/* 111 */       catPageName = xssApi.encodeForHTML(catPageName);
/* 112 */       session = (Session)resolver.adaptTo(Session.class);
/*     */       
/* 114 */       if (currentOffer == null) {
/* 115 */         if (currPagePath != null) {
/* 116 */           allOffers = handleUrlHit(session, currPagePath, currOfferId, catPageName);
/* 117 */           if (allOffers.has("currentPreviewUrl")) {
/* 118 */             allOffers.put("currentOfferData", getCurrentOffer
/* 119 */               .getCurrentOfferData(allOffers.getString("currentPreviewUrl"), resolver));
/*     */           }
/*     */         } else {
/* 122 */           log.debug("URL accessed with invalid parameters");
/*     */         }
/* 124 */       } else if ((catPagePath != null) && (parentName != null)) {
/* 125 */         allOffers = getAllOfferPreviewUrls(session, currentOffer, catPagePath, parentName);
/* 126 */         if (allOffers.has("currentPreviewUrl")) {
/* 127 */           allOffers.put("currentOfferData", getCurrentOffer
/* 128 */             .getCurrentOfferData(allOffers.getString("currentPreviewUrl"), resolver));
/*     */         }
/*     */       } else {
/* 131 */         allOffers.put("currentOfferData", getCurrentOffer
/* 132 */           .getCurrentOfferData(currentOffer, resolver));
/* 133 */         if ((isSearchPreview != null) && (isSearchPreview.equalsIgnoreCase("yes"))) {
/* 134 */           JSONObject previewUrls = new JSONObject();
/* 135 */           previewUrls.put("currentOffer", currentOffer);
/* 136 */           allOffers.put("previewUrls", previewUrls);
/* 137 */           allOffers.put("currentOfferIndex", "0");
/* 138 */           allOffers.put("catPagePath", catPagePath + ".html");
/* 139 */           allOffers.put("catPageName", "ALL");
/*     */         }
/*     */       }
/*     */     } catch (JSONException e) {
/* 143 */       log.error("JSON Exception Occured in GetAllPreviewOfferPages getOfferData() :" + e
/* 144 */         .getMessage());
/*     */     } catch (Exception e) {
/* 146 */       log.error("Exception Occured in GetAllPreviewOfferPages getOfferData() :" + e.getMessage());
/*     */     } finally {
/* 148 */       VppJsonUtil.closeResolver(resolver);
/*     */     }
/* 150 */     return allOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getAllOfferPreviewUrls(Session session, String currentOffer, String catPagePath, String parentName)
/*     */   {
/* 165 */     JSONObject allOffers = new JSONObject();
/* 166 */     String catPageName = "";
/*     */     try {
/* 168 */       StringBuilder sb = new StringBuilder(catPagePath.substring(1));
/* 169 */       sb.append("/");
/* 170 */       sb.append("jcr:content");
/* 171 */       Node rootNode = session.getRootNode();
/* 172 */       String disclaimText = "";
/* 173 */       if (rootNode.hasNode(sb.toString())) {
/* 174 */         Node catJcrNode = rootNode.getNode(sb.toString());
/* 175 */         catPageName = catJcrNode.getProperty("jcr:title").getString();
/* 176 */         if (catJcrNode.hasNode("optionalParsys/notification_text")) {
/* 177 */           Node notificationTextNode = catJcrNode.getNode("optionalParsys/notification_text");
/* 178 */           if (notificationTextNode.hasProperty("disclaimerText")) {
/* 179 */             disclaimText = notificationTextNode.getProperty("disclaimerText").getString();
/*     */           }
/*     */         }
/*     */       }
/* 183 */       allOffers.put("disclaimerText", disclaimText);
/* 184 */       sb.append("/");
/* 185 */       sb.append(parentName);
/* 186 */       String parentNodePath = sb.toString();
/* 187 */       if (rootNode.hasNode(parentNodePath)) {
/* 188 */         Node parentNode = rootNode.getNode(parentNodePath);
/* 189 */         JSONObject previewUrls = new JSONObject();
/* 190 */         JSONObject offerIds = new JSONObject();
/* 191 */         NodeIterator offerNodeItr = parentNode.getNodes();
/* 192 */         int currentOfferIndex = 0;
/* 193 */         int offerIndex = 0;
/* 194 */         String previewUrl = "";
/* 195 */         while (offerNodeItr.hasNext()) {
/* 196 */           Node childNode = offerNodeItr.nextNode();
/* 197 */           if ((childNode.hasProperty("offerId")) && 
/* 198 */             (childNode.hasProperty("previewURL"))) {
/* 199 */             String currentPreviewUrl = childNode.getProperty("previewURL").getString();
/* 200 */             String currentOfferId = childNode.getProperty("offerId").getString();
/* 201 */             if (currentOfferId.equals(currentOffer)) {
/* 202 */               offerIndex = currentOfferIndex;
/* 203 */               previewUrl = currentPreviewUrl;
/*     */             }
/* 205 */             String currOfferIndexString = Integer.toString(currentOfferIndex);
/* 206 */             previewUrls.put(currOfferIndexString, currentPreviewUrl);
/* 207 */             offerIds.put(currOfferIndexString, currentOfferId);
/* 208 */             currentOfferIndex += 1;
/*     */           }
/*     */         }
/* 211 */         allOffers.put("previewUrls", previewUrls);
/* 212 */         allOffers.put("offerIdList", offerIds);
/* 213 */         allOffers.put("currentOfferIndex", Integer.toString(offerIndex));
/* 214 */         allOffers.put("catPageName", catPageName);
/* 215 */         allOffers.put("currentPreviewUrl", previewUrl);
/* 216 */         allOffers.put("catPagePath", catPagePath + ".html");
/* 217 */         log.debug("JSON created successfully for Preview Page : On load ");
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 220 */       log.error("Repository Exception Occured in GetAllPreviewOfferPages getAllOfferPreviewURLs() :" + e
/* 221 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 223 */       log.error("JSON Exception Occured in GetAllPreviewOfferPages getAllOfferPreviewURLs()");
/*     */     } catch (Exception e) {
/* 225 */       log.error("Exception Occured in GetAllPreviewOfferPages getAllOfferPreviewURLs() :" + e
/* 226 */         .getMessage());
/*     */     }
/* 228 */     return allOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject handleUrlHit(Session jcrSession, String currPagePath, String currOfferId, String catPageName)
/*     */   {
/* 243 */     JSONObject allOffers = new JSONObject();
/*     */     try {
/* 245 */       JSONObject previewUrls = new JSONObject();
/* 246 */       String currPreviewUrl = "";
/* 247 */       StringBuilder sb = new StringBuilder();
/* 248 */       String catPagePath = "";
/* 249 */       sb.append(currPagePath.substring(0, currPagePath.lastIndexOf("/")))
/* 250 */         .append("/").append(catPageName);
/* 251 */       catPagePath = sb.toString();
/* 252 */       previewUrls.put("currOfferId", currOfferId);
/* 253 */       allOffers.put("previewUrls", previewUrls);
/* 254 */       allOffers.put("currentOfferIndex", "0");
/* 255 */       Node offerNode = VppUtil.getCatgoryOfferNode(jcrSession, catPagePath, currOfferId);
/* 256 */       log.debug("Category Page Path " + sb.toString());
/* 257 */       if (offerNode != null) {
/* 258 */         if (offerNode.hasProperty("previewURL")) {
/* 259 */           currPreviewUrl = offerNode.getProperty("previewURL").getString();
/*     */         }
/* 261 */         Node catJcrNode = offerNode.getParent().getParent();
/* 262 */         allOffers.put("currentPreviewUrl", currPreviewUrl);
/* 263 */         allOffers.put("catPagePath", catPagePath + ".html");
/* 264 */         allOffers.put("catPageName", catJcrNode.getProperty("jcr:title").getString());
/*     */       }
/* 266 */       else if (catPageName.equalsIgnoreCase("ALL")) {
/* 267 */         currPreviewUrl = getOfferPreviewUrl(jcrSession, currPagePath, currOfferId);
/* 268 */         allOffers.put("currentPreviewUrl", currPreviewUrl);
/* 269 */         allOffers.put("catPagePath", currPagePath
/* 270 */           .substring(0, currPagePath.lastIndexOf("/")) + ".html");
/*     */         
/* 272 */         allOffers.put("catPageName", "ALL");
/*     */       } else {
/* 274 */         log.debug("Offer Not Found on Category Page Or Category Page not available");
/*     */       }
/*     */     }
/*     */     catch (AccessDeniedException e) {
/* 278 */       log.error("AccessDeniedException Occured in GetAllPreviewOfferPages handleUrlHit() :" + e
/* 279 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 281 */       log.error("ValueFormatException Occured in GetAllPreviewOfferPages handleUrlHit() :" + e
/* 282 */         .getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 284 */       log.error("PathNotFoundException Occured in GetAllPreviewOfferPages handleUrlHit() :" + e
/* 285 */         .getMessage());
/*     */     } catch (ItemNotFoundException e) {
/* 287 */       log.error("ItemNotFoundException Occured in GetAllPreviewOfferPages handleUrlHit() :" + e
/* 288 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 290 */       log.error("Repository Exception Occured in GetAllPreviewOfferPages handleUrlHit() :" + e
/* 291 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 293 */       log.error("JSON Exception Occured in GetAllPreviewOfferPages handleUrlHit()");
/*     */     } catch (Exception e) {
/* 295 */       log.error("Exception Occured in GetAllPreviewOfferPages handleUrlHit() :" + e.getMessage());
/*     */     }
/* 297 */     return allOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getOfferPreviewUrl(Session jcrSession, String currPagePath, String currOfferId)
/*     */   {
/* 311 */     int landingNodeDepth = 0;
/* 312 */     String landingNodeName = "";
/* 313 */     String jsonFileName = "";
/* 314 */     JSONObject offerJson = null;
/* 315 */     String offerJsonLocation = VppJsonUtil.getOfferJsonLocation(currPagePath);
/*     */     
/* 317 */     if (offerJsonLocation.equalsIgnoreCase("invalidPath")) {
/* 318 */       log.debug("Invalid JSON Location Path ,returning empty JSON ");
/* 319 */       return "failure";
/*     */     }
/*     */     try
/*     */     {
/* 323 */       if (jcrSession.nodeExists(currPagePath)) {
/* 324 */         Node detailPageNode = jcrSession.getNode(currPagePath);
/* 325 */         Node landingPageNode = detailPageNode.getParent();
/* 326 */         landingNodeDepth = landingPageNode.getDepth();
/* 327 */         landingNodeName = landingPageNode.getName();
/* 328 */         StringBuffer sb = new StringBuffer(landingNodeName);
/* 329 */         sb.append("_").append(landingNodeDepth).append(".json");
/* 330 */         jsonFileName = sb.toString();
/* 331 */         offerJson = VppJsonUtil.getOfferJson(jcrSession, offerJsonLocation, jsonFileName);
/* 332 */         Iterator<String> it = offerJson.keys();
/*     */         
/* 334 */         while (it.hasNext()) {
/* 335 */           String key = (String)it.next();
/* 336 */           JSONObject catJsonObj = offerJson.getJSONObject(key);
/* 337 */           if (catJsonObj.has(currOfferId)) {
/* 338 */             JSONObject currOfferJson = catJsonObj.getJSONObject(currOfferId);
/* 339 */             if (currOfferJson.has("previewURL")) {
/* 340 */               return currOfferJson.getString("previewURL");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 346 */       log.error("PathNotFoundException Occured in GetAllPreviewOfferPages getOfferPreviewUrl() :" + e
/* 347 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 349 */       log.error("Repository Exception Occured in GetAllPreviewOfferPages getOfferPreviewUrl() :" + e
/* 350 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 352 */       log.error("JSON Exception Occured in GetAllPreviewOfferPages getOfferPreviewUrl()");
/*     */     } catch (Exception e) {
/* 354 */       log.error("Exception Occured in GetAllPreviewOfferPages handleUrlHit() :" + e.getMessage());
/*     */     }
/* 356 */     return "failure";
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\servlets\GetAllPreviewOfferPages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */