/*     */ package com.visa.vpp.servlets;
/*     */ 
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.InvalidItemStateException;
/*     */ import javax.jcr.ItemExistsException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.ReferentialIntegrityException;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.lock.LockException;
/*     */ import javax.jcr.nodetype.ConstraintViolationException;
/*     */ import javax.jcr.nodetype.NoSuchNodeTypeException;
/*     */ import javax.jcr.version.VersionException;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/offerDisplayCategoryPage"}, methods={"POST"}, metatype=false)
/*     */ public class OfferDisplayCategoryPage
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String SELECTED_OFFER_JSON_STRING = "selectedJson";
/*     */   private static final String PAGE_PATH = "pagePath";
/*     */   private static final String NT_UNSTRUCTURED = "nt:unstructured";
/*     */   private static final String SLING_RESOURCETYPE_PROPERTY = "foundation/components/parsys";
/*     */   private static final String SLING_RESOURCETYPE_COMPONENT = "vpp/components/content/offer_category";
/*     */   private static final String TRUE = "true";
/*  58 */   private static final Logger logger = LoggerFactory.getLogger(OfferDisplayCategoryPage.class);
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  70 */     String checkCondition = createDynamicComponents(request);
/*  71 */     response.setContentType("application/text");
/*  72 */     response.getWriter().write(checkCondition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createDynamicComponents(SlingHttpServletRequest request)
/*     */   {
/*  81 */     String firstTimeCheck = "false";
/*  82 */     Node moreOffers = null;
/*  83 */     Node featuredOffers = null;
/*  84 */     String condition = "failure";
/*  85 */     String catPageName = "";
/*  86 */     ArrayList<String> nodeCombinedArrList = new ArrayList();
/*     */     
/*  88 */     String selectedJsonString = request.getParameter("selectedJson");
/*  89 */     String pagePath = request.getParameter("pagePath");
/*  90 */     if ((selectedJsonString == null) || (selectedJsonString.length() == 0)) {
/*  91 */       return condition;
/*     */     }
/*  93 */     if ((pagePath == null) || (pagePath.length() == 0)) {
/*  94 */       return condition;
/*     */     }
/*     */     
/*     */ 
/*  98 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*  99 */     Session session = (Session)resolver.adaptTo(Session.class);
/* 100 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/* 101 */     pagePath = xssApi.encodeForHTML(pagePath);
/*     */     try
/*     */     {
/* 104 */       Node rootNode = session.getRootNode();
/* 105 */       if (rootNode.hasNode(pagePath.substring(1) + "/jcr:content")) {
/* 106 */         Node pageNode = rootNode.getNode(pagePath.substring(1) + "/jcr:content");
/*     */         
/* 108 */         catPageName = pageNode.getParent().getName();
/* 109 */         Node landingPageNode = pageNode.getParent().getParent();
/*     */         
/* 111 */         String checkFileCreation = createCategoryJson(selectedJsonString, catPageName, session, pagePath, landingPageNode);
/*     */         
/* 113 */         if (checkFileCreation.equalsIgnoreCase("success")) {
/* 114 */           logger.debug("file created successfully!!!!");
/*     */         } else {
/* 116 */           logger.debug("file creation failed!!!!");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 121 */         if (!pageNode.hasNode("more_offers")) {
/* 122 */           firstTimeCheck = "true";
/* 123 */           moreOffers = pageNode.addNode("more_offers", "nt:unstructured");
/* 124 */           moreOffers.setProperty("sling:resourceType", "foundation/components/parsys");
/* 125 */           logger.debug("added the more offers parsys node" + firstTimeCheck);
/*     */         } else {
/* 127 */           moreOffers = pageNode.getNode("more_offers");
/*     */         }
/*     */         
/* 130 */         if (!pageNode.hasNode("featured_offers")) {
/* 131 */           featuredOffers = pageNode.addNode("featured_offers", "nt:unstructured");
/* 132 */           featuredOffers.setProperty("sling:resourceType", "foundation/components/parsys");
/*     */           
/* 134 */           logger.debug("added the FEATURED_OFFERS  parsys node");
/*     */         } else {
/* 136 */           featuredOffers = pageNode.getNode("featured_offers");
/*     */         }
/* 138 */         JSONObject selectedJsonObj = new JSONObject(selectedJsonString);
/* 139 */         Iterator<String> iterator = selectedJsonObj.keys();
/* 140 */         if (firstTimeCheck.equalsIgnoreCase("true")) {
/* 141 */           logger.debug("first time the components will be created");
/* 142 */           while (iterator.hasNext()) {
/* 143 */             String jsonObjKey = ((String)iterator.next()).toString();
/* 144 */             JSONObject childJsonObj = selectedJsonObj.getJSONObject(jsonObjKey);
/* 145 */             createNode(childJsonObj, jsonObjKey, moreOffers, pagePath, session);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 150 */           Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(pagePath, rootNode, "MODIFIED");
/* 151 */           if (setPropertyCheck.booleanValue()) {
/* 152 */             logger.debug("modified property set successfully");
/*     */           }
/*     */         }
/*     */         else {
/* 156 */           ArrayList<String> selectedArrList = copyIterator(iterator);
/* 157 */           logger.debug("selectedArrList" + Arrays.toString(selectedArrList.toArray()));
/*     */           
/* 159 */           ArrayList<String> moreofferArrList = getNodeArray(moreOffers);
/* 160 */           ArrayList<String> featuredOfferArrList = getNodeArray(featuredOffers);
/*     */           
/*     */ 
/* 163 */           nodeCombinedArrList.addAll(moreofferArrList);
/* 164 */           nodeCombinedArrList.addAll(featuredOfferArrList);
/* 165 */           logger.debug("nodeCombinedArrList" + Arrays.toString(nodeCombinedArrList.toArray()));
/*     */           
/*     */ 
/*     */ 
/* 169 */           ArrayList<String> deletedArrayList = getmodifiedArrList(nodeCombinedArrList, selectedArrList);
/* 170 */           if (deletedArrayList.size() != 0)
/*     */           {
/*     */ 
/* 173 */             moreofferArrList = removeElement(moreofferArrList, deletedArrayList);
/* 174 */             logger.debug("after deleting" + Arrays.toString(moreofferArrList.toArray()));
/*     */             
/* 176 */             removeFeaturedOffers(deletedArrayList, featuredOffers);
/*     */           }
/*     */           
/*     */ 
/* 180 */           ArrayList<String> newOfferArrList = getmodifiedArrList(selectedArrList, nodeCombinedArrList);
/*     */           
/* 182 */           if ((deletedArrayList.size() != 0) || (newOfferArrList.size() != 0)) {
/* 183 */             ArrayList<String> newOrderArrList = new ArrayList();
/* 184 */             newOrderArrList.addAll(newOfferArrList);
/* 185 */             newOrderArrList.addAll(moreofferArrList);
/* 186 */             logger.debug("newOrderArrList @@@@" + Arrays.toString(newOrderArrList.toArray()));
/*     */             
/* 188 */             if (pageNode.hasNode("more_offers")) {
/* 189 */               pageNode.getNode("more_offers").remove();
/* 190 */               logger.debug("node removed successfully");
/*     */             }
/* 192 */             moreOffers = pageNode.addNode("more_offers", "nt:unstructured");
/* 193 */             moreOffers.setProperty("sling:resourceType", "foundation/components/parsys");
/* 194 */             logger.debug("added the more offers parsys node next time");
/* 195 */             for (String jsonObjKey : newOrderArrList) {
/* 196 */               JSONObject childJsonObj = selectedJsonObj.getJSONObject(jsonObjKey);
/* 197 */               createNode(childJsonObj, jsonObjKey, moreOffers, pagePath, session);
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 202 */             Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(pagePath, rootNode, "MODIFIED");
/* 203 */             if (setPropertyCheck.booleanValue()) {
/* 204 */               logger.debug("modified property set successfully");
/*     */             }
/*     */           } else {
/* 207 */             logger.debug("no new offers are added/deleted ,so no changes");
/*     */           }
/*     */         }
/*     */         
/* 211 */         session.save();
/* 212 */         condition = "success";
/*     */       }
/*     */     } catch (JSONException e) {
/* 215 */       logger.error("JSONException occured in createDynamicComponents()" + e.getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 217 */       logger.error("PathNotFoundException occured in createDynamicComponents()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 219 */       logger.error("RepositoryException occured in createDynamicComponents()" + e.getMessage());
/*     */     } finally {
/* 221 */       VppJsonUtil.closeResolver(resolver);
/*     */     }
/*     */     
/* 224 */     logger.debug("condition" + condition);
/* 225 */     return condition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNode(JSONObject childJsonObj, String key, Node moreOffers, String pagePath, Session session)
/*     */   {
/* 239 */     logger.debug("creating more-offer nodes");
/* 240 */     String offerTitle = "";
/* 241 */     String merchantName = "";
/* 242 */     String offerShortDesc = "";
/* 243 */     String thumbImage = "";
/* 244 */     String previewUrl = "";
/* 245 */     String offerSource = "";
/* 246 */     String offerLastModified = "";
/* 247 */     String pageType = "";
/*     */     try {
/* 249 */       if (childJsonObj.has("offerTitle")) {
/* 250 */         offerTitle = childJsonObj.get("offerTitle").toString();
/*     */       }
/* 252 */       if (childJsonObj.has("merchantName")) {
/* 253 */         merchantName = childJsonObj.get("merchantName").toString();
/*     */       }
/* 255 */       if (childJsonObj.has("offerShortDesc")) {
/* 256 */         offerShortDesc = childJsonObj.get("offerShortDesc").toString();
/*     */       }
/* 258 */       if (childJsonObj.has("thumbImage")) {
/* 259 */         thumbImage = childJsonObj.get("thumbImage").toString();
/*     */       }
/* 261 */       if (childJsonObj.has("previewURL")) {
/* 262 */         previewUrl = childJsonObj.get("previewURL").toString();
/*     */       }
/* 264 */       if (childJsonObj.has("pageType")) {
/* 265 */         pageType = childJsonObj.get("pageType").toString();
/*     */       }
/* 267 */       if (childJsonObj.has("offerSource")) {
/* 268 */         offerSource = childJsonObj.get("offerSource").toString();
/*     */       }
/* 270 */       if (childJsonObj.has("offerLastModified")) {
/* 271 */         offerLastModified = childJsonObj.get("offerLastModified").toString();
/*     */       }
/* 273 */       if (offerSource.equalsIgnoreCase("AEM")) {
/* 274 */         Boolean check = offerMap(previewUrl, pagePath, session);
/* 275 */         if (check.booleanValue()) {
/* 276 */           logger.debug("offer tagged to category page");
/*     */         }
/*     */       }
/*     */       
/* 280 */       if (!moreOffers.hasNode(key)) {
/* 281 */         Node offerNode = moreOffers.addNode(key, "nt:unstructured");
/* 282 */         offerNode.setProperty("offerId", key);
/* 283 */         offerNode.setProperty("offerTitle", offerTitle);
/* 284 */         offerNode.setProperty("merchantName", merchantName);
/* 285 */         offerNode.setProperty("offerShortDesc", offerShortDesc);
/* 286 */         offerNode.setProperty("thumbImage", thumbImage);
/* 287 */         offerNode.setProperty("previewURL", previewUrl);
/* 288 */         offerNode.setProperty("pageType", pageType);
/* 289 */         offerNode.setProperty("offerSource", offerSource);
/* 290 */         offerNode.setProperty("offerLastModified", offerLastModified);
/* 291 */         offerNode.setProperty("sling:resourceType", "vpp/components/content/offer_category");
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 295 */       logger.error("JSONException occured in createNode()" + e.getMessage());
/*     */     } catch (ItemExistsException e) {
/* 297 */       logger.error("ItemExistsException occured in createNode()" + e.getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 299 */       logger.error("PathNotFoundException occured in createNode()" + e.getMessage());
/*     */     } catch (NoSuchNodeTypeException e) {
/* 301 */       logger.error("NoSuchNodeTypeException occured in createNode()" + e.getMessage());
/*     */     } catch (LockException e) {
/* 303 */       logger.error("LockException occured in createNode()" + e.getMessage());
/*     */     } catch (VersionException e) {
/* 305 */       logger.error("VersionException occured in createNode()" + e.getMessage());
/*     */     } catch (ConstraintViolationException e) {
/* 307 */       logger.error("ConstraintViolationException occured in createNode()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 309 */       logger.error("RepositoryException occured in createNode()" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> copyIterator(Iterator<String> iter)
/*     */   {
/* 321 */     ArrayList<String> selectedArrList = new ArrayList();
/* 322 */     while (iter.hasNext()) {
/* 323 */       selectedArrList.add(iter.next());
/*     */     }
/* 325 */     return selectedArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getNodeArray(Node offerNode)
/*     */   {
/* 335 */     ArrayList<String> subNodeArrList = new ArrayList();
/*     */     try {
/* 337 */       NodeIterator offerNodeItr = offerNode.getNodes();
/* 338 */       while (offerNodeItr.hasNext()) {
/* 339 */         Node childNode = offerNodeItr.nextNode();
/* 340 */         if (childNode.hasProperty("offerId")) {
/* 341 */           String offerId = childNode.getProperty("offerId").getString();
/* 342 */           subNodeArrList.add(offerId);
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 346 */       logger.error("RepositoryException in getNodeArray " + e.getMessage());
/*     */     }
/* 348 */     return subNodeArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getmodifiedArrList(ArrayList<String> list1, ArrayList<String> list2)
/*     */   {
/* 359 */     ArrayList<String> modifiedArrList = new ArrayList(list1);
/* 360 */     modifiedArrList.removeAll(list2);
/* 361 */     return modifiedArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> removeElement(ArrayList<String> moreOffers, ArrayList<String> deletedOffers)
/*     */   {
/* 373 */     for (String i : deletedOffers) {
/* 374 */       if (moreOffers.contains(i)) {
/* 375 */         moreOffers.remove(i);
/* 376 */         logger.debug("removed offer ******" + i);
/*     */       }
/*     */     }
/* 379 */     return moreOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void removeFeaturedOffers(ArrayList<String> deletedOffers, Node featuredOffers)
/*     */   {
/* 389 */     for (String offerId : deletedOffers) {
/*     */       try {
/* 391 */         NodeIterator featuredOffersNodeItr = featuredOffers.getNodes();
/* 392 */         while (featuredOffersNodeItr.hasNext()) {
/* 393 */           Node childNode = featuredOffersNodeItr.nextNode();
/* 394 */           if (childNode.hasProperty("offerId")) {
/* 395 */             String offerIdFeaturedNode = childNode.getProperty("offerId").getString();
/* 396 */             if (offerId.equalsIgnoreCase(offerIdFeaturedNode)) {
/* 397 */               childNode.remove();
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (PathNotFoundException e) {
/* 402 */         logger.error("PathNotFoundException" + e.getMessage());
/*     */       } catch (RepositoryException e) {
/* 404 */         logger.error("RepositoryException" + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createCategoryJson(String selectedJsonString, String catPageName, Session session, String pagePath, Node landingPageNode)
/*     */   {
/* 422 */     String statusCheck = "failure";
/* 423 */     String landingPageFileName = "";
/*     */     try {
/* 425 */       String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(pagePath);
/*     */       
/* 427 */       if (landingPageNode.hasNode("jcr:content")) {
/* 428 */         Node landPageJcrContent = landingPageNode.getNode("jcr:content");
/* 429 */         if (!landPageJcrContent.hasProperty("landingJsonName"))
/*     */         {
/* 431 */           landingPageFileName = VppJsonUtil.getLandingJsonFileName(landingPageNode);
/* 432 */           logger.debug("landingPageFileName in offer display category" + landingPageFileName);
/* 433 */           landPageJcrContent.setProperty("landingJsonName", landingPageFileName);
/*     */         } else {
/* 435 */           logger.debug("landingPageFileName property is already set");
/*     */           
/*     */ 
/* 438 */           landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/*     */         }
/*     */       }
/* 441 */       JSONObject selectedJson = new JSONObject(selectedJsonString);
/*     */       
/* 443 */       JSONObject categoryPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileName);
/* 444 */       categoryPageJson.put(pagePath, selectedJson);
/* 445 */       String catPageJsonName = catPageName + ".json";
/*     */       
/*     */ 
/* 448 */       String fileCheck = createCategoryJsonFile(jsonFileLocation, landingPageFileName, session, categoryPageJson, catPageJsonName);
/*     */       
/* 450 */       session.save();
/* 451 */       if (fileCheck.equalsIgnoreCase("success")) {
/* 452 */         statusCheck = "success";
/*     */       }
/*     */     } catch (JSONException e) {
/* 455 */       logger.debug("JSONException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 456 */         .getMessage());
/*     */     } catch (AccessDeniedException e) {
/* 458 */       logger.debug("AccessDeniedException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 459 */         .getMessage());
/*     */     } catch (ItemExistsException e) {
/* 461 */       logger.debug("ItemExistsException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 462 */         .getMessage());
/*     */     }
/*     */     catch (ReferentialIntegrityException e) {
/* 465 */       logger.debug("ReferentialIntegrityException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 466 */         .getMessage());
/*     */     }
/*     */     catch (ConstraintViolationException e) {
/* 469 */       logger.debug("ConstraintViolationException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 470 */         .getMessage());
/*     */     } catch (InvalidItemStateException e) {
/* 472 */       logger.debug("InvalidItemStateException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 473 */         .getMessage());
/*     */     } catch (VersionException e) {
/* 475 */       logger.debug("VersionException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 476 */         .getMessage());
/*     */     } catch (LockException e) {
/* 478 */       logger.debug("LockException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 479 */         .getMessage());
/*     */     } catch (NoSuchNodeTypeException e) {
/* 481 */       logger.debug("NoSuchNodeTypeException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 482 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 484 */       logger.debug("RepositoryException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 485 */         .getMessage());
/*     */     }
/* 487 */     return statusCheck;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createCategoryJsonFile(String jsonFileLocation, String landingFileName, Session session, JSONObject jsonObj, String categoryPageName)
/*     */   {
/* 501 */     logger.debug("landingFileName" + landingFileName);
/* 502 */     String checkStatus = "failure";
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 508 */       Node rootNode = session.getRootNode();
/* 509 */       if (rootNode.hasNode(jsonFileLocation)) {
/* 510 */         Node parentFilePathNode = rootNode.getNode(jsonFileLocation);
/* 511 */         Node landingFolder; Node landingFolder; if (!parentFilePathNode.hasNode(landingFileName)) {
/* 512 */           landingFolder = parentFilePathNode.addNode(landingFileName, "nt:folder");
/*     */         } else
/* 514 */           landingFolder = parentFilePathNode.getNode(landingFileName);
/*     */         Node fileJcrNode;
/* 516 */         if (!landingFolder.hasNode(categoryPageName)) {
/* 517 */           Node fileNode = landingFolder.addNode(categoryPageName, "nt:file");
/* 518 */           Node fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 519 */           logger.debug("Create  Operation : JSON Created for the first time");
/*     */         } else {
/* 521 */           Node fileNode = landingFolder.getNode(categoryPageName);
/* 522 */           fileJcrNode = fileNode.getNode("jcr:content");
/*     */         }
/* 524 */         if (fileJcrNode != null) {
/* 525 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 526 */           fileJcrNode.setProperty("jcr:data", jsonObj.toString());
/* 527 */           checkStatus = "success";
/* 528 */           logger.debug("json file updated" + checkStatus);
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 532 */       logger.error("RepositoryException  Occured in  createCategoryJsonFile() :" + e.getMessage());
/*     */     }
/* 534 */     return checkStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean offerMap(String previewUrl, String pagePath, Session session)
/*     */   {
/* 546 */     Boolean offerMapStatus = Boolean.valueOf(false);
/* 547 */     String offerPath = VppJsonUtil.getOfferDataPath(previewUrl);
/* 548 */     logger.debug("offerPath" + offerPath);
/* 549 */     Node offerNode = null;
/* 550 */     String categoryMap = "";
/* 551 */     JSONObject categoryMapObj = new JSONObject();
/*     */     try {
/* 553 */       Node rootNode = session.getRootNode();
/* 554 */       if (rootNode.hasNode(offerPath)) {
/* 555 */         offerNode = rootNode.getNode(offerPath);
/*     */       }
/* 557 */       if (offerNode != null) {
/* 558 */         if (offerNode.hasProperty("categoryMap")) {
/* 559 */           categoryMap = offerNode.getProperty("categoryMap").getString();
/* 560 */           categoryMapObj = new JSONObject(categoryMap);
/*     */         }
/* 562 */         categoryMapObj.put(pagePath, pagePath);
/* 563 */         categoryMap = categoryMapObj.toString();
/* 564 */         offerNode.setProperty("categoryMap", categoryMap);
/* 565 */         logger.debug(categoryMap);
/* 566 */         offerMapStatus = Boolean.valueOf(true);
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 569 */       logger.error("RepositoryException  Occured in  offerMap() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 571 */       logger.error("JSONException  Occured in  offerMap() :" + e.getMessage());
/*     */     }
/* 573 */     return offerMapStatus;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\servlets\OfferDisplayCategoryPage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */