/*     */ package com.visa.vpp.utill;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.Binary;
/*     */ import javax.jcr.ItemNotFoundException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import javax.jcr.lock.LockException;
/*     */ import javax.jcr.nodetype.ConstraintViolationException;
/*     */ import javax.jcr.version.VersionException;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public final class VppJsonUtil
/*     */ {
/*  35 */   private static final Logger log = LoggerFactory.getLogger(VppJsonUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean checkPromotionDateValidity(String promoStart, String promoEnd)
/*     */   {
/*  47 */     Date currDate = new Date();
/*  48 */     DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  53 */       currDate = sdf.parse(sdf.format(currDate));
/*  54 */       Date promoStartDate = sdf.parse(promoStart);
/*  55 */       Date promoEndDate = sdf.parse(promoEnd);
/*  56 */       if ((currDate.compareTo(promoStartDate) >= 0) && (promoEndDate.compareTo(currDate) >= 0)) {
/*  57 */         return true;
/*     */       }
/*     */     }
/*     */     catch (ParseException e) {
/*  61 */       log.error("ParseException occured while parsing date in GetAvailableOffersJSON checkPromotionDateValidity()" + e
/*  62 */         .getMessage());
/*     */     } catch (Exception e) {
/*  64 */       log.error("Exception occured while parsing date in GetAvailableOffersJSON checkPromotionDateValidity()" + e
/*  65 */         .getMessage());
/*     */     }
/*  67 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONObject getOfferJson(Session jcrSession, String offerJsonLocation, String jsonFileName)
/*     */   {
/*  82 */     InputStream inputStream = null;
/*  83 */     StringBuilder jsonSb = new StringBuilder();
/*  84 */     JSONObject offerJson = new JSONObject();
/*  85 */     BufferedReader bufferRead = null;
/*     */     try
/*     */     {
/*  88 */       StringBuilder sb = new StringBuilder(offerJsonLocation);
/*  89 */       sb.append("/");
/*  90 */       sb.append(jsonFileName);
/*  91 */       sb.append("/");
/*  92 */       sb.append("jcr:content");
/*  93 */       String offerJsonfilePath = sb.toString();
/*  94 */       Node rootNode = jcrSession.getRootNode();
/*  95 */       if (rootNode.hasNode(offerJsonfilePath)) {
/*  96 */         Node fileJcrNode = rootNode.getNode(offerJsonfilePath);
/*  97 */         if (fileJcrNode.hasProperty("jcr:data")) {
/*  98 */           inputStream = fileJcrNode.getProperty("jcr:data").getBinary().getStream();
/*  99 */           bufferRead = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
/*     */           
/* 101 */           String line = "";
/* 102 */           while ((line = bufferRead.readLine()) != null) {
/* 103 */             jsonSb.append(line);
/*     */           }
/*     */         }
/*     */         
/* 107 */         offerJson = new JSONObject(jsonSb.toString());
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 110 */       log.error("Repository Exception Occured in GetAvailableOffersJSON getOfferJSON() :" + e
/* 111 */         .getMessage());
/*     */     } catch (IOException e) {
/* 113 */       log.error("IO Exception Occured in GetAvailableOffersJSON getOfferJSON() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 115 */       log.error("JSONException Occured in GetAvailableOffersJSON getOfferJSON()");
/*     */     } finally {
/* 117 */       VppUtil.closeBufferReader(bufferRead);
/* 118 */       VppUtil.closeInputStream(inputStream);
/*     */     }
/* 120 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOfferJsonLocation(String catPagePath)
/*     */   {
/* 131 */     String offerJsonLocation = "";
/*     */     try {
/* 133 */       String[] catPageArr = catPagePath.split("/");
/* 134 */       StringBuilder sb = new StringBuilder("etc/vpp-tools/offers");
/* 135 */       sb.append("/");
/* 136 */       sb.append(catPageArr[4]);
/* 137 */       sb.append("/");
/* 138 */       sb.append(catPageArr[5]);
/* 139 */       offerJsonLocation = sb.toString();
/* 140 */       log.debug("offerJSONLocation" + offerJsonLocation);
/*     */     } catch (Exception e) {
/* 142 */       log.error("Exception Occured in GetAvailableOffersJSON getOfferJSONLocation() :" + e
/* 143 */         .getMessage());
/* 144 */       return "invalidPath";
/*     */     }
/* 146 */     return offerJsonLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeResolver(ResourceResolver resolver)
/*     */   {
/* 158 */     if (resolver != null) {
/* 159 */       log.debug("resolver closed ");
/* 160 */       resolver.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOfferDataPath(String offerUrl)
/*     */   {
/* 173 */     String offerDataPath = "invalidPath";
/*     */     try {
/* 175 */       offerUrl = offerUrl.substring(1, offerUrl.lastIndexOf(".html"));
/* 176 */       log.debug("Offer URL " + offerUrl);
/* 177 */       StringBuilder sb = new StringBuilder(offerUrl);
/* 178 */       sb.append("/");
/* 179 */       sb.append("jcr:content");
/* 180 */       sb.append("/");
/* 181 */       sb.append("offer_creation");
/* 182 */       offerDataPath = sb.toString();
/*     */     } catch (Exception e) {
/* 184 */       log.error("Exception Occured in  getOfferDataPath() :" + e.getMessage());
/*     */     }
/* 186 */     return offerDataPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createUpdateJsonFile(String jsonFileLocation, String jsonFileName, Session session, JSONObject jsonObj)
/*     */   {
/* 198 */     log.debug("jsonFileName" + jsonFileName);
/* 199 */     String checkStatus = "failure";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 204 */       Node rootNode = session.getRootNode();
/* 205 */       if (rootNode.hasNode(jsonFileLocation)) {
/* 206 */         Node parentFilePathNode = rootNode.getNode(jsonFileLocation);
/* 207 */         Node fileJcrNode; if (!parentFilePathNode.hasNode(jsonFileName)) {
/* 208 */           Node fileNode = parentFilePathNode.addNode(jsonFileName, "nt:file");
/* 209 */           Node fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 210 */           log.debug("Create  Operation : JSON Created for the first time");
/*     */         } else {
/* 212 */           Node fileNode = parentFilePathNode.getNode(jsonFileName);
/* 213 */           fileJcrNode = fileNode.getNode("jcr:content");
/*     */         }
/* 215 */         if (fileJcrNode != null) {
/* 216 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 217 */           fileJcrNode.setProperty("jcr:data", jsonObj.toString());
/* 218 */           checkStatus = "success";
/* 219 */           log.debug("json file updated" + checkStatus);
/*     */         }
/*     */       }
/* 222 */       session.save();
/*     */     }
/*     */     catch (RepositoryException e) {
/* 225 */       log.error("RepositoryException  Occured in  createUpdateJsonFile() :" + e.getMessage());
/*     */     } catch (Exception e) {
/* 227 */       log.error("Exception  Occured in  createUpdateJsonFile() :" + e.getMessage());
/*     */     }
/*     */     
/* 230 */     return checkStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean areEqual(JSONObject targetObj, JSONObject sourceObj)
/*     */     throws JSONException
/*     */   {
/* 241 */     log.debug("Comparing Two JSONObjects for modifications ");
/*     */     try {
/* 243 */       Iterator<String> keys = sourceObj.keys();
/* 244 */       while (keys.hasNext()) {
/* 245 */         String key = (String)keys.next();
/* 246 */         String toCompare = sourceObj.getString(key);
/* 247 */         if (targetObj.has(key)) {
/* 248 */           String withCompare = targetObj.getString(key);
/* 249 */           if (!toCompare.equals(withCompare)) {
/* 250 */             log.debug("Key : " + key + " has unequal value in Both JSONs");
/* 251 */             return false;
/*     */           }
/*     */         } else {
/* 254 */           log.debug("Key : " + key + " not found in Target JSON Object");
/* 255 */           return false;
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 259 */       log.debug("Exception Occured while comparing two JSON Objects . Proceed as unequal objects " + e
/* 260 */         .getMessage());
/* 261 */       return false;
/*     */     }
/* 263 */     log.debug("Two JSONObjects are equal. No modifications found");
/* 264 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONObject getCurrOfferData(JSONObject aemOffers, String currOfferId)
/*     */   {
/* 274 */     JSONObject currentData = new JSONObject();
/*     */     
/* 276 */     String offerTitle = "";
/* 277 */     String merchName = "";
/* 278 */     String offerShortDesc = "";
/* 279 */     String thumbImage = "";
/* 280 */     String previewUrl = "";
/* 281 */     String offerLastModified = "";
/* 282 */     String offerSource = "";
/* 283 */     String pageType = "";
/*     */     try {
/* 285 */       JSONObject currentOfferJson = aemOffers.getJSONObject(currOfferId);
/* 286 */       if (currentOfferJson.has("offerTitle")) {
/* 287 */         offerTitle = currentOfferJson.getString("offerTitle");
/*     */       }
/* 289 */       if (currentOfferJson.has("offerShortDesc")) {
/* 290 */         offerShortDesc = currentOfferJson.getString("offerShortDesc");
/*     */       }
/* 292 */       if (currentOfferJson.has("pageType")) {
/* 293 */         pageType = currentOfferJson.getString("pageType");
/*     */       }
/* 295 */       if (currentOfferJson.has("thumbImage")) {
/* 296 */         thumbImage = currentOfferJson.getString("thumbImage");
/*     */       }
/* 298 */       if (currentOfferJson.has("merchantName")) {
/* 299 */         merchName = currentOfferJson.getString("merchantName");
/*     */       }
/* 301 */       if (currentOfferJson.has("previewURL")) {
/* 302 */         previewUrl = currentOfferJson.getString("previewURL");
/*     */       }
/* 304 */       if (currentOfferJson.has("offerSource")) {
/* 305 */         offerSource = currentOfferJson.getString("offerSource");
/*     */       }
/* 307 */       if (currentOfferJson.has("offerLastModified")) {
/* 308 */         offerLastModified = currentOfferJson.getString("offerLastModified");
/*     */       }
/* 310 */       log.debug("pageType ::: " + pageType);
/* 311 */       log.debug("merchName ::: " + merchName);
/* 312 */       log.debug("offerTitle ::: " + offerTitle);
/* 313 */       if (pageType.equalsIgnoreCase("benefit")) {
/* 314 */         log.debug("inside benefit ::: " + offerTitle);
/* 315 */         offerTitle = merchName;
/*     */       }
/* 317 */       else if ((!merchName.equalsIgnoreCase("")) && (!pageType.equalsIgnoreCase("benefit"))) {
/* 318 */         log.debug("inside merchant ::: " + merchName);
/* 319 */         offerTitle = merchName;
/*     */       }
/* 321 */       currentData.put("offerId", currOfferId);
/* 322 */       currentData.put("offerShortDesc", offerShortDesc);
/* 323 */       currentData.put("pageType", pageType);
/* 324 */       currentData.put("thumbImage", thumbImage);
/* 325 */       currentData.put("previewURL", previewUrl);
/* 326 */       currentData.put("offerTitle", offerTitle);
/* 327 */       currentData.put("merchantName", merchName);
/* 328 */       currentData.put("offerSource", offerSource);
/* 329 */       currentData.put("offerLastModified", offerLastModified);
/*     */     } catch (JSONException e) {
/* 331 */       log.error("JSONException Occured in VPPJSONUtil getCurrOfferData()");
/*     */     } catch (Exception e) {
/* 333 */       log.error("Exception Occured in VPPJSONUtil getCurrOfferData()" + e.getMessage());
/*     */     }
/*     */     
/* 336 */     return currentData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean setCategoryApprovalStatus(String pagePath, Node rootNode, String propVal)
/*     */   {
/* 348 */     boolean catPropSet = false;
/* 349 */     StringBuffer sb = new StringBuffer();
/* 350 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/* 351 */     String catJcrPath = sb.toString();
/*     */     try
/*     */     {
/* 354 */       if (rootNode.hasNode(catJcrPath)) {
/* 355 */         Node catNode = rootNode.getNode(catJcrPath);
/* 356 */         log.debug("catNode" + catNode.getName());
/* 357 */         catNode.setProperty("catApprovalStatus", propVal);
/* 358 */         log.debug("cat page approval status is set successfully" + propVal);
/* 359 */         catPropSet = true;
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 362 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 363 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 365 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 366 */         .getMessage());
/*     */     } catch (VersionException e) {
/* 368 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 369 */         .getMessage());
/*     */     } catch (LockException e) {
/* 371 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 372 */         .getMessage());
/*     */     } catch (ConstraintViolationException e) {
/* 374 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 375 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 377 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 378 */         .getMessage());
/*     */     }
/* 380 */     return Boolean.valueOf(catPropSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized int offerFileIteration(String fileLangPath, Session session)
/*     */   {
/* 391 */     int count = 0;
/*     */     try {
/* 393 */       Node rootNode = session.getRootNode();
/* 394 */       if (rootNode.hasNode(fileLangPath)) {
/* 395 */         Node fileLangNode = rootNode.getNode(fileLangPath);
/* 396 */         log.debug("fileLangNode name" + fileLangNode.getName());
/* 397 */         NodeIterator nodeItr = fileLangNode.getNodes();
/* 398 */         while (nodeItr.hasNext()) {
/* 399 */           Node childNode = nodeItr.nextNode();
/* 400 */           if (childNode.hasProperty("jcr:primaryType"))
/*     */           {
/* 402 */             String jcrProp = childNode.getProperty("jcr:primaryType").getValue().getString();
/* 403 */             if (jcrProp.equalsIgnoreCase("nt:file")) {
/* 404 */               count++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 410 */       log.error("RepositoryException in offerFileIteration() of VPPJSONUtil" + e.getMessage());
/*     */     }
/* 412 */     log.debug("filecount" + count);
/* 413 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getLandingPageName(Node landingNode)
/*     */   {
/* 423 */     String landingPageFileName = "invalid";
/*     */     try {
/* 425 */       if (landingNode.hasNode("jcr:content")) {
/* 426 */         Node landPageJcrContent = landingNode.getNode("jcr:content");
/* 427 */         if (landPageJcrContent.hasProperty("landingJsonName"))
/*     */         {
/*     */ 
/* 430 */           landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/* 431 */           log.debug("landingPageFileName property value" + landingPageFileName);
/*     */         } else {
/* 433 */           log.debug("landingPageFileName property is not set" + landingPageFileName);
/*     */         }
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 437 */       log.error("PathNotFoundException in getLandingPageName() of CreateLandingPageJson" + e
/* 438 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 440 */       log.error("ValueFormatException in getLandingPageName() of CreateLandingPageJson" + e
/* 441 */         .getMessage());
/*     */     } catch (IllegalStateException e) {
/* 443 */       log.error("IllegalStateException in getLandingPageName() of CreateLandingPageJson" + e
/* 444 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 446 */       log.error("RepositoryException in getLandingPageName() of CreateLandingPageJson" + e
/* 447 */         .getMessage());
/*     */     }
/* 449 */     return landingPageFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getLandingJsonFileName(Node landingNode)
/*     */   {
/* 459 */     String landingJsonFileName = "";
/*     */     try {
/* 461 */       Node subHomePageNode = landingNode.getParent();
/* 462 */       Node homePageNode = subHomePageNode.getParent();
/* 463 */       boolean isTwoLevelHome = false;
/* 464 */       String landingName = landingNode.getName();
/* 465 */       String subHomeName = subHomePageNode.getName();
/* 466 */       StringBuffer sb = new StringBuffer();
/*     */       
/* 468 */       if (homePageNode.hasNode("jcr:content")) {
/* 469 */         Node homePageJcrNode = homePageNode.getNode("jcr:content");
/* 470 */         if (homePageJcrNode.hasProperty("cq:template"))
/*     */         {
/* 472 */           String templateValue = homePageJcrNode.getProperty("cq:template").getValue().getString();
/* 473 */           log.debug("templateValue" + templateValue);
/* 474 */           if (templateValue.equalsIgnoreCase("/apps/vpp/templates/issuer_home")) {
/* 475 */             isTwoLevelHome = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 480 */       if (isTwoLevelHome) {
/* 481 */         String homePageName = homePageNode.getName();
/* 482 */         sb.append(homePageName).append("_").append(subHomeName)
/* 483 */           .append("_").append(landingName);
/* 484 */         log.debug("Two level home page");
/*     */       } else {
/* 486 */         sb.append(subHomeName).append("_").append(landingName);
/* 487 */         log.debug("One level home page");
/*     */       }
/* 489 */       landingJsonFileName = sb.toString();
/* 490 */       log.debug("landingJsonFileName" + landingJsonFileName);
/*     */     }
/*     */     catch (AccessDeniedException e) {
/* 493 */       log.error("AccessDeniedException in getLandingJsonFileName() of VppJSonUtil" + e
/* 494 */         .getMessage());
/*     */     } catch (ItemNotFoundException e) {
/* 496 */       log.error("ItemNotFoundException in getLandingJsonFileName() of VppJSonUtil" + e
/* 497 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 499 */       log.error("RepositoryException in getLandingJsonFileName() of VppJSonUtil" + e
/* 500 */         .getMessage());
/*     */     }
/* 502 */     return landingJsonFileName;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\utill\VppJsonUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */