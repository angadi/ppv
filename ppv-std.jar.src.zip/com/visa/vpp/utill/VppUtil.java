/*     */ package com.visa.vpp.utill;
/*     */ 
/*     */ import com.adobe.granite.workflow.exec.Route;
/*     */ import com.day.cq.replication.ReplicationActionType;
/*     */ import com.day.cq.replication.ReplicationException;
/*     */ import com.day.cq.replication.Replicator;
/*     */ import com.day.cq.wcm.resource.details.AssetDetails;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.ValueFactory;
/*     */ import javax.jcr.query.Query;
/*     */ import javax.jcr.query.QueryManager;
/*     */ import javax.jcr.query.QueryResult;
/*     */ import org.apache.jackrabbit.api.security.user.Authorizable;
/*     */ import org.apache.jackrabbit.api.security.user.Group;
/*     */ import org.apache.jackrabbit.api.security.user.UserManager;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.commons.json.jcr.JsonItemWriter;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class VppUtil
/*     */ {
/*  53 */   private static Logger logger = LoggerFactory.getLogger(VppUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Map<String, String>> getMultiFieldPanelValuesMap(String[] items)
/*     */   {
/*  63 */     List<Map<String, String>> results = new ArrayList();
/*  64 */     if (null != items) {
/*  65 */       String[] values = items;
/*  66 */       for (String value : values)
/*     */       {
/*     */         try
/*     */         {
/*  70 */           value = value.replace("[\"", "[").replace("\"]", "]").replace("\\n", "").replace("}\"", "}").replace("\"{", "{");
/*     */           
/*  72 */           value = value.replace("\\", "");
/*     */           
/*  74 */           JSONObject parsed = new JSONObject(value);
/*     */           
/*  76 */           Map<String, String> columnMap = new HashMap();
/*  77 */           for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
/*  78 */             String key = (String)iter.next();
/*  79 */             String innerValue = parsed.getString(key);
/*  80 */             columnMap.put(key, innerValue);
/*     */           }
/*     */           
/*  83 */           results.add(columnMap);
/*     */         }
/*     */         catch (JSONException e) {
/*  86 */           logger.error("JSON Error while reading content {}", e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  91 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Map<String, String>> getMultiLinkJsonData(String fieldValue)
/*     */   {
/* 101 */     String value = fieldValue;
/* 102 */     logger.debug("inside getMultiLinkJsonData  " + value);
/* 103 */     value = value.replace("[", "").replace("]", "").replace("},", "}~@#!");
/* 104 */     ArrayList<Map<String, String>> results = new ArrayList();
/* 105 */     String[] strvalue = value.split("~@#!");
/*     */     try {
/* 107 */       for (String strJson : strvalue) {
/* 108 */         JSONObject parsed = new JSONObject(strJson);
/*     */         
/* 110 */         Map<String, String> columnMap = new HashMap();
/* 111 */         for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
/* 112 */           String key = (String)iter.next();
/* 113 */           String innerValue = parsed.getString(key);
/* 114 */           columnMap.put(key, innerValue);
/*     */         }
/* 116 */         results.add(columnMap);
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 120 */       logger.error("JSON Error while reading content {}", e.getMessage());
/*     */     }
/* 122 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertCalendarToString(Calendar dateCal, String dateFormatter)
/*     */   {
/* 133 */     String dateStr = "";
/* 134 */     if (dateCal != null) {
/* 135 */       SimpleDateFormat sdf = new SimpleDateFormat(dateFormatter);
/* 136 */       dateStr = sdf.format(dateCal.getTime());
/*     */     }
/* 138 */     return dateStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Session getUserJcrSession(ResourceResolverFactory resolverFactory, String userService)
/*     */   {
/* 150 */     ResourceResolver resolver = null;
/* 151 */     Session session = null;
/* 152 */     Map<String, Object> param = new HashMap();
/* 153 */     param.put("sling.service.subservice", userService);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 158 */       resolver = resolverFactory.getServiceResourceResolver(param);
/* 159 */       session = (Session)resolver.adaptTo(Session.class);
/*     */       
/* 161 */       logger.debug("####### session ######### : " + session.getUserID());
/*     */     } catch (Exception e) {
/* 163 */       logger.error("Access denied in " + e);
/*     */     }
/* 165 */     return session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResourceResolver getUserResourceResolver(ResourceResolverFactory resolverFactory, String userService)
/*     */   {
/* 177 */     ResourceResolver resolver = null;
/*     */     
/* 179 */     Map<String, Object> param = new HashMap();
/* 180 */     param.put("sling.service.subservice", userService);
/*     */     try
/*     */     {
/* 183 */       resolver = resolverFactory.getServiceResourceResolver(param);
/*     */     }
/*     */     catch (Exception e) {
/* 186 */       logger.error("Access denied in " + e);
/*     */     }
/* 188 */     return resolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeInputStream(InputStream inptStrmParam)
/*     */   {
/*     */     try
/*     */     {
/* 199 */       if (null != inptStrmParam) {
/* 200 */         inptStrmParam.close();
/*     */       }
/*     */     } catch (IOException ex) {
/* 203 */       logger.error("IO Exception occured while closing inputStream in closeInputStream() " + ex
/* 204 */         .getMessage());
/*     */     } catch (Exception e) {
/* 206 */       logger.error("Exception Occured while closing inputStream in closeInputStream() " + e
/* 207 */         .getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeBufferReader(BufferedReader bufferedReader)
/*     */   {
/*     */     try
/*     */     {
/* 219 */       if (null != bufferedReader) {
/* 220 */         bufferedReader.close();
/*     */       }
/*     */     } catch (IOException ex) {
/* 223 */       logger.error("IO Exception occured while closing BufferedReader in closeBufferReader() " + ex
/* 224 */         .getMessage());
/*     */     } catch (Exception e) {
/* 226 */       logger.error("Exception Occured while closing BufferedReader in closeBufferReader() " + e
/* 227 */         .getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void closeJcrSession(Session sessionob)
/*     */   {
/* 239 */     if ((sessionob != null) && (sessionob.isLive())) {
/* 240 */       sessionob.logout();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertGmtToDate(String parseFmt, String formatFmt, String dateString)
/*     */   {
/* 252 */     DateFormat mod = new SimpleDateFormat(formatFmt);
/* 253 */     DateFormat gmt = new SimpleDateFormat(parseFmt);
/* 254 */     String formattedDate = "";
/*     */     try
/*     */     {
/* 257 */       java.util.Date dateGmt = gmt.parse(dateString);
/* 258 */       formattedDate = mod.format(dateGmt);
/*     */     }
/*     */     catch (ParseException e) {
/* 261 */       logger.error("Date format error " + e);
/*     */     }
/* 263 */     return formattedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void populateSingleMultifield(Node currentNode, Session session, String multifieldname)
/*     */     throws Exception
/*     */   {
/* 275 */     String multifieldnameJson = multifieldname + "multi";
/* 276 */     StringWriter stringWriter = new StringWriter();
/* 277 */     ValueFactory valueFactory = session.getValueFactory();
/* 278 */     PrintWriter test = new PrintWriter(stringWriter);
/* 279 */     int count = 0;
/*     */     
/* 281 */     if (currentNode.hasProperty(multifieldnameJson)) {
/* 282 */       currentNode.getProperty(multifieldnameJson).remove();
/*     */     }
/*     */     
/* 285 */     Set<String> propertiesToIgnore = new HashSet() {};
/* 300 */     JsonItemWriter jsonWriter = new JsonItemWriter(propertiesToIgnore);
/*     */     try
/*     */     {
/* 303 */       jsonWriter.dump(currentNode, test, 2, true);
/* 304 */       JSONObject obj = new JSONObject(stringWriter.toString());
/* 305 */       if (obj.has(multifieldname)) {
/* 306 */         JSONObject jsondata = (JSONObject)obj.get(multifieldname);
/*     */         
/* 308 */         int jsondatalength = jsondata.length();
/* 309 */         Value[] values = new Value[jsondatalength];
/* 310 */         Iterator iterator = jsondata.keys();
/* 311 */         while (iterator.hasNext()) {
/* 312 */           String key = (String)iterator.next();
/* 313 */           JSONObject pagex = (JSONObject)jsondata.get(key);
/* 314 */           values[count] = valueFactory.createValue(pagex.toString());
/* 315 */           count++;
/*     */         }
/* 317 */         currentNode.setProperty(multifieldnameJson, values);
/*     */       }
/* 319 */       session.save();
/*     */     } catch (RepositoryException e) {
/* 321 */       logger.error("Could not get JSON", e.getMessage());
/*     */     } finally {
/* 323 */       if (test != null) {
/* 324 */         test.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void populateNestedMultifield(Node currentNode, Session session, String multifieldname)
/*     */     throws Exception
/*     */   {
/* 339 */     String nested = "nested";
/* 340 */     String linkReference = "linkReference";
/* 341 */     String cardImage = "cardImage";
/* 342 */     String altText = "alttext";
/* 343 */     String cardLinks = "cardLinks";
/* 344 */     String multifieldnameJson = multifieldname + nested;
/* 345 */     ArrayList<String> linkReferenceList = new ArrayList();
/* 346 */     JSONObject finalJson = new JSONObject();
/* 347 */     String mylinkReference = "";
/* 348 */     StringWriter stringWriter = new StringWriter();
/* 349 */     ValueFactory valueFactory = session.getValueFactory();
/* 350 */     PrintWriter test = new PrintWriter(stringWriter);
/* 351 */     int count = 0;
/*     */     
/* 353 */     if (currentNode.hasProperty(multifieldnameJson)) {
/* 354 */       currentNode.getProperty(multifieldnameJson).remove();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 360 */     Set<String> propertiesToIgnore = new HashSet() {};
/* 376 */     JsonItemWriter jsonWriter = new JsonItemWriter(propertiesToIgnore);
/*     */     try {
/* 378 */       jsonWriter.dump(currentNode, test, 2, true);
/* 379 */       JSONObject obj = new JSONObject(stringWriter.toString());
/* 380 */       if (obj.has(multifieldname)) {
/* 381 */         JSONObject jsondata = (JSONObject)obj.get(multifieldname);
/* 382 */         JSONObject newJson = jsondata;
/*     */         
/* 384 */         int jsondatalength = jsondata.length();
/* 385 */         Value[] values = new Value[jsondatalength];
/* 386 */         Iterator iterator = jsondata.keys();
/* 387 */         while (iterator.hasNext()) {
/* 388 */           String key = (String)iterator.next();
/* 389 */           JSONObject pageData = (JSONObject)jsondata.get(key);
/* 390 */           mylinkReference = pageData.getString(linkReference);
/* 391 */           if (linkReferenceList.isEmpty()) {
/* 392 */             linkReferenceList.add(mylinkReference);
/* 393 */             JSONArray cardMap = duplicateImages(mylinkReference, newJson);
/* 394 */             finalJson.put(cardImage, mylinkReference);
/* 395 */             finalJson.put(altText, pageData.getString(altText));
/* 396 */             finalJson.put(cardLinks, cardMap);
/* 397 */             values[count] = valueFactory.createValue(finalJson.toString());
/* 398 */             count++;
/*     */           }
/* 400 */           else if (!linkReferenceList.contains(mylinkReference)) {
/* 401 */             linkReferenceList.add(mylinkReference);
/* 402 */             JSONArray cardMap = duplicateImages(mylinkReference, newJson);
/*     */             
/* 404 */             finalJson.put(cardImage, mylinkReference);
/* 405 */             finalJson.put(altText, pageData.getString(altText));
/* 406 */             finalJson.put(cardLinks, cardMap);
/* 407 */             values[count] = valueFactory.createValue(finalJson.toString());
/* 408 */             count++;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 413 */         currentNode.setProperty(multifieldnameJson, values);
/*     */       }
/*     */       
/* 416 */       session.save();
/*     */     }
/*     */     catch (RepositoryException e) {
/* 419 */       logger.error("Could not get JSON", e.getMessage());
/*     */     } finally {
/* 421 */       if (test != null) {
/* 422 */         test.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONArray duplicateImages(String imgRef, JSONObject jsonlist)
/*     */   {
/* 435 */     String linkReference = "linkReference";
/* 436 */     String linkText = "linkText";
/* 437 */     String link = "link";
/* 438 */     Iterator itr = jsonlist.keys();
/* 439 */     JSONArray arr = new JSONArray();
/*     */     try
/*     */     {
/* 442 */       while (itr.hasNext()) {
/* 443 */         String defaultVal = "";
/* 444 */         String key = (String)itr.next();
/* 445 */         JSONObject cardartdetails = (JSONObject)jsonlist.get(key);
/* 446 */         if (imgRef.equals(cardartdetails.getString(linkReference))) {
/* 447 */           JSONObject cardDetails = new JSONObject();
/* 448 */           if (cardartdetails.getString(linkText).length() != 0) {
/* 449 */             cardDetails.put(linkText, cardartdetails.getString(linkText));
/*     */           } else {
/* 451 */             cardDetails.put(linkText, defaultVal);
/*     */           }
/* 453 */           if (cardartdetails.getString(link).length() != 0) {
/* 454 */             cardDetails.put(link, cardartdetails.getString(link));
/*     */           } else {
/* 456 */             cardDetails.put(link, defaultVal);
/*     */           }
/* 458 */           arr.put(cardDetails);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 462 */       logger.error("Could not get JSON", e.getMessage());
/*     */     }
/*     */     
/* 465 */     return arr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAuthorMode(SlingSettingsService settingsService)
/*     */   {
/* 477 */     boolean authorMode = false;
/* 478 */     if (null != settingsService) {
/* 479 */       Set<String> runModes = settingsService.getRunModes();
/* 480 */       if (null != runModes) {
/* 481 */         authorMode = runModes.contains("author");
/*     */       }
/*     */     }
/* 484 */     return authorMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void replicateResource(Session session, String resourcePath, Replicator replicator)
/*     */   {
/* 495 */     logger.debug("replicator" + replicator);
/* 496 */     if (replicator != null) {
/*     */       try {
/* 498 */         replicator.replicate(session, ReplicationActionType.ACTIVATE, resourcePath);
/* 499 */         logger.debug("Resource Replicated Successfully");
/*     */       } catch (ReplicationException e) {
/* 501 */         logger.error("ReplicationException Occured in  replicateResource() :" + e.getMessage());
/*     */       } catch (Exception e) {
/* 503 */         logger.error("Exception Occured in  replicateResource() :" + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void deactivateResource(Session session, String resourcePath, Replicator replicator)
/*     */   {
/* 518 */     logger.debug("replicator" + replicator);
/* 519 */     if (replicator != null) {
/*     */       try {
/* 521 */         replicator.replicate(session, ReplicationActionType.DEACTIVATE, resourcePath);
/* 522 */         logger.debug("Resource Deactivated Successfully");
/*     */       } catch (ReplicationException e) {
/* 524 */         logger.error("ReplicationException Occured in  deactivateResource() :" + e.getMessage());
/*     */       } catch (Exception e) {
/* 526 */         logger.error("Exception Occured in  deactivateResource() :" + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node getCatgoryOfferNode(Session session, String path, String offerid)
/*     */   {
/* 542 */     logger.debug("initialize getCatgoryOfferNode" + path);
/*     */     
/* 544 */     Node node = null;
/*     */     try
/*     */     {
/* 547 */       QueryManager queryManager = session.getWorkspace().getQueryManager();
/*     */       
/* 549 */       String sqlStatement = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + path + "]) and CONTAINS(s.offerId, '" + offerid + "')";
/*     */       
/*     */ 
/*     */ 
/* 553 */       Query query = queryManager.createQuery(sqlStatement, "JCR-SQL2");
/*     */       
/* 555 */       QueryResult result = query.execute();
/*     */       
/* 557 */       NodeIterator nodeIter = result.getNodes();
/*     */       
/* 559 */       while (nodeIter.hasNext())
/*     */       {
/* 561 */         node = nodeIter.nextNode();
/*     */         
/* 563 */         logger.debug("node path =============>" + node.getPath());
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 567 */       logger.error("repository exception " + e);
/*     */     }
/* 569 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String updateCurrentCategoryPage(String catPagePath, String offerId, JSONObject currentData, Session jcrSession)
/*     */   {
/* 581 */     logger.debug("Initiazing Updation of Category Page ");
/*     */     try
/*     */     {
/* 584 */       Node offerNode = getCatgoryOfferNode(jcrSession, catPagePath, offerId);
/* 585 */       if (offerNode == null) {
/* 586 */         logger.debug("Offer Node Not found on Category Page");
/* 587 */         return catPagePath;
/*     */       }
/* 589 */       if (currentData.length() == 0) {
/* 590 */         offerNode.remove();
/* 591 */         logger.debug("Offer Node Successfully Removed from Category Page");
/*     */       } else {
/* 593 */         offerNode.setProperty("offerId", currentData.getString("offerId"));
/* 594 */         offerNode.setProperty("offerTitle", currentData
/* 595 */           .getString("offerTitle"));
/* 596 */         offerNode.setProperty("merchantName", currentData
/* 597 */           .getString("merchantName"));
/* 598 */         offerNode.setProperty("offerShortDesc", currentData
/* 599 */           .getString("offerShortDesc"));
/* 600 */         offerNode.setProperty("pageType", currentData
/* 601 */           .getString("pageType"));
/* 602 */         offerNode.setProperty("thumbImage", currentData
/* 603 */           .getString("thumbImage"));
/* 604 */         offerNode.setProperty("previewURL", currentData
/* 605 */           .getString("previewURL"));
/* 606 */         offerNode.setProperty("offerSource", currentData
/* 607 */           .getString("offerSource"));
/* 608 */         offerNode.setProperty("offerLastModified", currentData
/* 609 */           .getString("offerLastModified"));
/* 610 */         logger.debug("Offer Node Successfully Updated on Category Page");
/*     */       }
/* 612 */       jcrSession.save();
/* 613 */       return "success";
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 616 */       logger.error("Path Not Found Exception Occured in VPPUtil updateCurrentCategoryPage()" + e
/* 617 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 619 */       logger.error("Repository Exception Occured in VPPUtil updateCurrentCategoryPage()" + e
/* 620 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 622 */       logger.error("JSONException Occured in VPPUtil updateCurrentCategoryPage()");
/*     */     } catch (Exception e) {
/* 624 */       logger.error("Exception Occured in VPPUtil updateCurrentCategoryPage()" + e.getMessage());
/*     */     }
/* 626 */     return "failure";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Map<String, String>> getMultifieldPaths(ArrayList<Map<String, String>> linkedList, String fieldName)
/*     */   {
/* 640 */     ArrayList<Map<String, String>> list = new ArrayList();
/*     */     
/* 642 */     for (int a = 0; a < linkedList.size(); a++) {
/* 643 */       HashMap<String, String> map = new HashMap();
/* 644 */       String keyName = "";
/* 645 */       String data = "";
/* 646 */       Map<String, String> tmpData = (Map)linkedList.get(a);
/*     */       
/* 648 */       for (Map.Entry<String, String> entry : tmpData.entrySet()) {
/* 649 */         keyName = (String)entry.getKey();
/* 650 */         data = (String)entry.getValue();
/*     */         
/* 652 */         if (keyName.equals(fieldName)) {
/* 653 */           data = getUrl(data);
/* 654 */           logger.debug("fieldName is" + fieldName);
/* 655 */           logger.debug("PathField after update  is" + data);
/*     */         }
/* 657 */         logger.debug("Key Value is" + keyName);
/* 658 */         logger.debug("The data is" + data);
/* 659 */         map.put(keyName, data);
/*     */       }
/*     */       
/*     */ 
/* 663 */       list.add(map);
/*     */     }
/*     */     
/* 666 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUrl(String path)
/*     */   {
/* 677 */     if ((path == null) || (path.equals("")))
/* 678 */       return "";
/* 679 */     if ((path.startsWith("http")) || 
/* 680 */       (path.startsWith("https")) || 
/* 681 */       (path.startsWith("/content/dam")))
/* 682 */       return path;
/* 683 */     if ((path.startsWith("/content/vpp")) && 
/* 684 */       (path.indexOf(".html") == -1)) {
/* 685 */       return path + ".html";
/*     */     }
/* 687 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getImageWidthHeight(Resource res)
/*     */   {
/*     */     try
/*     */     {
/* 699 */       AssetDetails assetDetails = new AssetDetails(res);
/* 700 */       int imgWidth = (int)assetDetails.getWidth();
/* 701 */       logger.debug("Image Width : " + imgWidth);
/* 702 */       int imgHeight = (int)assetDetails.getHeight();
/* 703 */       logger.debug("Image Height : " + imgHeight);
/* 704 */       StringBuilder sb = new StringBuilder();
/* 705 */       sb.append(imgWidth).append("_").append(imgHeight);
/* 706 */       return sb.toString();
/*     */     } catch (RepositoryException e) {
/* 708 */       logger.error("Repository Exception Occured while trying to access the asset in VPPUtil getImageWidthHeight()" + e
/* 709 */         .getMessage());
/*     */     } catch (Exception e) {
/* 711 */       logger.error("Exception Occured while trying to access the asset in VPPUtil getImageWidthHeight()" + e
/* 712 */         .getMessage());
/*     */     }
/* 714 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Route getRoute(List<Route> routes, String routeName)
/*     */   {
/* 725 */     Route finalRoute = null;
/* 726 */     for (Route route : routes) {
/* 727 */       if (route.getName().equalsIgnoreCase(routeName)) {
/* 728 */         finalRoute = route;
/* 729 */         break;
/*     */       }
/*     */     }
/* 732 */     return finalRoute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<String> getUserIds(String workFlowInitiator, ResourceResolver resourceResolver)
/*     */   {
/* 744 */     logger.debug("workFlowInitiator in vpp util" + workFlowInitiator);
/* 745 */     ArrayList<String> userGroupIds = new ArrayList();
/* 746 */     UserManager userManager = (UserManager)resourceResolver.adaptTo(UserManager.class);
/*     */     try
/*     */     {
/* 749 */       Authorizable auth = userManager.getAuthorizable(workFlowInitiator);
/* 750 */       if (!auth.isGroup()) {
/* 751 */         Iterator<Group> groups = auth.memberOf();
/* 752 */         while (groups.hasNext()) {
/* 753 */           Group group = (Group)groups.next();
/* 754 */           logger.debug("groupID Name." + group.getID());
/* 755 */           userGroupIds.add(group.getID());
/*     */         }
/* 757 */         logger.debug("Group Ids in getUserIds()" + Arrays.toString(userGroupIds.toArray()));
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 760 */       logger.debug("RepositoryException in getUserIds() of VppUtils" + e.getMessage());
/*     */     }
/* 762 */     return userGroupIds;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\utill\VppUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */