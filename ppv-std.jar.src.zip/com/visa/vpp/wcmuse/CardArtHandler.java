/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ValueMap;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CardArtHandler
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private static final String CARD_IMAGE_MAP_NESTED = "cardImageMapnested";
/*    */   private static final String CARD_IMAGE_MAP = "cardImageMap";
/*    */   private static final String CARD_LOGO = "cardLogo";
/*    */   private static final String IS_CLICKABLE = "isClickable";
/*    */   private ArrayList<Map<String, String>> cardList;
/*    */   private String cardLogo;
/*    */   private String isClickable;
/* 33 */   private Logger logger = LoggerFactory.getLogger(CardArtHandler.class);
/*    */   
/*    */   public void activate() throws Exception
/*    */   {
/* 37 */     this.logger.debug("CardArtHandler Activate initialised");
/* 38 */     ResourceResolver resolver = getResourceResolver();
/* 39 */     Session session = (Session)resolver.adaptTo(Session.class);
/* 40 */     Node currentNode = (Node)getResource().adaptTo(Node.class);
/* 41 */     VppUtil.populateNestedMultifield(currentNode, session, "cardImageMap");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ArrayList<Map<String, String>> getCardList()
/*    */   {
/* 49 */     String[] cards = (String[])getProperties().get("cardImageMapnested", String[].class);
/* 50 */     this.cardList = ((ArrayList)VppUtil.getMultiFieldPanelValuesMap(cards));
/* 51 */     this.logger.debug("cardList from getter :: " + this.cardList.size());
/* 52 */     return this.cardList;
/*    */   }
/*    */   
/*    */   public String getCardLogo() {
/* 56 */     this.cardLogo = ((String)getProperties().get("cardLogo", String.class));
/* 57 */     return this.cardLogo;
/*    */   }
/*    */   
/*    */   public String getIsClickable() {
/* 61 */     this.isClickable = ((String)getProperties().get("isClickable", String.class));
/* 62 */     return this.isClickable;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\CardArtHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */