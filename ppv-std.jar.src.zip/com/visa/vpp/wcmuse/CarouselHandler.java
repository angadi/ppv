/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CarouselHandler
/*    */   extends WCMUsePojo
/*    */ {
/* 20 */   private Logger logger = LoggerFactory.getLogger(CarouselHandler.class);
/*    */   public static final String MULTIFIELD_NAME = "links";
/*    */   
/*    */   public void activate() throws Exception
/*    */   {
/* 25 */     ResourceResolver resolver = getResourceResolver();
/* 26 */     Session session = (Session)resolver.adaptTo(Session.class);
/* 27 */     this.logger.debug("executing carousel script");
/* 28 */     Node currentNode = (Node)getResource().adaptTo(Node.class);
/* 29 */     VppUtil.populateSingleMultifield(currentNode, session, "links");
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\CarouselHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */