/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientLibHandler
/*    */   extends WCMUsePojo
/*    */ {
/* 19 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/* 21 */   private static int ISSUER_PAGE_DEPTH = 3;
/* 22 */   private String issuerName = "";
/* 23 */   private String categoryname = "";
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 28 */     this.logger.debug("ClientLibHandler initialised");
/*    */     
/* 30 */     this.logger.debug("parent path:: " + getCurrentPage().getPath());
/* 31 */     if (getCurrentPage().getDepth() > ISSUER_PAGE_DEPTH) {
/* 32 */       Page page = getCurrentPage().getAbsoluteParent(ISSUER_PAGE_DEPTH);
/* 33 */       if (null != page) {
/* 34 */         this.issuerName = page.getName();
/* 35 */         this.logger.debug("issuerName  :: " + this.issuerName);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getCategoryname()
/*    */   {
/* 46 */     this.logger.debug("Categorynamevpp." + this.issuerName);
/* 47 */     if (!"".equals(this.issuerName)) {
/* 48 */       this.categoryname = ("vpp." + this.issuerName);
/*    */     }
/* 50 */     return this.categoryname;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getIssuerName()
/*    */   {
/* 57 */     return this.issuerName;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\ClientLibHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */