/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeMultiFieldHelper
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private static final String MULTI_FIELD_DATA = "multiFieldData";
/* 20 */   List<Map<String, String>> result = new ArrayList();
/*    */   
/*    */   public void activate() throws Exception
/*    */   {
/* 24 */     String multiFieldData = (String)get("multiFieldData", String.class);
/* 25 */     if (null != multiFieldData) {
/* 26 */       this.result = VppUtil.getMultiLinkJsonData(multiFieldData);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<Map<String, String>> getResult() {
/* 31 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\CompositeMultiFieldHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */