/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.interfaces.FeaturedOfferCheck;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.scripting.SlingScriptHelper;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeaturedOffersCheck
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private String featuredOffersCheck;
/*    */   private String moreOffersCheck;
/*    */   private static final String FEATURED_NODE = "/featured_offers";
/*    */   private static final String MORE_NODE = "/more_offers";
/* 23 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/*    */   public void activate() throws Exception
/*    */   {
/* 27 */     Resource resource = getResource();
/* 28 */     String pagePath = resource.getPath() + "/featured_offers";
/* 29 */     String moreOfferPath = resource.getPath() + "/more_offers";
/* 30 */     this.logger.debug("pagePath" + pagePath);
/* 31 */     this.logger.debug("moreOfferPath " + moreOfferPath);
/*    */     
/* 33 */     FeaturedOfferCheck featuredOffersCheckObj = (FeaturedOfferCheck)getSlingScriptHelper().getService(FeaturedOfferCheck.class);
/* 34 */     this.featuredOffersCheck = featuredOffersCheckObj.checkFeaturedOffers(pagePath);
/* 35 */     this.logger.debug("featuredOffersCheck" + this.featuredOffersCheck);
/* 36 */     this.moreOffersCheck = featuredOffersCheckObj.checkFeaturedOffers(moreOfferPath);
/*    */   }
/*    */   
/*    */   public String getFeaturedOffersCheck()
/*    */   {
/* 41 */     return this.featuredOffersCheck;
/*    */   }
/*    */   
/*    */   public String getMoreOffersCheck()
/*    */   {
/* 46 */     return this.moreOffersCheck;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\FeaturedOffersCheck.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */