/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ import org.apache.sling.api.resource.ValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalFooter
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private static final String FOOTER_LINK_MAP = "footerLinkMap";
/*    */   private ArrayList<Map<String, String>> footerLinksList;
/*    */   private static final String FOOTER_INTERNAL_LINK = "footerInternalLink";
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 24 */     String[] footerLinks = (String[])getProperties().get("footerLinkMap", String[].class);
/*    */     
/* 26 */     this.footerLinksList = ((ArrayList)VppUtil.getMultiFieldPanelValuesMap(footerLinks));
/*    */   }
/*    */   
/*    */   public ArrayList<Map<String, String>> getFooterLinksList()
/*    */   {
/* 31 */     this.footerLinksList = VppUtil.getMultifieldPaths(this.footerLinksList, "footerInternalLink");
/* 32 */     return this.footerLinksList;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\GlobalFooter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */