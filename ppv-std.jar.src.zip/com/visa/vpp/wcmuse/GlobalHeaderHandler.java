/*     */ package com.visa.vpp.wcmuse;
/*     */ 
/*     */ import com.adobe.cq.sightly.WCMUsePojo;
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ValueMap;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalHeaderHandler
/*     */   extends WCMUsePojo
/*     */ {
/*     */   private static final String LANDING_PAGE_TEMPLATE = "landing_page";
/*  31 */   private static String CATEGORY_PAGE_TEMPLATE = "category_page";
/*  32 */   private static String OFFER_PREVIEW_TEMPLATE = "offer_preview";
/*     */   private static final String HOME_PAGE_TEMPLATE = "issuer_home";
/*  34 */   private static String SEARCH_TEMPLATE = "search_page";
/*     */   
/*     */   private static final String NAVIGATION_LINKS_MAP = "navigationLinksMap";
/*     */   
/*     */   private static final String ISSUER_LOGO_LINK_TYPE = "issuerLogoLinkType";
/*     */   
/*     */   private static final String ISSUER_LOGO_INTERNAL_LINK = "issuerLogoInternalLink";
/*     */   private static final String ISSUER_LOGO_EXTERNAL_LINK = "issuerLogoExternalLink";
/*     */   private static final String ISSUER_LOGO_TARGET = "issuerLogoTarget";
/*     */   private static final String ISSUER_NAME = "issuerName";
/*     */   private static final String ISSUER_LOGO_REFERENCE = "issuerLogoReference";
/*     */   private static final String NAVIGATION_LINK_BUTTON_OPTION = "navigationLinkButtonOption";
/*     */   private static final String LOGO_ALT_TEXT = "logoAlttext";
/*     */   private ArrayList<Map<String, String>> navigationLinksList;
/*     */   private String issuerLogoLinkType;
/*     */   private String issuerLogoInternalLink;
/*     */   private String issuerLogoExternalLink;
/*     */   private String issuerLogoTarget;
/*     */   private String issuerName;
/*     */   private String issuerLogo;
/*     */   private String logoAlttext;
/*     */   private String navigationLinkButtonOption;
/*     */   private ArrayList<Map<String, String>> meganavigationList;
/*     */   private static final String IMAGE_REFERENCE = "logoReference";
/*     */   private static final String HOME_LOGO_ALT_TEXT = "homeLogoAltText";
/*     */   private static final String LOGO_URL = "logoUrl";
/*     */   private static final String USE_BUTTON_OPTION = "useButtonOption";
/*     */   private static final String HEADER_TITLE_TEXT = "headerTitleText";
/*     */   private static final String HEADER_LINK_TEXT = "headerLinkText";
/*     */   private static final String HEADER_LINK_URL = "headerLinkURL";
/*     */   private static final String BUTTON_LABEL = "buttonLabel";
/*     */   private static final String BUTTON_LINK = "buttonLink";
/*     */   private static final String SEARCH_TEXT = "searchText";
/*  67 */   private String landingHeaderPath = "/jcr:content/landingPageHeader";
/*     */   
/*     */   private String logoReference;
/*     */   
/*     */   private static final String HOME_LINK_TYPE = "homeLinkType";
/*     */   
/*     */   private static final String HOME_PAGE_LINK_TEXT = "homePageLinkText";
/*     */   
/*     */   private static final String HOME_INTERNAL_LINK = "homeInternalLink";
/*     */   
/*     */   private static final String HOME_EXTERNAL_LINK = "homeExternalLink";
/*     */   
/*     */   private static final String ISSUER_LINK_TEXT = "issuerLinkText";
/*     */   
/*     */   private static final String ISSUER_LINK_URL = "issuerLinkURL";
/*     */   
/*     */   private static final String LOGO_LINK_TYPE = "logoLinkType";
/*     */   
/*     */   private static final String LOGO_INTERNAL_LINK = "logoInternalLink";
/*     */   
/*     */   private static final String LOGO_EXTERNAL_LINK = "logoExternalLink";
/*     */   
/*     */   private static final String INTERNAL = "internal";
/*     */   
/*     */   private static final String EXTERNAL = "external";
/*     */   
/*     */   private String homePageLinkText;
/*     */   
/*     */   private String homePageLinkValue;
/*     */   
/*     */   private String issuerLinkText;
/*     */   
/*     */   private String issuerLinkUrl;
/*     */   
/*     */   private String logoLinkValue;
/*     */   
/*     */   private String homeLogoAltText;
/*     */   private String logoUrl;
/*     */   private String useButtonOption;
/*     */   private String headerTitleText;
/*     */   private String headerLinkText;
/*     */   private String headerLinkUrl;
/*     */   private String buttonLabel;
/*     */   private String buttonLink;
/*     */   private String searchText;
/*     */   private String genericHomeLink;
/* 113 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*     */   
/*     */ 
/*     */   public void activate()
/*     */     throws Exception
/*     */   {
/* 119 */     String[] navigationLinks = (String[])getProperties().get("navigationLinksMap", String[].class);
/*     */     
/* 121 */     this.navigationLinksList = ((ArrayList)VppUtil.getMultiFieldPanelValuesMap(navigationLinks));
/* 122 */     this.issuerLogoLinkType = ((String)getProperties().get("issuerLogoLinkType", String.class));
/* 123 */     this.issuerLogoInternalLink = ((String)getProperties().get("issuerLogoInternalLink", String.class));
/* 124 */     this.issuerLogoExternalLink = ((String)getProperties().get("issuerLogoExternalLink", String.class));
/* 125 */     this.issuerLogoTarget = ((String)getProperties().get("issuerLogoTarget", String.class));
/* 126 */     this.issuerName = ((String)getProperties().get("issuerName", String.class));
/* 127 */     this.issuerLogo = ((String)getProperties().get("issuerLogoReference", String.class));
/* 128 */     this.navigationLinkButtonOption = ((String)getProperties().get("navigationLinkButtonOption", String.class));
/* 129 */     this.logoAlttext = ((String)getProperties().get("logoAlttext", String.class));
/*     */     
/* 131 */     this.logoReference = ((String)getProperties().get("logoReference", String.class));
/* 132 */     this.homeLogoAltText = ((String)getProperties().get("homeLogoAltText", String.class));
/* 133 */     this.logoUrl = ((String)getProperties().get("logoUrl", String.class));
/* 134 */     this.useButtonOption = ((String)getProperties().get("useButtonOption", String.class));
/* 135 */     this.headerTitleText = ((String)getProperties().get("headerTitleText", String.class));
/* 136 */     this.headerLinkText = ((String)getProperties().get("headerLinkText", String.class));
/* 137 */     this.headerLinkUrl = ((String)getProperties().get("headerLinkURL", String.class));
/* 138 */     this.buttonLabel = ((String)getProperties().get("buttonLabel", String.class));
/* 139 */     this.buttonLink = ((String)getProperties().get("buttonLink", String.class));
/* 140 */     this.searchText = ((String)getProperties().get("searchText", String.class));
/* 141 */     Session session = (Session)getResourceResolver().adaptTo(Session.class);
/* 142 */     if (getCurrentPage().getTemplate().getName().equals("issuer_home")) {
/* 143 */       this.genericHomeLink = (getCurrentPage().getPath() + ".html");
/* 144 */       this.logoLinkValue = this.genericHomeLink;
/*     */     }
/*     */     
/* 147 */     if (getCurrentPage().getTemplate().getName().equals("landing_page")) {
/* 148 */       this.logger.debug("inside landing page");
/* 149 */       this.genericHomeLink = (getCurrentPage().getPath() + ".html");
/*     */       
/* 151 */       setLandingPageHeader(getCurrentPage().getPath(), session);
/*     */       
/* 153 */       this.meganavigationList = new ArrayList();
/* 154 */       Iterator<Page> childList = getCurrentPage().listChildren();
/* 155 */       this.logger.debug("inside landingpage");
/* 156 */       while (childList.hasNext()) {
/* 157 */         HashMap<String, String> pageMap = new HashMap();
/* 158 */         Page childPage = (Page)childList.next();
/* 159 */         this.logger
/* 160 */           .debug("child page name:: " + childPage.getName() + " title::" + childPage.getTitle());
/* 161 */         if (childPage.getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) {
/* 162 */           pageMap.put("name", childPage.getTitle());
/* 163 */           pageMap.put("path", childPage.getPath());
/* 164 */           this.meganavigationList.add(pageMap);
/*     */         }
/*     */       }
/* 167 */       this.logger.debug("meganavigationList size:: " + this.meganavigationList.size());
/*     */     }
/* 169 */     if ((getCurrentPage().getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) || 
/* 170 */       (getCurrentPage().getTemplate().getName().equals(OFFER_PREVIEW_TEMPLATE)) || 
/* 171 */       (getCurrentPage().getTemplate().getName().equals(SEARCH_TEMPLATE))) {
/* 172 */       this.logger.debug("inside landing page");
/* 173 */       this.genericHomeLink = (getCurrentPage().getParent().getPath() + ".html");
/* 174 */       setLandingPageHeader(getCurrentPage().getParent().getPath(), session);
/* 175 */       this.meganavigationList = new ArrayList();
/* 176 */       Iterator<Page> childList = getCurrentPage().getParent().listChildren();
/* 177 */       this.logger.debug("inside landingpage");
/* 178 */       while (childList.hasNext()) {
/* 179 */         HashMap<String, String> pageMap = new HashMap();
/* 180 */         Page childPage = (Page)childList.next();
/* 181 */         this.logger
/* 182 */           .debug("child page name:: " + childPage.getName() + " title::" + childPage.getTitle());
/* 183 */         if (childPage.getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) {
/* 184 */           pageMap.put("name", childPage.getTitle());
/* 185 */           pageMap.put("path", childPage.getPath());
/* 186 */           this.meganavigationList.add(pageMap);
/*     */         }
/*     */       }
/* 189 */       this.logger.debug("meganavigationList size:: " + this.meganavigationList.size());
/*     */     }
/*     */     
/* 192 */     this.logger.debug("genericHomeLink:: " + this.genericHomeLink);
/*     */   }
/*     */   
/*     */   public ArrayList<Map<String, String>> getNavigationLinksList() {
/* 196 */     return this.navigationLinksList;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoLinkType() {
/* 200 */     return this.issuerLogoLinkType;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoInternalLink() {
/* 204 */     return this.issuerLogoInternalLink;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoExternalLink() {
/* 208 */     return this.issuerLogoExternalLink;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoTarget() {
/* 212 */     return this.issuerLogoTarget;
/*     */   }
/*     */   
/*     */   public String getIssuerName() {
/* 216 */     return this.issuerName;
/*     */   }
/*     */   
/*     */   public String getIssuerLogo() {
/* 220 */     return this.issuerLogo;
/*     */   }
/*     */   
/*     */   public String getNavigationLinkButtonOption() {
/* 224 */     return this.navigationLinkButtonOption;
/*     */   }
/*     */   
/*     */   public String getLogoAlttext() {
/* 228 */     return this.logoAlttext;
/*     */   }
/*     */   
/*     */   public String getLogoReference() {
/* 232 */     return this.logoReference;
/*     */   }
/*     */   
/*     */   public String getHomeLogoAltText() {
/* 236 */     return this.homeLogoAltText;
/*     */   }
/*     */   
/*     */   public String getLogoUrl() {
/* 240 */     return this.logoUrl;
/*     */   }
/*     */   
/*     */   public String getUseButtonOption() {
/* 244 */     return this.useButtonOption;
/*     */   }
/*     */   
/*     */   public String getHeaderTitleText() {
/* 248 */     return this.headerTitleText;
/*     */   }
/*     */   
/*     */   public String getHeaderLinkText() {
/* 252 */     return this.headerLinkText;
/*     */   }
/*     */   
/*     */   public String getHeaderLinkUrl() {
/* 256 */     return this.headerLinkUrl;
/*     */   }
/*     */   
/*     */   public String getButtonLabel() {
/* 260 */     return this.buttonLabel;
/*     */   }
/*     */   
/*     */   public String getButtonLink() {
/* 264 */     return this.buttonLink;
/*     */   }
/*     */   
/*     */   public ArrayList<Map<String, String>> getMeganavigationList() {
/* 268 */     return this.meganavigationList;
/*     */   }
/*     */   
/*     */   public String getSearchText() {
/* 272 */     return this.searchText;
/*     */   }
/*     */   
/*     */   public String getGenericHomeLink() {
/* 276 */     return this.genericHomeLink;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getHomePageLinkText()
/*     */   {
/* 282 */     return this.homePageLinkText;
/*     */   }
/*     */   
/*     */   public void setHomePageLinkText(String homePageLinkText) {
/* 286 */     this.homePageLinkText = homePageLinkText;
/*     */   }
/*     */   
/*     */   public String getHomePageLinkValue() {
/* 290 */     return this.homePageLinkValue;
/*     */   }
/*     */   
/*     */   public void setHomePageLinkValue(String homePageLinkValue) {
/* 294 */     this.homePageLinkValue = homePageLinkValue;
/*     */   }
/*     */   
/*     */   public String getIssuerLinkText() {
/* 298 */     return this.issuerLinkText;
/*     */   }
/*     */   
/*     */   public void setIssuerLinkText(String issuerLinkText) {
/* 302 */     this.issuerLinkText = issuerLinkText;
/*     */   }
/*     */   
/*     */   public String getIssuerLinkUrl() {
/* 306 */     return this.issuerLinkUrl;
/*     */   }
/*     */   
/*     */   public void setIssuerLinkUrl(String issuerLinkUrl) {
/* 310 */     this.issuerLinkUrl = issuerLinkUrl;
/*     */   }
/*     */   
/*     */   public String getLogoLinkValue() {
/* 314 */     return this.logoLinkValue;
/*     */   }
/*     */   
/*     */   public void setLogoLinkValue(String logoLinkValue) {
/* 318 */     this.logoLinkValue = logoLinkValue;
/*     */   }
/*     */   
/*     */   public void setSearchText(String searchText) {
/* 322 */     this.searchText = searchText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLandingPageHeader(String path, Session session)
/*     */   {
/* 333 */     this.logger.debug(" setLandingPageHeader path " + path);
/* 334 */     Node node = null;
/*     */     try {
/* 336 */       if (session.nodeExists(path + this.landingHeaderPath)) {
/* 337 */         node = session.getNode(path + this.landingHeaderPath);
/* 338 */         this.logger.debug("prp val :" + node.getProperty("logoLinkType").getValue().getString());
/*     */         
/*     */ 
/*     */ 
/* 342 */         if (node.hasProperty("issuerLinkText")) {
/* 343 */           this.issuerLinkText = node.getProperty("issuerLinkText").getValue().getString();
/*     */         }
/* 345 */         if (node.hasProperty("issuerLinkURL")) {
/* 346 */           this.issuerLinkUrl = node.getProperty("issuerLinkURL").getValue().getString();
/*     */         }
/* 348 */         if (node.hasProperty("homePageLinkText")) {
/* 349 */           this.homePageLinkText = node.getProperty("homePageLinkText").getValue().getString();
/*     */         }
/* 351 */         if (node.hasProperty("homeLinkType")) {
/* 352 */           String linkType = node.getProperty("homeLinkType").getValue().getString();
/* 353 */           if ((linkType.equals("internal")) && (node.hasProperty("homeInternalLink")))
/*     */           {
/* 355 */             this.homePageLinkValue = node.getProperty("homeInternalLink").getValue().getString();
/* 356 */             this.homePageLinkValue = VppUtil.getUrl(this.homePageLinkValue);
/*     */           }
/*     */           
/*     */ 
/* 360 */           if ((linkType.equals("external")) && (node.hasProperty("homeExternalLink")))
/*     */           {
/* 362 */             this.homePageLinkValue = node.getProperty("homeExternalLink").getValue().getString();
/*     */           }
/*     */         }
/* 365 */         if (node.hasProperty("logoLinkType")) {
/* 366 */           String linkType = node.getProperty("logoLinkType").getValue().getString();
/* 367 */           if ((linkType.equals("internal")) && (node.hasProperty("logoInternalLink")))
/*     */           {
/* 369 */             this.logoLinkValue = node.getProperty("logoInternalLink").getValue().getString();
/* 370 */             this.logoLinkValue = VppUtil.getUrl(this.logoLinkValue);
/*     */           }
/*     */           
/*     */ 
/* 374 */           if ((linkType.equals("external")) && (node.hasProperty("logoExternalLink")))
/*     */           {
/* 376 */             this.logoLinkValue = node.getProperty("logoExternalLink").getValue().getString();
/*     */           }
/*     */         }
/*     */         
/* 380 */         if (node.hasProperty("searchText")) {
/* 381 */           this.searchText = node.getProperty("searchText").getValue().getString();
/*     */         }
/* 383 */         this.logger.debug("issuerLinkText " + this.issuerLinkText);
/* 384 */         this.logger.debug("issuerLinkUrl " + this.issuerLinkUrl);
/* 385 */         this.logger.debug("homePageLinkText " + this.homePageLinkText);
/* 386 */         this.logger.debug("homePageLinkValue " + this.homePageLinkValue);
/* 387 */         this.logger.debug("logoLinkValue " + this.logoLinkValue);
/*     */       } else {
/* 389 */         this.logoLinkValue = this.genericHomeLink;
/* 390 */         this.homePageLinkValue = this.genericHomeLink;
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 393 */       this.logger.error("RepositoryException in setLandingPageHeader() of GlobalHeaderHandler" + e
/* 394 */         .getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\GlobalHeaderHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */