/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.day.cq.wcm.api.Template;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InheritCardArtLanding
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private String componentPath;
/* 23 */   private static String CATEGORY_PAGE_TEMPLATE = "category_page";
/* 24 */   private static String OFFER_PREVIEW_TEMPLATE = "offer_preview";
/* 25 */   private static String SEARCH_TEMPLATE = "search_page";
/* 26 */   private String cardArtPagePath = "/jcr:content/cardArtLanding";
/* 27 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 32 */     this.logger.debug("InheritCardArtLanding initialised");
/* 33 */     this.logger.debug("current page path:: " + getCurrentPage().getPath());
/* 34 */     this.logger.debug("depth ::" + getCurrentPage().getDepth());
/* 35 */     Session session = (Session)getResourceResolver().adaptTo(Session.class);
/* 36 */     this.logger.debug("template name :: " + getCurrentPage().getTemplate().getName());
/* 37 */     this.logger.debug("parent path:: " + getCurrentPage().getParent().getPath());
/*    */     
/* 39 */     if ((getCurrentPage().getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) || 
/* 40 */       (getCurrentPage().getTemplate().getName().equals(OFFER_PREVIEW_TEMPLATE)) || 
/* 41 */       (getCurrentPage().getTemplate().getName().equals(SEARCH_TEMPLATE))) {
/* 42 */       this.logger.debug("inside child home page");
/* 43 */       Page page = getCurrentPage().getParent();
/* 44 */       this.logger.debug("page getpath" + page.getPath());
/* 45 */       this.logger.debug("node ?" + session.nodeExists(new StringBuilder().append(page.getPath()).append(this.cardArtPagePath).toString()));
/* 46 */       if (session.nodeExists(page.getPath() + this.cardArtPagePath)) {
/* 47 */         this.componentPath = (page.getPath() + this.cardArtPagePath);
/*    */       }
/*    */     }
/*    */     
/* 51 */     this.logger.debug("componentPath:: " + this.componentPath);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getComponentPath()
/*    */   {
/* 59 */     return this.componentPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\InheritCardArtLanding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */