/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.day.cq.wcm.api.Template;
/*    */ import java.util.Iterator;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InheritFooter
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private String footerPath;
/* 22 */   private static int HOME_PAGE_DEPTH = 6;
/* 23 */   private static String HOME_PAGE_TEMPLATE = "issuer_home";
/* 24 */   private String footerPagePath = "footer/jcr:content/footer";
/* 25 */   private static int PARENT_HOME_PAGE_DEPTH = 5;
/* 26 */   private static String LANDING_PAGE_TEMPLATE = "landing_page";
/* 27 */   private static String CATEGORY_PAGE_TEMPLATE = "category_page";
/* 28 */   private static String OFFER_PREVIEW_TEMPLATE = "offer_preview";
/* 29 */   private static String SEARCH_TEMPLATE = "search_page";
/* 30 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 35 */     this.logger.debug("InheritFooter initialised");
/* 36 */     this.logger.debug("current page path:: " + getCurrentPage().getPath());
/* 37 */     this.logger.debug("depth ::" + getCurrentPage().getDepth());
/* 38 */     Session session = (Session)getResourceResolver().adaptTo(Session.class);
/* 39 */     this.logger.debug("template name :: " + getCurrentPage().getTemplate().getName());
/* 40 */     this.logger.debug("parent path:: " + getCurrentPage().getParent().getPath());
/* 41 */     if ((getCurrentPage().getDepth() == HOME_PAGE_DEPTH) && 
/* 42 */       (getCurrentPage().getTemplate().getName().equals(HOME_PAGE_TEMPLATE))) {
/* 43 */       this.logger.debug("inside home page");
/* 44 */       if (session.nodeExists(getCurrentPage().getPath() + "/" + this.footerPagePath)) {
/* 45 */         this.footerPath = (getCurrentPage().getPath() + "/" + this.footerPagePath);
/*    */       }
/*    */     }
/* 48 */     if (((getCurrentPage().getTemplate().getName().equals(HOME_PAGE_TEMPLATE)) && 
/* 49 */       (getCurrentPage().getDepth() > HOME_PAGE_DEPTH)) || 
/* 50 */       (getCurrentPage().getTemplate().getName().equals(LANDING_PAGE_TEMPLATE)) || 
/* 51 */       (getCurrentPage().getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) || 
/* 52 */       (getCurrentPage().getTemplate().getName().equals(OFFER_PREVIEW_TEMPLATE)) || 
/* 53 */       (getCurrentPage().getTemplate().getName().equals(SEARCH_TEMPLATE))) {
/* 54 */       this.logger.debug("inside child home page");
/* 55 */       Page page = getCurrentPage().getAbsoluteParent(PARENT_HOME_PAGE_DEPTH);
/* 56 */       this.logger.debug("page getpath" + page.getPath());
/* 57 */       if (session.nodeExists(page.getPath() + "/" + this.footerPagePath)) {
/* 58 */         this.footerPath = (page.getPath() + "/" + this.footerPagePath);
/*    */       }
/*    */     }
/*    */     
/* 62 */     if (getCurrentPage().getTemplate().getName().equals(LANDING_PAGE_TEMPLATE)) {
/* 63 */       this.logger.debug("inside landing page");
/* 64 */       Page page = getCurrentPage().getAbsoluteParent(PARENT_HOME_PAGE_DEPTH);
/* 65 */       this.logger.debug("page getpath" + page.getPath());
/* 66 */       if (session.nodeExists(page.getPath() + "/" + this.footerPagePath)) {
/* 67 */         this.footerPath = (page.getPath() + "/" + this.footerPagePath);
/*    */       }
/* 69 */       Iterator<Page> childList = getCurrentPage().listChildren();
/* 70 */       while (childList.hasNext()) {
/* 71 */         this.logger.debug("child page" + ((Page)childList.next()).getName());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getFooterPath()
/*    */   {
/* 78 */     return this.footerPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\InheritFooter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */