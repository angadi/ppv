/*    */ package com.visa.vpp.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.day.cq.wcm.api.Template;
/*    */ import java.util.Iterator;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InheritHeader
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private String headerPath;
/* 24 */   private static int HOME_PAGE_DEPTH = 6;
/* 25 */   private static int PARENT_HOME_PAGE_DEPTH = 5;
/* 26 */   private static String HOME_PAGE_TEMPLATE = "issuer_home";
/* 27 */   private static String LANDING_PAGE_TEMPLATE = "landing_page";
/* 28 */   private static String CATEGORY_PAGE_TEMPLATE = "category_page";
/* 29 */   private static String OFFER_PREVIEW_TEMPLATE = "offer_preview";
/* 30 */   private static String SEARCH_TEMPLATE = "search_page";
/* 31 */   private String headerPagePath = "header/jcr:content/header";
/* 32 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 37 */     this.logger.debug("InheritHeader initialised");
/* 38 */     this.logger.debug("current page path:: " + getCurrentPage().getPath());
/* 39 */     this.logger.debug("depth ::" + getCurrentPage().getDepth());
/* 40 */     Session session = (Session)getResourceResolver().adaptTo(Session.class);
/* 41 */     this.logger.debug("template name :: " + getCurrentPage().getTemplate().getName());
/* 42 */     this.logger.debug("parent path:: " + getCurrentPage().getParent().getPath());
/* 43 */     if ((getCurrentPage().getDepth() == HOME_PAGE_DEPTH) && 
/* 44 */       (getCurrentPage().getTemplate().getName().equals(HOME_PAGE_TEMPLATE))) {
/* 45 */       this.logger.debug("inside home page");
/* 46 */       if (session.nodeExists(getCurrentPage().getPath() + "/" + this.headerPagePath)) {
/* 47 */         this.headerPath = (getCurrentPage().getPath() + "/" + this.headerPagePath);
/*    */       }
/*    */     }
/* 50 */     if (((getCurrentPage().getTemplate().getName().equals(HOME_PAGE_TEMPLATE)) && 
/* 51 */       (getCurrentPage().getDepth() > HOME_PAGE_DEPTH)) || 
/* 52 */       (getCurrentPage().getTemplate().getName().equals(CATEGORY_PAGE_TEMPLATE)) || 
/* 53 */       (getCurrentPage().getTemplate().getName().equals(OFFER_PREVIEW_TEMPLATE)) || 
/* 54 */       (getCurrentPage().getTemplate().getName().equals(SEARCH_TEMPLATE))) {
/* 55 */       this.logger.debug("inside child home page");
/* 56 */       Page page = getCurrentPage().getAbsoluteParent(PARENT_HOME_PAGE_DEPTH);
/* 57 */       this.logger.debug("page getpath" + page.getPath());
/* 58 */       if (session.nodeExists(page.getPath() + "/" + this.headerPagePath)) {
/* 59 */         this.headerPath = (page.getPath() + "/" + this.headerPagePath);
/*    */       }
/*    */     }
/*    */     
/* 63 */     if (getCurrentPage().getTemplate().getName().equals(LANDING_PAGE_TEMPLATE)) {
/* 64 */       this.logger.debug("inside landing page");
/* 65 */       Page page = getCurrentPage().getAbsoluteParent(PARENT_HOME_PAGE_DEPTH);
/* 66 */       this.logger.debug("page getpath" + page.getPath());
/* 67 */       if (session.nodeExists(page.getPath() + "/" + this.headerPagePath)) {
/* 68 */         this.headerPath = (page.getPath() + "/" + this.headerPagePath);
/*    */       }
/* 70 */       Iterator<Page> childList = getCurrentPage().listChildren();
/* 71 */       while (childList.hasNext()) {
/* 72 */         this.logger.debug("child page" + ((Page)childList.next()).getName());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getHeaderPath()
/*    */   {
/* 80 */     return this.headerPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\InheritHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */