/*     */ package com.visa.vpp.wcmuse;
/*     */ 
/*     */ import com.adobe.cq.sightly.WCMUsePojo;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.sling.api.resource.ValueMap;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.parser.Tag;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OfferPreviewHandler
/*     */   extends WCMUsePojo
/*     */ {
/*     */   private String visaTermsandConditions;
/*     */   private String merchantTermsandConditions;
/*     */   public String totalTermsandConditions;
/*     */   public String totalTermsandConditionsHtml;
/*     */   private Calendar validStartDate;
/*     */   private Calendar validEndDate;
/*     */   public String eventStartDate;
/*     */   public String eventEndDate;
/*  39 */   public ArrayList<String> allElements = new ArrayList();
/*  40 */   public ArrayList<String> restElements = new ArrayList();
/*  41 */   public int visaTermsandConditionsCount = 0;
/*  42 */   public int merchantTermsandConditionsCount = 0;
/*  43 */   private int finalTermsandConditionsCount = 0;
/*     */   public static final String VISA_TandC = "visaTandC";
/*     */   public static final String MERCHANT_TandC = "merchantTandC";
/*     */   public static final String VAL_START_DATE = "valStartDate";
/*     */   public static final String VAL_END_DATE = "valEndDate";
/*     */   public static final String TAG_LI = "li";
/*     */   public static final String TAG_P = "p";
/*     */   public static final String TAG_OL = "ol";
/*     */   public static final String TAG_UL = "ul";
/*     */   public static final String TAG_UL_HTML_START_CLASS = "<ul class= \"tcList\">";
/*     */   public static final String TAG_OL_HTML_START_CLASS = "<ol class= \"tcList\">";
/*     */   public static final String TAG_P_HTML_START_CLASS = "<p class= \"tcList\">";
/*     */   public static final String TAG_UL_HTML_START = "<ul>";
/*     */   public static final String TAG_UL_HTML_END = "</ul>";
/*     */   public static final String TAG_OL_HTML_START = "<ol>";
/*     */   public static final String TAG_OL_HTML_END = "</ol>";
/*     */   public static final String TAG_P_HTML_START = "<p>";
/*     */   public static final String TAG_P_HTML_END = "</p>";
/*     */   public static final String TAG_HIDE_ELEM = "<span class= \"remainingTC hideElem\">";
/*     */   public static final int TERMS_AND_CONDITIONS_COUNT = 9;
/*     */   public String parentTagStart;
/*     */   public String parentTagEnd;
/*  65 */   public String moreTag = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String parentTagRestStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionTelChecked;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionTel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionMail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionMailChecked;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String offerCopy;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String visaTandC;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String merchantTandC;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String EMAIL_PATTERN = "[a-zA-Z0-9]+[._a-zA-Z0-9!#$%&'*+-=?^_`{|}~]*[a-zA-Z]*@[a-zA-Z0-9]{2,8}.[a-zA-Z.]{2,6}";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String TEL_PATTERN = "(\\d-)?(\\d{3}-)?\\d{3,4}-\\d{4}|\\+(\\d{2}-\\(\\d{1}\\)\\d{2}-\\d{4}-\\d{4})|\\+(\\d{2}-\\d{10})|\\+(\\d{2}-\\d{4}-\\d{4})|(\\d{1}\\s\\d{2}\\s\\d{8})|(\\d{2}\\s\\d{2}\\s\\d{8})|(\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\(\\d{2}\\)\\-\\d{10})|(\\(\\d{2}\\)\\s\\d{10})|(\\(\\d{4}\\)\\s\\d{6})|(\\(\\+(\\d{2}\\s\\d{4}\\))\\s\\d{6})|(\\(\\+(\\d{3}\\))\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\(\\+(\\d{2}\\s\\-\\d{2}\\))\\s\\d{8})|(\\(\\d{2}\\)\\s\\-\\s\\(\\d{2}\\)\\s\\-\\s\\d{8})|(\\(\\+(\\d{2}\\))\\-\\d{2}\\s\\d{8})|(\\(\\d{3}\\s\\d{3}\\)\\s\\d{8})|(\\(\\d{2}\\)\\-\\(\\d{2}\\)\\-\\s\\d{8})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{8})|(\\d{3}-\\d{3}-\\d{4})|(\\[\\+\\d{1}]\\s\\d{3}-\\d{3}-\\d{4})|(\\(\\d{3}\\)\\-\\d{3}-\\d{4})|(\\d{2}-\\d{2}-\\d{8})|(\\d{2}-\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\-\\s\\d{2}\\s\\-\\s\\d{8})|(\\d{2}-\\d{4}-\\d{6})|(\\d{2}\\s\\-\\s\\d{4}\\s\\-\\s\\d{6})|(\\d{1}-\\d{3}-\\d{3}-\\d{4})|(\\d{2}-\\d{3}-\\d{3}-\\d{4})|(\\d{1}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{2}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{3}-\\d{7})|(\\d{2}-\\d{10})|(\\d{1}\\-\\d{3}-\\d{7})|(\\d{2}\\-\\d{3}-\\d{7})|(\\d{1}\\s\\d{3}-\\d{7})|(\\d{2}\\s\\d{3}-\\d{7})|(^(\\+\\d{2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$)|(\\d{1}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\d{3}\\s\\d{4})|(\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{1}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{1}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{7})|(\\d{1}\\s\\d{3}\\s\\d{7})|(\\d{3}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{4}\\s\\d{4})|(\\d{2}\\-\\d{2}\\-\\d{4}\\s\\d{4})|(\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{2}\\s\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{1}\\.\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{5}\\s\\d{9})|(\\d{4}\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\(\\d{1}\\)\\s\\d{7})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\d{3}\\s\\d{2}\\s\\d{5})|(\\d{2}\\s\\(\\d{1}\\)\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{4}\\s\\d{3}\\s\\d{4})|(\\d{4}-\\d{3}-\\d{4})|(\\d{3}-\\d{8})|(\\d{3}-\\d{2}-\\d{5})|(\\d{2}\\s\\d{2}\\s\\d{4}-\\d{4})|(\\d{2}\\-\\d{2}\\. ISSN \\d{4}-\\d{4})|(\\d{4}\\-\\d{4}\\-\\d{1}-\\d{3})|(\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{3}\\s\\d{1}\\s\\d{7})|(\\d{13})|(\\d{12})|(\\d{11})|(\\d{10})|(\\d{9})|(\\d{2}\\s\\d{10})|(\\d{1}\\s\\d{10})|(^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$)";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */   private Logger logger = LoggerFactory.getLogger(OfferPreviewHandler.class);
/*     */   
/*     */   public void activate() throws Exception
/*     */   {
/* 271 */     this.logger.debug("OfferPreviewHandler Activate initialised");
/*     */     
/* 273 */     this.eventStartDate = VppUtil.convertCalendarToString(getValidStartDate(), "MMM d, yyyy");
/*     */     
/* 275 */     this.eventEndDate = VppUtil.convertCalendarToString(getValidEndDate(), "MMM d, yyyy");
/* 276 */     this.redemptionTelChecked = formatTelephone(getRedemptionTel());
/* 277 */     this.redemptionMailChecked = formatEmail(getRedemptionEmail());
/* 278 */     this.logger.debug("redemptionMailChck--" + this.redemptionMailChecked);
/* 279 */     this.totalTermsandConditions = (getVisaTermsandConditions() + getMerchantTermsandConditions());
/*     */     
/* 281 */     this.totalTermsandConditionsHtml = renderTotalTermsandConditionsHtml(this.allElements, this.restElements);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVisaTermsandConditions()
/*     */   {
/* 292 */     this.visaTermsandConditions = ((String)getProperties().get("visaTandC", String.class));
/* 293 */     if (this.visaTermsandConditions != null) {
/* 294 */       this.visaTermsandConditionsCount = getTermsAndConditionsCount(this.visaTermsandConditions).intValue();
/*     */     }
/* 296 */     return this.visaTermsandConditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMerchantTermsandConditions()
/*     */   {
/* 304 */     this.merchantTermsandConditions = ((String)getProperties().get("merchantTandC", String.class));
/* 305 */     if (this.merchantTermsandConditions != null) {
/* 306 */       this.merchantTermsandConditionsCount = getTermsAndConditionsCount(this.merchantTermsandConditions).intValue();
/*     */     }
/* 308 */     return this.merchantTermsandConditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getValidStartDate()
/*     */   {
/* 316 */     this.validStartDate = ((Calendar)getProperties().get("valStartDate", Calendar.class));
/* 317 */     return this.validStartDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getValidEndDate()
/*     */   {
/* 325 */     this.validEndDate = ((Calendar)getProperties().get("valEndDate", Calendar.class));
/* 326 */     return this.validEndDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFinalTermsandConditionsCount()
/*     */   {
/* 335 */     this.finalTermsandConditionsCount = (this.visaTermsandConditionsCount + this.merchantTermsandConditionsCount);
/* 336 */     return this.finalTermsandConditionsCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRedemptionTel()
/*     */   {
/* 344 */     this.redemptionTel = ((String)getProperties().get("redemptionTel", String.class));
/* 345 */     return this.redemptionTel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRedemptionEmail()
/*     */   {
/* 354 */     this.redemptionMail = ((String)getProperties().get("redemptionEmail", String.class));
/* 355 */     return this.redemptionMail;
/*     */   }
/*     */   
/*     */   public String getOfferCopy()
/*     */   {
/* 360 */     return this.offerCopy;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getVisaTandC()
/*     */   {
/* 366 */     return this.visaTandC;
/*     */   }
/*     */   
/*     */   public String getMerchantTandC()
/*     */   {
/* 371 */     return this.merchantTandC;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getTermsAndConditionsCount(String text)
/*     */   {
/* 380 */     Document doc = Jsoup.parse(text);
/* 381 */     Elements elements = doc.getAllElements();
/* 382 */     Integer count = Integer.valueOf(0);
/*     */     
/* 384 */     for (Element em : elements) {
/* 385 */       Tag tg = em.tag();
/* 386 */       if ((tg.getName().equalsIgnoreCase("ul")) || (tg.getName().equalsIgnoreCase("ol")) || 
/* 387 */         (tg.getName().equalsIgnoreCase("p"))) {
/* 388 */         this.moreTag = "<span class= \"remainingTC hideElem\">";
/*     */         
/* 390 */         if (tg.getName().equalsIgnoreCase("ul")) {
/* 391 */           this.parentTagStart = "<ul class= \"tcList\">";
/* 392 */           this.parentTagRestStart = "<ul>";
/* 393 */           this.parentTagEnd = "</ul>";
/*     */         }
/* 395 */         else if (tg.getName().equalsIgnoreCase("ol")) {
/* 396 */           this.parentTagStart = "<ol class= \"tcList\">";
/* 397 */           this.parentTagRestStart = "<ol>";
/* 398 */           this.parentTagEnd = "</ol>";
/*     */         } else {
/* 400 */           this.parentTagStart = "<p class= \"tcList\">";
/* 401 */           this.parentTagRestStart = "<p>";
/* 402 */           this.parentTagEnd = "</p>";
/*     */         }
/*     */       }
/*     */       
/* 406 */       if (((tg.getName().equalsIgnoreCase("li")) || (tg.getName().equalsIgnoreCase("p"))) && 
/* 407 */         (em.hasText()) && (em.text() != null)) {
/* 408 */         Integer localInteger1 = count;Integer localInteger2 = count = Integer.valueOf(count.intValue() + 1);
/* 409 */         this.finalTermsandConditionsCount += 1;
/* 410 */         if (this.finalTermsandConditionsCount <= 9) {
/* 411 */           this.allElements.add(em.toString());
/*     */         } else {
/* 413 */           this.restElements.add(em.toString());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 418 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String renderTotalTermsandConditionsHtml(ArrayList<String> allElements2, ArrayList<String> restElements2)
/*     */   {
/* 431 */     String result = "";
/* 432 */     StringBuffer resultFinal = new StringBuffer();
/*     */     
/* 434 */     if ((!allElements2.isEmpty()) || (!restElements2.isEmpty()))
/*     */     {
/* 436 */       resultFinal.append(this.parentTagStart);
/*     */       
/*     */ 
/* 439 */       for (int i = 0; i < allElements2.size(); i++) {
/* 440 */         String item = (String)allElements2.get(i);
/* 441 */         resultFinal.append(item);
/*     */       }
/*     */       
/* 444 */       if (!restElements2.isEmpty()) {
/* 445 */         resultFinal.append(this.moreTag);
/* 446 */         for (int i = 0; i < restElements2.size(); i++) {
/* 447 */           String item = (String)restElements2.get(i);
/* 448 */           resultFinal.append(item);
/*     */         }
/*     */       }
/*     */       
/* 452 */       resultFinal.append(this.parentTagEnd);
/*     */     }
/* 454 */     result = resultFinal.toString();
/* 455 */     if ((null != result) && (result.length() > 0)) {
/* 456 */       result = result.replaceAll("<a", "<a target='blank'");
/*     */     }
/* 458 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatTelephone(String redemptionTel)
/*     */   {
/* 467 */     Boolean hasAnchor = Boolean.valueOf(false);
/* 468 */     this.logger.debug("OfferPreviewHandler format Telephone" + redemptionTel);
/* 469 */     if (redemptionTel != null)
/*     */     {
/* 471 */       Document doc = Jsoup.parse(redemptionTel);
/* 472 */       Elements elements = doc.getAllElements();
/* 473 */       for (Element em : elements) {
/* 474 */         Tag tg = em.tag();
/* 475 */         if (tg.getName().equalsIgnoreCase("a")) {
/* 476 */           hasAnchor = Boolean.valueOf(true);
/*     */         }
/*     */       }
/*     */       
/* 480 */       if (!hasAnchor.booleanValue())
/*     */       {
/* 482 */         Pattern p = Pattern.compile("(\\d-)?(\\d{3}-)?\\d{3,4}-\\d{4}|\\+(\\d{2}-\\(\\d{1}\\)\\d{2}-\\d{4}-\\d{4})|\\+(\\d{2}-\\d{10})|\\+(\\d{2}-\\d{4}-\\d{4})|(\\d{1}\\s\\d{2}\\s\\d{8})|(\\d{2}\\s\\d{2}\\s\\d{8})|(\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\(\\d{2}\\)\\-\\d{10})|(\\(\\d{2}\\)\\s\\d{10})|(\\(\\d{4}\\)\\s\\d{6})|(\\(\\+(\\d{2}\\s\\d{4}\\))\\s\\d{6})|(\\(\\+(\\d{3}\\))\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\(\\+(\\d{2}\\s\\-\\d{2}\\))\\s\\d{8})|(\\(\\d{2}\\)\\s\\-\\s\\(\\d{2}\\)\\s\\-\\s\\d{8})|(\\(\\+(\\d{2}\\))\\-\\d{2}\\s\\d{8})|(\\(\\d{3}\\s\\d{3}\\)\\s\\d{8})|(\\(\\d{2}\\)\\-\\(\\d{2}\\)\\-\\s\\d{8})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{8})|(\\d{3}-\\d{3}-\\d{4})|(\\[\\+\\d{1}]\\s\\d{3}-\\d{3}-\\d{4})|(\\(\\d{3}\\)\\-\\d{3}-\\d{4})|(\\d{2}-\\d{2}-\\d{8})|(\\d{2}-\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\-\\s\\d{2}\\s\\-\\s\\d{8})|(\\d{2}-\\d{4}-\\d{6})|(\\d{2}\\s\\-\\s\\d{4}\\s\\-\\s\\d{6})|(\\d{1}-\\d{3}-\\d{3}-\\d{4})|(\\d{2}-\\d{3}-\\d{3}-\\d{4})|(\\d{1}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{2}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{3}-\\d{7})|(\\d{2}-\\d{10})|(\\d{1}\\-\\d{3}-\\d{7})|(\\d{2}\\-\\d{3}-\\d{7})|(\\d{1}\\s\\d{3}-\\d{7})|(\\d{2}\\s\\d{3}-\\d{7})|(^(\\+\\d{2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$)|(\\d{1}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\d{3}\\s\\d{4})|(\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{1}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{1}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{7})|(\\d{1}\\s\\d{3}\\s\\d{7})|(\\d{3}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{4}\\s\\d{4})|(\\d{2}\\-\\d{2}\\-\\d{4}\\s\\d{4})|(\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{2}\\s\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{1}\\.\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{5}\\s\\d{9})|(\\d{4}\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\(\\d{1}\\)\\s\\d{7})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\d{3}\\s\\d{2}\\s\\d{5})|(\\d{2}\\s\\(\\d{1}\\)\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{4}\\s\\d{3}\\s\\d{4})|(\\d{4}-\\d{3}-\\d{4})|(\\d{3}-\\d{8})|(\\d{3}-\\d{2}-\\d{5})|(\\d{2}\\s\\d{2}\\s\\d{4}-\\d{4})|(\\d{2}\\-\\d{2}\\. ISSN \\d{4}-\\d{4})|(\\d{4}\\-\\d{4}\\-\\d{1}-\\d{3})|(\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{3}\\s\\d{1}\\s\\d{7})|(\\d{13})|(\\d{12})|(\\d{11})|(\\d{10})|(\\d{9})|(\\d{2}\\s\\d{10})|(\\d{1}\\s\\d{10})|(^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$)");
/* 483 */         Matcher matcher = p.matcher(redemptionTel);
/* 484 */         while (matcher.find()) {
/* 485 */           String str1 = matcher.group();
/* 486 */           this.logger.debug("Text found " + str1 + " starting at index " + matcher
/* 487 */             .start() + " and ending at index " + matcher.end());
/* 488 */           Element anchorCheck = doc.createElement("a");
/* 489 */           anchorCheck = anchorCheck.attr("href", "tel:" + str1);
/* 490 */           anchorCheck = anchorCheck.attr("target", "TARGET");
/* 491 */           anchorCheck = anchorCheck.text(str1);
/* 492 */           String str2 = anchorCheck.toString();
/* 493 */           this.logger.debug("New Element-----" + str2);
/* 494 */           redemptionTel = redemptionTel.replace(str1, str2);
/* 495 */           this.logger.debug("New string-- " + redemptionTel);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 500 */     return redemptionTel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatEmail(String redemptionmail)
/*     */   {
/* 509 */     Boolean hasAnchor = Boolean.valueOf(false);
/* 510 */     this.logger.debug("OfferPreviewHandler format Email" + redemptionmail);
/* 511 */     if (redemptionmail != null)
/*     */     {
/* 513 */       Document doc = Jsoup.parse(redemptionmail);
/* 514 */       Elements elements = doc.getAllElements();
/* 515 */       for (Element em : elements) {
/* 516 */         Tag tg = em.tag();
/* 517 */         if (tg.getName().equalsIgnoreCase("a")) {
/* 518 */           hasAnchor = Boolean.valueOf(true);
/*     */         }
/*     */       }
/*     */       
/* 522 */       if (!hasAnchor.booleanValue())
/*     */       {
/* 524 */         Pattern p = Pattern.compile("[a-zA-Z0-9]+[._a-zA-Z0-9!#$%&'*+-=?^_`{|}~]*[a-zA-Z]*@[a-zA-Z0-9]{2,8}.[a-zA-Z.]{2,6}");
/* 525 */         Matcher matcher = p.matcher(redemptionmail);
/* 526 */         while (matcher.find()) {
/* 527 */           String str1 = matcher.group();
/* 528 */           this.logger.debug("Text found " + str1 + " starting at index " + matcher
/* 529 */             .start() + " and ending at index " + matcher.end());
/* 530 */           Element anchorCheck = doc.createElement("a");
/* 531 */           anchorCheck = anchorCheck.attr("href", "mailto:" + str1.trim());
/* 532 */           anchorCheck = anchorCheck.attr("target", "TARGET");
/* 533 */           anchorCheck = anchorCheck.text(str1);
/* 534 */           String str2 = anchorCheck.toString();
/* 535 */           this.logger.debug("New Element-----" + str2.trim());
/* 536 */           redemptionmail = redemptionmail.replace(str1, str2.trim());
/* 537 */           this.logger.debug("New string-- " + redemptionmail);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 542 */     return redemptionmail;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\wcmuse\OfferPreviewHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */