/*     */ package com.visa.vpp.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Create Landing Page JSON"})})
/*     */ public class CreateLandingPageJson
/*     */   implements WorkflowProcess
/*     */ {
/*  36 */   private static final Logger log = LoggerFactory.getLogger(CreateLandingPageJson.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*     */     throws WorkflowException
/*     */   {
/*  47 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/*  48 */     if (wfMetaDataMap.get("customPropertyCheck") != null) {
/*  49 */       String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/*  50 */       log.debug("categoryPagePath" + categoryPagePath);
/*  51 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*     */       try {
/*  53 */         Node rootNode = session.getRootNode();
/*  54 */         if (rootNode.hasNode(categoryPagePath.substring(1))) {
/*  55 */           Node catNode = rootNode.getNode(categoryPagePath.substring(1));
/*  56 */           Node landingNode = catNode.getParent();
/*  57 */           String catNodeName = catNode.getName();
/*  58 */           boolean cherryPic = false;
/*  59 */           String jsonObjKey = "";
/*  60 */           JSONObject childJsonObj = null;
/*  61 */           log.debug("catNodeName" + catNodeName);
/*  62 */           String landingPageFileName = "invalid";
/*     */           
/*  64 */           landingPageFileName = VppJsonUtil.getLandingPageName(landingNode);
/*  65 */           log.debug("landingPageFileName" + landingPageFileName);
/*  66 */           String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(categoryPagePath);
/*  67 */           log.debug("jsonFileLocation" + jsonFileLocation);
/*  68 */           if (rootNode.hasNode(jsonFileLocation)) {
/*  69 */             Node parentFileNode = rootNode.getNode(jsonFileLocation);
/*  70 */             if (parentFileNode.hasNode(landingPageFileName)) {
/*  71 */               Node landingPageFileNode = parentFileNode.getNode(landingPageFileName);
/*  72 */               String landingPageFilePath = landingPageFileNode.getPath();
/*  73 */               log.debug("landingPageFilePath" + landingPageFilePath);
/*  74 */               StringBuffer catNameBuffer = new StringBuffer(catNodeName);
/*  75 */               catNodeName = ".json";
/*  76 */               log.debug("catNodeName with json extension" + catNodeName);
/*     */               
/*  78 */               if (landingPageFileNode.hasNode(catNodeName)) {
/*  79 */                 cherryPic = true;
/*     */                 
/*     */ 
/*  82 */                 JSONObject categoryPageJson = VppJsonUtil.getOfferJson(session, landingPageFilePath.substring(1), catNodeName);
/*  83 */                 log.debug("categoryPageJSON" + categoryPageJson);
/*  84 */                 Iterator<String> iterator = categoryPageJson.keys();
/*  85 */                 while (iterator.hasNext()) {
/*  86 */                   jsonObjKey = ((String)iterator.next()).toString();
/*  87 */                   childJsonObj = categoryPageJson.getJSONObject(jsonObjKey);
/*  88 */                   log.debug("childJsonObj" + childJsonObj);
/*     */                 }
/*     */                 
/*  91 */                 Node catFileNode = landingPageFileNode.getNode(catNodeName);
/*  92 */                 catFileNode.remove();
/*  93 */                 log.debug("catFileNode removed successfully");
/*     */                 
/*     */ 
/*  96 */                 boolean landingPageStatus = createLandingPageJson(landingPageFileName, session, jsonFileLocation, jsonObjKey, childJsonObj, workItem);
/*     */                 
/*  98 */                 session.save();
/*  99 */                 if (landingPageStatus)
/*     */                 {
/*     */ 
/*     */ 
/* 103 */                   workItem.getWorkflowData().getMetaDataMap().put("landingPageJsonCheck", "landingPageJsonCheck");
/*     */                 }
/*     */               }
/*     */               else {
/* 107 */                 log.debug("cat json doesn't exists so cat page is not cherry picked");
/*     */               }
/*     */             } else {
/* 110 */               log.debug("landing page filename property is not set");
/*     */             }
/* 112 */             if (!cherryPic) {
/* 113 */               log.debug("cherryPic" + cherryPic);
/* 114 */               workItem.getWorkflowData().getMetaDataMap()
/* 115 */                 .put("no", "no");
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (RepositoryException e) {
/* 120 */         log.error("RepositoryException in execute() of CreateLandingPageJson " + e.getMessage());
/*     */       } catch (JSONException e) {
/* 122 */         log.error("JSONException in execute() of CreateLandingPageJson " + e.getMessage());
/*     */       }
/*     */     } else {
/* 125 */       log.error("Landing page JSON is not created because the custom publish property is not set");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean createLandingPageJson(String landingPageFileName, Session session, String jsonFileLocation, String jsonObjKey, JSONObject childJsonObj, WorkItem workItem)
/*     */   {
/* 143 */     Boolean checkfileStatus = Boolean.valueOf(false);
/* 144 */     StringBuffer sb = new StringBuffer(landingPageFileName);
/* 145 */     String landingPageFileNameJsonExt = ".json";
/*     */     
/* 147 */     JSONObject landingPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileNameJsonExt);
/*     */     try {
/* 149 */       landingPageJson.put(jsonObjKey, childJsonObj);
/*     */       
/*     */ 
/* 152 */       String filecreationCheck = VppJsonUtil.createUpdateJsonFile(jsonFileLocation, landingPageFileNameJsonExt, session, landingPageJson);
/*     */       
/* 154 */       log.debug("filecreationCheck" + filecreationCheck);
/* 155 */       if (filecreationCheck.equalsIgnoreCase("success"))
/*     */       {
/* 157 */         MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 158 */         StringBuffer landPageJsonBuffer = new StringBuffer();
/* 159 */         landPageJsonBuffer.append("/").append(jsonFileLocation)
/* 160 */           .append("/").append(landingPageFileNameJsonExt);
/* 161 */         String landingPageJsonFilePath = landPageJsonBuffer.toString();
/* 162 */         log.debug("landingPageJSonFileName" + landingPageJsonFilePath);
/* 163 */         catwfmetadata.put("landingPageJsonFilePath", landingPageJsonFilePath);
/* 164 */         log.debug("LANDING_PAGE_JSON_FILE_NAME property is set in metadata");
/* 165 */         checkfileStatus = Boolean.valueOf(true);
/*     */       }
/*     */     } catch (JSONException e) {
/* 168 */       log.error("JSONException in createLandingPageJson() of CreateLandingPageJson" + e
/* 169 */         .getMessage());
/*     */     }
/* 171 */     return checkfileStatus.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\CreateLandingPageJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */