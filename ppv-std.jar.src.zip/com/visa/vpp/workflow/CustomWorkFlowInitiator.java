/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.Route;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.Workflow;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"CustomWorkFlowInitiator"})})
/*    */ public class CustomWorkFlowInitiator
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/* 38 */   private static final Logger log = LoggerFactory.getLogger(CustomWorkFlowInitiator.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String ADMIN_APPROVER_ROUTE = "Approver/VppAdmin";
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String AUTHOR_ROUTE = "Author";
/*    */   
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 53 */     ResourceResolver resourceResolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*    */     try {
/* 55 */       String workFlowInitiator = workItem.getWorkflow().getInitiator();
/* 56 */       ArrayList<String> userGroupIds = VppUtil.getUserIds(workFlowInitiator, resourceResolver);
/*    */       
/* 58 */       Boolean isAuthor = isIssuerAuthor(userGroupIds);
/* 59 */       log.debug("isAuthor" + isAuthor);
/*    */       
/* 61 */       List<Route> routes = wfSession.getRoutes(workItem, false);
/* 62 */       Route route = null;
/* 63 */       if (isAuthor.booleanValue()) {
/* 64 */         log.debug("in author route");
/* 65 */         route = VppUtil.getRoute(routes, "Author".trim());
/* 66 */         wfSession.complete(workItem, route);
/*    */       }
/*    */       else {
/* 69 */         log.debug("in admin/approver route");
/* 70 */         route = VppUtil.getRoute(routes, "Approver/VppAdmin".trim());
/* 71 */         wfSession.complete(workItem, route);
/*    */       }
/*    */     } catch (Exception e) {
/* 74 */       log.error("Exception occured in execute() of WorkFlowInitiator " + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Boolean isIssuerAuthor(ArrayList<String> userGroupIds)
/*    */   {
/* 85 */     Boolean isAuthor = Boolean.valueOf(false);
/* 86 */     for (String userGroupId : userGroupIds) {
/* 87 */       if ((userGroupId.contains("vppadmin")) || (userGroupId.contains("approver"))) {
/* 88 */         isAuthor = Boolean.valueOf(false);
/* 89 */       } else if (userGroupId.contains("author")) {
/* 90 */         isAuthor = Boolean.valueOf(true);
/*    */       }
/*    */     }
/* 93 */     return isAuthor;
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\CustomWorkFlowInitiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */