/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.day.cq.replication.Replicator;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.Property;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import javax.jcr.Value;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Deactivate VPP Page"})})
/*    */ public class DeactivatePage
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   private Replicator replicator;
/* 37 */   private static final Logger log = LoggerFactory.getLogger(DeactivatePage.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 48 */     String pagePath = workItem.getWorkflowData().getPayload().toString();
/* 49 */     Session jcrSession = (Session)wfSession.adaptTo(Session.class);
/* 50 */     StringBuilder sb = new StringBuilder();
/* 51 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/* 52 */     String pageJcrPath = sb.toString();
/* 53 */     String pageTemplate = "";
/* 54 */     Boolean categoryCheck = Boolean.valueOf(false);
/* 55 */     log.debug("pageJcrPath in deactivate page" + pageJcrPath);
/*    */     try
/*    */     {
/* 58 */       Node rootNode = jcrSession.getRootNode();
/* 59 */       if (rootNode.hasNode(pageJcrPath)) {
/* 60 */         Node pageJcrNode = rootNode.getNode(pageJcrPath);
/* 61 */         if (pageJcrNode.hasProperty("cq:template")) {
/* 62 */           pageTemplate = pageJcrNode.getProperty("cq:template").getValue().getString();
/* 63 */           log.debug("pageTemplate" + pageTemplate);
/* 64 */           if (pageTemplate.trim().equalsIgnoreCase("/apps/vpp/templates/category_page".trim())) {
/* 65 */             categoryCheck = Boolean.valueOf(true);
/*    */           }
/*    */         }
/* 68 */         MetaDataMap wfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 69 */         if (((categoryCheck.booleanValue()) && (wfmetadata.get("landingPageJsonReplicated") != null)) || 
/* 70 */           ((categoryCheck.booleanValue()) && (wfmetadata.get("no") != null)) || 
/* 71 */           (!categoryCheck.booleanValue())) {
/* 72 */           VppUtil.deactivateResource(jcrSession, pagePath, this.replicator);
/*    */           
/* 74 */           MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 75 */           wfMetaDataMap.put("offerApprovalStatus", "APPROVED");
/* 76 */           log.debug("Page is deactivated");
/*    */         } else {
/* 78 */           log.debug("some error has occured and page is not deactivated");
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (RepositoryException e) {
/* 83 */       log.error("RepositoryException in execute() of DeactivatePage" + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     this.replicator = paramReplicator;
/*    */   }
/*    */   
/*    */   protected void unbindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     if (this.replicator == paramReplicator) {
/*    */       this.replicator = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\DeactivatePage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */