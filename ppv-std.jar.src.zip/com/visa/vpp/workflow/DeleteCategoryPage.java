/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.utill.VppJsonUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Delete Category Page"})})
/*    */ public class DeleteCategoryPage
/*    */   implements WorkflowProcess
/*    */ {
/* 26 */   private static final Logger log = LoggerFactory.getLogger(DeleteCategoryPage.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 37 */     String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/* 38 */     log.debug("categoryPagePath in RemoveCategoryFromLandingPageJson" + categoryPagePath);
/* 39 */     Session session = (Session)wfSession.adaptTo(Session.class);
/*    */     try {
/* 41 */       Node rootNode = session.getRootNode();
/* 42 */       String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(categoryPagePath);
/* 43 */       if (rootNode.hasNode(categoryPagePath.substring(1))) {
/* 44 */         Node catNode = rootNode.getNode(categoryPagePath.substring(1));
/* 45 */         Node landingNode = catNode.getParent();
/* 46 */         String catNodeName = catNode.getName();
/* 47 */         log.debug("catNodeName" + catNodeName);
/* 48 */         String landingPageName = landingNode.getName();
/* 49 */         int landingPageDepth = landingNode.getDepth();
/* 50 */         StringBuffer sb = new StringBuffer();
/* 51 */         sb.append(landingPageName).append("_").append(landingPageDepth);
/* 52 */         String landingPageFileName = sb.toString();
/* 53 */         log.debug("landingPageFileName" + landingPageFileName);
/*    */         
/* 55 */         if (rootNode.hasNode(jsonFileLocation)) {
/* 56 */           Node parentFileNode = rootNode.getNode(jsonFileLocation);
/* 57 */           if (parentFileNode.hasNode(landingPageFileName)) {
/* 58 */             Node landingPageFileNode = parentFileNode.getNode(landingPageFileName);
/* 59 */             StringBuffer catNameBuffer = new StringBuffer(catNodeName);
/* 60 */             catNodeName = ".json";
/* 61 */             log.debug("catNodeName with json extension" + catNodeName);
/* 62 */             if (landingPageFileNode.hasNode(catNodeName)) {
/* 63 */               Node catPageJsonNode = landingPageFileNode.getNode(catNodeName);
/* 64 */               catPageJsonNode.remove();
/* 65 */               log.debug("catPageJsonNode removed successfully");
/*    */             }
/*    */           }
/*    */         }
/* 69 */         catNode.remove();
/* 70 */         log.debug("cat page removed successfully");
/*    */       }
/* 72 */       session.save();
/*    */     } catch (RepositoryException e) {
/* 74 */       log.error("RepositoryException in execute() of DeleteCategoryPage" + e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\DeleteCategoryPage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */