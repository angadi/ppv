/*     */ package com.visa.vpp.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.Route;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.util.List;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Identify Vpp Page"})})
/*     */ public class IdentifyVppPage
/*     */   implements WorkflowProcess
/*     */ {
/*  36 */   private static Logger log = LoggerFactory.getLogger(IdentifyVppPage.class);
/*     */   
/*     */   private static final String CATEGORY_CHECK = "category_page";
/*     */   
/*     */   private static final String OFFER_CHECK = "offer_creation";
/*     */   
/*     */   private static final String OTHER_PAGES_CHECK = "other";
/*     */   
/*     */   private static final String CATEGORY_ROUTE = "Category Page";
/*     */   
/*     */   private static final String OFFER_ROUTE = "Offer Page";
/*     */   
/*     */   private static final String OTHER_PAGES_ROUTE = "Other Pages";
/*     */   
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  53 */     Session session = (Session)wfSession.adaptTo(Session.class);
/*  54 */     String pagePath = workItem.getWorkflowData().getPayload().toString();
/*  55 */     String pageTemplate = "";
/*  56 */     StringBuffer sb = new StringBuffer();
/*  57 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/*  58 */     String pageJcrPath = sb.toString();
/*  59 */     log.debug("pageJcrPath" + pageJcrPath);
/*     */     try {
/*  61 */       Node rootNode = session.getRootNode();
/*  62 */       if (rootNode.hasNode(pageJcrPath)) {
/*  63 */         Node pageJcrNode = rootNode.getNode(pageJcrPath);
/*  64 */         if (pageJcrNode.hasProperty("cq:template")) {
/*  65 */           pageTemplate = pageJcrNode.getProperty("cq:template").getValue().toString();
/*  66 */           String[] templateArr = pageTemplate.split("/");
/*  67 */           String templateName = templateArr[(templateArr.length - 1)];
/*  68 */           log.debug("templateName" + templateName);
/*  69 */           String tempCheck = getTemplateName(templateName);
/*  70 */           log.debug("tempCheck" + tempCheck);
/*     */           
/*  72 */           List<Route> routes = wfSession.getRoutes(workItem, false);
/*  73 */           Route route = null;
/*  74 */           if (tempCheck.equalsIgnoreCase("category_page")) {
/*  75 */             log.debug("in category");
/*  76 */             route = VppUtil.getRoute(routes, "Category Page".trim());
/*  77 */             wfSession.complete(workItem, route);
/*  78 */           } else if (tempCheck.equalsIgnoreCase("offer_creation")) {
/*  79 */             log.debug("offer route");
/*  80 */             route = VppUtil.getRoute(routes, "Offer Page".trim());
/*  81 */             wfSession.complete(workItem, route);
/*     */           }
/*     */           else {
/*  84 */             log.debug("other pages route");
/*  85 */             route = VppUtil.getRoute(routes, "Other Pages".trim());
/*  86 */             wfSession.complete(workItem, route);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/*  91 */       log.error("RepositoryException occured in execute()of IdentifyVppPage" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTemplateName(String templateName)
/*     */   {
/* 102 */     String tempName = "";
/* 103 */     if (templateName.equalsIgnoreCase("category_page")) {
/* 104 */       tempName = "category_page";
/* 105 */     } else if (templateName.equalsIgnoreCase("offer_creation")) {
/* 106 */       tempName = "offer_creation";
/*     */     } else {
/* 108 */       tempName = "other";
/*     */     }
/* 110 */     return tempName;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\IdentifyVppPage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */