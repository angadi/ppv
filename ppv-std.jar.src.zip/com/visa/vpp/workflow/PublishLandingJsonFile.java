/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.day.cq.replication.Replicator;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Publish Landing Page JSON"})})
/*    */ public class PublishLandingJsonFile
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   private Replicator replicator;
/* 35 */   private static final Logger log = LoggerFactory.getLogger(PublishLandingJsonFile.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 46 */     MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 47 */     if (catwfmetadata.get("landingPageJsonCheck") != null)
/*    */     {
/* 49 */       String landingPageJsonPath = (String)catwfmetadata.get("landingPageJsonFilePath", String.class);
/* 50 */       log.debug("landingPageJsonPath in PublishLandingJsonFiless" + landingPageJsonPath);
/* 51 */       Session jcrSession = (Session)wfSession.adaptTo(Session.class);
/* 52 */       VppUtil.replicateResource(jcrSession, landingPageJsonPath, this.replicator);
/* 53 */       log.debug("landing page json is replicated");
/* 54 */       catwfmetadata.put("landingPageJsonReplicated", "landingPageJsonReplicated");
/*    */     }
/*    */     else {
/* 57 */       log.debug("landing page json is not replicated beacuse landing page json is not created or no modifications required");
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     this.replicator = paramReplicator;
/*    */   }
/*    */   
/*    */   protected void unbindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     if (this.replicator == paramReplicator) {
/*    */       this.replicator = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\PublishLandingJsonFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */