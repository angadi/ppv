/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.day.cq.replication.Replicator;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Activate Offer Creation Page and relevent Category Pages"})})
/*    */ public class PublishOfferRelatedPages
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   private Replicator replicator;
/* 42 */   private static final Logger log = LoggerFactory.getLogger(PublishOfferRelatedPages.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String DATA_SEPARATOR = "##";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 56 */     MetaDataMap wfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 57 */     String offerApprovalStatus = (String)wfmetadata.get("offerApprovalStatus", String.class);
/*    */     Session jcrSession;
/* 59 */     if (offerApprovalStatus != null) {
/* 60 */       String offerPagePath = workItem.getWorkflowData().getPayload().toString();
/* 61 */       String offerRelatedContent = (String)wfmetadata.get("toBePublished", String.class);
/* 62 */       jcrSession = (Session)wfSession.adaptTo(Session.class);
/* 63 */       VppUtil.replicateResource(jcrSession, offerPagePath, this.replicator);
/* 64 */       log.debug("Offer Creation Page Published Successfully");
/* 65 */       if (offerRelatedContent != null) {
/* 66 */         String[] offerContent = offerRelatedContent.split("##");
/* 67 */         Set<String> offerSet = new HashSet();
/* 68 */         Collections.addAll(offerSet, offerContent);
/* 69 */         for (String currResource : offerSet) {
/* 70 */           if (!currResource.equalsIgnoreCase("")) {
/* 71 */             VppUtil.replicateResource(jcrSession, currResource, this.replicator);
/*    */           }
/*    */         }
/*    */       }
/*    */     } else {
/* 76 */       log.debug("Failed to create/update Offer JSON . Aborting Page publish and JSON file publish ");
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     this.replicator = paramReplicator;
/*    */   }
/*    */   
/*    */   protected void unbindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     if (this.replicator == paramReplicator) {
/*    */       this.replicator = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\PublishOfferRelatedPages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */