/*     */ package com.visa.vpp.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Remove Category Page from Landing Page JSON"})})
/*     */ public class RemoveCategoryFromLandingPageJson
/*     */   implements WorkflowProcess
/*     */ {
/*  38 */   private static final Logger log = LoggerFactory.getLogger(RemoveCategoryFromLandingPageJson.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*     */     throws WorkflowException
/*     */   {
/*  49 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/*  50 */     if (wfMetaDataMap.get("customPropertyCheck") != null) {
/*  51 */       String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/*  52 */       log.debug("categoryPagePath in RemoveCategoryFromLandingPageJson" + categoryPagePath);
/*  53 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*     */       try {
/*  55 */         Node rootNode = session.getRootNode();
/*  56 */         String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(categoryPagePath);
/*  57 */         log.debug("jsonFileLocation" + jsonFileLocation);
/*  58 */         if (rootNode.hasNode(categoryPagePath.substring(1))) {
/*  59 */           Node catNode = rootNode.getNode(categoryPagePath.substring(1));
/*  60 */           Node landingNode = catNode.getParent();
/*  61 */           String catNodeName = catNode.getName();
/*  62 */           log.debug("catNodeName" + catNodeName);
/*  63 */           String landingPageFileName = "invalid";
/*     */           
/*  65 */           if (landingNode.hasNode("jcr:content")) {
/*  66 */             Node landPageJcrContent = landingNode.getNode("jcr:content");
/*  67 */             if (landPageJcrContent.hasProperty("landingJsonName"))
/*     */             {
/*     */ 
/*  70 */               landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/*  71 */               log.debug("landingPageFileName property value" + landingPageFileName);
/*     */             } else {
/*  73 */               log.debug("landingPageFileName property is not set" + landingPageFileName);
/*     */             }
/*     */           }
/*  76 */           log.debug("landingPageFileName" + landingPageFileName);
/*  77 */           StringBuffer sb = new StringBuffer(landingPageFileName);
/*  78 */           String landingPageFileNameJsonExt = ".json";
/*     */           
/*  80 */           JSONObject landingPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileNameJsonExt);
/*  81 */           JSONObject categoryPageJson = null;
/*  82 */           if (landingPageJson.has(categoryPagePath)) {
/*  83 */             categoryPageJson = landingPageJson.getJSONObject(categoryPagePath);
/*  84 */             log.debug("categoryPageJson in remove cat from land json" + categoryPageJson);
/*  85 */             landingPageJson.remove(categoryPagePath);
/*  86 */             log.debug("after removing the cat page from landing page json" + landingPageJson);
/*     */             
/*     */ 
/*  89 */             String filecreationCheck = VppJsonUtil.createUpdateJsonFile(jsonFileLocation, landingPageFileNameJsonExt, session, landingPageJson);
/*     */             
/*  91 */             log.debug("filecreationCheck" + filecreationCheck);
/*     */             
/*  93 */             if (rootNode.hasNode(jsonFileLocation)) {
/*  94 */               Node parentFileNode = rootNode.getNode(jsonFileLocation);
/*  95 */               if (parentFileNode.hasNode(landingPageFileName)) {
/*  96 */                 Node landingPageFileNode = parentFileNode.getNode(landingPageFileName);
/*  97 */                 String landingPageFilePath = landingPageFileNode.getPath();
/*  98 */                 landingPageFilePath = landingPageFilePath.substring(1);
/*  99 */                 log.debug("landingPageFilePath" + landingPageFilePath);
/* 100 */                 StringBuffer catNameBuffer = new StringBuffer(catNodeName);
/* 101 */                 catNodeName = ".json";
/* 102 */                 log.debug("catNodeName with json extension" + catNodeName);
/*     */                 
/* 104 */                 JSONObject catFileJson = new JSONObject();
/* 105 */                 catFileJson.put(categoryPagePath, categoryPageJson);
/* 106 */                 log.debug("catFileJSON" + catFileJson);
/*     */                 
/* 108 */                 String catfilecreationCheck = VppJsonUtil.createUpdateJsonFile(landingPageFilePath, catNodeName, session, catFileJson);
/*     */                 
/* 110 */                 log.debug("catfilecreationCheck" + catfilecreationCheck);
/*     */                 
/* 112 */                 MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 113 */                 StringBuffer landPageJsonBuffer = new StringBuffer();
/* 114 */                 landPageJsonBuffer.append("/").append(jsonFileLocation)
/* 115 */                   .append("/").append(landingPageFileNameJsonExt);
/* 116 */                 String landingPageJsonFilePath = landPageJsonBuffer.toString();
/* 117 */                 log.debug("landingPageJSonFileName" + landingPageJsonFilePath);
/* 118 */                 catwfmetadata
/* 119 */                   .put("landingPageJsonFilePath", landingPageJsonFilePath);
/* 120 */                 log.debug("set the LANDING_PAGE_JSON_FILE_NAME property in metadata");
/* 121 */                 session.save();
/* 122 */                 workItem
/* 123 */                   .getWorkflowData()
/* 124 */                   .getMetaDataMap()
/* 125 */                   .put("landingPageJsonCheck", "landingPageJsonCheck");
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 131 */             log.debug("remove operation not required ,json file name property is not set for landing page or landingPageJson doesnot contain categoryPagePath");
/*     */             
/*     */ 
/* 134 */             if (catNode.hasNode("jcr:content")) {
/* 135 */               Node catJcrNode = catNode.getNode("jcr:content");
/* 136 */               if (catJcrNode.hasNode("more_offers")) {
/* 137 */                 log.debug("it has more offers node");
/*     */               } else {
/* 139 */                 log.debug("it doesn't have more offers node");
/* 140 */                 workItem.getWorkflowData().getMetaDataMap()
/* 141 */                   .put("no", "no");
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (RepositoryException e) {
/* 147 */         log.error("RepositoryException occured in execute() of RemoveCategoryFromLandingPageJson" + e
/* 148 */           .getMessage());
/*     */       } catch (JSONException e) {
/* 150 */         log.error("JSONException occured in execute() of RemoveCategoryFromLandingPageJson" + e
/* 151 */           .getMessage());
/*     */       }
/*     */     } else {
/* 154 */       log.error("Category page JSON is not removed because the custom publish property is not set");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\RemoveCategoryFromLandingPageJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */