/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.Route;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.List;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"VPP Approver Route"})})
/*    */ public class RouteApprover
/*    */   implements WorkflowProcess
/*    */ {
/* 32 */   private static final Logger log = LoggerFactory.getLogger(RouteApprover.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String APPROVED_ROUTE = "APPROVED";
/*    */   
/*    */ 
/*    */   private static final String REJECTED_ROUTE = "REJECTED";
/*    */   
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/* 46 */     List<Route> routes = wfSession.getRoutes(workItem, false);
/* 47 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 48 */     Route route = null;
/* 49 */     if (wfMetaDataMap.get("offerApprovalStatus") != null) {
/* 50 */       route = VppUtil.getRoute(routes, "APPROVED".trim());
/* 51 */       wfSession.complete(workItem, route);
/* 52 */       log.debug("In approve route");
/*    */     } else {
/* 54 */       route = VppUtil.getRoute(routes, "REJECTED".trim());
/* 55 */       wfSession.complete(workItem, route);
/* 56 */       log.debug("In rejected route");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\RouteApprover.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */