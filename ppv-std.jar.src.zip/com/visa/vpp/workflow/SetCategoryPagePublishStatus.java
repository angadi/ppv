/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.utill.VppJsonUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Category Page Publish Status"})})
/*    */ public class SetCategoryPagePublishStatus
/*    */   implements WorkflowProcess
/*    */ {
/* 33 */   private static final Logger log = LoggerFactory.getLogger(SetCategoryPagePublishStatus.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 44 */     String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/* 45 */     log.debug("categoryPagePath" + categoryPagePath);
/* 46 */     Session session = (Session)wfSession.adaptTo(Session.class);
/* 47 */     String argument = ((String)metadataMap.get("PROCESS_ARGS", "string")).toString();
/* 48 */     log.debug("argument" + argument);
/*    */     try {
/* 50 */       Node rootNode = session.getRootNode();
/*    */       
/*    */ 
/* 53 */       Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(categoryPagePath, rootNode, argument);
/* 54 */       if (setPropertyCheck.booleanValue()) {
/* 55 */         log.debug(argument + "property set successfully");
/* 56 */         MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 57 */         wfMetaDataMap.put("customPropertyCheck", "customPropertyCheck");
/*    */       }
/*    */     } catch (RepositoryException e) {
/* 60 */       log.error("RepositoryException in execute()of SetCategoryPagePublishStatus" + e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\SetCategoryPagePublishStatus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */