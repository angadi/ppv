/*     */ package com.visa.vpp.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.utill.VppJsonUtil;
/*     */ import com.visa.vpp.utill.VppUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.jcr.Binary;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Create/Update AEM Offer Listing JSON"})})
/*     */ public class UpdateOfferJson
/*     */   implements WorkflowProcess
/*     */ {
/*  54 */   private static final Logger log = LoggerFactory.getLogger(UpdateOfferJson.class);
/*     */   private static final String TYPE_JCR_PATH = "JCR_PATH";
/*     */   private static final String PREVIEW_URL = "previewURL";
/*     */   private static final String PREVIEW_DEFINITION = "?wcmmode=disabled";
/*     */   private static final String OFFER_FIELDS_MULTI = "categories,cardProducts,cardPayment";
/*  59 */   private static final String[] OFFER_FIELDS = { "pageType", "offerTitle", "offerShortDesc", "promoStartDate", "promoEndDate", "categories", "cardProducts", "cardPayment", "offerStatus", "merchantName" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  78 */     String payLoad = workItem.getWorkflowData().getPayload().toString();
/*  79 */     String offerId = "";
/*  80 */     WorkflowData workflowData = workItem.getWorkflowData();
/*  81 */     MetaDataMap wfmetadata = workflowData.getMetaDataMap();
/*  82 */     if (workflowData.getPayloadType().equals("JCR_PATH")) {
/*  83 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*  84 */       ResourceResolver resolver = null;
/*     */       try {
/*  86 */         Node rootNode = session.getRootNode();
/*  87 */         JSONObject currentOfferJson = new JSONObject();
/*  88 */         String lastModified = "";
/*  89 */         if (rootNode.hasNode(payLoad.substring(1) + "/jcr:content"))
/*     */         {
/*  91 */           Node pageJcrNode = rootNode.getNode(payLoad.substring(1) + "/jcr:content");
/*  92 */           if (pageJcrNode.hasProperty("offerId")) {
/*  93 */             offerId = pageJcrNode.getProperty("offerId").getString();
/*     */           }
/*  95 */           if (pageJcrNode.hasProperty("cq:lastModified")) {
/*  96 */             lastModified = pageJcrNode.getProperty("cq:lastModified").getString();
/*     */           }
/*     */           
/*  99 */           if (pageJcrNode.hasNode("offer_creation")) {
/* 100 */             Node offerCreation = pageJcrNode.getNode("offer_creation");
/* 101 */             String offerStatus = "";
/* 102 */             if (offerCreation.hasProperty("offerStatus")) {
/* 103 */               offerStatus = offerCreation.getProperty("offerStatus").getString();
/*     */             }
/* 105 */             String offerJsonLocation = "";
/* 106 */             boolean updateStatus = false;
/* 107 */             offerJsonLocation = VppJsonUtil.getOfferJsonLocation(payLoad);
/* 108 */             JSONObject offerJson = getOfferJson(session, offerJsonLocation);
/* 109 */             if (offerStatus.equalsIgnoreCase("active")) {
/* 110 */               for (int j = 0; j < OFFER_FIELDS.length; j++) {
/* 111 */                 if (offerCreation.hasProperty(OFFER_FIELDS[j])) {
/* 112 */                   Property currentProp = offerCreation.getProperty(OFFER_FIELDS[j]);
/* 113 */                   if (currentProp.isMultiple()) {
/* 114 */                     Value[] values = currentProp.getValues();
/* 115 */                     JSONArray stringValues = new JSONArray();
/* 116 */                     for (int i = 0; i < values.length; i++) {
/* 117 */                       stringValues.put(values[i].getString());
/*     */                     }
/* 119 */                     currentOfferJson.put(OFFER_FIELDS[j], stringValues);
/*     */                   }
/* 121 */                   else if ("categories,cardProducts,cardPayment".contains(OFFER_FIELDS[j])) {
/* 122 */                     JSONArray stringValues = new JSONArray();
/* 123 */                     stringValues.put(currentProp.getValue().getString());
/* 124 */                     currentOfferJson.put(OFFER_FIELDS[j], stringValues);
/*     */                   } else {
/* 126 */                     currentOfferJson.put(OFFER_FIELDS[j], currentProp.getValue().getString());
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/* 132 */               resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/*     */               
/* 134 */               String defaultHeroImg = getDefaultImage("fileReferenceHeroImage", payLoad, session);
/*     */               
/* 136 */               String defaultMerchLogoImg = getDefaultImage("fileReferenceLogoImage", payLoad, session);
/*     */               
/* 138 */               String defaultThumbnailImg = getDefaultImage("fileReferenceThumbImage", payLoad, session);
/*     */               
/* 140 */               if (offerCreation.hasProperty("heroImage"))
/*     */               {
/* 142 */                 String heroImage = offerCreation.getProperty("heroImage").getString();
/* 143 */                 Resource res = resolver.getResource(heroImage);
/* 144 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 145 */                 log.debug("Current Hero Image Width_Height  : " + currImgWidthHeight);
/* 146 */                 String defaultImgWidthHeight = "";
/* 147 */                 if (!defaultHeroImg.equalsIgnoreCase("failure")) {
/* 148 */                   res = resolver.getResource(defaultHeroImg);
/* 149 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 151 */                 log.debug("Default Hero Image Width_Height  : " + defaultImgWidthHeight);
/* 152 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 153 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 154 */                   offerCreation.setProperty("validHeroImg", "VALID");
/*     */                 } else {
/* 156 */                   offerCreation.setProperty("validHeroImg", defaultHeroImg);
/*     */                 }
/*     */               } else {
/* 159 */                 log.debug("No Hero Image Authored . Assigning default Hero Image");
/* 160 */                 offerCreation.setProperty("validHeroImg", defaultHeroImg);
/*     */               }
/* 162 */               if (offerCreation.hasProperty("thumbImage"))
/*     */               {
/* 164 */                 String thumbImage = offerCreation.getProperty("thumbImage").getString();
/* 165 */                 Resource res = resolver.getResource(thumbImage);
/* 166 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 167 */                 log.debug("Current Thumbnail Image Width_Height  : " + currImgWidthHeight);
/* 168 */                 String defaultImgWidthHeight = "";
/* 169 */                 if (!defaultThumbnailImg.equalsIgnoreCase("failure")) {
/* 170 */                   res = resolver.getResource(defaultThumbnailImg);
/* 171 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 173 */                 log.debug("Default Thumbnail Image Width_Height  : " + defaultImgWidthHeight);
/* 174 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 175 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 176 */                   currentOfferJson.put("thumbImage", thumbImage);
/*     */                 } else {
/* 178 */                   currentOfferJson.put("thumbImage", defaultThumbnailImg);
/*     */                 }
/*     */               } else {
/* 181 */                 log.debug("No ThumbNail Image Authored . Assigning default ThumbNail Image");
/* 182 */                 currentOfferJson.put("thumbImage", defaultThumbnailImg);
/*     */               }
/* 184 */               if (offerCreation.hasProperty("merchantLogo"))
/*     */               {
/* 186 */                 String merchLogo = offerCreation.getProperty("merchantLogo").getString();
/* 187 */                 Resource res = resolver.getResource(merchLogo);
/* 188 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 189 */                 log.debug("Current Merchant Logo Image Width_Height  : " + currImgWidthHeight);
/* 190 */                 String defaultImgWidthHeight = "";
/* 191 */                 if (!defaultMerchLogoImg.equalsIgnoreCase("failure")) {
/* 192 */                   res = resolver.getResource(defaultMerchLogoImg);
/* 193 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 195 */                 log.debug("Default Merchant Logo Image Width_Height  : " + defaultImgWidthHeight);
/* 196 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 197 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 198 */                   offerCreation.setProperty("validMerchLogoImg", "VALID");
/*     */                 }
/*     */                 else {
/* 201 */                   offerCreation.setProperty("validMerchLogoImg", defaultMerchLogoImg);
/*     */                 }
/*     */               }
/*     */               else {
/* 205 */                 log.debug("No Merchant Logo Image Authored . Assigning default Merchant Logo Image");
/*     */                 
/* 207 */                 offerCreation.setProperty("validMerchLogoImg", defaultMerchLogoImg);
/*     */               }
/* 209 */               currentOfferJson.put("offerId", offerId);
/* 210 */               currentOfferJson.put("previewURL", payLoad + ".html" + "?wcmmode=disabled");
/*     */               
/* 212 */               currentOfferJson.put("offerSource", "AEM");
/* 213 */               currentOfferJson.put("offerLastModified", lastModified);
/* 214 */               offerJson.put(offerId, currentOfferJson);
/* 215 */               updateStatus = createUpdateOfferJson(session, offerJson, offerJsonLocation);
/* 216 */               wfmetadata.put("offerJSONLocation", offerJsonLocation);
/*     */             }
/*     */             else {
/* 219 */               if (offerJson.has(offerId)) {
/* 220 */                 offerJson.remove(offerId);
/* 221 */                 updateStatus = createUpdateOfferJson(session, offerJson, offerJsonLocation);
/* 222 */                 wfmetadata.put("offerJSONLocation", offerJsonLocation);
/* 223 */                 log.debug("INACTIVE Offer removed from Aggregated Offer JSON");
/*     */               } else {
/* 225 */                 log.debug("Offer JSON Not updated as the offer is currently in INACTIVE state");
/*     */               }
/* 227 */               updateStatus = true;
/*     */             }
/*     */             
/* 230 */             if (updateStatus) {
/* 231 */               pageJcrNode.setProperty("offerApprovalStatus", "APPROVED");
/*     */               
/* 233 */               wfmetadata.put("offerApprovalStatus", "APPROVED");
/* 234 */               log.debug("Offer Approval Property Set Successfully");
/*     */             }
/*     */           } else {
/* 237 */             log.debug("Unauthored Page Approval Not Set, Page is rejected");
/*     */           }
/* 239 */           session.save();
/*     */         }
/*     */       } catch (PathNotFoundException e) {
/* 242 */         log.error("Path Not Found Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } catch (RepositoryException e) {
/* 244 */         log.error("Repository Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } catch (Exception e) {
/* 246 */         log.error("Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } finally {
/* 248 */         if (resolver != null) {
/* 249 */           log.debug("Resolver closed in UpdateOfferJSON execute()");
/* 250 */           resolver.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getOfferJson(Session jcrSession, String offerJsonLocation)
/*     */   {
/* 267 */     InputStream inputStream = null;
/* 268 */     StringBuilder jsonSb = new StringBuilder();
/* 269 */     JSONObject offerJson = new JSONObject();
/* 270 */     BufferedReader bufferRead = null;
/*     */     try
/*     */     {
/* 273 */       StringBuilder sb = new StringBuilder(offerJsonLocation);
/* 274 */       sb.append("/");
/* 275 */       sb.append("aem_offers.json");
/* 276 */       sb.append("/");
/* 277 */       sb.append("jcr:content");
/* 278 */       String offerJsonfilePath = sb.toString();
/* 279 */       Node rootNode = jcrSession.getRootNode();
/* 280 */       if (rootNode.hasNode(offerJsonfilePath)) {
/* 281 */         Node fileJcrNode = rootNode.getNode(offerJsonfilePath);
/* 282 */         if (fileJcrNode.hasProperty("jcr:data")) {
/* 283 */           inputStream = fileJcrNode.getProperty("jcr:data").getBinary().getStream();
/* 284 */           bufferRead = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
/*     */           
/* 286 */           String line = "";
/* 287 */           while ((line = bufferRead.readLine()) != null) {
/* 288 */             jsonSb.append(line);
/*     */           }
/*     */         }
/* 291 */         offerJson = new JSONObject(jsonSb.toString());
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 294 */       log.error("Repository Exception Occured in UpdateOfferJSON getOfferJSON():" + e.getMessage());
/*     */     } catch (IOException e) {
/* 296 */       log.error("IO Exception Occured in UpdateOfferJSON getOfferJSON() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 298 */       log.error("JSONException Occured in UpdateOfferJSON getOfferJSON()");
/*     */     } catch (Exception e) {
/* 300 */       log.error("Exception Occured in UpdateOfferJSON getOfferJSON():" + e.getMessage());
/*     */     } finally {
/* 302 */       VppUtil.closeBufferReader(bufferRead);
/* 303 */       VppUtil.closeInputStream(inputStream);
/*     */     }
/* 305 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean createUpdateOfferJson(Session jcrSession, JSONObject offerJson, String offerJsonLocation)
/*     */   {
/* 317 */     boolean updateStatus = false;
/*     */     try
/*     */     {
/* 320 */       Node rootNode = jcrSession.getRootNode();
/* 321 */       Node folderPathNode = null;
/* 322 */       Node fileNode = null;
/* 323 */       Node fileJcrNode = null;
/*     */       
/* 325 */       if (rootNode.hasNode(offerJsonLocation)) {
/* 326 */         folderPathNode = rootNode.getNode(offerJsonLocation);
/*     */       }
/* 328 */       else if (rootNode.hasNode("etc/vpp-tools/offers")) {
/* 329 */         Node issuerNode = null;
/* 330 */         Node baseFolderNode = rootNode.getNode("etc/vpp-tools/offers");
/* 331 */         String[] offerLocationArr = offerJsonLocation.split("/");
/* 332 */         String issuerString = offerLocationArr[(offerLocationArr.length - 2)];
/* 333 */         String languageString = offerLocationArr[(offerLocationArr.length - 1)];
/* 334 */         if (baseFolderNode.hasNode(issuerString)) {
/* 335 */           issuerNode = baseFolderNode.getNode(issuerString);
/*     */         } else {
/* 337 */           issuerNode = baseFolderNode.addNode(issuerString, "nt:folder");
/*     */         }
/* 339 */         if (issuerNode.hasNode(languageString)) {
/* 340 */           folderPathNode = issuerNode.getNode(languageString);
/*     */         } else {
/* 342 */           folderPathNode = issuerNode.addNode(languageString, "nt:folder");
/*     */         }
/*     */       } else {
/* 345 */         log.debug("Base Folder not Available , JSON not created ");
/*     */       }
/*     */       
/* 348 */       if (folderPathNode != null) {
/* 349 */         if (folderPathNode.hasNode("aem_offers.json")) {
/* 350 */           fileNode = folderPathNode.getNode("aem_offers.json");
/* 351 */           fileJcrNode = fileNode.getNode("jcr:content");
/* 352 */           log.debug("Update Operation : JSON Updated");
/*     */         } else {
/* 354 */           fileNode = folderPathNode.addNode("aem_offers.json", "nt:file");
/*     */           
/* 356 */           fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 357 */           log.debug("Create Operation : JSON Created");
/*     */         }
/*     */       }
/* 360 */       if (fileJcrNode != null) {
/* 361 */         fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 362 */         fileJcrNode.setProperty("jcr:data", offerJson.toString());
/* 363 */         updateStatus = true;
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 366 */       log.error("Path Not Found Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e
/* 367 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 369 */       log.error("Repository Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e
/* 370 */         .getMessage());
/*     */     } catch (Exception e) {
/* 372 */       log.error("Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e.getMessage());
/*     */     }
/* 374 */     return updateStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getDefaultImage(String currImg, String payLoad, Session jcrSession)
/*     */   {
/* 387 */     String defaultImg = "";
/*     */     try {
/* 389 */       String langPagePath = payLoad.substring(0, payLoad.indexOf("/aem"));
/* 390 */       StringBuilder sb = new StringBuilder(langPagePath.substring(1));
/* 391 */       sb.append("/");
/* 392 */       sb.append("VMORC_Offer_Program_List/jcr:content/imageDimension");
/* 393 */       Node rootNode = jcrSession.getRootNode();
/* 394 */       if (rootNode.hasNode(sb.toString())) {
/* 395 */         Node imgNode = rootNode.getNode(sb.toString());
/* 396 */         if (imgNode.hasProperty(currImg)) {
/* 397 */           return imgNode.getProperty(currImg).getString();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 402 */       log.error("Repository Exception Occured in UpdateOfferJSON getDefaultImage() : " + e
/* 403 */         .getMessage());
/*     */     } catch (Exception e) {
/* 405 */       log.error("Exception Occured in UpdateOfferJSON getDefaultImage() : " + e.getMessage());
/*     */     }
/* 407 */     log.debug("No default Image found for key : " + currImg);
/* 408 */     return "failure";
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\UpdateOfferJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */