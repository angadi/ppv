/*    */ package com.visa.vpp.workflow;
/*    */ 
/*    */ import com.day.cq.workflow.WorkflowException;
/*    */ import com.day.cq.workflow.WorkflowSession;
/*    */ import com.day.cq.workflow.exec.ParticipantStepChooser;
/*    */ import com.day.cq.workflow.exec.WorkItem;
/*    */ import com.day.cq.workflow.exec.Workflow;
/*    */ import com.day.cq.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="chooser.label", value={"Vpp Dynamic Participant Chooser"})})
/*    */ public class VppDynamicParticipantStep
/*    */   implements ParticipantStepChooser
/*    */ {
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/* 38 */   private static final Logger log = LoggerFactory.getLogger(VppDynamicParticipantStep.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String UNDERSCORE = "_";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getParticipant(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/* 50 */     log.debug(" Inside Dynamic Participient Step ");
/*    */     
/* 52 */     ResourceResolver resourceResolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vppcronservice");
/* 53 */     String approverGroupName = "";
/* 54 */     String workFlowInitiator = workItem.getWorkflow().getInitiator();
/* 55 */     ArrayList<String> userGroupIds = VppUtil.getUserIds(workFlowInitiator, resourceResolver);
/* 56 */     log.debug("Group Ids in VppDynamicParticipantStep" + Arrays.toString(userGroupIds.toArray()));
/*    */     
/* 58 */     for (String userGroupId : userGroupIds) {
/* 59 */       if ((userGroupId.contains("author")) && (userGroupId.indexOf("_") != -1)) {
/* 60 */         String[] userArr = userGroupId.split("_");
/* 61 */         String approver = userArr[0];
/* 62 */         log.debug("approver name" + approver);
/* 63 */         StringBuilder sb = new StringBuilder(approver);
/* 64 */         sb.append("_").append("approver");
/* 65 */         approverGroupName = sb.toString();
/* 66 */         log.debug("approverGroupName" + approverGroupName);
/*    */       }
/*    */     }
/*    */     
/* 70 */     return approverGroupName;
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\aem2std\jcr_root\apps\vpp\install\vpp-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\workflow\VppDynamicParticipantStep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */