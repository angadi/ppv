/*     */ package com.visa.vpp.premium.impl.filters;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingFilter;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ValueMap;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingFilter(label="Premium Filter", description="Premium Utility Filter", metatype=false, generateComponent=true, generateService=true, order=0, scope={org.apache.felix.scr.annotations.sling.SlingFilterScope.REQUEST})
/*     */ public class PremiumRequestFilter
/*     */   implements Filter
/*     */ {
/*     */   private static final String PREMIUM_PAGE_PATH = "/content/vpp/premium";
/*     */   private static final int HOME_PAGE_DEPTH = 6;
/*     */   @Reference
/*     */   private SlingSettingsService settingsService;
/*  46 */   private static final Logger log = LoggerFactory.getLogger(PremiumRequestFilter.class);
/*     */   
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  57 */     if ((!(request instanceof SlingHttpServletRequest)) || (!(response instanceof SlingHttpServletResponse)))
/*     */     {
/*  59 */       chain.doFilter(request, response);
/*  60 */       return;
/*     */     }
/*     */     
/*     */ 
/*  64 */     SlingHttpServletResponse slingResponse = (SlingHttpServletResponse)response;
/*  65 */     SlingHttpServletRequest slingRequest = (SlingHttpServletRequest)request;
/*     */     
/*  67 */     String url = slingRequest.getRequestURI();
/*     */     
/*  69 */     if (VppUtil.isAuthorMode(this.settingsService)) {
/*  70 */       chain.doFilter(request, response);
/*  71 */       return;
/*     */     }
/*     */     
/*  74 */     Resource resource = slingRequest.getResource();
/*  75 */     if ((resource.getResourceType().equals("cq:Page")) && (url.contains("/content/vpp/premium"))) {
/*  76 */       String id = null;
/*  77 */       HttpSession session = slingRequest.getSession(true);
/*  78 */       if (null != session) {
/*  79 */         Object userObject = session.getAttribute("userId");
/*  80 */         if (null != userObject) {
/*  81 */           id = userObject.toString();
/*     */         }
/*     */         else {
/*  84 */           log.debug("session userId is null");
/*     */         }
/*     */       }
/*     */       
/*  88 */       PageManager pageManager = (PageManager)resource.getResourceResolver().adaptTo(PageManager.class);
/*  89 */       Page page = pageManager.getPage(resource.getPath());
/*     */       
/*     */ 
/*  92 */       String templatePath = page.getContentResource().getValueMap().get("cq:template").toString();
/*  93 */       log.debug("templatePath :" + templatePath);
/*  94 */       if ((!templatePath.equals("/apps/vpp_premium/templates/home_page")) && 
/*  95 */         (!templatePath.equals("/apps/vpp_premium/templates/email_registration")) && 
/*  96 */         (!templatePath.equals("/apps/vpp_premium/templates/concierge_email")) && 
/*  97 */         (!templatePath.equals("/apps/vpp_premium/templates/logout_page")) && 
/*  98 */         (!templatePath.equals("/apps/vpp_premium/templates/concierge_home")) && 
/*  99 */         (!templatePath.equals("/apps/vpp_premium/templates/content_page")))
/*     */       {
/* 101 */         if ((id == null) && (page.getDepth() > 6)) {
/* 102 */           Page homePage = page.getAbsoluteParent(5);
/* 103 */           slingResponse.sendRedirect(homePage.getPath() + ".html");
/* 104 */           return; }
/* 105 */         if (id == null) {
/* 106 */           slingResponse.sendError(401, "Access denied");
/* 107 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 112 */     chain.doFilter(request, response);
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */   
/*     */   protected void bindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     this.settingsService = paramSlingSettingsService;
/*     */   }
/*     */   
/*     */   protected void unbindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     if (this.settingsService == paramSlingSettingsService) {
/*     */       this.settingsService = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\impl\filters\PremiumRequestFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */