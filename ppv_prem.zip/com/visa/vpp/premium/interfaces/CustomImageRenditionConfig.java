package com.visa.vpp.premium.interfaces;

import java.util.Map;

public abstract interface CustomImageRenditionConfig
{
  public abstract String[] getImagerenditions();
  
  public abstract Map<String, String> getRenditionByComponentName(String paramString);
}


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\interfaces\CustomImageRenditionConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */