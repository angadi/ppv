package com.visa.vpp.premium.interfaces;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONObject;

public abstract interface GetOfferData
{
  public abstract JSONObject getCurrentOfferData(String paramString, ResourceResolver paramResourceResolver);
}


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\interfaces\GetOfferData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */