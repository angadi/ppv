package com.visa.vpp.premium.interfaces;

public abstract interface TemplateConfig
{
  public abstract String[] getAuthorTemplatePaths();
  
  public abstract String[] getApproverTemplatePaths();
  
  public abstract String[] getAdminTemplatePaths();
}


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\interfaces\TemplateConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */