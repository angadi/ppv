/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.day.cq.wcm.api.PageFilter;
/*    */ import com.day.cq.wcm.api.Template;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class CategoryNavigationModel
/*    */ {
/* 29 */   private static final Logger log = LoggerFactory.getLogger(CategoryNavigationModel.class);
/* 30 */   private ArrayList<Map<String, String>> categoryNavigationList = new ArrayList();
/*    */   
/*    */   private static final int LANDING_PAGE_DEPTH = 7;
/*    */   
/*    */   @Inject
/*    */   private Page currentPage;
/*    */   @Inject
/*    */   @Optional
/*    */   private String catTemplate;
/*    */   
/*    */   @PostConstruct
/*    */   protected void init()
/*    */   {
/* 43 */     log.debug("Category Navigation Menu Model Initiated");
/* 44 */     getCategoryNavigationData();
/*    */   }
/*    */   
/*    */   public ArrayList<Map<String, String>> getCategoryNavigationList() {
/* 48 */     return this.categoryNavigationList;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void getCategoryNavigationData()
/*    */   {
/* 56 */     Page landingPage = null;
/* 57 */     String pagePath = this.currentPage.getPath();
/* 58 */     int currentPageDepth = this.currentPage.getDepth();
/* 59 */     log.debug("Current Page Path : " + pagePath);
/* 60 */     log.debug("Current Page Depth : " + currentPageDepth);
/* 61 */     log.debug("Category Template Name : " + this.catTemplate);
/* 62 */     if (currentPageDepth > 7) {
/* 63 */       landingPage = this.currentPage.getAbsoluteParent(6);
/* 64 */     } else if (currentPageDepth == 7) {
/* 65 */       landingPage = this.currentPage;
/*    */     }
/*    */     
/* 68 */     if (null != landingPage) {
/* 69 */       log.debug("Landing Page Name : " + landingPage.getName());
/*    */       
/* 71 */       PageFilter pageFilter = new PageFilter() {
/*    */         public boolean includes(Page p) {
/* 73 */           if (null == CategoryNavigationModel.this.catTemplate) {
/* 74 */             return true;
/*    */           }
/* 76 */           if (null == p) {
/* 77 */             return false;
/*    */           }
/* 79 */           return p.getTemplate().getName().equalsIgnoreCase(CategoryNavigationModel.this.catTemplate);
/*    */         }
/* 81 */       };
/* 82 */       Iterator<Page> childList = landingPage.listChildren(pageFilter);
/* 83 */       while (childList.hasNext()) {
/* 84 */         Map<String, String> navMenu = new HashMap();
/* 85 */         Page childPage = (Page)childList.next();
/* 86 */         navMenu.put("title", childPage.getTitle());
/* 87 */         navMenu.put("linkPath", childPage.getPath());
/* 88 */         this.categoryNavigationList.add(navMenu);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\CategoryNavigationModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */