/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class ClientLibHandler
/*    */ {
/* 17 */   private static final Logger log = LoggerFactory.getLogger(ClientLibHandler.class);
/*    */   
/*    */   private static final int ISSUER_PAGE_DEPTH = 3;
/* 20 */   private String issuerName = "";
/*    */   
/*    */ 
/*    */ 
/*    */   @Inject
/*    */   private Page currentPage;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getIssuerName()
/*    */   {
/* 32 */     int currentPageDepth = this.currentPage.getDepth();
/* 33 */     log.debug("currentPage depth" + currentPageDepth);
/* 34 */     if (currentPageDepth > 3) {
/* 35 */       Page issuerPage = this.currentPage.getAbsoluteParent(3);
/* 36 */       if (issuerPage != null) {
/* 37 */         this.issuerName = issuerPage.getName();
/* 38 */         log.debug("issuerName" + this.issuerName);
/*    */       }
/*    */     }
/* 41 */     return this.issuerName;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ClientLibHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */