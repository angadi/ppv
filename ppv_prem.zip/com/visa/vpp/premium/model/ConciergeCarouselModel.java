/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import java.util.ArrayList;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.ItemNotFoundException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.models.annotations.Default;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.Optional;
/*     */ import org.apache.sling.models.annotations.Via;
/*     */ import org.apache.sling.models.annotations.injectorspecific.SlingObject;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class ConciergeCarouselModel
/*     */ {
/*  42 */   private static final Logger log = LoggerFactory.getLogger(ConciergeCarouselModel.class);
/*  43 */   private ArrayList<String> carouselHeroImage = new ArrayList();
/*  44 */   private ArrayList<String> carouselSlideText = new ArrayList();
/*     */   private static final String CONCIERGE_CLASS_EMAIL = "contact-concierge-email";
/*     */   private static final String CONCIERGE_CLASS_NUMBER = "contact-concierge-number";
/*     */   private static final String TAG_A = "a";
/*     */   private static final String ATTR_CLASS = "class";
/*     */   private static final String ATTR_HREF = "href";
/*     */   private static final String HREF_TEL = "tel:";
/*     */   private static final String CONTACT_FORM_PATH = "jcr:content/concierge_form";
/*     */   private static final int LANDING_PAGE_DEPTH = 7;
/*  53 */   private int carouselCount = -1;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   @Default(values={""})
/*     */   private String contactInfo;
/*     */   
/*     */   @SlingObject
/*     */   Resource resource;
/*     */   
/*     */   @Inject
/*     */   private Page currentPage;
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private Node carousel;
/*     */   
/*     */   @PostConstruct
/*     */   protected void init()
/*     */   {
/*  74 */     log.debug("Concierge Carousel Model Initiated");
/*  75 */     String pagePath = this.resource.getPath();
/*  76 */     log.debug("Resource Path : " + pagePath);
/*  77 */     log.debug("Contact Info : " + this.contactInfo);
/*     */     try
/*     */     {
/*  80 */       if (null != this.carousel) {
/*  81 */         NodeIterator it = this.carousel.getNodes();
/*  82 */         while (it.hasNext()) {
/*  83 */           Node currNode = it.nextNode();
/*  84 */           if (currNode.hasProperty("heroImage")) {
/*  85 */             this.carouselHeroImage.add(currNode.getProperty("heroImage").getString());
/*     */           }
/*  87 */           if (currNode.hasProperty("slideText")) {
/*  88 */             this.carouselSlideText.add(currNode.getProperty("slideText").getString());
/*  89 */             this.carouselCount += 1;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (AccessDeniedException e) {
/*  94 */       log.debug("AccessDeniedException occured in ConciergeCarouselModel init()" + e.getMessage());
/*     */     } catch (ItemNotFoundException e) {
/*  96 */       log.debug("ItemNotFoundException occured in ConciergeCarouselModel init()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/*  98 */       log.debug("RepositoryException occured in ConciergeCarouselModel init()" + e.getMessage());
/*     */     } catch (Exception e) {
/* 100 */       log.debug("Exception occured in ConciergeCarouselModel init()" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public ArrayList<String> getCarouselHeroImage() {
/* 105 */     return this.carouselHeroImage;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getCarouselSlideText() {
/* 109 */     return this.carouselSlideText;
/*     */   }
/*     */   
/*     */   public int getCarouselCount() {
/* 113 */     return this.carouselCount;
/*     */   }
/*     */   
/*     */   public String getContactInfo() {
/* 117 */     return getFormattedText(this.contactInfo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getIsConciergeFormAuthored()
/*     */   {
/* 126 */     if (this.currentPage.getDepth() >= 7) {
/* 127 */       log.debug("current Page : " + this.currentPage.getName());
/* 128 */       Page landingPage = this.currentPage.getAbsoluteParent(6);
/* 129 */       log.debug("Landing page : " + landingPage.getName());
/*     */       try {
/* 131 */         Node landingPageNode = (Node)landingPage.adaptTo(Node.class);
/* 132 */         return Boolean.valueOf(landingPageNode.hasNode("jcr:content/concierge_form"));
/*     */       } catch (RepositoryException e) {
/* 134 */         log.error("RepositoryException in getConciergePath() of  PremiumGenericConciergeInheriter" + e
/* 135 */           .getMessage());
/*     */       }
/*     */     }
/* 138 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getFormattedText(String currentText)
/*     */   {
/* 149 */     Document doc = Jsoup.parse(currentText);
/* 150 */     Elements anchorElements = doc.select("a");
/* 151 */     for (Element anchorElement : anchorElements) {
/* 152 */       String hrefVal = anchorElement.attr("href");
/* 153 */       if (hrefVal.endsWith("#contact-concierge-email")) {
/* 154 */         log.debug("hrefValue ****** : " + hrefVal);
/* 155 */         anchorElement.attr("href", "#");
/* 156 */         anchorElement.attr("class", "contact-concierge-email");
/*     */       }
/* 158 */       if (hrefVal.startsWith("tel:")) {
/* 159 */         anchorElement.attr("class", "contact-concierge-number");
/*     */       }
/*     */     }
/*     */     
/* 163 */     return doc.outerHtml().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ConciergeCarouselModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */