/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={Resource.class})
/*     */ public class ConciergeFormModel
/*     */ {
/*     */   @Inject
/*     */   @Optional
/*     */   private String heading;
/*     */   @Inject
/*     */   @Optional
/*     */   private String phoneNumberLabel;
/*     */   @Inject
/*     */   @Optional
/*     */   private String phoneNumberValidationMessage;
/*     */   @Inject
/*     */   @Optional
/*     */   private String commentTextboxLabel;
/*     */   @Inject
/*     */   @Optional
/*     */   private String[] linkMap;
/*     */   @Inject
/*     */   @Optional
/*     */   private String title;
/*     */   @Inject
/*     */   @Optional
/*     */   private String description;
/*     */   @Inject
/*     */   @Optional
/*     */   private String disclaimer;
/*     */   @Inject
/*     */   @Optional
/*     */   private String buttonLabel;
/*     */   private List<ContactLink> contactLinks;
/*     */   
/*     */   @PostConstruct
/*     */   protected void init()
/*     */     throws JSONException
/*     */   {
/*  66 */     this.contactLinks = new ArrayList();
/*  67 */     if ((this.linkMap != null) && (this.linkMap.length > 0)) {
/*  68 */       for (String linkString : this.linkMap) {
/*  69 */         JSONObject jsonObj = new JSONObject(linkString);
/*  70 */         this.contactLinks.add(new ContactLink(jsonObj.getString("linkTitle"), jsonObj
/*  71 */           .getString("linkType"), jsonObj.getString("internalLink"), jsonObj
/*  72 */           .getString("externalLink"), jsonObj.getString("target")));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHeading() {
/*  78 */     return this.heading;
/*     */   }
/*     */   
/*     */   public String getPhoneNumberLabel() {
/*  82 */     return this.phoneNumberLabel;
/*     */   }
/*     */   
/*     */   public String getPhoneNumberValidationMessage() {
/*  86 */     return this.phoneNumberValidationMessage;
/*     */   }
/*     */   
/*     */   public String getCommentTextboxLabel() {
/*  90 */     return this.commentTextboxLabel;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/*  94 */     return this.title;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  98 */     return this.description;
/*     */   }
/*     */   
/*     */   public String getDisclaimer() {
/* 102 */     return this.disclaimer;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getButtonLabel()
/*     */   {
/* 108 */     return this.buttonLabel;
/*     */   }
/*     */   
/*     */   public List<ContactLink> getContactLinks() {
/* 112 */     return this.contactLinks;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ConciergeFormModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */