/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContactLink
/*    */ {
/*    */   private String linkTitle;
/*    */   private String linkType;
/*    */   private String internalLink;
/*    */   private String externalLink;
/*    */   private String target;
/*    */   
/*    */   public ContactLink(String linkTitle, String linkType, String internalLink, String externalLink, String target)
/*    */   {
/* 34 */     this.linkTitle = linkTitle;
/* 35 */     this.linkType = linkType;
/* 36 */     this.internalLink = internalLink;
/* 37 */     this.externalLink = externalLink;
/* 38 */     this.target = target;
/*    */   }
/*    */   
/*    */   public String getLinkTitle() {
/* 42 */     return this.linkTitle;
/*    */   }
/*    */   
/*    */   public String getLinkType() {
/* 46 */     return this.linkType;
/*    */   }
/*    */   
/*    */   public String getInternalLink() {
/* 50 */     return VppUtil.getUrl(this.internalLink);
/*    */   }
/*    */   
/*    */   public String getExternalLink() {
/* 54 */     return this.externalLink;
/*    */   }
/*    */   
/*    */   public String getTarget() {
/* 58 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ContactLink.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */