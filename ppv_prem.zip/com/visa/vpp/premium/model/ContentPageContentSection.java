/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentPageContentSection
/*    */ {
/*    */   private String title;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String subTitle;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String description;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentPageContentSection(String title, String subTitle, String description)
/*    */   {
/* 26 */     this.title = title;
/* 27 */     this.subTitle = subTitle;
/* 28 */     this.description = description;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 32 */     return this.title;
/*    */   }
/*    */   
/*    */   public String getSubTitle() {
/* 36 */     return this.subTitle;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 40 */     return this.description;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ContentPageContentSection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */