/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.commons.json.JSONException;
/*    */ import org.apache.sling.commons.json.JSONObject;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class ContentPageModel
/*    */ {
/*    */   @Inject
/*    */   @Optional
/*    */   private String pageTitle;
/*    */   @Inject
/*    */   @Optional
/*    */   private String[] contentSectionMap;
/*    */   private List<ContentPageContentSection> contentSection;
/*    */   
/*    */   @PostConstruct
/*    */   protected void init()
/*    */     throws JSONException
/*    */   {
/* 38 */     this.contentSection = new ArrayList();
/* 39 */     if ((this.contentSectionMap != null) && (this.contentSectionMap.length > 0)) {
/* 40 */       for (String linkString : this.contentSectionMap) {
/* 41 */         JSONObject jsonObj = new JSONObject(linkString);
/* 42 */         this.contentSection.add(new ContentPageContentSection(jsonObj.getString("title"), jsonObj
/* 43 */           .getString("subTitle"), jsonObj.getString("description")));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPageTitle() {
/* 49 */     return this.pageTitle;
/*    */   }
/*    */   
/*    */   public List<ContentPageContentSection> getContentSection() {
/* 53 */     return this.contentSection;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\ContentPageModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */