/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import com.day.cq.commons.jcr.JcrUtil;
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import java.util.Iterator;
/*     */ import javax.inject.Inject;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.models.annotations.Default;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.Optional;
/*     */ import org.apache.sling.models.annotations.Via;
/*     */ import org.apache.sling.models.annotations.injectorspecific.SlingObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class EmailBodyModel
/*     */ {
/*  39 */   private static final Logger log = LoggerFactory.getLogger(EmailBodyModel.class);
/*     */   
/*     */ 
/*     */   private static final String RESET_PASSWORD = "reset_password";
/*     */   
/*     */   private static final String EMAIL_LINK_PLACE_HOLDER = "##email_link##";
/*     */   
/*     */   private static final String TOKEN_LINK_PLACE_HOLDER = "##token_id##";
/*     */   
/*     */   private static final String HOME_PAGE_TEMPLATE = "home_page";
/*     */   
/*     */   private static final String COINCIERGE_HOME_PAGE = "concierge_home";
/*     */   
/*     */   private static final int LANGUAGE_PAGE_DEPTH = 5;
/*     */   
/*     */   private static final String CONCIERGE_PATH = "concierge";
/*     */   
/*     */   @Inject
/*     */   private SlingHttpServletRequest request;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   @Default(values={""})
/*     */   private String emailBody;
/*     */   
/*     */   @SlingObject
/*     */   Resource resource;
/*     */   
/*     */   @Inject
/*     */   private Page currentPage;
/*     */   
/*     */ 
/*     */   public String getEmailBody()
/*     */   {
/*  74 */     if ((this.currentPage != null) && (this.currentPage.getPath().contains("reset_password"))) {
/*  75 */       Page homePage = null;
/*  76 */       Page languagePage = this.currentPage.getAbsoluteParent(4);
/*     */       
/*     */ 
/*  79 */       if ((null != languagePage) && (!languagePage.getPath().contains("concierge"))) {
/*  80 */         Iterator<Page> childList = languagePage.listChildren();
/*  81 */         while (childList.hasNext())
/*     */         {
/*  83 */           Page childPage = (Page)childList.next();
/*  84 */           log.debug("path ::" + childPage.getPath());
/*  85 */           if (childPage.getTemplate().getName().equalsIgnoreCase("home_page")) {
/*  86 */             homePage = childPage;
/*  87 */             break;
/*     */           }
/*     */         }
/*     */         
/*  91 */         if (null != homePage)
/*     */         {
/*  93 */           String url = "<a href=##email_link##" + homePage.getPath() + ".html/#/forgot-password/" + "##token_id##" + " target='Target'>Reset link</a>";
/*     */           
/*  95 */           if (!this.emailBody.contains("##token_id##")) {
/*  96 */             this.emailBody = this.emailBody.replace("##email_link##", url);
/*  97 */             updateNode(this.currentPage, this.emailBody);
/*     */           }
/*     */         }
/*     */       }
/* 101 */       else if ((null != languagePage) && (languagePage.getPath().contains("concierge"))) {
/* 102 */         Iterator<Page> childList = languagePage.listChildren();
/* 103 */         while (childList.hasNext())
/*     */         {
/* 105 */           Page childPage = (Page)childList.next();
/* 106 */           log.debug("path ::" + childPage.getPath());
/* 107 */           String templateName = childPage.getTemplate().getName();
/* 108 */           if (templateName.equalsIgnoreCase("concierge_home")) {
/* 109 */             homePage = childPage;
/* 110 */             break;
/*     */           }
/*     */         }
/*     */         
/* 114 */         if (null != homePage)
/*     */         {
/* 116 */           String url = "<a href=##email_link##" + homePage.getPath() + ".html#/reset-password/" + "##token_id##" + " target='Target'>Reset link</a>";
/*     */           
/* 118 */           if (!this.emailBody.contains("##token_id##")) {
/* 119 */             this.emailBody = this.emailBody.replace("##email_link##", url);
/* 120 */             updateNode(this.currentPage, this.emailBody);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 127 */     return this.emailBody;
/*     */   }
/*     */   
/*     */   private void updateNode(Page page, String emailText) {
/* 131 */     log.debug("inside update node");
/* 132 */     ResourceResolver resolver = null;
/* 133 */     Session session = null;
/*     */     try {
/* 135 */       resolver = this.request.getResourceResolver();
/*     */       
/* 137 */       session = (Session)resolver.adaptTo(Session.class);
/* 138 */       log.debug("path :: " + page.getPath() + "/jcr:content/email_body");
/* 139 */       if (session.nodeExists(page.getPath() + "/jcr:content/email_body")) {
/* 140 */         log.debug(" node exists" + page.getPath() + "/jcr:content/email_body");
/* 141 */         Node nodeContent = session.getNode(page.getPath() + "/jcr:content/email_body");
/* 142 */         JcrUtil.setProperty(nodeContent, "emailBody", emailText);
/* 143 */         session.save();
/*     */       }
/*     */     } catch (Exception e) {
/* 146 */       log.error("Exception in email body set property" + e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\EmailBodyModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */