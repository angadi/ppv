/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Calendar;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.commons.json.JSONException;
/*    */ import org.apache.sling.commons.json.JSONObject;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class EmailFooterHandler
/*    */ {
/* 28 */   private static final Logger log = LoggerFactory.getLogger(EmailFooterHandler.class);
/*    */   @Inject
/*    */   @Optional
/*    */   private String[] footerLinkMap;
/*    */   private List<EmailFooterLinksList> emailFooterLinkList;
/*    */   public int year;
/*    */   
/*    */   @PostConstruct
/*    */   protected void init()
/*    */     throws JSONException
/*    */   {
/* 39 */     this.year = Calendar.getInstance().get(1);
/* 40 */     log.debug("inside EmailFooterHandler");
/* 41 */     this.emailFooterLinkList = new ArrayList();
/* 42 */     if ((this.footerLinkMap != null) && (this.footerLinkMap.length > 0)) {
/* 43 */       for (String linkString : this.footerLinkMap) {
/* 44 */         JSONObject jsonObj = new JSONObject(linkString);
/* 45 */         this.emailFooterLinkList.add(new EmailFooterLinksList(jsonObj.getString("footerLinkTitle"), jsonObj
/* 46 */           .getString("footerLinkType"), jsonObj.getString("footerInternalLink"), jsonObj
/* 47 */           .getString("footerExternalLink"), jsonObj.getString("footerTarget")));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public int getYear() {
/* 53 */     return this.year;
/*    */   }
/*    */   
/*    */   public List<EmailFooterLinksList> getFooterLinkList() {
/* 57 */     return this.emailFooterLinkList;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\EmailFooterHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */