/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmailFooterLinksList
/*    */ {
/*    */   private String footerLinkTitle;
/*    */   private String footerLinkType;
/*    */   private String footerInternalLink;
/*    */   private String footerExternalLink;
/*    */   private String footerTarget;
/*    */   
/*    */   public String getFooterLinkTitle()
/*    */   {
/* 19 */     return this.footerLinkTitle;
/*    */   }
/*    */   
/*    */   public String getFooterLinkType() {
/* 23 */     return this.footerLinkType;
/*    */   }
/*    */   
/*    */   public String getFooterInternalLink() {
/* 27 */     this.footerInternalLink = VppUtil.getUrl(this.footerInternalLink);
/* 28 */     return this.footerInternalLink;
/*    */   }
/*    */   
/*    */   public String getFooterExternalLink() {
/* 32 */     return this.footerExternalLink;
/*    */   }
/*    */   
/*    */   public String getFooterTarget() {
/* 36 */     return this.footerTarget;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EmailFooterLinksList(String footerLinkTitle, String footerLinkType, String footerInternalLink, String footerExternalLink, String footerTarget)
/*    */   {
/* 51 */     this.footerLinkTitle = footerLinkTitle;
/* 52 */     this.footerLinkType = footerLinkType;
/* 53 */     this.footerInternalLink = footerInternalLink;
/* 54 */     this.footerExternalLink = footerExternalLink;
/* 55 */     this.footerTarget = footerTarget;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\EmailFooterLinksList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */