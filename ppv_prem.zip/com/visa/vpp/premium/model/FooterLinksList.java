/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FooterLinksList
/*    */ {
/*    */   private String footerLinkTitle;
/*    */   private String footerLinkType;
/*    */   private String footerInternalLink;
/*    */   private String footerExternalLink;
/*    */   private String footerTarget;
/*    */   
/*    */   public String getFooterLinkTitle()
/*    */   {
/* 21 */     return this.footerLinkTitle;
/*    */   }
/*    */   
/*    */   public String getFooterLinkType() {
/* 25 */     return this.footerLinkType;
/*    */   }
/*    */   
/*    */   public String getFooterInternalLink() {
/* 29 */     this.footerInternalLink = VppUtil.getUrl(this.footerInternalLink);
/* 30 */     return this.footerInternalLink;
/*    */   }
/*    */   
/*    */   public String getFooterExternalLink() {
/* 34 */     return this.footerExternalLink;
/*    */   }
/*    */   
/*    */   public String getFooterTarget() {
/* 38 */     return this.footerTarget;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FooterLinksList(String footerLinkTitle, String footerLinkType, String footerInternalLink, String footerExternalLink, String footerTarget)
/*    */   {
/* 53 */     this.footerLinkTitle = footerLinkTitle;
/* 54 */     this.footerLinkType = footerLinkType;
/* 55 */     this.footerInternalLink = footerInternalLink;
/* 56 */     this.footerExternalLink = footerExternalLink;
/* 57 */     this.footerTarget = footerTarget;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\FooterLinksList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */