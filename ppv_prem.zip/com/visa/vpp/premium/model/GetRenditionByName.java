/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class GetRenditionByName
/*    */ {
/* 21 */   private static final Logger log = LoggerFactory.getLogger(GetRenditionByName.class);
/*    */   
/*    */ 
/*    */ 
/*    */   @Inject
/*    */   @Optional
/*    */   private String imagePath;
/*    */   
/*    */ 
/*    */ 
/*    */   @Inject
/*    */   @Optional
/*    */   private String compName;
/*    */   
/*    */ 
/*    */   @Inject
/*    */   @Optional
/*    */   Resource resource;
/*    */   
/*    */ 
/*    */   private Map<String, String> renditionMap;
/*    */   
/*    */ 
/*    */ 
/*    */   @PostConstruct
/*    */   protected void init()
/*    */   {
/* 48 */     log.debug("inside imagePath :: " + this.imagePath);
/* 49 */     log.debug("inside compName :: " + this.compName);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getImagePath()
/*    */   {
/* 62 */     Map<String, String> hm = VppUtil.getRenditionList(this.imagePath, this.resource, this.compName);
/*    */     
/* 64 */     for (Map.Entry<String, String> entry : hm.entrySet()) {
/* 65 */       log.debug("Util KEY Value -------::" + (String)entry.getKey() + "value" + (String)entry.getValue());
/*    */     }
/*    */     
/*    */ 
/* 69 */     return this.imagePath;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, String> getRenditionMap()
/*    */   {
/* 78 */     this.renditionMap = VppUtil.getRenditionList(this.imagePath, this.resource, this.compName);
/* 79 */     return this.renditionMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\GetRenditionByName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */