/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.commons.json.JSONException;
/*    */ import org.apache.sling.commons.json.JSONObject;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class GlobalFooterHandler
/*    */ {
/*    */   @Inject
/*    */   @Optional
/*    */   private String[] footerLinkMap;
/*    */   private List<FooterLinksList> footerLinkList;
/*    */   
/*    */   @PostConstruct
/*    */   protected void init()
/*    */     throws JSONException
/*    */   {
/* 34 */     this.footerLinkList = new ArrayList();
/* 35 */     if ((this.footerLinkMap != null) && (this.footerLinkMap.length > 0)) {
/* 36 */       for (String linkString : this.footerLinkMap) {
/* 37 */         JSONObject jsonObj = new JSONObject(linkString);
/* 38 */         this.footerLinkList.add(new FooterLinksList(jsonObj.getString("footerLinkTitle"), jsonObj
/* 39 */           .getString("footerLinkType"), jsonObj.getString("footerInternalLink"), jsonObj
/* 40 */           .getString("footerExternalLink"), jsonObj.getString("footerTarget")));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public List<FooterLinksList> getFooterLinkList() {
/* 46 */     return this.footerLinkList;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\GlobalFooterHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */