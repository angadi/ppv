/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.Optional;
/*     */ import org.apache.sling.models.annotations.Via;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class HeaderModel
/*     */ {
/*     */   private static final String INTERNAL = "internal";
/*     */   private static final String EXTERNAL = "external";
/*     */   private static final String FIRST_NAME_PLACEHOLDER = "##firstName##";
/*  34 */   private static final Logger log = LoggerFactory.getLogger(HeaderModel.class);
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String issuerLogoReference;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String logoAlttext;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String issuerLogoLinkType;
/*     */   
/*     */   private String logoLink;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String issuerLogoInternalLink;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String issuerLogoExternalLink;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String issuerLogoTarget;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String visaLogoReference;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String visaLogoAlttext;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String welcomeText;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String conciergeText;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String conciergeLink;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String profileText;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String signoutText;
/*     */   
/*     */   @Inject
/*     */   @Via("resource")
/*     */   @Optional
/*     */   private String searchText;
/*     */   
/*     */   @Inject
/*     */   private SlingSettingsService settingsService;
/*     */   
/*     */   @Inject
/*     */   private SlingHttpServletRequest request;
/*     */   
/*     */   @Inject
/*     */   XSSAPI xssApi;
/*     */   
/*     */ 
/*     */   @PostConstruct
/*     */   protected void init() {}
/*     */   
/*     */   public String getIssuerLogoReference()
/*     */   {
/* 123 */     return this.issuerLogoReference;
/*     */   }
/*     */   
/*     */   public String getLogoAlttext() {
/* 127 */     return this.logoAlttext;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoLinkType() {
/* 131 */     return this.issuerLogoLinkType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLogoLink()
/*     */   {
/* 140 */     if ((null != this.issuerLogoLinkType) && (this.issuerLogoLinkType.equals("internal"))) {
/* 141 */       this.logoLink = VppUtil.getUrl(this.issuerLogoInternalLink);
/*     */     }
/* 143 */     if ((null != this.issuerLogoLinkType) && (this.issuerLogoLinkType.equals("external"))) {
/* 144 */       this.logoLink = this.issuerLogoExternalLink;
/*     */     }
/* 146 */     return this.logoLink;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoInternalLink() {
/* 150 */     return this.issuerLogoInternalLink;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoExternalLink() {
/* 154 */     return this.issuerLogoExternalLink;
/*     */   }
/*     */   
/*     */   public String getIssuerLogoTarget() {
/* 158 */     return this.issuerLogoTarget;
/*     */   }
/*     */   
/*     */   public String getVisaLogoReference() {
/* 162 */     return this.visaLogoReference;
/*     */   }
/*     */   
/*     */   public String getVisaLogoAlttext() {
/* 166 */     return this.visaLogoAlttext;
/*     */   }
/*     */   
/*     */   public String getWelcomeText() {
/* 170 */     return getFormattedWelcomeText(this.welcomeText);
/*     */   }
/*     */   
/*     */   public String getConciergeText() {
/* 174 */     return this.conciergeText;
/*     */   }
/*     */   
/*     */   public String getConciergeLink() {
/* 178 */     return this.conciergeLink;
/*     */   }
/*     */   
/*     */   public String getProfileText() {
/* 182 */     return this.profileText;
/*     */   }
/*     */   
/*     */   public String getSignoutText() {
/* 186 */     return this.signoutText;
/*     */   }
/*     */   
/*     */   public String getSearchText() {
/* 190 */     return this.searchText;
/*     */   }
/*     */   
/*     */   public Boolean isAuthorMode() {
/* 194 */     return Boolean.valueOf(VppUtil.isAuthorMode(this.settingsService));
/*     */   }
/*     */   
/*     */   private String getFormattedWelcomeText(String welcomeText) {
/* 198 */     String userFirstName = "";
/*     */     
/* 200 */     if (this.request.getSession(true).getAttribute("firstName") != null)
/*     */     {
/* 202 */       userFirstName = this.request.getSession(true).getAttribute("firstName").toString();
/*     */     } else {
/* 204 */       log.debug("session Could not be fetched. User First Name will be treated as empty");
/*     */     }
/* 206 */     if ((null != welcomeText) && (welcomeText.contains("##firstName##")))
/* 207 */       return welcomeText.replace("##firstName##", userFirstName);
/* 208 */     if (null == welcomeText) {
/* 209 */       return userFirstName;
/*     */     }
/* 211 */     return welcomeText;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\HeaderModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */