/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OfferCreationUtil
/*    */   extends WCMUsePojo
/*    */ {
/*    */   private String offerCopy;
/*    */   private String visaTandC;
/*    */   private String merchantTandC;
/*    */   private String faqs;
/*    */   private String totalTermsandConditionsHtml;
/*    */   
/*    */   public void activate()
/*    */     throws Exception
/*    */   {
/* 31 */     String offerCopyVal = (String)get("offerCopy", String.class);
/* 32 */     String visaTandCVal = (String)get("visaTandC", String.class);
/* 33 */     String merchantTandCVal = (String)get("merchantTandC", String.class);
/* 34 */     String faqsVal = (String)get("faqs", String.class);
/* 35 */     String totalTncVal = (String)get("totalTermsandConditionsHtml", String.class);
/*    */     
/* 37 */     if ((null != offerCopyVal) && (offerCopyVal.length() > 0)) {
/* 38 */       this.offerCopy = offerCopyVal.replaceAll("<a", "<a target='_blank'");
/*    */     }
/*    */     
/* 41 */     if ((null != visaTandCVal) && (visaTandCVal.length() > 0)) {
/* 42 */       this.visaTandC = visaTandCVal.replaceAll("<a", "<a target='_blank'");
/*    */     }
/*    */     
/* 45 */     if ((null != merchantTandCVal) && (merchantTandCVal.length() > 0)) {
/* 46 */       this.merchantTandC = merchantTandCVal.replaceAll("<a", "<a target='_blank'");
/*    */     }
/*    */     
/* 49 */     if ((null != faqsVal) && (faqsVal.length() > 0)) {
/* 50 */       this.faqs = faqsVal.replaceAll("<a", "<a target='blank'");
/*    */     }
/* 52 */     if ((null != totalTncVal) && (totalTncVal.length() > 0)) {
/* 53 */       this.totalTermsandConditionsHtml = totalTncVal.replaceAll("<a", "<a target='_blank'");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getTotalTermsandConditionsHtml()
/*    */   {
/* 60 */     return this.totalTermsandConditionsHtml;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getOfferCopy()
/*    */   {
/* 66 */     return this.offerCopy;
/*    */   }
/*    */   
/*    */   public String getVisaTandC()
/*    */   {
/* 71 */     return this.visaTandC;
/*    */   }
/*    */   
/*    */   public String getMerchantTandC()
/*    */   {
/* 76 */     return this.merchantTandC;
/*    */   }
/*    */   
/*    */   public String getFaqs()
/*    */   {
/* 81 */     return this.faqs;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\OfferCreationUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */