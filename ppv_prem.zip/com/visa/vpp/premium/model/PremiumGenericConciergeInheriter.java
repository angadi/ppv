/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import javax.inject.Inject;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class PremiumGenericConciergeInheriter
/*    */ {
/* 19 */   private static final Logger log = LoggerFactory.getLogger(PremiumGenericConciergeInheriter.class);
/*    */   
/*    */   @Inject
/*    */   private Page currentPage;
/* 23 */   private String conciergePath = "";
/*    */   private static final int LANDING_PAGE_DEPTH = 7;
/* 25 */   private String conciergePagePath = "jcr:content/concierge_carousel";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getConciergePath()
/*    */   {
/* 33 */     if (this.currentPage.getDepth() >= 7) {
/* 34 */       log.debug("current Page : " + this.currentPage.getName());
/* 35 */       Page landingPage = this.currentPage.getAbsoluteParent(6);
/* 36 */       log.debug("Landing page : " + landingPage.getName());
/*    */       try {
/* 38 */         Node landingPageNode = (Node)landingPage.adaptTo(Node.class);
/* 39 */         if (landingPageNode.hasNode(this.conciergePagePath)) {
/* 40 */           Node conciergeNode = landingPageNode.getNode(this.conciergePagePath);
/* 41 */           this.conciergePath = conciergeNode.getPath();
/*    */         } else {
/* 43 */           log.debug("Concierge Component is not authored on Landing Page");
/*    */         }
/*    */       } catch (RepositoryException e) {
/* 46 */         log.error("RepositoryException in getConciergePath() of  PremiumGenericConciergeInheriter" + e
/* 47 */           .getMessage());
/*    */       }
/*    */     }
/* 50 */     return this.conciergePath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\PremiumGenericConciergeInheriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */