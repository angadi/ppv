/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import javax.inject.Inject;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class PremiumGenericFooterInheriter
/*    */ {
/* 26 */   private static final Logger logger = LoggerFactory.getLogger(PremiumGenericFooterInheriter.class);
/*    */   
/*    */   @Inject
/*    */   private Page currentPage;
/* 30 */   private String footerPath = "";
/*    */   private static final int HOME_PAGE_DEPTH = 5;
/* 32 */   private String footerPagePath = "jcr:content/footer";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFooterPath()
/*    */   {
/* 40 */     if (this.currentPage.getDepth() > 5) {
/* 41 */       logger.debug("currentPage" + this.currentPage.getPath());
/* 42 */       Page page = this.currentPage.getAbsoluteParent(5);
/* 43 */       logger.debug("parent page" + page.getPath());
/*    */       try {
/* 45 */         Node homePageNode = (Node)page.adaptTo(Node.class);
/* 46 */         logger.debug("homePageNode" + homePageNode.getName());
/* 47 */         if (homePageNode.hasNode(this.footerPagePath)) {
/* 48 */           Node footerNode = homePageNode.getNode(this.footerPagePath);
/* 49 */           this.footerPath = footerNode.getPath();
/*    */         } else {
/* 51 */           logger.debug("Footer Component is not authored in Home Page");
/*    */         }
/*    */       } catch (RepositoryException e) {
/* 54 */         logger.error("RepositoryException in getFooterPath() of  PremiumGenericFooterInheriter" + e
/* 55 */           .getMessage());
/*    */       }
/*    */     }
/* 58 */     logger.debug("footerPath" + this.footerPath);
/* 59 */     return this.footerPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\PremiumGenericFooterInheriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */