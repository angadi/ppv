/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import javax.inject.Inject;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class PremiumGenericHeroImageInheriter
/*    */ {
/* 19 */   private static final Logger log = LoggerFactory.getLogger(PremiumGenericHeroImageInheriter.class);
/*    */   
/*    */   @Inject
/*    */   private Page currentPage;
/* 23 */   private String heroImgPath = "";
/*    */   private static final int LANDING_PAGE_DEPTH = 7;
/* 25 */   private String heroImgPagePath = "jcr:content/heroImg";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getHeroImgPath()
/*    */   {
/* 33 */     if (this.currentPage.getDepth() >= 7) {
/* 34 */       log.debug("current Page : " + this.currentPage.getName());
/* 35 */       Page landingPage = this.currentPage.getAbsoluteParent(6);
/* 36 */       log.debug("Landing page : " + landingPage.getName());
/*    */       try {
/* 38 */         Node landingPageNode = (Node)landingPage.adaptTo(Node.class);
/* 39 */         if (landingPageNode.hasNode(this.heroImgPagePath)) {
/* 40 */           Node heroImageNode = landingPageNode.getNode(this.heroImgPagePath);
/* 41 */           this.heroImgPath = heroImageNode.getPath();
/* 42 */           log.debug(this.heroImgPath);
/*    */         } else {
/* 44 */           log.debug("heroImage Component is not authored on Landing Page");
/*    */         }
/*    */       } catch (RepositoryException e) {
/* 47 */         log.error("RepositoryException in getheroImagePath() of  PremiumGenericHeroimageInheriter" + e
/* 48 */           .getMessage());
/*    */       }
/*    */     }
/* 51 */     return this.heroImgPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\PremiumGenericHeroImageInheriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */