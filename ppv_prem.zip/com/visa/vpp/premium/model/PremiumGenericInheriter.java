/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import javax.inject.Inject;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={SlingHttpServletRequest.class})
/*    */ public class PremiumGenericInheriter
/*    */ {
/* 26 */   private static final Logger logger = LoggerFactory.getLogger(PremiumGenericInheriter.class);
/*    */   
/*    */ 
/*    */   @Inject
/*    */   private Page currentPage;
/*    */   
/* 32 */   private String headerPath = "";
/*    */   private static final int HOME_PAGE_DEPTH = 5;
/* 34 */   private String headerPagePath = "jcr:content/header";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getHeaderPath()
/*    */   {
/* 43 */     if (this.currentPage.getDepth() > 5) {
/* 44 */       Page page = this.currentPage.getAbsoluteParent(5);
/* 45 */       logger.debug("parent page" + page.getPath());
/*    */       try {
/* 47 */         Node homePageNode = (Node)page.adaptTo(Node.class);
/* 48 */         logger.debug("homePageNode" + homePageNode.getName());
/* 49 */         if (homePageNode.hasNode(this.headerPagePath)) {
/* 50 */           Node headerNode = homePageNode.getNode(this.headerPagePath);
/* 51 */           this.headerPath = headerNode.getPath();
/*    */         } else {
/* 53 */           logger.debug("Header Component is not authored in Home Page");
/*    */         }
/*    */       } catch (RepositoryException e) {
/* 56 */         logger.error("RepositoryException in getFooterPath() of  PremiumGenericFooterInheriter" + e
/* 57 */           .getMessage());
/*    */       }
/*    */     }
/* 60 */     logger.debug("headerPath" + this.headerPath);
/*    */     
/* 62 */     return this.headerPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\PremiumGenericInheriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */