/*    */ package com.visa.vpp.premium.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.commons.json.JSONException;
/*    */ import org.apache.sling.commons.json.JSONObject;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class SecurityQuestionsModel
/*    */ {
/*    */   @Inject
/*    */   @Optional
/*    */   private String securityQuestionTitle;
/*    */   @Inject
/*    */   @Optional
/*    */   private String[] securityQuestionsMap;
/*    */   @Inject
/*    */   @Optional
/*    */   private String messageText;
/*    */   @Inject
/*    */   @Optional
/*    */   private String attestationMessageText;
/*    */   @Inject
/*    */   @Optional
/*    */   private String registerButtonText;
/*    */   @Inject
/*    */   @Optional
/*    */   private String backLinkText;
/*    */   private List<SecurityQuestionsMap> securityQuestionList;
/*    */   
/*    */   public List<SecurityQuestionsMap> getSecurityQuestionList()
/*    */   {
/* 47 */     return this.securityQuestionList;
/*    */   }
/*    */   
/*    */   @PostConstruct
/*    */   protected void init() throws JSONException {
/* 52 */     this.securityQuestionList = new ArrayList();
/* 53 */     if ((this.securityQuestionsMap != null) && (this.securityQuestionsMap.length > 0)) {
/* 54 */       for (String linkString : this.securityQuestionsMap) {
/* 55 */         JSONObject jsonObj = new JSONObject(linkString);
/* 56 */         this.securityQuestionList.add(new SecurityQuestionsMap(jsonObj.getString("securityQuestion"), jsonObj
/* 57 */           .getString("securityAnswer")));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getSecurityQuestionTitle() {
/* 63 */     return this.securityQuestionTitle;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getMessageText()
/*    */   {
/* 69 */     return this.messageText;
/*    */   }
/*    */   
/*    */   public String getAttestationMessageText() {
/* 73 */     return this.attestationMessageText;
/*    */   }
/*    */   
/*    */   public String getRegisterButtonText() {
/* 77 */     return this.registerButtonText;
/*    */   }
/*    */   
/*    */   public String getBackLinkText() {
/* 81 */     return this.backLinkText;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\SecurityQuestionsModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */