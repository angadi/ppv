/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageFilter;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.pojo.CategoryOfferTile;
/*     */ import com.visa.vpp.premium.pojo.CategoryPageObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.Optional;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class SuperCategoryContentModel
/*     */ {
/*  34 */   private static final Logger log = LoggerFactory.getLogger(SuperCategoryContentModel.class);
/*  35 */   private ArrayList<CategoryPageObject> superCategoryOfferList = new ArrayList();
/*     */   
/*     */   @Inject
/*     */   private Page currentPage;
/*     */   
/*     */   @Inject
/*     */   private SlingHttpServletRequest request;
/*     */   
/*     */   @Inject
/*     */   @Optional
/*     */   private String catTemplate;
/*     */   
/*     */   @Inject
/*     */   @Optional
/*     */   private String isCategory;
/*     */   
/*     */   @PostConstruct
/*     */   protected void init()
/*     */   {
/*  54 */     log.debug("Super Category Content Model Initiated");
/*  55 */     String userBenefitTypeCode = "";
/*  56 */     if (this.request.getSession(true).getAttribute("benefitTypeCode") != null)
/*     */     {
/*  58 */       userBenefitTypeCode = this.request.getSession(true).getAttribute("benefitTypeCode").toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  63 */     String allowedBenefitTypeCode = "";
/*     */     
/*  65 */     if (userBenefitTypeCode.length() != 0) {
/*  66 */       allowedBenefitTypeCode = normalizedBenefitCodes(userBenefitTypeCode);
/*     */     }
/*  68 */     log.debug("Category Page check --" + this.isCategory);
/*     */     
/*  70 */     if (this.isCategory == "false") {
/*  71 */       getCategoryPages(this.currentPage, allowedBenefitTypeCode);
/*     */     } else {
/*  73 */       getCategoryPages(this.currentPage.getParent(), allowedBenefitTypeCode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getCategoryPages(Page landingPage, String allowedBenefitTypeCode)
/*     */   {
/*  84 */     log.debug("Landing Page Name : " + landingPage.getName());
/*  85 */     log.debug("Category Template Name : " + this.catTemplate);
/*  86 */     PageFilter pageFilter = new PageFilter() {
/*     */       public boolean includes(Page p) {
/*  88 */         if (null == SuperCategoryContentModel.this.catTemplate) {
/*  89 */           return true;
/*     */         }
/*  91 */         return p.getTemplate().getName().equalsIgnoreCase(SuperCategoryContentModel.this.catTemplate);
/*     */       }
/*  93 */     };
/*  94 */     Iterator<Page> childList = landingPage.listChildren(pageFilter);
/*  95 */     while (childList.hasNext()) {
/*  96 */       Page catPage = (Page)childList.next();
/*  97 */       CategoryPageObject catPageObj = getCategoryOfferData(catPage, allowedBenefitTypeCode);
/*  98 */       if (null != catPageObj) {
/*  99 */         this.superCategoryOfferList.add(catPageObj);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CategoryPageObject getCategoryOfferData(Page catPage, String allowedBenefitTypeCode)
/*     */   {
/* 112 */     String catPageTitle = catPage.getTitle().trim();
/* 113 */     String catPagePath = catPage.getPath().trim();
/* 114 */     String catPageName = catPage.getName().trim();
/*     */     
/* 116 */     Node catPageNode = (Node)catPage.adaptTo(Node.class);
/*     */     
/* 118 */     ArrayList<CategoryOfferTile> catOfferTileList = new ArrayList();
/*     */     try
/*     */     {
/* 121 */       StringBuilder sb = new StringBuilder("jcr:content");
/* 122 */       sb.append("/").append("more_offers");
/* 123 */       if (catPageNode.hasNode(sb.toString())) {
/* 124 */         Node moreOffers = catPageNode.getNode(sb.toString());
/* 125 */         NodeIterator nodeIt = moreOffers.getNodes();
/* 126 */         int offerCount = 0;
/* 127 */         if (this.isCategory == "false") {
/* 128 */           while ((nodeIt.hasNext()) && (offerCount < 3)) {
/* 129 */             Node offerNode = nodeIt.nextNode();
/*     */             
/*     */ 
/* 132 */             CategoryOfferTile catOfferTile = fillCategoryOfferTileData(offerNode, allowedBenefitTypeCode);
/* 133 */             if (null != catOfferTile) {
/* 134 */               catOfferTileList.add(catOfferTile);
/* 135 */               offerCount++;
/*     */             }
/*     */           }
/*     */         }
/* 139 */         while (nodeIt.hasNext()) {
/* 140 */           Node offerNode = nodeIt.nextNode();
/*     */           
/* 142 */           CategoryOfferTile catOfferTile = fillCategoryOfferTileData(offerNode, allowedBenefitTypeCode);
/* 143 */           if (null != catOfferTile) {
/* 144 */             catOfferTileList.add(catOfferTile);
/* 145 */             offerCount++;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 150 */         if (catOfferTileList.size() == 0) {
/* 151 */           log.debug("Offer Data for Catgoey Page : " + catPageTitle + " not found");
/* 152 */           return null;
/*     */         }
/* 154 */         return new CategoryPageObject(catPageTitle, catPagePath, catPageName, catOfferTileList);
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e)
/*     */     {
/* 159 */       log.debug("ValueFormatException occured in SuperCategoryContentModel getCategoryOfferData() " + e
/* 160 */         .getMessage());
/*     */     } catch (Exception e) {
/* 162 */       log.debug("Exception occured in SuperCategoryContentModel getCategoryOfferData() " + e
/* 163 */         .getMessage());
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CategoryOfferTile fillCategoryOfferTileData(Node offerNode, String allowedBenefitTypeCode)
/*     */   {
/* 178 */     String offerId = "";
/* 179 */     String offerTitle = "";
/* 180 */     String thumbImg = "";
/* 181 */     String offerSource = "";
/* 182 */     String offerShortDesc = "";
/* 183 */     String previewUrl = "";
/*     */     
/* 185 */     String pageType = "";
/* 186 */     String heroImage = "";
/* 187 */     CategoryOfferTile catOfferTile = null;
/* 188 */     ArrayList<String> benefitCodeList = new ArrayList();
/*     */     try
/*     */     {
/* 191 */       Boolean isInvalid = Boolean.valueOf(true);
/* 192 */       offerId = offerNode.getProperty("offerId").getString();
/* 193 */       offerTitle = offerNode.getProperty("offerTitle").getString();
/* 194 */       offerShortDesc = offerNode.getProperty("offerShortDesc").getString();
/* 195 */       thumbImg = offerNode.getProperty("thumbImage").getString();
/* 196 */       previewUrl = offerNode.getProperty("previewURL").getString();
/* 197 */       offerSource = offerNode.getProperty("offerSource").getString();
/* 198 */       pageType = offerNode.getProperty("pageType").getString();
/* 199 */       if (offerNode.hasProperty("heroImage")) {
/* 200 */         heroImage = offerNode.getProperty("heroImage").getString();
/*     */       }
/* 202 */       if (offerNode.hasProperty("benefitTypeCode")) {
/* 203 */         log.debug("Inside Benefit Type--" + offerNode
/* 204 */           .getProperty("benefitTypeCode").isMultiple() + "--offerId--" + offerId);
/*     */         String[] benefitTypeCode;
/* 206 */         if (offerNode.getProperty("benefitTypeCode").isMultiple())
/*     */         {
/* 208 */           Value[] values = offerNode.getProperty("benefitTypeCode").getValues();
/* 209 */           String[] benefitTypeCode = new String[values.length];
/* 210 */           for (int i = 0; i < values.length; i++) {
/* 211 */             benefitTypeCode[i] = values[i].getString();
/* 212 */             log.debug("VAlue is --" + values[i].getString());
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 217 */           log.debug("Inside the else part " + offerNode
/* 218 */             .getProperty("benefitTypeCode").getValue().toString());
/*     */           
/* 220 */           benefitTypeCode = new String[] {offerNode.getProperty("benefitTypeCode").getValue().toString() };
/*     */         }
/* 222 */         Collections.addAll(benefitCodeList, benefitTypeCode);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */       if ((pageType.length() > 0) && (pageType.equals("benefit")) && (offerNode.getProperty("offerSource").getString().equals("AEM")) && 
/* 234 */         (allowedBenefitTypeCode.length() > 0))
/*     */       {
/* 236 */         if (benefitCodeList.size() > 0) {
/* 237 */           Iterator itr = benefitCodeList.iterator();
/* 238 */           while (itr.hasNext()) {
/* 239 */             String checkBenefit = itr.next().toString();
/* 240 */             if ((checkBenefit.length() > 0) && (allowedBenefitTypeCode.contains(checkBenefit))) {
/* 241 */               isInvalid = Boolean.valueOf(false);
/* 242 */               log.debug("Valid AEM Offer");
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 247 */         isInvalid = Boolean.valueOf(false);
/* 248 */         log.debug("VMORC offer Or AEM Offer or AEM Event");
/*     */       }
/*     */       
/* 251 */       if ((offerId.equals("")) || (offerTitle.equals("")) || (offerShortDesc.equals("")) || 
/* 252 */         (thumbImg.equals("")) || (isInvalid.booleanValue())) {
/* 253 */         return null;
/*     */       }
/* 255 */       String[] benefitTypeCode = (String[])benefitCodeList.toArray(new String[benefitCodeList.size()]);
/* 256 */       return new CategoryOfferTile(offerId, offerTitle, thumbImg, offerSource, offerShortDesc, previewUrl, heroImage, benefitTypeCode);
/*     */ 
/*     */     }
/*     */     catch (ValueFormatException e)
/*     */     {
/* 261 */       log.debug("ValueFormatException occured in SuperCategoryContentModel fillCategoryOfferTileData() " + e
/*     */       
/* 263 */         .getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 265 */       log.debug("PathNotFoundException occured in SuperCategoryContentModel fillCategoryOfferTileData() " + e
/*     */       
/* 267 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 269 */       log.debug("RepositoryException occured in SuperCategoryContentModel fillCategoryOfferTileData() " + e
/*     */       
/* 271 */         .getMessage());
/*     */     } catch (Exception e) {
/* 273 */       log.debug("Exception occured in SuperCategoryContentModel fillCategoryOfferTileData() " + e
/* 274 */         .getMessage());
/*     */     }
/* 276 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<CategoryPageObject> getSuperCategoryOfferList() {
/* 280 */     return this.superCategoryOfferList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String normalizedBenefitCodes(String userBenefitTypeCode)
/*     */   {
/* 291 */     StringBuffer benefitFinal = new StringBuffer();
/*     */     try {
/* 293 */       if ((userBenefitTypeCode.length() != 0) && (userBenefitTypeCode.contains("["))) {
/* 294 */         JSONArray arr = new JSONArray(userBenefitTypeCode);
/*     */         
/* 296 */         benefitFinal.append(arr.getString(0));
/* 297 */         for (int i = 1; i < arr.length(); i++)
/*     */         {
/*     */ 
/* 300 */           benefitFinal.append(",");
/* 301 */           benefitFinal.append(arr.getString(i));
/*     */         }
/*     */         
/*     */       }
/* 305 */       else if ((userBenefitTypeCode.length() != 0) && (userBenefitTypeCode.contains("-"))) {
/* 306 */         String[] arr = userBenefitTypeCode.split("-");
/*     */         
/* 308 */         benefitFinal.append(arr[0]);
/* 309 */         for (int i = 1; i < arr.length; i++)
/*     */         {
/*     */ 
/* 312 */           benefitFinal.append(",");
/* 313 */           benefitFinal.append(arr[i]);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 318 */         benefitFinal.append(userBenefitTypeCode);
/*     */       }
/*     */     } catch (JSONException e) {
/* 321 */       log.debug("Error trace--" + e);
/*     */     }
/*     */     
/* 324 */     return benefitFinal.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean validateCookie(String cookieValue)
/*     */   {
/* 330 */     if (cookieValue.matches("^[a-zA-Z0-9]{10,100}$")) {
/* 331 */       return true;
/*     */     }
/* 333 */     log.debug("This is an invalid string");
/* 334 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\SuperCategoryContentModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */