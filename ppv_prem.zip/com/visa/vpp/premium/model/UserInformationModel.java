/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.visa.vpp.premium.pojo.SecurityQuestion;
/*     */ import com.visa.vpp.premium.pojo.UserDetails;
/*     */ import java.util.List;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class UserInformationModel
/*     */ {
/*  38 */   private static final Logger log = LoggerFactory.getLogger(UserInformationModel.class);
/*     */   
/*     */   @Inject
/*     */   private Page currentPage;
/*     */   
/*     */   @Inject
/*     */   private SlingHttpServletRequest request;
/*     */   
/*     */   @Inject
/*     */   XSSAPI xssApi;
/*     */   
/*     */   private static final String REQUEST_URL_START_POINT = "/vpp-backend/v1/";
/*     */   
/*     */   private static final String PRODUCT = "infinite";
/*     */   
/*     */   private static final String REQUEST_URL_END_POINT = "/users/user/";
/*     */   
/*     */   private static final String STATUS_OBJ = "status";
/*     */   private static final String RESPONSE_OBJ = "response";
/*     */   private static final String STATUS_CODE = "statusCode";
/*     */   private static final String MASK_CHAR = "*";
/*     */   private UserDetails userDetails;
/*  60 */   private String userId = "";
/*     */   
/*     */   @PostConstruct
/*     */   protected void init() {
/*  64 */     log.debug("User Information Model Initiated");
/*     */     
/*  66 */     if (this.request.getSession(true).getAttribute("userId") != null) {
/*  67 */       this.userId = this.request.getSession(true).getAttribute("userId").toString();
/*     */     } else {
/*  69 */       log.debug("session Could not be fetched. User Id will be treated as empty");
/*     */     }
/*  71 */     connectToService();
/*     */   }
/*     */   
/*     */   private void connectToService() {
/*  75 */     log.debug("connectToService : ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getUserInfo(String responseString)
/*     */   {
/*  85 */     if (!responseString.equalsIgnoreCase("")) {
/*     */       try {
/*  87 */         JsonParser jsonParser = new JsonParser();
/*  88 */         JsonObject responseJson = jsonParser.parse(responseString).getAsJsonObject();
/*  89 */         JsonObject statusObj = responseJson.get("status").getAsJsonObject();
/*     */         
/*  91 */         int statusCode = statusObj.get("statusCode").getAsInt();
/*  92 */         log.debug("Status Code From Tacpoint : " + statusCode);
/*  93 */         if (statusCode == 200) {
/*  94 */           JsonObject responseObj = responseJson.get("response").getAsJsonObject();
/*  95 */           log.debug("responseObj : " + responseObj.toString());
/*  96 */           Gson gson = new GsonBuilder().setPrettyPrinting().create();
/*  97 */           this.userDetails = ((UserDetails)gson.fromJson(responseObj, UserDetails.class));
/*     */         } else {
/*  99 */           log.debug("Failure from tacpoint with statusCode : " + statusCode);
/*     */         }
/*     */       } catch (JsonSyntaxException e) {
/* 102 */         log.error("JsonSyntaxException Occured in getUserInfo() UserInformationModel " + e
/* 103 */           .getMessage());
/*     */       } catch (Exception e) {
/* 105 */         log.error("Exception Occured in getUserInfo() UserInformationModel " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formRequestUrl()
/*     */   {
/* 118 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getIssuerName(String currentPagePath)
/*     */   {
/* 128 */     String issuerName = "";
/*     */     try {
/* 130 */       String[] currPageArr = currentPagePath.split("/");
/* 131 */       issuerName = currPageArr[4];
/*     */     } catch (Exception e) {
/* 133 */       log.error("Exception Occured while fetching issuer name in getIssuerName() UserInformationModel " + e
/*     */       
/* 135 */         .getMessage());
/*     */     }
/* 137 */     return issuerName;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getUserFirstName()
/*     */   {
/* 143 */     log.debug("User First Name : " + this.userDetails.getFirstName());
/* 144 */     return this.userDetails.getFirstName();
/*     */   }
/*     */   
/*     */   public String getUserLastName() {
/* 148 */     log.debug("User Last Name : " + this.userDetails.getLastName());
/* 149 */     return this.userDetails.getLastName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserEmail()
/*     */   {
/* 159 */     String userEmail = this.userDetails.getEmail();
/* 160 */     if (null != userEmail) {
/* 161 */       String[] emailArr = userEmail.split("@");
/* 162 */       if (emailArr.length == 2) {
/* 163 */         String emailArrId = emailArr[0];
/* 164 */         StringBuilder sb = new StringBuilder();
/* 165 */         for (int i = 0; i < emailArrId.length(); i++) {
/* 166 */           sb.append("*");
/*     */         }
/* 168 */         sb.append("@").append(emailArr[1]);
/* 169 */         userEmail = sb.toString();
/*     */       }
/*     */     }
/* 172 */     log.debug("User Email : " + userEmail);
/* 173 */     return userEmail;
/*     */   }
/*     */   
/*     */   public String getUserCity() {
/* 177 */     log.debug("User City : " + this.userDetails.getCity());
/* 178 */     return this.userDetails.getCity();
/*     */   }
/*     */   
/*     */   public String getPostalCode() {
/* 182 */     log.debug("Postal Code : " + this.userDetails.getZip());
/* 183 */     return this.userDetails.getZip();
/*     */   }
/*     */   
/*     */   public String getUserCountry() {
/* 187 */     log.debug("User Country : " + this.userDetails.getCountry());
/* 188 */     return this.userDetails.getCountry();
/*     */   }
/*     */   
/*     */   public List<SecurityQuestion> getSecurityQuestions() {
/* 192 */     return this.userDetails.getSecurityQuestions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserDefaultQuestions()
/*     */   {
/* 201 */     StringBuilder sb = new StringBuilder();
/* 202 */     List<SecurityQuestion> securityQuestions = this.userDetails.getSecurityQuestions();
/*     */     try
/*     */     {
/* 205 */       if ((null != securityQuestions) && (securityQuestions.size() >= 2)) {
/* 206 */         String firstId = ((SecurityQuestion)securityQuestions.get(0)).getQuestionId();
/* 207 */         String secondId = ((SecurityQuestion)securityQuestions.get(1)).getQuestionId();
/* 208 */         sb.append(firstId).append(",").append(secondId);
/* 209 */         log.debug("User Default Questions : " + sb.toString());
/* 210 */         return sb.toString();
/*     */       }
/*     */     } catch (Exception e) {
/* 213 */       log.error("Exception Occurred while getting user's default security question's Ids " + e
/* 214 */         .getMessage());
/*     */     }
/* 216 */     return "";
/*     */   }
/*     */   
/*     */   public UserDetails getUserDetails() {
/* 220 */     return this.userDetails;
/*     */   }
/*     */   
/*     */   public boolean validString(String accessTokenString) {
/* 224 */     if (accessTokenString.matches("^[a-zA-Z0-9]{10,100}$")) {
/* 225 */       return true;
/*     */     }
/* 227 */     log.debug("This is an invalid string");
/* 228 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\UserInformationModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */