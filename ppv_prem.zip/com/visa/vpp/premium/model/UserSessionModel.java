/*     */ package com.visa.vpp.premium.model;
/*     */ 
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Model(adaptables={SlingHttpServletRequest.class})
/*     */ public class UserSessionModel
/*     */ {
/*     */   @Inject
/*     */   private SlingHttpServletRequest request;
/*     */   
/*     */   public String getUserId()
/*     */   {
/*  32 */     if (this.request.getSession(true).getAttribute("userId") != null) {
/*  33 */       return this.request.getSession(true).getAttribute("userId").toString();
/*     */     }
/*  35 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFirstName()
/*     */   {
/*  47 */     if (this.request.getSession(true).getAttribute("firstName") != null) {
/*  48 */       return this.request.getSession(true).getAttribute("firstName").toString();
/*     */     }
/*  50 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCardHolderUserId()
/*     */   {
/*  62 */     if (this.request.getSession(true).getAttribute("cardHolderId") != null) {
/*  63 */       return this.request.getSession(true).getAttribute("cardHolderId").toString();
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCardId()
/*     */   {
/*  77 */     if (this.request.getSession(true).getAttribute("cardId") != null) {
/*  78 */       return this.request.getSession(true).getAttribute("cardId").toString();
/*     */     }
/*  80 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCardHolderFirstName()
/*     */   {
/*  92 */     if (this.request.getSession(true).getAttribute("cardHolderName") != null) {
/*  93 */       return this.request.getSession(true).getAttribute("cardHolderName").toString();
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBenefitTypeCode()
/*     */   {
/* 102 */     if (this.request.getSession(true).getAttribute("benefitTypeCode") != null) {
/* 103 */       return this.request.getSession(true).getAttribute("benefitTypeCode").toString();
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConciergeUser()
/*     */   {
/* 112 */     if (this.request.getSession(true).getAttribute("isConcierge") != null) {
/* 113 */       return this.request.getSession(true).getAttribute("isConcierge").toString();
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSsoUser()
/*     */   {
/* 122 */     if (this.request.getSession(true).getAttribute("isSsoUser") != null) {
/* 123 */       return this.request.getSession(true).getAttribute("isSsoUser").toString();
/*     */     }
/* 125 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\model\UserSessionModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */