package com.visa.vpp.premium;

import aQute.bnd.annotation.Version;

@Version("1.0.0")
abstract interface package-info {}


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */