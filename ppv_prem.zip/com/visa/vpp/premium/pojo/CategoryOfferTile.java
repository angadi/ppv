/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategoryOfferTile
/*    */ {
/*    */   private String offerId;
/*    */   
/*    */ 
/*    */   private String offerTitle;
/*    */   
/*    */ 
/*    */   private String thumbImg;
/*    */   
/*    */ 
/*    */   private String offerSource;
/*    */   
/*    */   private String offerShortDesc;
/*    */   
/*    */   private String previewUrl;
/*    */   
/*    */   private String heroImage;
/*    */   
/*    */   private String[] benefitTypeCode;
/*    */   
/*    */ 
/*    */   public CategoryOfferTile(String offerId, String offerTitle, String thumbImg, String offerSource, String offerShortDesc, String previewUrl, String heroImage, String[] benefitTypeCode)
/*    */   {
/* 29 */     this.offerId = offerId;
/* 30 */     this.offerTitle = offerTitle;
/* 31 */     this.thumbImg = thumbImg;
/* 32 */     this.offerSource = offerSource;
/* 33 */     this.offerShortDesc = offerShortDesc;
/* 34 */     this.previewUrl = previewUrl;
/* 35 */     this.heroImage = heroImage;
/* 36 */     this.benefitTypeCode = benefitTypeCode;
/*    */   }
/*    */   
/*    */   public String getOfferId()
/*    */   {
/* 41 */     return this.offerId;
/*    */   }
/*    */   
/*    */   public String getHeroImage()
/*    */   {
/* 46 */     return this.heroImage;
/*    */   }
/*    */   
/*    */   public String[] getBenefitTypeCode()
/*    */   {
/* 51 */     return this.benefitTypeCode;
/*    */   }
/*    */   
/*    */   public String getOfferTitle()
/*    */   {
/* 56 */     return this.offerTitle;
/*    */   }
/*    */   
/*    */   public String getThumbImg()
/*    */   {
/* 61 */     return this.thumbImg;
/*    */   }
/*    */   
/*    */   public String getOfferSource()
/*    */   {
/* 66 */     return this.offerSource;
/*    */   }
/*    */   
/*    */   public String getOfferShortDesc()
/*    */   {
/* 71 */     return this.offerShortDesc;
/*    */   }
/*    */   
/*    */   public String getPreviewUrl()
/*    */   {
/* 76 */     return this.previewUrl;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\CategoryOfferTile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */