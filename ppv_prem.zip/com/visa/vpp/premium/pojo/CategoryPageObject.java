/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategoryPageObject
/*    */ {
/*    */   private String catPageTitle;
/*    */   private String catPagePath;
/*    */   private String catPageName;
/*    */   private ArrayList<CategoryOfferTile> catOfferTileList;
/*    */   
/*    */   public CategoryPageObject(String catPageTitle, String catPagePath, String catPageName, ArrayList<CategoryOfferTile> catOfferTileList)
/*    */   {
/* 23 */     this.catPageTitle = catPageTitle;
/* 24 */     this.catPagePath = catPagePath;
/* 25 */     this.catPageName = catPageName;
/* 26 */     this.catOfferTileList = catOfferTileList;
/*    */   }
/*    */   
/*    */   public String getCatPageName() {
/* 30 */     return this.catPageName;
/*    */   }
/*    */   
/*    */   public String getCatPageTitle() {
/* 34 */     return this.catPageTitle;
/*    */   }
/*    */   
/*    */   public String getCatPagePath() {
/* 38 */     return this.catPagePath;
/*    */   }
/*    */   
/*    */   public ArrayList<CategoryOfferTile> getCatOfferTileList() {
/* 42 */     return this.catOfferTileList;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\CategoryPageObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */