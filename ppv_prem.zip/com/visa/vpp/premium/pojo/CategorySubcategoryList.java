/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategorySubcategoryList
/*    */ {
/* 15 */   private List<Subcategory> subcategories = null;
/*    */   private String value;
/*    */   private Integer key;
/*    */   
/*    */   public List<Subcategory> getSubcategories() {
/* 20 */     return this.subcategories;
/*    */   }
/*    */   
/*    */   public void setSubcategories(List<Subcategory> subcategories) {
/* 24 */     this.subcategories = subcategories;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 28 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   
/*    */   public Integer getKey() {
/* 36 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(Integer key) {
/* 40 */     this.key = key;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\CategorySubcategoryList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */