/*     */ package com.visa.vpp.premium.pojo;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageList
/*     */ {
/*     */   private List<String> offerImagePromotionChannelIds;
/*     */   private String imageFileHeight;
/*     */   private List<String> offerImagePromotionChannels;
/*     */   private String description;
/*     */   private String imageFileWidth;
/*     */   private String fileLocation;
/*     */   private String imageResolution;
/*     */   private String imageAltTag;
/*     */   private String key;
/*     */   private String imageFileSize;
/*     */   
/*     */   public List<String> getOfferImagePromotionChannelIds()
/*     */   {
/*  27 */     return this.offerImagePromotionChannelIds;
/*     */   }
/*     */   
/*     */   public void setOfferImagePromotionChannelIds(List<String> offerImagePromotionChannelIds) {
/*  31 */     this.offerImagePromotionChannelIds = offerImagePromotionChannelIds;
/*     */   }
/*     */   
/*     */   public String getImageFileHeight() {
/*  35 */     return this.imageFileHeight;
/*     */   }
/*     */   
/*     */   public void setImageFileHeight(String imageFileHeight) {
/*  39 */     this.imageFileHeight = imageFileHeight;
/*     */   }
/*     */   
/*     */   public List<String> getOfferImagePromotionChannels() {
/*  43 */     return this.offerImagePromotionChannels;
/*     */   }
/*     */   
/*     */   public void setOfferImagePromotionChannels(List<String> offerImagePromotionChannels) {
/*  47 */     this.offerImagePromotionChannels = offerImagePromotionChannels;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  51 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  55 */     this.description = description;
/*     */   }
/*     */   
/*     */   public String getImageFileWidth() {
/*  59 */     return this.imageFileWidth;
/*     */   }
/*     */   
/*     */   public void setImageFileWidth(String imageFileWidth) {
/*  63 */     this.imageFileWidth = imageFileWidth;
/*     */   }
/*     */   
/*     */   public String getFileLocation() {
/*  67 */     return this.fileLocation;
/*     */   }
/*     */   
/*     */   public void setFileLocation(String fileLocation) {
/*  71 */     this.fileLocation = fileLocation;
/*     */   }
/*     */   
/*     */   public String getImageResolution() {
/*  75 */     return this.imageResolution;
/*     */   }
/*     */   
/*     */   public void setImageResolution(String imageResolution) {
/*  79 */     this.imageResolution = imageResolution;
/*     */   }
/*     */   
/*     */   public String getImageAltTag() {
/*  83 */     return this.imageAltTag;
/*     */   }
/*     */   
/*     */   public void setImageAltTag(String imageAltTag) {
/*  87 */     this.imageAltTag = imageAltTag;
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  91 */     return this.key;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/*  95 */     this.key = key;
/*     */   }
/*     */   
/*     */   public String getImageFileSize() {
/*  99 */     return this.imageFileSize;
/*     */   }
/*     */   
/*     */   public void setImageFileSize(String imageFileSize) {
/* 103 */     this.imageFileSize = imageFileSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\ImageList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */