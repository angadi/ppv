/*     */ package com.visa.vpp.premium.pojo;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MerchantImage
/*     */ {
/*     */   private List<String> promotionChannels;
/*     */   private String imageFileHeight;
/*     */   private String fileName;
/*  21 */   private List<String> languages = null;
/*     */   
/*     */   private String description;
/*     */   
/*  25 */   private List<String> promotionIds = null;
/*     */   
/*  27 */   private List<String> languageIds = null;
/*     */   
/*     */   private String fileLocation;
/*     */   
/*     */   private String promotionId;
/*     */   
/*     */   private String imageFileSize;
/*     */   
/*     */   private String promotionChannel;
/*     */   
/*     */   private String imageFileWidth;
/*     */   
/*     */   private String logoAltTag;
/*     */   
/*     */   private String defaultMerchImg;
/*     */   
/*     */   private String imageResolution;
/*     */   private String key;
/*     */   
/*     */   public List<String> getPromotionChannels()
/*     */   {
/*  48 */     return this.promotionChannels;
/*     */   }
/*     */   
/*     */   public void setPromotionChannels(List<String> promotionChannels) {
/*  52 */     this.promotionChannels = promotionChannels;
/*     */   }
/*     */   
/*     */   public String getImageFileHeight() {
/*  56 */     return this.imageFileHeight;
/*     */   }
/*     */   
/*     */   public void setImageFileHeight(String imageFileHeight) {
/*  60 */     this.imageFileHeight = imageFileHeight;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  64 */     return this.fileName;
/*     */   }
/*     */   
/*     */   public void setFileName(String fileName) {
/*  68 */     this.fileName = fileName;
/*     */   }
/*     */   
/*     */   public List<String> getLanguages() {
/*  72 */     return this.languages;
/*     */   }
/*     */   
/*     */   public void setLanguages(List<String> languages) {
/*  76 */     this.languages = languages;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  80 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  84 */     this.description = description;
/*     */   }
/*     */   
/*     */   public List<String> getPromotionIds() {
/*  88 */     return this.promotionIds;
/*     */   }
/*     */   
/*     */   public void setPromotionIds(List<String> promotionIds) {
/*  92 */     this.promotionIds = promotionIds;
/*     */   }
/*     */   
/*     */   public List<String> getLanguageIds() {
/*  96 */     return this.languageIds;
/*     */   }
/*     */   
/*     */   public void setLanguageIds(List<String> languageIds) {
/* 100 */     this.languageIds = languageIds;
/*     */   }
/*     */   
/*     */   public String getFileLocation() {
/* 104 */     return this.fileLocation;
/*     */   }
/*     */   
/*     */   public void setFileLocation(String fileLocation) {
/* 108 */     this.fileLocation = fileLocation;
/*     */   }
/*     */   
/*     */   public String getPromotionId() {
/* 112 */     return this.promotionId;
/*     */   }
/*     */   
/*     */   public void setPromotionId(String promotionId) {
/* 116 */     this.promotionId = promotionId;
/*     */   }
/*     */   
/*     */   public String getImageFileSize() {
/* 120 */     return this.imageFileSize;
/*     */   }
/*     */   
/*     */   public void setImageFileSize(String imageFileSize) {
/* 124 */     this.imageFileSize = imageFileSize;
/*     */   }
/*     */   
/*     */   public String getPromotionChannel() {
/* 128 */     return this.promotionChannel;
/*     */   }
/*     */   
/*     */   public void setPromotionChannel(String promotionChannel) {
/* 132 */     this.promotionChannel = promotionChannel;
/*     */   }
/*     */   
/*     */   public String getImageFileWidth() {
/* 136 */     return this.imageFileWidth;
/*     */   }
/*     */   
/*     */   public void setImageFileWidth(String imageFileWidth) {
/* 140 */     this.imageFileWidth = imageFileWidth;
/*     */   }
/*     */   
/*     */   public String getLogoAltTag() {
/* 144 */     return this.logoAltTag;
/*     */   }
/*     */   
/*     */   public void setLogoAltTag(String logoAltTag) {
/* 148 */     this.logoAltTag = logoAltTag;
/*     */   }
/*     */   
/*     */   public String getDefaultMerchImg() {
/* 152 */     return this.defaultMerchImg;
/*     */   }
/*     */   
/*     */   public void setDefaultMerchImg(String defaultMerchImg) {
/* 156 */     this.defaultMerchImg = defaultMerchImg;
/*     */   }
/*     */   
/*     */   public String getImageResolution() {
/* 160 */     return this.imageResolution;
/*     */   }
/*     */   
/*     */   public void setImageResolution(String imageResolution) {
/* 164 */     this.imageResolution = imageResolution;
/*     */   }
/*     */   
/*     */   public String getKey() {
/* 168 */     return this.key;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/* 172 */     this.key = key;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\MerchantImage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */