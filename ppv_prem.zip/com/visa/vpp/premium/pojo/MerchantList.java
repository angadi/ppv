/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MerchantList
/*    */ {
/* 15 */   private List<MerchantImage> merchantImages = null;
/*    */   
/*    */   private Integer merchantId;
/*    */   
/*    */   private String merchant;
/*    */   private List<Object> merchantAddress;
/*    */   
/*    */   public List<MerchantImage> getMerchantImages()
/*    */   {
/* 24 */     return this.merchantImages;
/*    */   }
/*    */   
/*    */   public void setMerchantImages(List<MerchantImage> merchantImages) {
/* 28 */     this.merchantImages = merchantImages;
/*    */   }
/*    */   
/*    */   public Integer getMerchantId() {
/* 32 */     return this.merchantId;
/*    */   }
/*    */   
/*    */   public void setMerchantId(Integer merchantId) {
/* 36 */     this.merchantId = merchantId;
/*    */   }
/*    */   
/*    */   public String getMerchant() {
/* 40 */     return this.merchant;
/*    */   }
/*    */   
/*    */   public void setMerchant(String merchant) {
/* 44 */     this.merchant = merchant;
/*    */   }
/*    */   
/*    */   public List<Object> getMerchantAddress() {
/* 48 */     return this.merchantAddress;
/*    */   }
/*    */   
/*    */   public void setMerchantAddress(List<Object> merchantAddress) {
/* 52 */     this.merchantAddress = merchantAddress;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\MerchantList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */