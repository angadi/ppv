/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedemptionCountry
/*    */ {
/*    */   private String value;
/*    */   
/*    */ 
/*    */   private String key;
/*    */   
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 17 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 21 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 25 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 29 */     this.key = key;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\RedemptionCountry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */