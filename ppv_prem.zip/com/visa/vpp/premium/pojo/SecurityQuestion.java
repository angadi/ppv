/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ public class SecurityQuestion
/*    */ {
/*    */   private String questionId;
/*    */   private String questionText;
/*    */   
/*    */   public String getQuestionId() {
/*  9 */     return this.questionId;
/*    */   }
/*    */   
/*    */   public void setQuestionId(String questionId) {
/* 13 */     this.questionId = questionId;
/*    */   }
/*    */   
/*    */   public String getQuestionText() {
/* 17 */     return this.questionText;
/*    */   }
/*    */   
/*    */   public void setQuestionText(String questionText) {
/* 21 */     this.questionText = questionText;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\SecurityQuestion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */