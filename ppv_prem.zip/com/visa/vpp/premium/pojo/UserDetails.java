/*    */ package com.visa.vpp.premium.pojo;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class UserDetails
/*    */ {
/*    */   private String token;
/*    */   private String firstName;
/*    */   private String lastName;
/*    */   private String email;
/*    */   private String city;
/*    */   private String zip;
/*    */   private String country;
/*    */   private List<SecurityQuestion> securityQuestions;
/*    */   
/*    */   public String getToken() {
/* 17 */     return this.token;
/*    */   }
/*    */   
/*    */   public void setToken(String token) {
/* 21 */     this.token = token;
/*    */   }
/*    */   
/*    */   public String getFirstName() {
/* 25 */     return this.firstName;
/*    */   }
/*    */   
/*    */   public void setFirstName(String firstName) {
/* 29 */     this.firstName = firstName;
/*    */   }
/*    */   
/*    */   public String getLastName() {
/* 33 */     return this.lastName;
/*    */   }
/*    */   
/*    */   public void setLastName(String lastName) {
/* 37 */     this.lastName = lastName;
/*    */   }
/*    */   
/*    */   public String getEmail() {
/* 41 */     return this.email;
/*    */   }
/*    */   
/*    */   public void setEmail(String email) {
/* 45 */     this.email = email;
/*    */   }
/*    */   
/*    */   public String getCity() {
/* 49 */     return this.city;
/*    */   }
/*    */   
/*    */   public void setCity(String city) {
/* 53 */     this.city = city;
/*    */   }
/*    */   
/*    */   public String getZip() {
/* 57 */     return this.zip;
/*    */   }
/*    */   
/*    */   public void setZip(String zip) {
/* 61 */     this.zip = zip;
/*    */   }
/*    */   
/*    */   public String getCountry() {
/* 65 */     return this.country;
/*    */   }
/*    */   
/*    */   public void setCountry(String country) {
/* 69 */     this.country = country;
/*    */   }
/*    */   
/*    */   public List<SecurityQuestion> getSecurityQuestions() {
/* 73 */     return this.securityQuestions;
/*    */   }
/*    */   
/*    */   public void setSecurityQuestions(List<SecurityQuestion> securityQuestions) {
/* 77 */     this.securityQuestions = securityQuestions;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\UserDetails.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */