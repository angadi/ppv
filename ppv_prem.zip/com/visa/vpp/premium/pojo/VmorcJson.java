/*     */ package com.visa.vpp.premium.pojo;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VmorcJson
/*     */ {
/*     */   private List<RedemptionCountry> redemptionCountries;
/*     */   private String language;
/*     */   private String programName;
/*     */   private String promotionToDate;
/*     */   private String eventSubTitle;
/*     */   private List<CardPaymentTypeList> cardPaymentTypeList;
/*  22 */   private List<CardProductList> cardProductList = null;
/*     */   private String offerStatus;
/*     */   private Map<String, String> offerCopy;
/*     */   private Map<String, String> offerShortDescription;
/*     */   private Map<String, String> fAQs;
/*     */   private String offerId;
/*     */   private String offerContentId;
/*     */   private List<ImageList> imageList;
/*     */   private Map<String, String> redemptionTelephone;
/*     */   private String isOfferEvent;
/*     */   private List<OfferType> offerType;
/*     */   private String lastModifiedDatetime;
/*     */   private String offerSourceContact;
/*     */   private String redemptionEmail;
/*     */   private String validityToDate;
/*     */   private List<PromotionChannelList> promotionChannelList;
/*     */   private List<PromotingCountry> promotingCountries;
/*     */   private String offerTitle;
/*     */   private String redemptionCode;
/*     */   private String languageId;
/*     */   private String validityFromDate;
/*     */   private List<CategorySubcategoryList> categorySubcategoryList;
/*     */   private String promotionFromDate;
/*     */   private Map<String, String> visaTerms;
/*     */   private String redemptionUrl;
/*     */   private Map<String, String> merchantTerms;
/*     */   private String featuredOfferIndicator;
/*     */   private List<MerchantList> merchantList;
/*     */   private String programId;
/*     */   
/*     */   public String getOfferId()
/*     */   {
/*  54 */     return this.offerId;
/*     */   }
/*     */   
/*     */   public void setOfferId(String offerId) {
/*  58 */     this.offerId = offerId;
/*     */   }
/*     */   
/*     */   public String getOfferContentId() {
/*  62 */     return this.offerContentId;
/*     */   }
/*     */   
/*     */   public void setOfferContentId(String offerContentId) {
/*  66 */     this.offerContentId = offerContentId;
/*     */   }
/*     */   
/*     */   public String getOfferTitle() {
/*  70 */     return this.offerTitle;
/*     */   }
/*     */   
/*     */   public void setOfferTitle(String offerTitle) {
/*  74 */     this.offerTitle = offerTitle;
/*     */   }
/*     */   
/*     */   public Map<String, String> getOfferShortDescription() {
/*  78 */     return this.offerShortDescription;
/*     */   }
/*     */   
/*     */   public void setOfferShortDescription(Map<String, String> offerShortDescription) {
/*  82 */     this.offerShortDescription = offerShortDescription;
/*     */   }
/*     */   
/*     */   public List<ImageList> getImageList() {
/*  86 */     return this.imageList;
/*     */   }
/*     */   
/*     */   public void setImageList(List<ImageList> imageList) {
/*  90 */     this.imageList = imageList;
/*     */   }
/*     */   
/*     */   public List<RedemptionCountry> getRedemptionCountries() {
/*  94 */     return this.redemptionCountries;
/*     */   }
/*     */   
/*     */   public void setRedemptionCountries(List<RedemptionCountry> redemptionCountries) {
/*  98 */     this.redemptionCountries = redemptionCountries;
/*     */   }
/*     */   
/*     */   public Map<String, String> getOfferCopy() {
/* 102 */     return this.offerCopy;
/*     */   }
/*     */   
/*     */   public void setOfferCopy(Map<String, String> offerCopy) {
/* 106 */     this.offerCopy = offerCopy;
/*     */   }
/*     */   
/*     */   public String getLanguage() {
/* 110 */     return this.language;
/*     */   }
/*     */   
/*     */   public void setLanguage(String language) {
/* 114 */     this.language = language;
/*     */   }
/*     */   
/*     */   public String getProgramName() {
/* 118 */     return this.programName;
/*     */   }
/*     */   
/*     */   public void setProgramName(String programName) {
/* 122 */     this.programName = programName;
/*     */   }
/*     */   
/*     */   public String getPromotionToDate() {
/* 126 */     return this.promotionToDate;
/*     */   }
/*     */   
/*     */   public void setPromotionToDate(String promotionToDate) {
/* 130 */     this.promotionToDate = promotionToDate;
/*     */   }
/*     */   
/*     */   public String getEventSubTitle() {
/* 134 */     return this.eventSubTitle;
/*     */   }
/*     */   
/*     */   public void setEventSubTitle(String eventSubTitle) {
/* 138 */     this.eventSubTitle = eventSubTitle;
/*     */   }
/*     */   
/*     */   public List<CardPaymentTypeList> getCardPaymentTypeList() {
/* 142 */     return this.cardPaymentTypeList;
/*     */   }
/*     */   
/*     */   public void setCardPaymentTypeList(List<CardPaymentTypeList> cardPaymentTypeList) {
/* 146 */     this.cardPaymentTypeList = cardPaymentTypeList;
/*     */   }
/*     */   
/*     */   public String getOfferStatus() {
/* 150 */     return this.offerStatus;
/*     */   }
/*     */   
/*     */   public void setOfferStatus(String offerStatus) {
/* 154 */     this.offerStatus = offerStatus;
/*     */   }
/*     */   
/*     */   public Map<String, String> getfAQs() {
/* 158 */     return this.fAQs;
/*     */   }
/*     */   
/*     */   public void setfAQs(Map<String, String> fAQs) {
/* 162 */     this.fAQs = fAQs;
/*     */   }
/*     */   
/*     */   public Map<String, String> getRedemptionTelephone() {
/* 166 */     return this.redemptionTelephone;
/*     */   }
/*     */   
/*     */   public void setRedemptionTelephone(Map<String, String> redemptionTelephone) {
/* 170 */     this.redemptionTelephone = redemptionTelephone;
/*     */   }
/*     */   
/*     */   public String getIsOfferEvent() {
/* 174 */     return this.isOfferEvent;
/*     */   }
/*     */   
/*     */   public void setIsOfferEvent(String isOfferEvent) {
/* 178 */     this.isOfferEvent = isOfferEvent;
/*     */   }
/*     */   
/*     */   public List<OfferType> getOfferType() {
/* 182 */     return this.offerType;
/*     */   }
/*     */   
/*     */   public void setOfferType(List<OfferType> offerType) {
/* 186 */     this.offerType = offerType;
/*     */   }
/*     */   
/*     */   public String getLastModifiedDatetime() {
/* 190 */     return this.lastModifiedDatetime;
/*     */   }
/*     */   
/*     */   public void setLastModifiedDatetime(String lastModifiedDatetime) {
/* 194 */     this.lastModifiedDatetime = lastModifiedDatetime;
/*     */   }
/*     */   
/*     */   public String getOfferSourceContact() {
/* 198 */     return this.offerSourceContact;
/*     */   }
/*     */   
/*     */   public void setOfferSourceContact(String offerSourceContact) {
/* 202 */     this.offerSourceContact = offerSourceContact;
/*     */   }
/*     */   
/*     */   public String getRedemptionEmail() {
/* 206 */     return this.redemptionEmail;
/*     */   }
/*     */   
/*     */   public void setRedemptionEmail(String redemptionEmail) {
/* 210 */     this.redemptionEmail = redemptionEmail;
/*     */   }
/*     */   
/*     */   public String getValidityToDate() {
/* 214 */     return this.validityToDate;
/*     */   }
/*     */   
/*     */   public void setValidityToDate(String validityToDate) {
/* 218 */     this.validityToDate = validityToDate;
/*     */   }
/*     */   
/*     */   public List<PromotionChannelList> getPromotionChannelList() {
/* 222 */     return this.promotionChannelList;
/*     */   }
/*     */   
/*     */   public void setPromotionChannelList(List<PromotionChannelList> promotionChannelList) {
/* 226 */     this.promotionChannelList = promotionChannelList;
/*     */   }
/*     */   
/*     */   public List<PromotingCountry> getPromotingCountries() {
/* 230 */     return this.promotingCountries;
/*     */   }
/*     */   
/*     */   public void setPromotingCountries(List<PromotingCountry> promotingCountries) {
/* 234 */     this.promotingCountries = promotingCountries;
/*     */   }
/*     */   
/*     */   public String getRedemptionCode() {
/* 238 */     return this.redemptionCode;
/*     */   }
/*     */   
/*     */   public void setRedemptionCode(String redemptionCode) {
/* 242 */     this.redemptionCode = redemptionCode;
/*     */   }
/*     */   
/*     */   public String getLanguageId() {
/* 246 */     return this.languageId;
/*     */   }
/*     */   
/*     */   public void setLanguageId(String languageId) {
/* 250 */     this.languageId = languageId;
/*     */   }
/*     */   
/*     */   public String getValidityFromDate() {
/* 254 */     return this.validityFromDate;
/*     */   }
/*     */   
/*     */   public void setValidityFromDate(String validityFromDate) {
/* 258 */     this.validityFromDate = validityFromDate;
/*     */   }
/*     */   
/*     */   public List<CategorySubcategoryList> getCategorySubcategoryList() {
/* 262 */     return this.categorySubcategoryList;
/*     */   }
/*     */   
/*     */   public void setCategorySubcategoryList(List<CategorySubcategoryList> categorySubcategoryList) {
/* 266 */     this.categorySubcategoryList = categorySubcategoryList;
/*     */   }
/*     */   
/*     */   public String getPromotionFromDate() {
/* 270 */     return this.promotionFromDate;
/*     */   }
/*     */   
/*     */   public void setPromotionFromDate(String promotionFromDate) {
/* 274 */     this.promotionFromDate = promotionFromDate;
/*     */   }
/*     */   
/*     */   public Map<String, String> getVisaTerms() {
/* 278 */     return this.visaTerms;
/*     */   }
/*     */   
/*     */   public void setVisaTerms(Map<String, String> visaTerms) {
/* 282 */     this.visaTerms = visaTerms;
/*     */   }
/*     */   
/*     */   public String getRedemptionUrl() {
/* 286 */     return this.redemptionUrl;
/*     */   }
/*     */   
/*     */   public void setRedemptionUrl(String redemptionUrl) {
/* 290 */     this.redemptionUrl = redemptionUrl;
/*     */   }
/*     */   
/*     */   public Map<String, String> getMerchantTerms() {
/* 294 */     return this.merchantTerms;
/*     */   }
/*     */   
/*     */   public void setMerchantTerms(Map<String, String> merchantTerms) {
/* 298 */     this.merchantTerms = merchantTerms;
/*     */   }
/*     */   
/*     */   public String getFeaturedOfferIndicator() {
/* 302 */     return this.featuredOfferIndicator;
/*     */   }
/*     */   
/*     */   public void setFeaturedOfferIndicator(String featuredOfferIndicator) {
/* 306 */     this.featuredOfferIndicator = featuredOfferIndicator;
/*     */   }
/*     */   
/*     */   public List<MerchantList> getMerchantList() {
/* 310 */     return this.merchantList;
/*     */   }
/*     */   
/*     */   public void setMerchantList(List<MerchantList> merchantList) {
/* 314 */     this.merchantList = merchantList;
/*     */   }
/*     */   
/*     */   public String getProgramId() {
/* 318 */     return this.programId;
/*     */   }
/*     */   
/*     */   public void setProgramId(String programId) {
/* 322 */     this.programId = programId;
/*     */   }
/*     */   
/*     */   public List<CardProductList> getCardProductList() {
/* 326 */     return this.cardProductList;
/*     */   }
/*     */   
/*     */   public void setCardProductList(List<CardProductList> cardProductList) {
/* 330 */     this.cardProductList = cardProductList;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\pojo\VmorcJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */