/*     */ package com.visa.vpp.premium.scheduler;
/*     */ 
/*     */ import com.day.cq.replication.Replicator;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(metatype=true, label="Premium Category Page scheduler", description="Premium Category Pag scheduler to validate offers")
/*     */ @Service({Runnable.class})
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="scheduler.expression", value={"0 40 12 1/1 * ? *"}, description="Cron-job expression"), @org.apache.felix.scr.annotations.Property(name="scheduler.concurrent", boolValue={false}, description="Whether or not to schedule this task concurrently")})
/*     */ public class PremiumCategoryPageScheduler
/*     */   implements Runnable
/*     */ {
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(PremiumCategoryPageScheduler.class);
/*     */   
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */   @Reference
/*     */   private Replicator replicator;
/*     */   
/*     */   @Reference
/*     */   private SlingSettingsService settingsService;
/*     */   
/*     */ 
/*     */   public void run()
/*     */   {
/*  65 */     logger.debug("PremiumCategoryPageScheduler is now running");
/*     */     
/*  67 */     boolean isAuthor = VppUtil.isAuthorMode(this.settingsService);
/*     */     
/*  69 */     if (isAuthor) {
/*  70 */       logger.debug("isAuthor1 ::" + isAuthor);
/*  71 */       ArrayList<String> issuerNmaes = getChildNodes("etc/vpp-premium-tools/offers");
/*  72 */       ArrayList<String> languageNames = null;
/*  73 */       Iterator<String> it = issuerNmaes.iterator();
/*  74 */       while (it.hasNext()) {
/*  75 */         String name = (String)it.next();
/*  76 */         logger.debug("issuer name ::" + name);
/*  77 */         languageNames = getChildNodes("etc/vpp-premium-tools/offers/" + name);
/*  78 */         Iterator<String> langIterator = languageNames.iterator();
/*  79 */         while (langIterator.hasNext()) {
/*  80 */           String langName = (String)langIterator.next();
/*  81 */           validateOffers("etc/vpp-premium-tools/offers/" + name + "/" + langName);
/*     */         }
/*     */       }
/*     */     } else {
/*  85 */       logger.debug("isAuthor ::" + isAuthor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void validateOffers(String languagePath)
/*     */   {
/*  98 */     logger.debug("issuer languagePath " + languagePath);
/*  99 */     ArrayList<String> fileNames = null;
/* 100 */     JSONObject aemOfferJson = getJsonObject(languagePath, "aem_offers.json");
/*     */     
/*     */ 
/* 103 */     JSONObject vmorcOfferJson = getJsonObject(languagePath, "vmorc_offers.json");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */     ResourceResolver resolver = null;
/* 111 */     Session session = null;
/* 112 */     fileNames = getChildNodes(languagePath);
/* 113 */     Iterator<String> it = fileNames.iterator();
/*     */     try {
/* 115 */       JSONObject updatedAemOfferJson = new JSONObject(aemOfferJson.toString());
/*     */       
/* 117 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 118 */       session = (Session)resolver.adaptTo(Session.class);
/* 119 */       while (it.hasNext()) {
/* 120 */         String name = (String)it.next();
/* 121 */         boolean isFile = isFile(languagePath + "/" + name);
/* 122 */         boolean isFolder = isFolder(languagePath + "/" + name);
/* 123 */         logger.debug("=======================Start json file process**===============");
/*     */         
/* 125 */         if ((isFile) && (!name.equals("vmorc_offers.json")) && 
/* 126 */           (!name.equals("aem_offers.json"))) {
/* 127 */           logger.debug("landing page json   ::" + name);
/* 128 */           JSONObject landingPageJson = getJsonObject(languagePath, name);
/* 129 */           JSONObject updatedLandingPageJson = new JSONObject(landingPageJson.toString());
/* 130 */           Iterator<String> iterator = landingPageJson.keys();
/*     */           
/*     */ 
/* 133 */           while (iterator.hasNext()) {
/* 134 */             String jsonObjKey = (String)iterator.next();
/*     */             
/* 136 */             JSONObject categoryJson = landingPageJson.getJSONObject(jsonObjKey);
/* 137 */             JSONObject updatedCatJson = new JSONObject(categoryJson.toString());
/* 138 */             logger.debug("jsonObjKey :: " + jsonObjKey);
/* 139 */             Iterator<String> catIterator = categoryJson.keys();
/* 140 */             while (catIterator.hasNext()) {
/* 141 */               String childJson = (String)catIterator.next();
/* 142 */               logger.debug("childJson ::" + childJson);
/* 143 */               JSONObject offerJson = categoryJson.getJSONObject(childJson);
/* 144 */               String offerSource = offerJson.get("offerSource").toString();
/* 145 */               logger.debug("offersource :: " + offerJson.get("offerSource"));
/* 146 */               logger.debug("offerId :: " + offerJson.get("offerId"));
/* 147 */               String offerId = offerJson.get("offerId").toString();
/* 148 */               if ("AEM".equals(offerSource)) {
/* 149 */                 boolean isValid = isValidAemOffer(offerJson, aemOfferJson);
/*     */                 
/* 151 */                 logger.debug("isValid ::" + isValid);
/* 152 */                 if (!isValid) {
/* 153 */                   logger.debug("aem landing json update:: remove offer from landing json  ");
/* 154 */                   if (updatedCatJson.has(offerId)) {
/* 155 */                     updatedCatJson.remove(offerId);
/* 156 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/*     */                   }
/*     */                   
/* 159 */                   logger.debug("remove offer from aem src ");
/*     */                   
/* 161 */                   if (aemOfferJson.has(offerId)) {
/* 162 */                     logger.debug("removed offer from aem src ");
/* 163 */                     updatedAemOfferJson.remove(offerId);
/*     */                   }
/*     */                   
/* 166 */                   updateNode(jsonObjKey, offerId);
/* 167 */                   logger.debug("node updated");
/*     */                 }
/*     */               }
/* 170 */               if ("VMORC".equals(offerSource)) {
/* 171 */                 logger.debug("inside vmorc validation");
/* 172 */                 if (vmorcOfferJson.has(offerId)) {
/* 173 */                   logger.debug("inside landing VMORC offer:: ");
/*     */                   
/*     */ 
/* 176 */                   JSONObject formatVmorcOffer = VppJsonUtil.getCurrOfferData(vmorcOfferJson, offerId);
/* 177 */                   boolean isModified = VppJsonUtil.areEqual(offerJson, formatVmorcOffer);
/* 178 */                   logger.debug("isModified ::" + isModified);
/* 179 */                   if (!isModified) {
/* 180 */                     VppUtil.updateCurrentCategoryPage(jsonObjKey, offerId, formatVmorcOffer, session);
/*     */                     
/* 182 */                     logger.debug("before vmorc updatedCatJson");
/* 183 */                     updatedCatJson.put(offerId, formatVmorcOffer);
/* 184 */                     logger.debug("after vmorc updatedCatJson");
/*     */                     
/* 186 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/*     */                   }
/*     */                 }
/*     */                 else
/*     */                 {
/* 191 */                   logger.debug("vmorc landing update before ");
/* 192 */                   if (updatedCatJson.has(offerId)) {
/* 193 */                     updatedCatJson.remove(offerId);
/* 194 */                     updatedLandingPageJson.put(jsonObjKey, updatedCatJson);
/* 195 */                     logger.debug("vmorc landing update after ");
/* 196 */                     updateNode(jsonObjKey, offerId);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 205 */             logger.debug("isModifiedCatPage ::" + isModifiedCatPage(jsonObjKey));
/* 206 */             if (!isModifiedCatPage(jsonObjKey)) {
/* 207 */               logger.debug("is not modified page and publish page::");
/* 208 */               VppUtil.replicateResource(session, jsonObjKey, this.replicator);
/*     */             }
/*     */           }
/*     */           
/* 212 */           logger.debug("update final landingpage json langpath:: " + languagePath + " name" + name);
/* 213 */           VppJsonUtil.createUpdateJsonFile(languagePath, name, session, updatedLandingPageJson);
/* 214 */           VppUtil.replicateResource(session, "/" + languagePath + "/" + name, this.replicator);
/*     */         }
/* 216 */         if (isFolder) {
/* 217 */           logger.debug("inside landing folder::  " + languagePath + "/" + name);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 223 */           ArrayList<String> catFiles = getChildNodes(languagePath + "/" + name);
/* 224 */           if ((null != catFiles) && (catFiles.size() > 0)) {
/* 225 */             Iterator<String> catIteratorObj = catFiles.iterator();
/* 226 */             while (catIteratorObj.hasNext()) {
/* 227 */               String catFileName = (String)catIteratorObj.next();
/* 228 */               logger.debug("cat file name :: " + catFileName);
/*     */               
/* 230 */               JSONObject catJsonSrc = VppJsonUtil.getOfferJson(session, languagePath + "/" + name, catFileName);
/* 231 */               JSONObject updatedCatJsonSrc = new JSONObject(catJsonSrc.toString());
/*     */               
/* 233 */               Iterator<String> catJsonIterator = catJsonSrc.keys();
/* 234 */               while (catJsonIterator.hasNext()) {
/* 235 */                 String catJson = (String)catJsonIterator.next();
/* 236 */                 logger.debug("catJson ::" + catJson);
/* 237 */                 JSONObject catOfferJson = catJsonSrc.getJSONObject(catJson);
/* 238 */                 JSONObject catOfferJsonSrc = new JSONObject(catOfferJson.toString());
/* 239 */                 Iterator<String> catOfferIter = catOfferJson.keys();
/* 240 */                 while (catOfferIter.hasNext())
/*     */                 {
/* 242 */                   String catOffer = (String)catOfferIter.next();
/* 243 */                   logger.debug("catOffer :: " + catOffer);
/* 244 */                   JSONObject catOfferJsonObj = catOfferJson.getJSONObject(catOffer);
/* 245 */                   logger.debug("catOfferJsonObj :: " + catOfferJsonObj.toString());
/*     */                   
/* 247 */                   String catOfferSource = catOfferJsonObj.get("offerSource").toString();
/* 248 */                   logger.debug("catoffersource :: " + catOfferJsonObj
/* 249 */                     .get("offerSource"));
/* 250 */                   logger.debug("catofferId :: " + catOfferJsonObj.get("offerId"));
/* 251 */                   String offerId = catOfferJsonObj.get("offerId").toString();
/* 252 */                   if ("AEM".equals(catOfferSource)) {
/* 253 */                     boolean isValid = isValidAemOffer(catOfferJsonObj, aemOfferJson);
/*     */                     
/* 255 */                     if (!isValid) {
/* 256 */                       logger.debug("updatedCatJsonSrc update before ");
/* 257 */                       catOfferJsonSrc.remove(offerId);
/* 258 */                       updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/* 259 */                       logger.debug("updatedCatJsonSrc after remove");
/* 260 */                       logger.debug("aem json before removal");
/* 261 */                       if (aemOfferJson.has(offerId)) {
/* 262 */                         updatedAemOfferJson.remove(offerId);
/*     */                       }
/* 264 */                       logger.debug("aem json after removal");
/* 265 */                       updateNode(catJson, offerId);
/*     */                     }
/*     */                   }
/*     */                   
/* 269 */                   if ("VMORC".equals(catOfferSource)) {
/* 270 */                     if (vmorcOfferJson.has(offerId)) {
/* 271 */                       logger.debug("inside landing VMORC offer:: ");
/*     */                       
/* 273 */                       JSONObject formatVmorcOffer = VppJsonUtil.getCurrOfferData(vmorcOfferJson, offerId);
/* 274 */                       boolean isModified = VppJsonUtil.areEqual(formatVmorcOffer, catOfferJsonObj);
/* 275 */                       logger.debug("isModified ::" + isModified);
/* 276 */                       if (!isModified) {
/* 277 */                         VppUtil.updateCurrentCategoryPage(catJson, offerId, formatVmorcOffer, session);
/*     */                         
/* 279 */                         logger.debug("before vmorc updatedCatJson");
/* 280 */                         catOfferJsonSrc.put(offerId, formatVmorcOffer);
/* 281 */                         updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/*     */                         
/* 283 */                         logger.debug("after vmorc updatedCatJson");
/*     */                       }
/*     */                     }
/*     */                     else
/*     */                     {
/* 288 */                       logger.debug("is file vmorc:: remove vmorc from cat json file ");
/* 289 */                       if (catOfferJson.has(offerId)) {
/* 290 */                         catOfferJsonSrc.remove(offerId);
/* 291 */                         updatedCatJsonSrc.put(catJson, catOfferJsonSrc);
/* 292 */                         logger.debug("updatedCatJsonSrc in loop::" + updatedCatJsonSrc.toString());
/* 293 */                         updateNode(catJson, offerId);
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/* 301 */               logger.debug("updatedCatJsonS final::" + updatedCatJsonSrc.toString());
/* 302 */               logger.debug("update category file json :: " + languagePath + "/" + name + "/" + catFileName);
/*     */               
/* 304 */               VppJsonUtil.createUpdateJsonFile(languagePath + "/" + name, catFileName, session, updatedCatJsonSrc);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 312 */         VppJsonUtil.createUpdateJsonFile(languagePath, "aem_offers.json", session, updatedAemOfferJson);
/*     */         
/* 314 */         logger.debug("=======================end  json file process===============");
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 318 */       logger.error("JSONException in validating offer :: " + e);
/*     */     } catch (Exception e) {
/* 320 */       logger.error("Exception in File process" + e);
/*     */     } finally {
/* 322 */       if (resolver != null) {
/* 323 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getChildNodes(String path)
/*     */   {
/* 338 */     ResourceResolver resolver = null;
/* 339 */     Session session = null;
/* 340 */     ArrayList<String> childNames = new ArrayList();
/* 341 */     String type = null;
/*     */     try
/*     */     {
/* 344 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 345 */       session = (Session)resolver.adaptTo(Session.class);
/* 346 */       Node rootNode = session.getRootNode();
/* 347 */       if (rootNode.hasNode(path)) {
/* 348 */         Node parentNode = rootNode.getNode(path);
/* 349 */         NodeIterator nodes = parentNode.getNodes();
/* 350 */         while (nodes.hasNext()) {
/* 351 */           Node node = nodes.nextNode();
/* 352 */           type = node.getProperty("jcr:primaryType").getString();
/* 353 */           if ((type.equals("nt:file")) || 
/* 354 */             (type.equals("nt:folder"))) {
/* 355 */             childNames.add(node.getName());
/*     */           }
/*     */         }
/*     */       }
/* 359 */       if (childNames.size() == 0) {
/* 360 */         childNames = null;
/*     */       }
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 364 */       logger.error("Path Not Found Exception Occured  :" + e);
/*     */     } catch (RepositoryException e) {
/* 366 */       logger.error("node creation exception" + e);
/*     */     } finally {
/* 368 */       if (resolver != null) {
/* 369 */         resolver.close();
/*     */       }
/*     */     }
/* 372 */     return childNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getJsonObject(String filePath, String fileName)
/*     */   {
/* 384 */     ResourceResolver resolver = null;
/* 385 */     Session session = null;
/* 386 */     JSONObject offerJson = null;
/*     */     try
/*     */     {
/* 389 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 390 */       session = (Session)resolver.adaptTo(Session.class);
/* 391 */       offerJson = VppJsonUtil.getOfferJson(session, filePath, fileName);
/*     */     }
/*     */     catch (Exception e) {
/* 394 */       logger.error("exception" + e);
/*     */     } finally {
/* 396 */       if (resolver != null)
/*     */       {
/* 398 */         resolver.close();
/*     */       }
/*     */     }
/* 401 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFile(String filePath)
/*     */   {
/* 412 */     ResourceResolver resolver = null;
/* 413 */     Session session = null;
/* 414 */     Node node = null;
/* 415 */     boolean isFile = false;
/*     */     try
/*     */     {
/* 418 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 419 */       session = (Session)resolver.adaptTo(Session.class);
/* 420 */       Node rootNode = session.getRootNode();
/* 421 */       if (rootNode.hasNode(filePath)) {
/* 422 */         node = rootNode.getNode(filePath);
/* 423 */         String type = node.getProperty("jcr:primaryType").getString();
/*     */         
/* 425 */         if (type.equals("nt:file")) {
/* 426 */           isFile = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 431 */       logger.error("exception" + e);
/*     */     } finally {
/* 433 */       if (resolver != null)
/*     */       {
/* 435 */         resolver.close();
/*     */       }
/*     */     }
/* 438 */     return isFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFolder(String filePath)
/*     */   {
/* 449 */     ResourceResolver resolver = null;
/* 450 */     Session session = null;
/* 451 */     Node node = null;
/* 452 */     boolean isFolder = false;
/*     */     try
/*     */     {
/* 455 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 456 */       session = (Session)resolver.adaptTo(Session.class);
/* 457 */       Node rootNode = session.getRootNode();
/* 458 */       if (rootNode.hasNode(filePath)) {
/* 459 */         node = rootNode.getNode(filePath);
/* 460 */         String type = node.getProperty("jcr:primaryType").getString();
/* 461 */         if (type.equals("nt:folder")) {
/* 462 */           isFolder = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 467 */       logger.error("exception" + e);
/*     */     } finally {
/* 469 */       if (resolver != null)
/*     */       {
/* 471 */         resolver.close();
/*     */       }
/*     */     }
/* 474 */     return isFolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isValidAemOffer(JSONObject aemOfferJson, JSONObject aemJsonSource)
/*     */   {
/* 485 */     boolean isValid = false;
/*     */     
/* 487 */     if (null != aemOfferJson) {
/*     */       try {
/* 489 */         String offerId = aemOfferJson.get("offerId").toString();
/*     */         
/* 491 */         if (aemJsonSource.has(offerId)) {
/* 492 */           JSONObject srcAemOffer = aemJsonSource.getJSONObject(offerId);
/* 493 */           logger.debug("srcAemOffer :: " + srcAemOffer.toString());
/* 494 */           String promoEndDate = srcAemOffer.get("promoEndDate").toString();
/*     */           
/* 496 */           String promoStartDate = srcAemOffer.get("promoStartDate").toString();
/*     */           
/* 498 */           isValid = VppJsonUtil.checkPromotionDateValidity(promoStartDate, promoEndDate);
/*     */           
/* 500 */           logger.debug("isValidAemOffer isValid:: " + isValid);
/*     */         }
/*     */       }
/*     */       catch (JSONException e) {
/* 504 */         logger.error("JSON Exception " + e);
/*     */       }
/*     */     }
/* 507 */     return isValid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateNode(String path, String offerid)
/*     */   {
/* 520 */     logger.debug("initialize updateNode1" + path);
/* 521 */     ResourceResolver resolver = null;
/* 522 */     Session session = null;
/* 523 */     Node node = null;
/*     */     try {
/* 525 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 526 */       session = (Session)resolver.adaptTo(Session.class);
/*     */       
/* 528 */       node = VppUtil.getCatgoryOfferNode(session, path, offerid);
/*     */       
/* 530 */       if (null != node) {
/* 531 */         logger.debug("node path ===========>>>" + node.getPath());
/* 532 */         node.remove();
/* 533 */         session.save();
/*     */       }
/*     */     } catch (Exception e) {
/* 536 */       logger.error("repository exception " + e);
/*     */     } finally {
/* 538 */       if (resolver != null)
/*     */       {
/* 540 */         resolver.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isModifiedCatPage(String path)
/*     */   {
/* 554 */     logger.debug("initialize isModifiedCatPage");
/* 555 */     ResourceResolver resolver = null;
/* 556 */     Session session = null;
/* 557 */     Node jcrNode = null;
/* 558 */     boolean isModified = false;
/*     */     try {
/* 560 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 561 */       session = (Session)resolver.adaptTo(Session.class);
/* 562 */       if (session.nodeExists(path + "/" + "jcr:content")) {
/* 563 */         jcrNode = session.getNode(path + "/" + "jcr:content");
/* 564 */         if (jcrNode.hasProperty("catApprovalStatus"))
/*     */         {
/* 566 */           if (jcrNode.getProperty("catApprovalStatus").getString().equalsIgnoreCase("MODIFIED")) {
/* 567 */             isModified = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 572 */       logger.error("repository exception " + e);
/*     */     } finally {
/* 574 */       if (resolver != null)
/*     */       {
/* 576 */         resolver.close();
/*     */       }
/*     */     }
/* 579 */     return isModified;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     this.replicator = paramReplicator;
/*     */   }
/*     */   
/*     */   protected void unbindReplicator(Replicator paramReplicator)
/*     */   {
/*     */     if (this.replicator == paramReplicator) {
/*     */       this.replicator = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     this.settingsService = paramSlingSettingsService;
/*     */   }
/*     */   
/*     */   protected void unbindSettingsService(SlingSettingsService paramSlingSettingsService)
/*     */   {
/*     */     if (this.settingsService == paramSlingSettingsService) {
/*     */       this.settingsService = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\scheduler\PremiumCategoryPageScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */