/*      */ package com.visa.vpp.premium.scheduler;
/*      */ 
/*      */ import com.day.cq.commons.jcr.JcrUtil;
/*      */ import com.day.cq.replication.Replicator;
/*      */ import com.day.cq.wcm.api.Page;
/*      */ import com.day.cq.wcm.api.PageManager;
/*      */ import com.day.cq.wcm.api.WCMException;
/*      */ import com.google.gson.Gson;
/*      */ import com.google.gson.GsonBuilder;
/*      */ import com.google.gson.JsonArray;
/*      */ import com.google.gson.JsonElement;
/*      */ import com.google.gson.JsonObject;
/*      */ import com.google.gson.JsonParser;
/*      */ import com.visa.vpp.premium.pojo.CardPaymentTypeList;
/*      */ import com.visa.vpp.premium.pojo.CardProductList;
/*      */ import com.visa.vpp.premium.pojo.CategorySubcategoryList;
/*      */ import com.visa.vpp.premium.pojo.ImageList;
/*      */ import com.visa.vpp.premium.pojo.MerchantImage;
/*      */ import com.visa.vpp.premium.pojo.MerchantList;
/*      */ import com.visa.vpp.premium.pojo.VmorcJson;
/*      */ import com.visa.vpp.premium.utill.VppUtil;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.InputStreamReader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.jcr.Node;
/*      */ import javax.jcr.PathNotFoundException;
/*      */ import javax.jcr.Property;
/*      */ import javax.jcr.RepositoryException;
/*      */ import javax.jcr.Session;
/*      */ import javax.jcr.Value;
/*      */ import org.apache.felix.scr.annotations.Component;
/*      */ import org.apache.felix.scr.annotations.Properties;
/*      */ import org.apache.felix.scr.annotations.Reference;
/*      */ import org.apache.felix.scr.annotations.Service;
/*      */ import org.apache.http.HttpEntity;
/*      */ import org.apache.http.NameValuePair;
/*      */ import org.apache.http.StatusLine;
/*      */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*      */ import org.apache.http.client.methods.CloseableHttpResponse;
/*      */ import org.apache.http.client.methods.HttpGet;
/*      */ import org.apache.http.client.methods.HttpPost;
/*      */ import org.apache.http.impl.client.CloseableHttpClient;
/*      */ import org.apache.http.impl.client.HttpClientBuilder;
/*      */ import org.apache.http.message.BasicNameValuePair;
/*      */ import org.apache.sling.api.resource.Resource;
/*      */ import org.apache.sling.api.resource.ResourceResolver;
/*      */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*      */ import org.apache.sling.commons.json.JSONArray;
/*      */ import org.apache.sling.commons.json.JSONException;
/*      */ import org.apache.sling.commons.json.JSONObject;
/*      */ import org.apache.sling.commons.osgi.PropertiesUtil;
/*      */ import org.apache.sling.settings.SlingSettingsService;
/*      */ import org.osgi.service.component.ComponentContext;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Component(metatype=true, label="VMORC Premium scheduler", description="Premium VMORC scheduler to get offer/events/benefits")
/*      */ @Service({Runnable.class})
/*      */ @Properties({@org.apache.felix.scr.annotations.Property(name="scheduler.expression", value={"0 0 12 1/1 * ? *"}, description="Cron-job expression"), @org.apache.felix.scr.annotations.Property(name="scheduler.concurrent", boolValue={false}, description="Whether or not to schedule this task concurrently"), @org.apache.felix.scr.annotations.Property(name="scheduler.disable", boolValue={false}, description="enable or disable cron job"), @org.apache.felix.scr.annotations.Property(name="proxy.host", value={"internet.visa.com"}, description="proxy host"), @org.apache.felix.scr.annotations.Property(name="proxy.port", intValue={80}, description="proxy port"), @org.apache.felix.scr.annotations.Property(name="username", value={""}, description="proxy username"), @org.apache.felix.scr.annotations.Property(name="password", value={""}, description="proxy password"), @org.apache.felix.scr.annotations.Property(name="proxy.enabled", boolValue={false}, description="proxy enabled or disabled"), @org.apache.felix.scr.annotations.Property(name="service.url", value={""}, description="web service url to be called"), @org.apache.felix.scr.annotations.Property(name="token.generation.url", value={"https://qa.vpp.tacpoint.net/vpp_api_service/oauth/token.do"}, description="token generation url"), @org.apache.felix.scr.annotations.Property(name="grant.type", value={"client_credentials"}, description="grant type for token generation"), @org.apache.felix.scr.annotations.Property(name="client.id", value={"AEMclient"}, description="client id to be passed"), @org.apache.felix.scr.annotations.Property(name="client.secret", value={"1X10i4567479mM109S91tSL9N6G4y84J"}, description="client secrete key")})
/*      */ public class PremiumVmorcScheduler
/*      */   implements Runnable
/*      */ {
/*  108 */   private static final Logger logger = LoggerFactory.getLogger(PremiumVmorcScheduler.class);
/*      */   
/*      */   private static String PROXY_HOST;
/*      */   
/*      */   private static int PROXY_PORT;
/*      */   
/*      */   private static String USERNAME;
/*      */   
/*      */   private static boolean PROXY_ENABLED;
/*      */   
/*      */   private static boolean SCHEDULER_DISABLED;
/*      */   
/*      */   private static String SERVICE_URL;
/*      */   
/*      */   private static String GRANT_TYPE;
/*      */   
/*      */   private static String CLIENT_ID;
/*      */   
/*      */   private static String CLIENT_SECRET_KEY;
/*      */   
/*      */   private static String TOKEN_GENERATION_URL;
/*      */   
/*      */   private static final String PROGRAM_LIST_MAP = "programInfo";
/*      */   
/*      */   private static final String PREMIUM_PAGE_PATH = "/content/vpp/premium";
/*      */   
/*      */   private static final String PROXY_HOST_PROPERTY = "proxy.host";
/*      */   private static final String PROXY_HOST_DEFAULT = "internet.visa.com";
/*      */   private static final String PROXY_PORT_PROPERTY = "proxy.port";
/*      */   private static final int PROXY_PORT_DEFAULT = 80;
/*      */   private static final String USERNAME_PROPERTY = "username";
/*      */   private static final String PASSWORD_PROPERTY = "password";
/*      */   private static final String PROXY_ENABLED_PROPERTY = "proxy.enabled";
/*      */   private static final String SCHEDULER_DISABLED_PROPERTY = "scheduler.disable";
/*      */   private static final String SERVICE_URL_PROPERTY = "service.url";
/*      */   private static final String SERVICE_URL_DEFAULT = "https://qa.vpp.tacpoint.net/vpp_api_service/v1";
/*  144 */   private static String TOKEN_GENERATION_URL_DEFAULT = "https://qa.vpp.tacpoint.net/vpp_api_service/oauth/token.do";
/*      */   
/*  146 */   private static String CLIENT_SECRET_KEY_DEFAULT = "1X10i4567479mM109S91tSL9N6G4y84J";
/*  147 */   private static String CLIENT_ID_DEFAULT = "AEMclient";
/*  148 */   private static String GRANT_TYPE_DEFAULT = "client_credentials";
/*      */   
/*      */   private static final String RESPONSE = "response";
/*      */   private static final String PROGRAM_ID = "programId";
/*      */   private static final String VMORC_PROGRAM_NODE = "VMORC_Offer_Program_List/jcr:content/vmorcProgramList";
/*      */   private static final String AUTHORIZATION = "Authorization";
/*      */   private static final String BEARER = "Bearer";
/*  155 */   private static String GRANT_TYPE_PROPERTY = "grant.type";
/*  156 */   private static String CLIENT_ID_PROPERTY = "client.id";
/*      */   
/*  158 */   private static String CLIENT_SECRET_KEY_PROPERTY = "client.secret";
/*      */   
/*  160 */   private static String TOKEN_GENERATION_URL_PROPERTY = "token.generation.url";
/*      */   
/*  162 */   private static String PIXEL = " px";
/*      */   
/*      */ 
/*      */ 
/*      */   @Reference
/*      */   private ResourceResolverFactory resolverFactory;
/*      */   
/*      */ 
/*      */ 
/*      */   @Reference
/*      */   private SlingSettingsService settingsService;
/*      */   
/*      */ 
/*      */ 
/*      */   @Reference
/*      */   private Replicator replicator;
/*      */   
/*      */ 
/*      */ 
/*      */   protected void activate(ComponentContext context)
/*      */   {
/*  183 */     Dictionary<String, ?> props = context.getProperties();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  188 */     SERVICE_URL = PropertiesUtil.toString(props.get("service.url"), "https://qa.vpp.tacpoint.net/vpp_api_service/v1");
/*  189 */     GRANT_TYPE = PropertiesUtil.toString(props.get(GRANT_TYPE_PROPERTY), GRANT_TYPE_DEFAULT);
/*  190 */     CLIENT_ID = PropertiesUtil.toString(props.get(CLIENT_ID_PROPERTY), CLIENT_ID_DEFAULT);
/*      */     
/*  192 */     CLIENT_SECRET_KEY = PropertiesUtil.toString(props.get(CLIENT_SECRET_KEY_PROPERTY), CLIENT_SECRET_KEY_DEFAULT);
/*  193 */     TOKEN_GENERATION_URL = PropertiesUtil.toString(props.get(TOKEN_GENERATION_URL_PROPERTY), TOKEN_GENERATION_URL_DEFAULT);
/*      */     
/*  195 */     SCHEDULER_DISABLED = PropertiesUtil.toBoolean(props.get("scheduler.disable"), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void run()
/*      */   {
/*  204 */     logger.debug(" Premium VMORCScheduler is now running");
/*  205 */     logger.debug("SERVICE_URL " + SERVICE_URL);
/*  206 */     logger.debug("SCHEDULER_DISABLED " + SCHEDULER_DISABLED);
/*      */     
/*  208 */     List<VmorcJson> vmorcList = null;
/*  209 */     boolean isAuthor = VppUtil.isAuthorMode(this.settingsService);
/*  210 */     if ((isAuthor) && (!SCHEDULER_DISABLED)) {
/*  211 */       List<String> issuerList = getChildPage("/content/vpp/premium");
/*  212 */       Iterator<String> itIssuer = issuerList.iterator();
/*  213 */       while (itIssuer.hasNext()) {
/*  214 */         String issuer = (String)itIssuer.next();
/*  215 */         String issuerName = issuer.replaceAll("/content/vpp/premium", "");
/*  216 */         logger.debug("issuerName name:: " + issuerName);
/*  217 */         logger.debug("issuer :: " + issuer);
/*      */         
/*  219 */         List<String> languageList = getChildPage("/content/vpp/premium/" + issuerName);
/*  220 */         Iterator<String> itLanguage = languageList.iterator();
/*  221 */         while (itLanguage.hasNext()) {
/*  222 */           String languageName = (String)itLanguage.next();
/*  223 */           logger.debug("languageName :: " + languageName);
/*  224 */           String programIds = getProgramIds(languageName);
/*  225 */           if (!"".equals(programIds)) {
/*  226 */             vmorcList = getVmorcList(issuerName, programIds);
/*  227 */             if (vmorcList != null) {
/*      */               try {
/*  229 */                 createOfferNode(vmorcList, languageName);
/*      */               }
/*      */               catch (JSONException e) {
/*  232 */                 logger.error("error parsing json" + e);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<VmorcJson> getVmorcList(String issuerCardType, String programIds)
/*      */   {
/*  252 */     logger.debug("inside getVMORCList  :: ");
/*      */     
/*  254 */     CloseableHttpClient client = null;
/*  255 */     CloseableHttpResponse response = null;
/*  256 */     List<VmorcJson> offerList = null;
/*      */     
/*  258 */     StringBuffer offerJson = new StringBuffer("");
/*  259 */     BufferedReader br = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  271 */       client = HttpClientBuilder.create().build();
/*      */       
/*  273 */       logger.debug("URL :: " + new StringBuffer(SERVICE_URL).append(issuerCardType)
/*  274 */         .append("/allproduct/offers/offers.do?programList=").append(programIds).toString());
/*  275 */       HttpGet getRequest = new HttpGet(SERVICE_URL + issuerCardType + "/allproduct/offers/offers.do?programList=" + programIds);
/*      */       
/*      */ 
/*  278 */       String token = getAccessToken();
/*  279 */       logger.debug("Retrived token :: " + token);
/*      */       
/*  281 */       getRequest.setHeader("Authorization", "Bearer " + token);
/*  282 */       response = client.execute(getRequest);
/*      */       
/*  284 */       if (response.getStatusLine().getStatusCode() != 200) {
/*  285 */         logger.error("Failed : HTTP error code :  :: " + response.getStatusLine().getStatusCode());
/*      */         
/*  287 */         throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
/*      */       }
/*  289 */       br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF8"));
/*  290 */       String output; while ((output = br.readLine()) != null) {
/*  291 */         offerJson = offerJson.append(output);
/*      */       }
/*  293 */       logger.debug("Offer offerJson :: " + offerJson.toString());
/*  294 */       JsonParser jsonParser; Gson gson; if ((!offerJson.toString().equals("")) && (offerJson.indexOf("200") != -1)) {
/*  295 */         jsonParser = new JsonParser();
/*  296 */         JsonObject responseObject = jsonParser.parse(offerJson.toString()).getAsJsonObject();
/*  297 */         JsonArray offerArray = responseObject.get("response").getAsJsonArray();
/*  298 */         gson = new GsonBuilder().setPrettyPrinting().create();
/*  299 */         offerList = new ArrayList();
/*  300 */         for (JsonElement offer : offerArray) {
/*  301 */           VmorcJson vmorcoffer = (VmorcJson)gson.fromJson(offer, VmorcJson.class);
/*  302 */           offerList.add(vmorcoffer);
/*      */         }
/*      */       }
/*  305 */       return offerList;
/*      */     } catch (RuntimeException e) {
/*  307 */       throw e;
/*      */     }
/*      */     catch (Exception e) {
/*  310 */       logger.error("Exception while parsing JSON :: " + e);
/*      */     } finally {
/*  312 */       if (br != null) {
/*      */         try {
/*  314 */           br.close();
/*      */         } catch (Exception e) {
/*  316 */           logger.error("Exception while closing reader :: " + e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  321 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> getChildPage(String path)
/*      */   {
/*  332 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  333 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/*  334 */     Page rootPage = pageManager.getPage(path);
/*  335 */     List<String> pageList = new ArrayList();
/*  336 */     if (null != rootPage) {
/*  337 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/*  338 */       while (rootPageIterator.hasNext()) {
/*  339 */         Page childPage = (Page)rootPageIterator.next();
/*  340 */         String childPath = childPage.getPath();
/*  341 */         pageList.add(childPath);
/*      */       }
/*  343 */       return pageList;
/*      */     }
/*  345 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void createOfferNode(List<VmorcJson> vmorcList, String offerPath)
/*      */     throws JSONException
/*      */   {
/*  355 */     logger.debug("inside createOfferNode ::");
/*  356 */     Session session = null;
/*  357 */     Page vmorcListPage = null;
/*  358 */     ArrayList<String> cardPayList = null;
/*  359 */     ArrayList<String> categoryList = null;
/*  360 */     ArrayList<String> cardProductList = null;
/*  361 */     ImageList heroImage = null;
/*  362 */     ImageList thumbImage = null;
/*  363 */     MerchantImage merchantLogoImage = null;
/*      */     
/*  365 */     String defaultHeroImgPath = "failure";
/*  366 */     String defaultLogoImgPath = "failure";
/*  367 */     String defaultThumbImgPath = "failure";
/*  368 */     String heroSize = null;
/*  369 */     String thumbSize = null;
/*  370 */     String logoSize = null;
/*  371 */     String heroSizeHeight = null;
/*  372 */     String thumbSizeHeight = null;
/*  373 */     String logoSizeHeight = null;
/*  374 */     ResourceResolver resolver = null;
/*  375 */     PageManager pageManager = null;
/*  376 */     JSONObject vmorcJson = new JSONObject();
/*      */     try
/*      */     {
/*  379 */       HashMap<String, String> imageMap = getImageDimension(offerPath);
/*  380 */       if ((imageMap != null) && (imageMap.size() > 0)) {
/*  381 */         defaultHeroImgPath = (String)imageMap.get("fileReferenceHeroImage");
/*  382 */         defaultLogoImgPath = (String)imageMap.get("fileReferenceLogoImage");
/*  383 */         defaultThumbImgPath = (String)imageMap.get("fileReferenceThumbImage");
/*  384 */         heroSize = (String)imageMap.get("hero_image_size");
/*  385 */         thumbSize = (String)imageMap.get("thumb_image_size");
/*  386 */         logoSize = (String)imageMap.get("logo_image_size");
/*      */       }
/*      */       
/*  389 */       if ((heroSize != null) && (!heroSize.equals(""))) {
/*  390 */         heroSize = heroSize.split("_")[0] + PIXEL;
/*  391 */         heroSizeHeight = ((String)imageMap.get("hero_image_size")).split("_")[1] + PIXEL;
/*      */       }
/*  393 */       if ((thumbSize != null) && (!thumbSize.equals(""))) {
/*  394 */         thumbSize = thumbSize.split("_")[0] + PIXEL;
/*  395 */         thumbSizeHeight = ((String)imageMap.get("thumb_image_size")).split("_")[1] + PIXEL;
/*      */       }
/*  397 */       if ((logoSize != null) && (!logoSize.equals(""))) {
/*  398 */         logoSize = logoSize.split("_")[0] + PIXEL;
/*  399 */         logoSizeHeight = ((String)imageMap.get("logo_image_size")).split("_")[1] + PIXEL;
/*      */       }
/*  401 */       logger.debug("defaultHeroImgPath " + defaultHeroImgPath);
/*  402 */       logger.debug("defaultLogoImgPath " + defaultLogoImgPath);
/*  403 */       logger.debug("defaultThumbImgPath " + defaultThumbImgPath);
/*  404 */       logger.debug("heroSize " + heroSize + " X " + heroSizeHeight);
/*  405 */       logger.debug("thumbSize " + thumbSize + " X " + thumbSizeHeight);
/*  406 */       logger.debug("logoSize " + logoSize + " X " + logoSizeHeight);
/*      */       
/*  408 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  409 */       session = (Session)resolver.adaptTo(Session.class);
/*  410 */       pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/*      */       
/*  412 */       if (session.nodeExists(offerPath + "/" + "VMORC_OFFER_LIST")) {
/*  413 */         logger.debug(" offerListNode is   present");
/*      */         
/*  415 */         Node existingNodeList = session.getNode(offerPath + "/" + "VMORC_OFFER_LIST");
/*  416 */         existingNodeList.remove();
/*  417 */         session.save();
/*  418 */         logger.debug(" offerListNode is   deleted");
/*  419 */         vmorcListPage = pageManager.create(offerPath, "VMORC_OFFER_LIST", "/apps/vpp_premium/components/pages/blank_page", "VMORC_OFFER_LIST", true);
/*      */         
/*  421 */         logger.debug(" offerListNode is newly created after  deleted");
/*      */       } else {
/*  423 */         logger.debug(" offerListNode not exists? :: ");
/*  424 */         logger.debug(" vmorcListPage new page created");
/*  425 */         vmorcListPage = pageManager.create(offerPath, "VMORC_OFFER_LIST", "/apps/vpp_premium/components/pages/blank_page", "VMORC_OFFER_LIST", true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  430 */       Iterator<VmorcJson> it = vmorcList.iterator();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  439 */       while (it.hasNext()) {
/*  440 */         VmorcJson vm = (VmorcJson)it.next();
/*      */         
/*      */ 
/*  443 */         JSONObject aemJson = new JSONObject();
/*  444 */         if (vmorcListPage != null) {
/*  445 */           Node vmorcListNode = session.getNode(offerPath + "/" + "VMORC_OFFER_LIST");
/*  446 */           Node pageNode = JcrUtil.createUniqueNode(vmorcListNode, vm.getOfferId(), "cq:Page", session);
/*      */           
/*      */ 
/*  449 */           Node contentNode = JcrUtil.createUniqueNode(pageNode, "jcr:content", "cq:PageContent", session);
/*      */           
/*      */ 
/*  452 */           JcrUtil.setProperty(contentNode, "sling:resourceType", "vpp_premium/components/pages/offer_page");
/*      */           
/*  454 */           JcrUtil.setProperty(contentNode, "cq:template", "/apps/vpp_premium/templates/offer_creation");
/*      */           
/*      */ 
/*  457 */           Node componentNode = JcrUtil.createUniqueNode(contentNode, "offer_creation", "nt:unstructured", session);
/*      */           
/*  459 */           JcrUtil.setProperty(componentNode, "sling:resourceType", "vpp_premium/components/content/offer_page_creation");
/*      */           
/*      */ 
/*  462 */           if (vm.getIsOfferEvent() == "true") {
/*  463 */             JcrUtil.setProperty(contentNode, "pageType", "event");
/*      */           }
/*      */           else {
/*  466 */             JcrUtil.setProperty(contentNode, "pageType", "offer");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  471 */           aemJson.put("offerSource", "VMORC");
/*  472 */           JcrUtil.setProperty(contentNode, "jcr:title", vm.getOfferTitle());
/*  473 */           JcrUtil.setProperty(componentNode, "offerTitle", vm.getOfferTitle());
/*      */           
/*  475 */           aemJson.put("offerTitle", vm.getOfferTitle());
/*  476 */           JcrUtil.setProperty(contentNode, "offerId", vm.getOfferId());
/*      */           
/*  478 */           aemJson.put("offerId", vm.getOfferId());
/*      */           
/*  480 */           aemJson.put("previewURL", pageNode
/*  481 */             .getPath() + ".html" + "?wcmmode=disabled");
/*  482 */           JcrUtil.setProperty(componentNode, "offerShortDesc", vm
/*  483 */             .getOfferShortDescription().get("text"));
/*      */           
/*  485 */           aemJson.put("offerShortDesc", vm
/*  486 */             .getOfferShortDescription().get("text"));
/*  487 */           JcrUtil.setProperty(componentNode, "benefitTypeCode", " ");
/*  488 */           JcrUtil.setProperty(componentNode, "offerCopy", vm
/*  489 */             .getOfferCopy().get("richText"));
/*  490 */           String merchantName = ((MerchantList)vm.getMerchantList().get(0)).getMerchant();
/*      */           
/*  492 */           Iterator<ImageList> imageListIterator = vm.getImageList().iterator();
/*      */           
/*  494 */           while (imageListIterator.hasNext()) {
/*  495 */             ImageList imageObj = (ImageList)imageListIterator.next();
/*      */             
/*  497 */             if ((imageObj.getImageFileWidth().equals(heroSize)) && 
/*  498 */               (imageObj.getImageFileHeight().equals(heroSizeHeight))) {
/*  499 */               heroImage = imageObj;
/*  500 */               break;
/*      */             }
/*      */           }
/*  503 */           if (null != heroImage) {
/*  504 */             JcrUtil.setProperty(componentNode, "heroImage", heroImage
/*  505 */               .getFileLocation());
/*  506 */             aemJson.put("heroImage", heroImage.getFileLocation());
/*  507 */             JcrUtil.setProperty(componentNode, "validHeroImg", "VALID");
/*      */             
/*  509 */             if (!merchantName.equals("")) {
/*  510 */               JcrUtil.setProperty(componentNode, "heroImageAltText", merchantName);
/*      */             }
/*      */             else {
/*  513 */               JcrUtil.setProperty(componentNode, "heroImageAltText", vm
/*  514 */                 .getOfferTitle());
/*      */             }
/*  516 */             heroImage = null;
/*      */           }
/*      */           else {
/*  519 */             JcrUtil.setProperty(componentNode, "heroImage", defaultHeroImgPath);
/*      */             
/*  521 */             aemJson.put("heroImage", defaultHeroImgPath);
/*  522 */             JcrUtil.setProperty(componentNode, "validHeroImg", defaultHeroImgPath);
/*      */           }
/*      */           
/*  525 */           Iterator<ImageList> imageListIterator1 = vm.getImageList().iterator();
/*      */           
/*  527 */           while (imageListIterator1.hasNext()) {
/*  528 */             ImageList imageObj = (ImageList)imageListIterator1.next();
/*  529 */             logger.debug("thumbSize:" + thumbSize + "thumbImage width" + imageObj
/*  530 */               .getImageFileWidth());
/*  531 */             logger.debug("thumbSizeHeight:" + thumbSize + "thumbImage height" + imageObj
/*  532 */               .getImageFileHeight());
/*  533 */             if ((imageObj.getImageFileWidth().equals(thumbSize)) && 
/*  534 */               (imageObj.getImageFileHeight().equals(thumbSizeHeight))) {
/*  535 */               thumbImage = imageObj;
/*  536 */               logger.debug("thumbImage " + thumbImage.getFileLocation());
/*  537 */               break;
/*      */             }
/*      */           }
/*      */           
/*  541 */           if (null != thumbImage) {
/*  542 */             JcrUtil.setProperty(componentNode, "thumbImage", thumbImage
/*  543 */               .getFileLocation());
/*  544 */             aemJson.put("thumbImage", thumbImage.getFileLocation());
/*  545 */             if (!merchantName.equals("")) {
/*  546 */               JcrUtil.setProperty(componentNode, "thumbnailImageAltText", merchantName);
/*      */             }
/*      */             else {
/*  549 */               JcrUtil.setProperty(componentNode, "thumbnailImageAltText", vm
/*  550 */                 .getOfferTitle());
/*      */             }
/*  552 */             thumbImage = null;
/*      */           }
/*      */           else {
/*  555 */             JcrUtil.setProperty(componentNode, "thumbImage", defaultThumbImgPath);
/*      */             
/*  557 */             aemJson.put("thumbImage", defaultThumbImgPath);
/*      */           }
/*      */           
/*  560 */           JcrUtil.setProperty(componentNode, "valStartDate", 
/*  561 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/*  562 */             .getValidityFromDate()));
/*      */           
/*  564 */           JcrUtil.setProperty(componentNode, "valEndDate", 
/*  565 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/*  566 */             .getValidityToDate()));
/*      */           
/*      */ 
/*  569 */           JcrUtil.setProperty(componentNode, "promoStartDate", 
/*  570 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/*  571 */             .getPromotionFromDate()));
/*      */           
/*      */ 
/*  574 */           JcrUtil.setProperty(componentNode, "promoEndDate", 
/*  575 */             VppUtil.convertGmtToDate("MMM dd','yyyy", "yyyy-MM-dd'T'HH:mm:ss", vm
/*  576 */             .getPromotionToDate()));
/*      */           
/*      */ 
/*  579 */           categoryList = new ArrayList();
/*      */           
/*  581 */           Iterator<CategorySubcategoryList> categoryIterator = vm.getCategorySubcategoryList().iterator();
/*  582 */           while (categoryIterator.hasNext()) {
/*  583 */             CategorySubcategoryList rc = (CategorySubcategoryList)categoryIterator.next();
/*  584 */             categoryList.add(rc.getValue());
/*      */           }
/*      */           
/*  587 */           JcrUtil.setProperty(componentNode, "categories", categoryList
/*  588 */             .toArray(new String[0]));
/*  589 */           JSONArray categoryJsonArr = new JSONArray(categoryList);
/*      */           
/*      */ 
/*  592 */           aemJson.put("categories", categoryJsonArr);
/*  593 */           cardProductList = new ArrayList();
/*  594 */           Iterator<CardProductList> cardProductIterator = vm.getCardProductList().iterator();
/*  595 */           while (cardProductIterator.hasNext()) {
/*  596 */             CardProductList rc = (CardProductList)cardProductIterator.next();
/*  597 */             cardProductList.add(rc.getValue());
/*      */           }
/*  599 */           JcrUtil.setProperty(componentNode, "cardProducts", cardProductList
/*  600 */             .toArray(new String[0]));
/*      */           
/*  602 */           JSONArray cardProdJsonArr = new JSONArray(cardProductList);
/*  603 */           aemJson.put("cardProducts", cardProdJsonArr);
/*  604 */           JcrUtil.setProperty(componentNode, "faqs", vm
/*  605 */             .getfAQs().get("richText"));
/*      */           
/*      */ 
/*  608 */           JcrUtil.setProperty(componentNode, "visaTandC", vm
/*  609 */             .getVisaTerms().get("richText"));
/*      */           
/*  611 */           JcrUtil.setProperty(componentNode, "merchantTandC", vm
/*  612 */             .getMerchantTerms().get("richText"));
/*      */           
/*      */ 
/*  615 */           JcrUtil.setProperty(componentNode, "merchantName", 
/*  616 */             ((MerchantList)vm.getMerchantList().get(0)).getMerchant());
/*      */           
/*  618 */           aemJson.put("merchantName", 
/*  619 */             ((MerchantList)vm.getMerchantList().get(0)).getMerchant());
/*      */           
/*  621 */           Iterator<MerchantImage> merchantLogoIterator = ((MerchantList)vm.getMerchantList().get(0)).getMerchantImages().iterator();
/*  622 */           while (merchantLogoIterator.hasNext()) {
/*  623 */             MerchantImage imageObj = (MerchantImage)merchantLogoIterator.next();
/*      */             
/*  625 */             if ((imageObj.getImageFileWidth().equals(logoSize)) && 
/*  626 */               (imageObj.getImageFileHeight().equals(logoSizeHeight))) {
/*  627 */               merchantLogoImage = imageObj;
/*      */             }
/*      */           }
/*  630 */           if (null != merchantLogoImage) {
/*  631 */             JcrUtil.setProperty(componentNode, "merchantLogo", merchantLogoImage
/*  632 */               .getFileLocation());
/*  633 */             JcrUtil.setProperty(componentNode, "validMerchLogoImg", "VALID");
/*      */             
/*      */ 
/*  636 */             if (!merchantName.equals("")) {
/*  637 */               JcrUtil.setProperty(componentNode, "merchantLogoAltText", merchantName);
/*      */             }
/*      */             
/*  640 */             merchantLogoImage = null;
/*      */           }
/*      */           else {
/*  643 */             JcrUtil.setProperty(componentNode, "merchantLogo", defaultLogoImgPath);
/*      */             
/*  645 */             JcrUtil.setProperty(componentNode, "validMerchLogoImg", defaultLogoImgPath);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  650 */           JcrUtil.setProperty(componentNode, "redemptionInst", vm
/*  651 */             .getMerchantTerms().get("richText"));
/*      */           
/*  653 */           JcrUtil.setProperty(componentNode, "redemptionInst", "Redeem");
/*      */           
/*      */ 
/*      */ 
/*  657 */           JcrUtil.setProperty(componentNode, "redemptionEmail", vm
/*  658 */             .getRedemptionEmail());
/*      */           
/*      */ 
/*  661 */           JcrUtil.setProperty(componentNode, "redemptionURL", vm
/*  662 */             .getRedemptionUrl());
/*      */           
/*  664 */           JcrUtil.setProperty(componentNode, "redemptionTel", vm
/*  665 */             .getRedemptionTelephone().get("richText"));
/*      */           
/*  667 */           String lastModifiedDate = "";
/*  668 */           lastModifiedDate = VppUtil.convertGmtToDate("E, dd MMM yyyy HH:mm:ss z", "yyyy-MM-dd'T'HH:mm:ss", vm
/*  669 */             .getLastModifiedDatetime());
/*  670 */           JcrUtil.setProperty(componentNode, "offerLastModified", lastModifiedDate);
/*  671 */           aemJson.put("offerLastModified", lastModifiedDate);
/*  672 */           List<CardPaymentTypeList> cardPaymentList = vm.getCardPaymentTypeList();
/*  673 */           Iterator<CardPaymentTypeList> cardListIterator = cardPaymentList.iterator();
/*  674 */           cardPayList = new ArrayList();
/*  675 */           while (cardListIterator.hasNext()) {
/*  676 */             CardPaymentTypeList cardPaymentType = (CardPaymentTypeList)cardListIterator.next();
/*  677 */             cardPayList.add(cardPaymentType.getValue());
/*      */           }
/*      */           
/*  680 */           JcrUtil.setProperty(componentNode, "cardPayment", cardPayList
/*  681 */             .toArray(new String[0]));
/*      */           
/*  683 */           JSONArray cardPayJsonArr = new JSONArray(cardPayList);
/*  684 */           aemJson.put("cardPayment", cardPayJsonArr);
/*  685 */           session.save();
/*  686 */           vmorcJson.put(vm.getOfferId(), aemJson);
/*      */         }
/*      */         
/*      */ 
/*  690 */         VppUtil.replicateResource(session, offerPath + "/" + "VMORC_OFFER_LIST" + "/" + vm
/*  691 */           .getOfferId(), this.replicator);
/*      */       }
/*      */       
/*      */ 
/*  695 */       createJsonFile(vmorcJson.toString(), offerPath);
/*      */     } catch (RepositoryException e) {
/*  697 */       logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/*      */     } catch (WCMException e) {
/*  699 */       logger.error("[VPPERROR] VMORC CRON FAILED" + e);
/*      */     } finally {
/*  701 */       if (resolver != null) {
/*  702 */         logger.debug("resolver closed ");
/*  703 */         resolver.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProgramIds(String path)
/*      */   {
/*  716 */     logger.debug("####### getProgramIds path ->######### : " + path);
/*  717 */     ArrayList<Map<String, String>> programMapList = null;
/*  718 */     ArrayList<String> programArray = null;
/*  719 */     String programId = "";
/*  720 */     String[] programList = null;
/*  721 */     ResourceResolver resolver = null;
/*  722 */     Session session = null;
/*  723 */     Node progrmNode = null;
/*      */     try
/*      */     {
/*  726 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  727 */       session = (Session)resolver.adaptTo(Session.class);
/*  728 */       if (session.nodeExists(path + "/" + "VMORC_Offer_Program_List/jcr:content/vmorcProgramList")) {
/*  729 */         progrmNode = session.getNode(path + "/" + "VMORC_Offer_Program_List/jcr:content/vmorcProgramList");
/*  730 */         programArray = new ArrayList();
/*  731 */         if (progrmNode.hasProperty("programInfo")) {
/*  732 */           Property currentProp = progrmNode.getProperty("programInfo");
/*  733 */           if (currentProp.isMultiple()) {
/*  734 */             logger.debug(" programinfo is multiple");
/*  735 */             Value[] values = currentProp.getValues();
/*  736 */             for (int i = 0; i < values.length; i++) {
/*  737 */               programArray.add(values[i].getString());
/*      */             }
/*      */           } else {
/*  740 */             logger.debug(" programinfo is single");
/*  741 */             programArray.add(currentProp.getValue().getString());
/*      */           }
/*      */         }
/*      */       }
/*  745 */       if (null != programArray) {
/*  746 */         programList = (String[])programArray.toArray(new String[0]);
/*      */         
/*  748 */         programMapList = (ArrayList)VppUtil.getMultiFieldPanelValuesMap(programList);
/*      */       }
/*      */       
/*  751 */       if (null != programMapList) {
/*  752 */         Iterator<Map<String, String>> programIterator = programMapList.iterator();
/*  753 */         while (programIterator.hasNext()) {
/*  754 */           Map<String, String> programMap = (Map)programIterator.next();
/*  755 */           logger.debug(" program ids ma ::" + (String)programMap.get("programId"));
/*  756 */           if (programId.equals("")) {
/*  757 */             programId = (String)programMap.get("programId");
/*      */           } else {
/*  759 */             programId = programId + "," + (String)programMap.get("programId");
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (RepositoryException e) {
/*  764 */       logger.error("node creation exception" + e);
/*      */     } finally {
/*  766 */       if (resolver != null) {
/*  767 */         logger.debug("resolver closed ");
/*  768 */         resolver.close();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  773 */     return programId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void createJsonFile(String jsonData, String path)
/*      */   {
/*  785 */     String[] payLoadArr = path.split("/");
/*  786 */     StringBuilder sb = new StringBuilder("etc/vpp-premium-tools/offers");
/*  787 */     sb.append("/");
/*  788 */     sb.append(payLoadArr[4]);
/*  789 */     sb.append("/");
/*  790 */     sb.append(payLoadArr[5]);
/*  791 */     String offerJsonLocation = "";
/*  792 */     offerJsonLocation = sb.toString();
/*  793 */     logger.debug("offerJSONLocation:: " + offerJsonLocation);
/*  794 */     ResourceResolver resolver = null;
/*  795 */     Session session = null;
/*      */     
/*      */     try
/*      */     {
/*  799 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  800 */       session = (Session)resolver.adaptTo(Session.class);
/*  801 */       Node rootNode = session.getRootNode();
/*  802 */       if (rootNode.hasNode(offerJsonLocation)) {
/*  803 */         logger.debug("path exists");
/*  804 */         Node folderPathNode = rootNode.getNode(offerJsonLocation);
/*  805 */         Node fileNode = null;
/*  806 */         Node fileJcrNode = null;
/*  807 */         if (folderPathNode.hasNode("vmorc_offers.json")) {
/*  808 */           fileNode = folderPathNode.getNode("vmorc_offers.json");
/*  809 */           fileJcrNode = fileNode.getNode("jcr:content");
/*  810 */           logger.debug("Update Operation :VMORC JSON Updated");
/*      */         } else {
/*  812 */           fileNode = folderPathNode.addNode("vmorc_offers.json", "nt:file");
/*      */           
/*  814 */           fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/*  815 */           logger.debug("Create Operation : VMORC JSON Created");
/*      */         }
/*  817 */         if (fileJcrNode != null) {
/*  818 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/*  819 */           fileJcrNode.setProperty("jcr:data", jsonData);
/*      */         }
/*      */       }
/*      */       else {
/*  823 */         logger.debug("path exists");
/*  824 */         if (rootNode.hasNode("etc/vpp-premium-tools/offers"))
/*      */         {
/*  826 */           Node issuerNode = null;
/*  827 */           Node fileJcrNode = null;
/*  828 */           Node fileNode = null;
/*  829 */           Node folderPathNode = null;
/*  830 */           Node baseFolderNode = rootNode.getNode("etc/vpp-premium-tools/offers");
/*  831 */           String[] offerLocationArr = offerJsonLocation.split("/");
/*  832 */           String issuerString = offerLocationArr[(offerLocationArr.length - 2)];
/*  833 */           String languageString = offerLocationArr[(offerLocationArr.length - 1)];
/*  834 */           logger.debug("issuerString " + issuerString);
/*  835 */           logger.debug("path languageString " + languageString);
/*  836 */           logger.debug("baseFolderNode " + baseFolderNode.getName());
/*      */           
/*  838 */           if (baseFolderNode.hasNode(issuerString)) {
/*  839 */             issuerNode = baseFolderNode.getNode(issuerString);
/*      */           } else {
/*  841 */             issuerNode = baseFolderNode.addNode(issuerString, "nt:folder");
/*      */           }
/*  843 */           if (issuerNode.hasNode(languageString)) {
/*  844 */             folderPathNode = issuerNode.getNode(languageString);
/*      */           } else {
/*  846 */             folderPathNode = issuerNode.addNode(languageString, "nt:folder");
/*      */           }
/*  848 */           if (folderPathNode != null) {
/*  849 */             if (folderPathNode.hasNode("vmorc_offers.json")) {
/*  850 */               fileNode = folderPathNode.getNode("vmorc_offers.json");
/*  851 */               fileJcrNode = fileNode.getNode("jcr:content");
/*  852 */               logger.debug("Update Operation : JSON Updated");
/*      */             } else {
/*  854 */               fileNode = folderPathNode.addNode("vmorc_offers.json", "nt:file");
/*      */               
/*  856 */               fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/*  857 */               logger.debug("Create Operation : JSON Created");
/*      */             }
/*      */           }
/*  860 */           if (fileJcrNode != null) {
/*  861 */             fileJcrNode.setProperty("jcr:mimeType", "application/json");
/*  862 */             fileJcrNode.setProperty("jcr:data", jsonData);
/*      */           }
/*      */         }
/*      */         else {
/*  866 */           logger.debug("Base Folder not Available , JSON not created ");
/*      */         }
/*      */       }
/*  869 */       session.save();
/*      */     } catch (PathNotFoundException e) {
/*  871 */       logger.error("Path Not Found Exception Occured in UpdateOfferJSON createJsonFile() :" + e);
/*      */     } catch (RepositoryException e) {
/*  873 */       logger.error("node creation exception" + e);
/*      */     } finally {
/*  875 */       if (resolver != null) {
/*  876 */         logger.debug("resolver closed ");
/*  877 */         resolver.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessToken()
/*      */   {
/*  891 */     logger.debug("inside getAccessToken  :: " + PROXY_ENABLED);
/*      */     
/*  893 */     CloseableHttpClient client = null;
/*  894 */     CloseableHttpResponse response = null;
/*      */     
/*  896 */     String accessToken = null;
/*  897 */     StringBuilder offerJson = new StringBuilder("");
/*  898 */     BufferedReader br = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  910 */       client = HttpClientBuilder.create().build();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  915 */       List<NameValuePair> urlParameters = new ArrayList();
/*  916 */       urlParameters.add(new BasicNameValuePair("grant_type", GRANT_TYPE));
/*  917 */       urlParameters.add(new BasicNameValuePair("client_id", CLIENT_ID));
/*  918 */       urlParameters.add(new BasicNameValuePair("client_secret", CLIENT_SECRET_KEY));
/*  919 */       HttpPost postRequest = new HttpPost(TOKEN_GENERATION_URL);
/*  920 */       postRequest.setEntity(new UrlEncodedFormEntity(urlParameters));
/*  921 */       logger.debug("TOKEN_GENERATION_URL :" + TOKEN_GENERATION_URL);
/*  922 */       response = client.execute(postRequest);
/*  923 */       if (response != null) {
/*  924 */         logger.debug("token response" + response.toString());
/*      */       }
/*  926 */       if (response.getStatusLine().getStatusCode() != 200) {
/*  927 */         logger.error("Failed : HTTP error code :  :: " + response.getStatusLine().getStatusCode());
/*      */         
/*  929 */         throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
/*      */       }
/*  931 */       br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF8"));
/*      */       String output;
/*  933 */       while ((output = br.readLine()) != null)
/*      */       {
/*  935 */         offerJson = offerJson.append(output);
/*      */       }
/*      */       
/*  938 */       logger.debug("token JSON :: " + offerJson);
/*  939 */       JSONObject jsonObj; if (!offerJson.toString().equals("")) {
/*  940 */         jsonObj = new JSONObject(offerJson.toString());
/*  941 */         logger.debug("access_token :: " + jsonObj.get("access_token").toString());
/*      */         
/*  943 */         if (validString(jsonObj.get("access_token").toString(), "^[a-zA-Z0-9-]{1,500}$")) {
/*  944 */           accessToken = jsonObj.get("access_token").toString();
/*      */         }
/*      */       }
/*      */       
/*  948 */       return accessToken;
/*      */     }
/*      */     catch (RuntimeException e) {
/*  951 */       logger.error("RuntimeException  :: " + e);
/*      */     }
/*      */     catch (Exception e) {
/*  954 */       logger.error("Exception while parsing JSON :: " + e);
/*      */     } finally {
/*  956 */       if (br != null) {
/*      */         try {
/*  958 */           br.close();
/*      */         } catch (Exception e) {
/*  960 */           logger.error("Exception while closing reader :: " + e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  965 */     return accessToken;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, String> getImageDimension(String path)
/*      */   {
/*  975 */     logger.debug("####### getImageDimension path ->######### : " + path);
/*  976 */     HashMap<String, String> dimensionMap = null;
/*      */     
/*  978 */     ResourceResolver resolver = null;
/*  979 */     Session session = null;
/*  980 */     Node progrmNode = null;
/*      */     try
/*      */     {
/*  983 */       resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  984 */       session = (Session)resolver.adaptTo(Session.class);
/*  985 */       if (session.nodeExists(path + "/" + "VMORC_Offer_Program_List/jcr:content/imageDimension")) {
/*  986 */         progrmNode = session.getNode(path + "/" + "VMORC_Offer_Program_List/jcr:content/imageDimension");
/*  987 */         dimensionMap = new HashMap();
/*  988 */         if (progrmNode.hasProperty("fileReferenceHeroImage"))
/*      */         {
/*  990 */           Property currentProp = progrmNode.getProperty("fileReferenceHeroImage");
/*  991 */           dimensionMap.put("fileReferenceHeroImage", currentProp
/*  992 */             .getValue().getString());
/*  993 */           logger.debug("hero image" + currentProp.getValue().getString());
/*      */           
/*  995 */           String heroImage = progrmNode.getProperty("fileReferenceHeroImage").getString();
/*  996 */           Resource res = resolver.getResource(heroImage);
/*  997 */           String heroImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*  998 */           logger.debug("Current Hero Image Width_Height  : " + heroImgWidthHeight);
/*  999 */           dimensionMap.put("hero_image_size", heroImgWidthHeight);
/*      */         }
/*      */         
/* 1002 */         if (progrmNode.hasProperty("fileReferenceThumbImage"))
/*      */         {
/* 1004 */           Property currentProp = progrmNode.getProperty("fileReferenceThumbImage");
/* 1005 */           dimensionMap.put("fileReferenceThumbImage", currentProp
/* 1006 */             .getValue().getString());
/* 1007 */           logger.debug("FILE_REFERENCE_THUMB_IMAGE " + currentProp.getValue().getString());
/*      */           
/* 1009 */           String thumbImage = progrmNode.getProperty("fileReferenceThumbImage").getString();
/* 1010 */           Resource resThumb = resolver.getResource(thumbImage);
/* 1011 */           String thumbImgWidthHeight = VppUtil.getImageWidthHeight(resThumb);
/* 1012 */           logger.debug("Current thumb Image Width_Height  : " + thumbImgWidthHeight);
/* 1013 */           dimensionMap.put("thumb_image_size", thumbImgWidthHeight);
/*      */         }
/* 1015 */         if (progrmNode.hasProperty("fileReferenceLogoImage"))
/*      */         {
/* 1017 */           Property currentProp = progrmNode.getProperty("fileReferenceLogoImage");
/* 1018 */           dimensionMap.put("fileReferenceLogoImage", currentProp
/* 1019 */             .getValue().getString());
/* 1020 */           logger.debug("FILE_REFERENCE_LOGO_IMAGE" + currentProp.getValue().getString());
/*      */           
/* 1022 */           String logoImage = progrmNode.getProperty("fileReferenceLogoImage").getString();
/* 1023 */           Resource resThumb = resolver.getResource(logoImage);
/* 1024 */           String thumbImgWidthHeight = VppUtil.getImageWidthHeight(resThumb);
/* 1025 */           logger.debug("Current logo Image Width_Height  : " + thumbImgWidthHeight);
/* 1026 */           dimensionMap.put("logo_image_size", thumbImgWidthHeight);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (RepositoryException e) {
/* 1031 */       logger.error("node creation exception" + e);
/*      */     } finally {
/* 1033 */       if (resolver != null) {
/* 1034 */         logger.debug("resolver closed ");
/* 1035 */         resolver.close();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1040 */     return dimensionMap;
/*      */   }
/*      */   
/*      */   public boolean validString(String accessTokenString, String pattern)
/*      */   {
/* 1045 */     if (accessTokenString.matches(pattern)) {
/* 1046 */       return true;
/*      */     }
/* 1048 */     logger.debug("This is an invalid string");
/* 1049 */     return false;
/*      */   }
/*      */   
/*      */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*      */   {
/*      */     this.resolverFactory = paramResourceResolverFactory;
/*      */   }
/*      */   
/*      */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*      */   {
/*      */     if (this.resolverFactory == paramResourceResolverFactory) {
/*      */       this.resolverFactory = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void bindSettingsService(SlingSettingsService paramSlingSettingsService)
/*      */   {
/*      */     this.settingsService = paramSlingSettingsService;
/*      */   }
/*      */   
/*      */   protected void unbindSettingsService(SlingSettingsService paramSlingSettingsService)
/*      */   {
/*      */     if (this.settingsService == paramSlingSettingsService) {
/*      */       this.settingsService = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void bindReplicator(Replicator paramReplicator)
/*      */   {
/*      */     this.replicator = paramReplicator;
/*      */   }
/*      */   
/*      */   protected void unbindReplicator(Replicator paramReplicator)
/*      */   {
/*      */     if (this.replicator == paramReplicator) {
/*      */       this.replicator = null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\scheduler\PremiumVmorcScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */