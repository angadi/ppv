/*     */ package com.visa.vpp.premium.services;
/*     */ 
/*     */ import com.visa.vpp.premium.interfaces.ConciergeCarouselArrayList;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service
/*     */ @Component
/*     */ public class ConciergeCarouselArrayListImpl
/*     */   implements ConciergeCarouselArrayList
/*     */ {
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*  35 */   private static final Logger log = LoggerFactory.getLogger(ConciergeCarouselArrayListImpl.class);
/*     */   
/*     */   private static final String PARSYS_NODE_NAME = "optionalParsys";
/*     */   
/*     */   private static final String FILE_REFERENCE = "fileReference";
/*     */   
/*     */   private static final String MESSAGE_TEXT = "messageText";
/*     */   
/*     */   private static final String CONTACT_INFO = "contactInfo";
/*     */   
/*     */   private static final String RESOURCE_TYPE = "vpp/premium/components/content/concierge_carousel";
/*     */   
/*     */   private static final String CONCIERGE_CLASS_NAME = "contact-concierge-email";
/*     */   
/*     */   private static final String TAG_A = "a";
/*     */   
/*     */   private static final String ATTR_CLASS = "class";
/*     */   
/*     */   private static final String ATTR_HREF = "href";
/*     */   
/*     */ 
/*     */   public ArrayList<Map<String, String>> getConciergeCarouselArrayList(String pagePath)
/*     */   {
/*  58 */     log.debug("pagePath in service" + pagePath);
/*  59 */     ArrayList<Map<String, String>> carouselArr = new ArrayList();
/*     */     
/*  61 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  62 */     Session session = (Session)resolver.adaptTo(Session.class);
/*     */     try {
/*  64 */       if (session.nodeExists(pagePath)) {
/*  65 */         log.debug("node exists");
/*  66 */         Node pageJcr = session.getNode(pagePath);
/*  67 */         if (pageJcr.hasNode("optionalParsys")) {
/*  68 */           Node parsysNode = pageJcr.getNode("optionalParsys");
/*  69 */           NodeIterator nodeItr = parsysNode.getNodes();
/*  70 */           Map<String, String> nodeMap = new HashMap();
/*  71 */           while (nodeItr.hasNext()) {
/*  72 */             Node childNode = nodeItr.nextNode();
/*  73 */             if (childNode.hasProperty("sling:resourceType"))
/*     */             {
/*  75 */               String resourceType = childNode.getProperty("sling:resourceType").getValue().getString();
/*  76 */               if (resourceType.equalsIgnoreCase("vpp/premium/components/content/concierge_carousel")) {
/*  77 */                 nodeMap = getNodeProperties(childNode);
/*  78 */                 carouselArr.add(nodeMap);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/*  85 */       log.error("RepositoryException in  getConciergeCarouselArrayList() of ConciergeCarouselArrayListImpl" + e
/*  86 */         .getMessage());
/*     */     }
/*  88 */     log.debug("added succesfully");
/*  89 */     return carouselArr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getNodeProperties(Node childNode)
/*     */   {
/* 101 */     Map<String, String> nodeMap = new HashMap();
/* 102 */     String fileReference = "";
/* 103 */     String contactInfo = "";
/* 104 */     String messageText = "";
/*     */     try
/*     */     {
/* 107 */       if (childNode.hasProperty("fileReference")) {
/* 108 */         fileReference = childNode.getProperty("fileReference").getValue().getString();
/*     */       }
/* 110 */       if (childNode.hasProperty("contactInfo")) {
/* 111 */         contactInfo = childNode.getProperty("contactInfo").getValue().getString();
/*     */       }
/* 113 */       if (childNode.hasProperty("messageText")) {
/* 114 */         messageText = childNode.getProperty("messageText").getValue().getString();
/*     */       }
/* 116 */       nodeMap.put("fileReference", fileReference);
/* 117 */       log.debug("fileReference" + fileReference);
/* 118 */       nodeMap.put("contactInfo", getFormattedText(contactInfo));
/* 119 */       log.debug("contactInfo" + getFormattedText(contactInfo));
/* 120 */       nodeMap.put("messageText", getFormattedText(messageText));
/* 121 */       log.debug("messageText" + getFormattedText(contactInfo));
/*     */     }
/*     */     catch (RepositoryException e) {
/* 124 */       log.error("RepositoryException in  getNodeProperties() of ConciergeCarouselArrayListImpl" + e
/* 125 */         .getMessage());
/*     */     }
/* 127 */     return nodeMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getFormattedText(String currentText)
/*     */   {
/* 137 */     Document doc = Jsoup.parse(currentText);
/* 138 */     Elements anchorElements = doc.select("a");
/* 139 */     for (Element anchorElement : anchorElements) {
/* 140 */       String hrefVal = anchorElement.attr("href");
/* 141 */       if (hrefVal.endsWith("#contact-concierge-email")) {
/* 142 */         log.debug("hrefValue ****** : " + hrefVal);
/* 143 */         anchorElement.attr("class", "contact-concierge-email");
/*     */       }
/*     */     }
/* 146 */     return doc.toString();
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\services\ConciergeCarouselArrayListImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */