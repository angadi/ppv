/*     */ package com.visa.vpp.premium.services;
/*     */ 
/*     */ import com.visa.vpp.premium.interfaces.CustomImageRenditionConfig;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.annotations.Activate;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.osgi.PropertiesUtil;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(metatype=true, label="Custom VPP Premium Image Renditions", description="This service provides configuration details of the Image Renditions to be used by users")
/*     */ @Service({CustomImageRenditionConfig.class})
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="imageRenditions", label="Component Image Renditions", cardinality=100, value={"HeroImageBeforeLogin=[mobile:767x668|tablet:1099x480|desktop:1399x800]", "HeroImageAfterLogin=[mobile:767x200|tablet:1099x300|desktop:1399x500]", "SeamlessRedemption=[mobile:292x291|tablet:437x311|desktop:675x481]", "Teaser=[mobile:292x164|tablet:328x214|desktop:583x271]", "Seamless_Redemption_BackImage=[mobile:375x592|tablet:767x252|desktop:1099x248]"}, description="Add the renditions of the image,Each property should follow the pattern<ComponentName>=[mobile:<100*200>|tablet:<100*300>|desktop:<100*400>]")})
/*     */ public class CustomImageRenditionConfigImpl
/*     */   implements CustomImageRenditionConfig
/*     */ {
/*     */   private String[] imageRenditions;
/*  42 */   private static final Logger LOG = LoggerFactory.getLogger(CustomImageRenditionConfigImpl.class);
/*     */   
/*     */   @Activate
/*     */   protected void activate(Map<String, Object> properties) {
/*  46 */     LOG.info("[*** AEM ConfigurationService]: activating configuration service");
/*  47 */     readProperties(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void readProperties(Map<String, Object> properties)
/*     */   {
/*  57 */     this.imageRenditions = PropertiesUtil.toStringArray(properties.get("imageRenditions"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getImagerenditions()
/*     */   {
/*  66 */     return this.imageRenditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getRenditionByComponentName(String componentName)
/*     */   {
/*  77 */     Map<String, String> imageMap = new HashMap();
/*     */     
/*     */ 
/*  80 */     String[] imageRenditionsTemp = this.imageRenditions;
/*  81 */     if ((null != imageRenditionsTemp) && (imageRenditionsTemp.length > 0)) {
/*  82 */       for (int i = 0; i < imageRenditionsTemp.length; i++)
/*     */       {
/*  84 */         if (componentName.equalsIgnoreCase(imageRenditionsTemp[i].split("=")[0])) {
/*  85 */           LOG.debug("image folder name :: " + imageRenditionsTemp[i].split("=")[0]);
/*  86 */           imageMap = getImageDimensionMap(imageRenditionsTemp[i]);
/*  87 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  94 */     return imageMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getImageDimension(String imageConfig)
/*     */   {
/* 105 */     String[] compArray = imageConfig.split("=");
/* 106 */     String[] dimensionArray = compArray[1].replace("[", "").replaceAll("]", "").split("\\|");
/* 107 */     String[] imageDimensionVal = new String[dimensionArray.length];
/* 108 */     for (int i = 0; i < dimensionArray.length; i++) {
/* 109 */       imageDimensionVal[i] = dimensionArray[i].split(":")[1];
/*     */     }
/* 111 */     return imageDimensionVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getImageDimensionMap(String imageConfig)
/*     */   {
/* 122 */     HashMap<String, String> hm = new HashMap();
/* 123 */     String[] compArray = imageConfig.split("=");
/* 124 */     String[] dimensionArray = compArray[1].replace("[", "").replaceAll("]", "").split("\\|");
/* 125 */     for (int i = 0; i < dimensionArray.length; i++) {
/* 126 */       hm.put(dimensionArray[i].split(":")[0], dimensionArray[i].split(":")[1].replace("x", "."));
/*     */     }
/* 128 */     return hm;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\services\CustomImageRenditionConfigImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */