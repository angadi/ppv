/*     */ package com.visa.vpp.premium.services;
/*     */ 
/*     */ import com.visa.vpp.premium.interfaces.GetOfferData;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import com.visa.vpp.premium.wcmuse.OfferPreviewHandler;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.http.ParseException;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service({GetOfferData.class})
/*     */ @Component(immediate=true)
/*     */ public class GetOfferDataImpl
/*     */   implements GetOfferData
/*     */ {
/*  38 */   private static final Logger log = LoggerFactory.getLogger(GetOfferDataImpl.class);
/*     */   private static final String INVALID_PATH = "invalidPath";
/*     */   private static final String TERMS_AND_CONDITIONS = "termsAndConditions";
/*     */   private static final String T_AND_C_COUNT = "tAndConditionsCount";
/*  42 */   private static final String[] OFFER_PREVIEW_FIELDS = { "offerTitle", "offerShortDesc", "offerCopy", "redemptionInst", "redemptionURL", "merchantName", "heroImageAltText" };
/*     */   
/*     */ 
/*  45 */   public int tncCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JSONObject getCurrentOfferData(String offerUrl, ResourceResolver resolver)
/*     */   {
/*  57 */     JSONObject offerJson = new JSONObject();
/*  58 */     String offerDataPath = VppJsonUtil.getOfferDataPath(offerUrl);
/*  59 */     if (offerDataPath.equalsIgnoreCase("invalidPath")) {
/*  60 */       return offerJson;
/*     */     }
/*  62 */     Session session = null;
/*  63 */     String visaTandC = "";
/*  64 */     String merchantTandC = "";
/*  65 */     String valStartDate = "";
/*  66 */     String valEndDate = "";
/*  67 */     String termsAndCondData = "";
/*  68 */     String validHeroImg = "";
/*  69 */     String heroImage = "";
/*  70 */     String validMerchImg = "";
/*  71 */     String merchLogoImg = "";
/*  72 */     String redeemTelFormatted = "";
/*  73 */     String redeemEmailFormatted = "";
/*  74 */     DateFormat sdf = new SimpleDateFormat("MMM dd','yyyy");
/*  75 */     SimpleDateFormat aemSdf = new SimpleDateFormat("yyyy-MM-dd");
/*     */     try {
/*  77 */       session = (Session)resolver.adaptTo(Session.class);
/*  78 */       Node rootNode = session.getRootNode();
/*  79 */       Node offerDataNode = rootNode.getNode(offerDataPath);
/*  80 */       for (int j = 0; j < OFFER_PREVIEW_FIELDS.length; j++) {
/*  81 */         if (offerDataNode.hasProperty(OFFER_PREVIEW_FIELDS[j])) {
/*  82 */           Property currentProp = offerDataNode.getProperty(OFFER_PREVIEW_FIELDS[j]);
/*  83 */           offerJson.put(OFFER_PREVIEW_FIELDS[j], currentProp.getValue().getString());
/*     */         } else {
/*  85 */           offerJson.put(OFFER_PREVIEW_FIELDS[j], "");
/*     */         }
/*     */       }
/*  88 */       if (offerDataNode.hasProperty("visaTandC")) {
/*  89 */         visaTandC = offerDataNode.getProperty("visaTandC").getString();
/*     */       }
/*  91 */       if (offerDataNode.hasProperty("merchantTandC"))
/*     */       {
/*  93 */         merchantTandC = offerDataNode.getProperty("merchantTandC").getString();
/*     */       }
/*  95 */       if (offerDataNode.hasProperty("validHeroImg")) {
/*  96 */         validHeroImg = offerDataNode.getProperty("validHeroImg").getString();
/*     */       }
/*  98 */       if (offerDataNode.hasProperty("heroImage"))
/*     */       {
/* 100 */         String currHeroImage = offerDataNode.getProperty("heroImage").getString();
/* 101 */         if ((validHeroImg.equalsIgnoreCase("")) || 
/* 102 */           (validHeroImg.equalsIgnoreCase("VALID"))) {
/* 103 */           heroImage = currHeroImage;
/*     */         } else {
/* 105 */           heroImage = validHeroImg;
/*     */         }
/*     */       } else {
/* 108 */         heroImage = validHeroImg;
/*     */       }
/* 110 */       if (offerDataNode.hasProperty("validMerchLogoImg")) {
/* 111 */         validMerchImg = offerDataNode.getProperty("validMerchLogoImg").getString();
/*     */       }
/* 113 */       if (offerDataNode.hasProperty("merchantLogo"))
/*     */       {
/* 115 */         String currMerchLogoImage = offerDataNode.getProperty("merchantLogo").getString();
/* 116 */         if ((validMerchImg.equalsIgnoreCase("")) || 
/* 117 */           (validMerchImg.equalsIgnoreCase("VALID"))) {
/* 118 */           merchLogoImg = currMerchLogoImage;
/*     */         } else {
/* 120 */           merchLogoImg = validMerchImg;
/*     */         }
/*     */       } else {
/* 123 */         merchLogoImg = validMerchImg;
/*     */       }
/*     */       try {
/* 126 */         if (offerDataNode.hasProperty("valStartDate"))
/*     */         {
/* 128 */           String valStartString = offerDataNode.getProperty("valStartDate").getString();
/* 129 */           Date formattedDate = aemSdf.parse(valStartString);
/* 130 */           valStartDate = sdf.format(formattedDate);
/*     */         }
/* 132 */         if (offerDataNode.hasProperty("valEndDate"))
/*     */         {
/* 134 */           String valEndString = offerDataNode.getProperty("valEndDate").getString();
/* 135 */           Date formattedDate = aemSdf.parse(valEndString);
/* 136 */           valEndDate = sdf.format(formattedDate);
/*     */         }
/*     */       } catch (ParseException e) {
/* 139 */         log.debug("Exception Occurred while parsing the dates " + e.getMessage());
/*     */       }
/*     */       
/* 142 */       OfferPreviewHandler offerPreviewObj = new OfferPreviewHandler();
/* 143 */       if ((!visaTandC.equals("")) || (!merchantTandC.equals(""))) {
/* 144 */         termsAndCondData = getTermsAndConditionData(visaTandC, merchantTandC, offerPreviewObj);
/*     */       }
/* 146 */       if (offerDataNode.hasProperty("redemptionTel")) {
/* 147 */         redeemTelFormatted = getFormattedRedemptionTelephone(offerDataNode
/* 148 */           .getProperty("redemptionTel").getString(), offerPreviewObj);
/*     */       }
/*     */       
/* 151 */       if (offerDataNode.hasProperty("redemptionEmail")) {
/* 152 */         redeemEmailFormatted = getFormattedRedemptionEmail(offerDataNode
/* 153 */           .getProperty("redemptionEmail").getString(), offerPreviewObj);
/*     */       }
/*     */       
/*     */ 
/* 157 */       String offerJcrPath = offerDataPath.substring(0, offerDataPath.lastIndexOf("/"));
/* 158 */       if (rootNode.hasNode(offerJcrPath)) {
/* 159 */         Node offerJcrNode = rootNode.getNode(offerJcrPath);
/* 160 */         if (offerJcrNode.hasProperty("offerId")) {
/* 161 */           String offerId = offerJcrNode.getProperty("offerId").getString();
/* 162 */           offerJson.put("offerId", offerId);
/*     */         } else {
/* 164 */           offerJson.put("offerId", "");
/*     */         }
/*     */       }
/* 167 */       offerJson.put("merchantLogo", merchLogoImg);
/* 168 */       offerJson.put("heroImage", heroImage);
/* 169 */       offerJson.put("valStartDate", valStartDate);
/* 170 */       offerJson.put("valEndDate", valEndDate);
/* 171 */       offerJson.put("visaTandC", visaTandC);
/* 172 */       offerJson.put("merchantTandC", merchantTandC);
/* 173 */       offerJson.put("termsAndConditions", termsAndCondData);
/* 174 */       offerJson.put("tAndConditionsCount", this.tncCount);
/* 175 */       offerJson.put("redemptionEmail", redeemEmailFormatted);
/* 176 */       offerJson.put("redemptionTel", redeemTelFormatted);
/* 177 */       log.debug("Current Offer JSON created successfully ");
/*     */     } catch (RepositoryException e) {
/* 179 */       log.error("RepositoryException occured in GetOfferDataImpl getCurrentOfferData()" + e
/* 180 */         .getMessage());
/* 181 */       offerJson = new JSONObject();
/*     */     } catch (JSONException e) {
/* 183 */       log.error("JSONException occured in GetOfferDataImpl getCurrentOfferData()" + e.getMessage());
/* 184 */       offerJson = new JSONObject();
/*     */     } catch (Exception e) {
/* 186 */       log.error("Exception Occured in GetOfferDataImpl getCurrentOfferData() :" + e.getMessage());
/* 187 */       offerJson = new JSONObject();
/*     */     } finally {
/* 189 */       VppUtil.closeJcrSession(session);
/*     */     }
/* 191 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTermsAndConditionData(String visaTandC, String merchantTandC, OfferPreviewHandler offerPreviewObj)
/*     */   {
/* 206 */     String termsAndCondData = "";
/* 207 */     int visaCount = offerPreviewObj.getTermsAndConditionsCount(visaTandC).intValue();
/* 208 */     int merchCount = offerPreviewObj.getTermsAndConditionsCount(merchantTandC).intValue();
/* 209 */     this.tncCount = (visaCount + merchCount);
/* 210 */     termsAndCondData = offerPreviewObj.renderTotalTermsandConditionsHtml(offerPreviewObj.allElements, offerPreviewObj.restElements);
/*     */     
/* 212 */     return termsAndCondData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getFormattedRedemptionTelephone(String redemTel, OfferPreviewHandler offerPreviewObj)
/*     */   {
/* 225 */     return offerPreviewObj.formatTelephone(redemTel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getFormattedRedemptionEmail(String redemEmail, OfferPreviewHandler offerPreviewObj)
/*     */   {
/* 237 */     return offerPreviewObj.formatEmail(redemEmail);
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\services\GetOfferDataImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */