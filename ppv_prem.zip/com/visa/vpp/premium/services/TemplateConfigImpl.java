/*    */ package com.visa.vpp.premium.services;
/*    */ 
/*    */ import com.visa.vpp.premium.interfaces.TemplateConfig;
/*    */ import java.util.Map;
/*    */ import org.apache.felix.scr.annotations.Activate;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.commons.osgi.PropertiesUtil;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component(metatype=true, label="Premium Template Configurations", description="This service provides configuration details of the Templates to be used by users")
/*    */ @Service({TemplateConfig.class})
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="authorTemplatePaths", label="Templates Allowed for Authors", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to authors here"), @org.apache.felix.scr.annotations.Property(name="approverTemplatePaths", label="Templates Allowed for Approver", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to approvers here"), @org.apache.felix.scr.annotations.Property(name="adminTemplatePaths", label="Templates Allowed for Admins", cardinality=50, value={"/apps/vpp/components/pages/category_page", "/apps/vpp/components/pages/landing_page"}, description="Add template paths,which are allowed to admins here")})
/*    */ public class TemplateConfigImpl
/*    */   implements TemplateConfig
/*    */ {
/* 45 */   private static final Logger LOG = LoggerFactory.getLogger(TemplateConfigImpl.class);
/*    */   private String[] authorTemplatePaths;
/*    */   private String[] approverTemplatePaths;
/*    */   private String[] adminTemplatePaths;
/*    */   
/*    */   @Activate
/*    */   protected void activate(Map<String, Object> properties)
/*    */   {
/* 53 */     LOG.info("[*** AEM ConfigurationService]: activating configuration service");
/* 54 */     readProperties(properties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void readProperties(Map<String, Object> properties)
/*    */   {
/* 64 */     this.authorTemplatePaths = PropertiesUtil.toStringArray(properties.get("authorTemplatePaths"));
/*    */     
/* 66 */     this.approverTemplatePaths = PropertiesUtil.toStringArray(properties.get("approverTemplatePaths"));
/*    */     
/* 68 */     this.adminTemplatePaths = PropertiesUtil.toStringArray(properties.get("adminTemplatePaths"));
/*    */   }
/*    */   
/*    */   public String[] getAuthorTemplatePaths() {
/* 72 */     return this.authorTemplatePaths;
/*    */   }
/*    */   
/*    */   public String[] getApproverTemplatePaths() {
/* 76 */     return this.approverTemplatePaths;
/*    */   }
/*    */   
/*    */   public String[] getAdminTemplatePaths() {
/* 80 */     return this.adminTemplatePaths;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\services\TemplateConfigImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */