/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/conciergeLandingRedirection"}, methods={"GET"}, metatype=false)
/*     */ public class ConciergeLandingRedirection
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final String LANDING_PAGE_TEMPLATE = "concierge_landing";
/*     */   private static final String FIRSTNAME = "firstName";
/*     */   private static final String ID = "id";
/*     */   private static final String BENEFIT_CODE = "benefitCode";
/*  38 */   private static final Logger log = LoggerFactory.getLogger(ConciergeLandingRedirection.class);
/*     */   
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  47 */     String redirectPath = "";
/*  48 */     String userId = "";
/*  49 */     String firstName = "";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  54 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  55 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  56 */       String currPagePath = xssApi.encodeForHTML(request.getParameter("currentPagePath"));
/*  57 */       String validUserId = xssApi.encodeForHTML(request.getParameter("id"));
/*  58 */       String validFirstName = xssApi.encodeForHTML(request.getParameter("firstName"));
/*     */       
/*     */ 
/*  61 */       if (validString(validUserId, "^[0-9]{4,50}$")) {
/*  62 */         userId = validUserId;
/*     */       }
/*  64 */       if (validString(validFirstName.trim(), "^[a-zA-Z ]{1,50}$")) {
/*  65 */         firstName = validFirstName;
/*     */       }
/*     */       
/*     */ 
/*  69 */       response.setContentType("text/plain");
/*  70 */       Resource resource = resolver.getResource(currPagePath);
/*  71 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  73 */       Page landingPage = getLandingPage(currentPage.getPath());
/*  74 */       if (landingPage != null) {
/*  75 */         log.debug("Redirecting to landing page ");
/*  76 */         StringBuilder sb = new StringBuilder(landingPage.getPath());
/*  77 */         sb.append(".html");
/*  78 */         redirectPath = sb.toString();
/*  79 */         HttpSession session = request.getSession();
/*  80 */         if (null != userId) {
/*  81 */           session.setAttribute("userId", userId);
/*  82 */           session.setAttribute("isConcierge", userId);
/*     */         }
/*     */         
/*  85 */         if (null != firstName) {
/*  86 */           session.setAttribute("firstName", firstName);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  91 */         log.debug("landing page not found redirecting to home page");
/*  92 */         StringBuilder sb = new StringBuilder(currentPage.getPath());
/*  93 */         sb.append(".html");
/*  94 */         redirectPath = sb.toString();
/*     */       }
/*     */       
/*  97 */       response.getWriter().write(redirectPath);
/*     */     } catch (Exception e) {
/*  99 */       log.error("Exception Occured in LoginRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getLandingPage(String path)
/*     */   {
/* 114 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 115 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 116 */     Page rootPage = pageManager.getPage(path);
/* 117 */     Page landingPage = null;
/*     */     
/* 119 */     if (null != rootPage) {
/* 120 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 121 */       while (rootPageIterator.hasNext()) {
/* 122 */         Page childPage = (Page)rootPageIterator.next();
/* 123 */         if ((childPage != null) && (childPage.getTemplate().getName().equals("concierge_landing"))) {
/* 124 */           landingPage = childPage;
/* 125 */           break;
/*     */         }
/*     */       }
/*     */       
/* 129 */       return landingPage;
/*     */     }
/* 131 */     return landingPage;
/*     */   }
/*     */   
/*     */   public boolean validString(String accessTokenString, String pattern) {
/* 135 */     if (accessTokenString.matches(pattern)) {
/* 136 */       return true;
/*     */     }
/* 138 */     log.debug("This is an invalid string");
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\ConciergeLandingRedirection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */