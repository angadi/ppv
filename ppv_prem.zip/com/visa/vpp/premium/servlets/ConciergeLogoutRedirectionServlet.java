/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/conciergeUserSignout"}, methods={"GET"}, metatype=false)
/*     */ public class ConciergeLogoutRedirectionServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final String LOGIN_LINK = "#log-in";
/*     */   private static final String CONCIERGE_PATH = "/content/vpp/premium/concierge/en_us";
/*     */   private static final String HOME_PAGE_TEMPLATE = "concierge_home";
/*     */   private static final int HOME_PAGE_DEPTH = 6;
/*  41 */   private static final Logger log = LoggerFactory.getLogger(ConciergeLogoutRedirectionServlet.class);
/*     */   
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  50 */     String currPagePath = request.getParameter("currentPagePath");
/*     */     
/*  52 */     String redirectPath = "";
/*     */     
/*     */     try
/*     */     {
/*  56 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  57 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  58 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/*     */       
/*  60 */       response.setContentType("text/plain");
/*  61 */       Resource resource = resolver.getResource(currPagePath);
/*  62 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  64 */       Page homePage = getHomePage("/content/vpp/premium/concierge/en_us");
/*  65 */       if (homePage != null) {
/*  66 */         log.debug("Redirecting to home page ");
/*  67 */         StringBuilder sb = new StringBuilder(homePage.getPath());
/*  68 */         sb.append(".html");
/*  69 */         sb.append("#log-in");
/*  70 */         redirectPath = sb.toString();
/*     */         
/*  72 */         HttpSession session = request.getSession(true);
/*  73 */         session.invalidate();
/*     */       }
/*     */       else {
/*  76 */         log.debug("landing page not found redirecting to home page");
/*  77 */         StringBuilder sb = new StringBuilder(currentPage.getPath());
/*  78 */         sb.append(".html");
/*  79 */         redirectPath = xssApi.encodeForHTML(sb.toString());
/*     */       }
/*  81 */       response.getWriter().write(redirectPath);
/*     */     } catch (Exception e) {
/*  83 */       log.error("Exception Occured in LogoutRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getHomePage(String path)
/*     */   {
/*  98 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  99 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 100 */     Page rootPage = pageManager.getPage(path);
/* 101 */     Page landingPage = null;
/*     */     
/* 103 */     if (null != rootPage) {
/* 104 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 105 */       while (rootPageIterator.hasNext()) {
/* 106 */         Page childPage = (Page)rootPageIterator.next();
/* 107 */         if ((childPage != null) && (childPage.getTemplate().getName().equals("concierge_home"))) {
/* 108 */           landingPage = childPage;
/* 109 */           break;
/*     */         }
/*     */       }
/*     */       
/* 113 */       return landingPage;
/*     */     }
/* 115 */     return landingPage;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\ConciergeLogoutRedirectionServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */