/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Value;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/conciergeRedirection"}, methods={"GET"}, metatype=false)
/*     */ public class ConciergeRedirectionServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CARD_NUMBER = "cardNumber";
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final String REDIRECT_PAGE_TEMPLATE = "redirect_page";
/*     */   private static final String CARD_HOLDER_NAME = "firstName";
/*     */   private static final String CARD_HOLDER_ID = "userId";
/*     */   private static final String CARD_ID = "cardId";
/*  48 */   private static final Logger log = LoggerFactory.getLogger(ConciergeRedirectionServlet.class);
/*     */   
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  59 */     String currPagePath = request.getParameter("currentPagePath");
/*     */     
/*  61 */     String cardNumber = request.getParameter("cardNumber");
/*  62 */     String cardHolderId = request.getParameter("userId");
/*  63 */     String cardHolderName = request.getParameter("firstName");
/*  64 */     String cardId = request.getParameter("cardId");
/*     */     
/*     */     try
/*     */     {
/*  68 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  69 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  70 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/*     */       
/*  72 */       cardNumber = xssApi.encodeForHTML(cardNumber);
/*  73 */       String validcardHolderId = xssApi.encodeForHTML(cardHolderId);
/*  74 */       String validcardHolderName = xssApi.encodeForHTML(cardHolderName);
/*  75 */       String validcardId = xssApi.encodeForHTML(cardId);
/*     */       
/*     */ 
/*     */ 
/*  79 */       if (validString(validcardHolderId, "^[0-9]{4,50}$")) {
/*  80 */         cardHolderId = validcardHolderId;
/*     */       }
/*  82 */       if (validString(validcardHolderName, "^[a-zA-Z ]{1,50}$")) {
/*  83 */         cardHolderName = validcardHolderName;
/*     */       }
/*  85 */       if (validString(validcardId, "^[0-9]{4,50}$")) {
/*  86 */         cardId = validcardId;
/*     */       }
/*  88 */       response.setContentType("text/plain");
/*  89 */       Resource resource = resolver.getResource(currPagePath);
/*  90 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  92 */       String redirectPath1 = getIssuerLandingPage(currentPage.getPath(), cardNumber);
/*  93 */       if ((redirectPath1 == null) || (redirectPath1.equals("")))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */         log.debug("landing page not found redirecting to home page");
/* 101 */         response.setStatus(406);
/*     */       }
/*     */       else {
/* 104 */         log.debug("Redirecting to Issuer landing page ");
/* 105 */         HttpSession session = request.getSession();
/* 106 */         if (null != cardHolderId) {
/* 107 */           session.setAttribute("cardHolderId", cardHolderId);
/*     */         }
/* 109 */         if (null != cardHolderName) {
/* 110 */           session.setAttribute("cardHolderName", cardHolderName);
/*     */         }
/* 112 */         if (null != cardId) {
/* 113 */           session.setAttribute("cardId", cardId);
/*     */         }
/*     */         
/* 116 */         redirectPath1 = redirectPath1 + ".html";
/* 117 */         response.getWriter().write(redirectPath1);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 121 */       log.error("Exception Occured in LoginRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIssuerLandingPage(String path, String cardNumber)
/*     */   {
/* 135 */     String redirectPath = "";
/* 136 */     Page rootPage = null;
/*     */     
/* 138 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 139 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 140 */     if (path.contains("concierge")) {
/* 141 */       rootPage = pageManager.getPage(path).getParent(2);
/*     */     } else {
/* 143 */       rootPage = pageManager.getPage("/content/vpp/premium/concierge/en_us");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     if (null != rootPage) {
/* 149 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 150 */       while (rootPageIterator.hasNext()) {
/* 151 */         Page childPage = (Page)rootPageIterator.next();
/* 152 */         if ((childPage != null) && (childPage.getTemplate().getName().equals("redirect_page"))) {
/* 153 */           log.debug("Redirect Page path --" + childPage.getPath());
/*     */           
/*     */           try
/*     */           {
/* 157 */             Node childPageNode = (Node)childPage.adaptTo(Node.class);
/* 158 */             StringBuilder sb = new StringBuilder("jcr:content");
/* 159 */             sb.append("/").append("vmorcProgramList");
/* 160 */             Node jcrNode = childPageNode.getNode("jcr:content");
/* 161 */             log.debug("JCR Node" + jcrNode.getPath());
/* 162 */             if (jcrNode.hasNode("vmorcProgramList")) {
/* 163 */               Node redirectNode = jcrNode.getNode("vmorcProgramList");
/* 164 */               if (redirectNode.hasProperty("redirectInfo")) {
/* 165 */                 Property redirectProperty = redirectNode.getProperty("redirectInfo");
/* 166 */                 if (redirectProperty.isMultiple()) {
/* 167 */                   Value[] redirectValues = redirectProperty.getValues();
/* 168 */                   for (Value redirectValue : redirectValues) {
/* 169 */                     JSONObject json = new JSONObject(redirectValue.getString());
/*     */                     
/*     */ 
/* 172 */                     if (json.getString("cardNumber").equalsIgnoreCase(cardNumber.trim().substring(0, 6))) {
/* 173 */                       log.debug("loop is true");
/* 174 */                       redirectPath = json.getString("redirectUrl");
/*     */                     }
/*     */                     
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (RepositoryException e)
/*     */           {
/* 184 */             log.debug("ValueFormatException occured in ConciergeServlet getIssuerLandingPage " + e
/* 185 */               .getMessage());
/*     */           } catch (Exception e) {
/* 187 */             log.debug("Exception occured in ConciergeServlet getIssuerLandingPage  " + e
/* 188 */               .getMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 194 */       return redirectPath;
/*     */     }
/* 196 */     return redirectPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean validString(String accessTokenString, String pattern)
/*     */   {
/* 207 */     if (accessTokenString.matches(pattern)) {
/* 208 */       return true;
/*     */     }
/* 210 */     log.debug("This is an invalid string");
/* 211 */     return false;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\ConciergeRedirectionServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */