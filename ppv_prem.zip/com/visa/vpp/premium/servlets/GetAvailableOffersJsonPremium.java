/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/getAvailableOffersPremium"}, methods={"POST"}, metatype=false)
/*     */ public class GetAvailableOffersJsonPremium
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   private static final Logger log = LoggerFactory.getLogger(GetAvailableOffersJsonPremium.class);
/*     */   
/*     */ 
/*     */   private static final String CAT_PAGE_PATH = "catPagePath";
/*     */   
/*     */   private static final String SELECTED_OFFERS = "selectedOffers";
/*     */   
/*     */   private static final String INVALID_PATH = "invalidPath";
/*     */   
/*     */ 
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  58 */     JSONObject validOffersJson = getValidOffersJson(request);
/*  59 */     log.debug("Valid Offers JSON Size : " + validOffersJson.length());
/*  60 */     response.setContentType("application/json");
/*  61 */     response.setCharacterEncoding("UTF-8");
/*  62 */     response.getWriter().write(validOffersJson.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getValidOffersJson(SlingHttpServletRequest request)
/*     */   {
/*  75 */     String pagePath = request.getParameter("catPagePath");
/*  76 */     ResourceResolver resolver = request.getResourceResolver();
/*  77 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  78 */     pagePath = xssApi.encodeForHTML(pagePath);
/*  79 */     String offerJsonLocation = VppJsonUtil.getOfferJsonLocation(pagePath);
/*  80 */     JSONObject vmorcOfferJson = new JSONObject();
/*  81 */     Session session = null;
/*     */     
/*  83 */     if (offerJsonLocation.equalsIgnoreCase("invalidPath")) {
/*  84 */       log.debug("Invalid OfferJSONLocation Path , no offers returned");
/*  85 */       return vmorcOfferJson;
/*     */     }
/*     */     try {
/*  88 */       session = (Session)resolver.adaptTo(Session.class);
/*  89 */       vmorcOfferJson = VppJsonUtil.getOfferJson(session, offerJsonLocation, "vmorc_offers.json");
/*     */       
/*  91 */       JSONObject aemOfferJson = VppJsonUtil.getOfferJson(session, offerJsonLocation, "aem_offers.json");
/*     */       
/*  93 */       Iterator<String> it = aemOfferJson.keys();
/*     */       
/*  95 */       while (it.hasNext()) {
/*  96 */         String currentOfferKey = (String)it.next();
/*     */         try {
/*  98 */           JSONObject currentOfferJson = (JSONObject)aemOfferJson.get(currentOfferKey);
/*  99 */           if (currentOfferJson.has("promoStartDate"))
/*     */           {
/* 101 */             String promoStart = (String)currentOfferJson.get("promoStartDate");
/* 102 */             if (currentOfferJson.has("promoEndDate"))
/*     */             {
/* 104 */               String promoEnd = (String)currentOfferJson.get("promoEndDate");
/* 105 */               boolean promoValidity = VppJsonUtil.checkPromotionDateValidity(promoStart, promoEnd);
/* 106 */               if (promoValidity) {
/* 107 */                 vmorcOfferJson.put(currentOfferKey, currentOfferJson);
/*     */               }
/*     */             } else {
/* 110 */               log.debug("Promotion Date Range Missing , offer not added to available offers");
/*     */             }
/*     */           } else {
/* 113 */             log.debug("Promotion Date Range Missing , offer not added to available offers");
/*     */           }
/*     */         } catch (JSONException e) {
/* 116 */           log.error("JSONException occured in GetAvailableOffersJSON getValidOffersJSON()" + e.getMessage());
/*     */         } catch (Exception e) {
/* 118 */           log.error("Exception occured in GetAvailableOffersJSON getValidOffersJSON()" + e
/* 119 */             .getMessage());
/*     */         }
/*     */       }
/*     */       
/* 123 */       StringBuilder sb = new StringBuilder(pagePath);
/* 124 */       sb.append("/");
/* 125 */       sb.append("jcr:content");
/* 126 */       String catJcrPath = sb.toString();
/* 127 */       Node rootNode = session.getRootNode();
/* 128 */       ArrayList<String> selectedOffersArrList = new ArrayList();
/*     */       
/* 130 */       if (rootNode.hasNode(catJcrPath.substring(1))) {
/* 131 */         Node catJcrNode = rootNode.getNode(catJcrPath.substring(1));
/* 132 */         Node moreOffersNode = null;
/* 133 */         Node featuredOffersNode = null;
/* 134 */         if (catJcrNode.hasNode("more_offers")) {
/* 135 */           moreOffersNode = catJcrNode.getNode("more_offers");
/* 136 */           selectedOffersArrList = getSelectedOffersList(moreOffersNode);
/*     */         }
/* 138 */         if (catJcrNode.hasNode("featured_offers")) {
/* 139 */           featuredOffersNode = catJcrNode.getNode("featured_offers");
/* 140 */           selectedOffersArrList.addAll(getSelectedOffersList(featuredOffersNode));
/*     */         }
/*     */       }
/* 143 */       JSONArray selectedOffersJsonArr = new JSONArray(selectedOffersArrList);
/* 144 */       vmorcOfferJson.put("selectedOffers", selectedOffersJsonArr);
/*     */     }
/*     */     catch (Exception e1) {
/* 147 */       log.error("Exception occured in GetAvailableOffersJSON getValidOffersJSON()" + e1
/* 148 */         .getMessage());
/*     */     } finally {
/* 150 */       VppUtil.closeJcrSession(session);
/*     */     }
/*     */     
/* 153 */     return vmorcOfferJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getSelectedOffersList(Node offerNode)
/*     */   {
/* 164 */     ArrayList<String> selectedOffersArrList = new ArrayList();
/*     */     try {
/* 166 */       NodeIterator offerNodeItr = offerNode.getNodes();
/* 167 */       while (offerNodeItr.hasNext()) {
/* 168 */         Node childNode = offerNodeItr.nextNode();
/* 169 */         if (childNode.hasProperty("offerId")) {
/* 170 */           String offerId = childNode.getProperty("offerId").getString();
/* 171 */           selectedOffersArrList.add(offerId);
/*     */         }
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 175 */       log.error("Path Not Found Exception Occured in GetAvailableOffersJSON getSelectedOffersList() :" + e
/*     */       
/* 177 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 179 */       log.error("Repository Exception Occured in GetAvailableOffersJSON getSelectedOffersList() :" + e
/* 180 */         .getMessage());
/*     */     } catch (Exception e) {
/* 182 */       log.error("Exception Occured in GetAvailableOffersJSON getSelectedOffersList() : " + e
/* 183 */         .getMessage());
/*     */     }
/* 185 */     return selectedOffersArrList;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\GetAvailableOffersJsonPremium.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */