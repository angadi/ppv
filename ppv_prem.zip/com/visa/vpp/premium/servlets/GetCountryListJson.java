/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @SlingServlet(paths={"/bin/GetCountryListJson"}, methods={"GET"}, metatype=false)
/*     */ public class GetCountryListJson
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  33 */   private static final Logger log = LoggerFactory.getLogger(GetCountryListJson.class);
/*     */   
/*     */   private static final String COUNTRY_PAGE_TEMPLATE = "genericlist";
/*     */   private static final String ISSUER = "issuer";
/*     */   private static final String LANGUAGE = "language";
/*     */   private static final String currPagePath = "/content/vpp/premium";
/*     */   private static final String LIST_PATH = "/jcr:content/list";
/*  40 */   private Page countryPage = null;
/*  41 */   private String issuerName = null;
/*  42 */   private String language = null;
/*  43 */   JSONArray countryListJsonArray = null;
/*     */   
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  53 */     String countryPagePath = null;
/*  54 */     this.countryListJsonArray = new JSONArray();
/*     */     try {
/*  56 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*     */       
/*  58 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  59 */       this.issuerName = xssApi.encodeForHTML(request.getParameter("issuer"));
/*  60 */       this.language = xssApi.encodeForHTML(request.getParameter("language"));
/*  61 */       StringBuilder sb = new StringBuilder("");
/*  62 */       sb.append("/content/vpp/premium");
/*  63 */       sb.append("/");
/*  64 */       sb.append(this.issuerName);
/*  65 */       countryPagePath = sb.toString();
/*  66 */       countryPagePath = xssApi.encodeForHTML(countryPagePath);
/*  67 */       String jcrTitle = "jcr:title";
/*  68 */       if (!this.language.equals("en_us")) {
/*  69 */         this.language = this.language.split("_")[0];
/*  70 */         jcrTitle = jcrTitle + "." + this.language;
/*     */       }
/*     */       
/*     */ 
/*  74 */       Resource resource = resolver.getResource(countryPagePath);
/*  75 */       Page rootPage = (Page)resource.adaptTo(Page.class);
/*  76 */       response.setContentType("application/json");
/*  77 */       response.setCharacterEncoding("UTF-8");
/*     */       
/*  79 */       if (null != rootPage) {
/*  80 */         Iterator<Page> rootPageIterator = rootPage.listChildren();
/*     */         
/*  82 */         while (rootPageIterator.hasNext()) {
/*  83 */           Page childPage = (Page)rootPageIterator.next();
/*  84 */           if ((childPage != null) && (childPage.getTemplate() != null) && 
/*  85 */             (childPage.getTemplate().getName().equals("genericlist"))) {
/*  86 */             this.countryPage = childPage;
/*  87 */             break;
/*     */           }
/*     */         }
/*     */         
/*  91 */         this.countryListJsonArray = getItemNodeJson(this.countryPage, resolver, jcrTitle);
/*  92 */         response.getWriter().write(this.countryListJsonArray.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  96 */       log.error("Exception Occured in GetCountryListJson : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONArray getItemNodeJson(Page countryPage2, ResourceResolver resolver, String jcrTitle)
/*     */   {
/* 105 */     Session session = null;
/* 106 */     session = (Session)resolver.adaptTo(Session.class);
/* 107 */     JSONArray countryArray = null;
/* 108 */     countryArray = new JSONArray();
/*     */     
/* 110 */     if ((countryPage2 != null) && (jcrTitle != null)) {
/*     */       try
/*     */       {
/* 113 */         if (session.nodeExists(countryPage2.getPath() + "/jcr:content/list")) {
/* 114 */           Node list = session.getNode(countryPage2.getPath() + "/jcr:content/list");
/* 115 */           Iterator<Node> childs = list.getNodes();
/* 116 */           while (childs.hasNext()) {
/* 117 */             Node child = (Node)childs.next();
/* 118 */             if ((child.hasProperty(jcrTitle)) && (child.hasProperty("value"))) {
/* 119 */               String name = child.getProperty(jcrTitle).getValue().getString();
/* 120 */               String id = child.getProperty("value").getValue().getString();
/* 121 */               JSONObject countryJson = new JSONObject();
/* 122 */               countryJson.put("name", name);
/* 123 */               countryJson.put("id", id);
/* 124 */               countryArray.put(countryJson);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 132 */         log.error("exception in finding jcr Node" + e.getMessage());
/*     */       }
/*     */     }
/* 135 */     return countryArray;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\GetCountryListJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */