/*    */ package com.visa.vpp.premium.servlets;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.day.cq.wcm.api.Template;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Iterator;
/*    */ import javax.jcr.Node;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.api.SlingHttpServletResponse;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*    */ import org.apache.sling.xss.XSSAPI;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SlingServlet(paths={"/bin/getEmailPreference"}, methods={"GET"}, metatype=false)
/*    */ public class GetEmailPreference
/*    */   extends SlingAllMethodsServlet
/*    */ {
/* 33 */   private String issuerName = null;
/* 34 */   private String language = null;
/* 35 */   private String configPagePath = null;
/* 36 */   private Page configPage = null;
/* 37 */   private String enable = null;
/* 38 */   private static final Logger log = LoggerFactory.getLogger(GetEmailPreference.class);
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/*    */   
/*    */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 46 */     this.enable = "false";
/*    */     try {
/* 48 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*    */       
/* 50 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/* 51 */       this.issuerName = xssApi.encodeForHTML(request.getParameter("issuer"));
/* 52 */       this.language = xssApi.encodeForHTML(request.getParameter("language"));
/* 53 */       StringBuilder sb = new StringBuilder("");
/* 54 */       sb.append("/content/vpp/premium");
/* 55 */       sb.append("/");
/* 56 */       sb.append(this.issuerName);
/* 57 */       sb.append("/");
/* 58 */       sb.append(this.language);
/* 59 */       this.configPagePath = sb.toString();
/* 60 */       this.configPagePath = xssApi.encodeForHTML(this.configPagePath);
/* 61 */       Resource resource = resolver.getResource(this.configPagePath);
/* 62 */       Page langPage = (Page)resource.adaptTo(Page.class);
/* 63 */       log.debug("language page found {}", langPage.getName());
/* 64 */       if (null != langPage) {
/* 65 */         Iterator<Page> langPageItr = langPage.listChildren();
/* 66 */         while (langPageItr.hasNext()) {
/* 67 */           Page child = (Page)langPageItr.next();
/* 68 */           if ((child != null) && (child.getTemplate() != null) && 
/* 69 */             (child.getTemplate().getName().equals("config_page"))) {
/* 70 */             this.configPage = child;
/* 71 */             log.debug("config page found {}", this.configPage.getName());
/* 72 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 80 */       if (this.configPage != null) {
/* 81 */         Node configPageNode = (Node)this.configPage.adaptTo(Node.class);
/* 82 */         if ((configPageNode != null) && (configPageNode.hasNode("jcr:content")) && (configPageNode.getNode("jcr:content").hasNode("emailPreference")) && 
/* 83 */           (configPageNode.getNode("jcr:content").getNode("emailPreference").hasProperty("emailPreference"))) {
/* 84 */           log.debug("config page found {}", Boolean.valueOf(configPageNode.getNode("jcr:content").hasNode("emailPreference")));
/* 85 */           this.enable = "true";
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 91 */       response.setContentType("application/json");
/* 92 */       response.setCharacterEncoding("UTF-8");
/* 93 */       response.getWriter().write(this.enable);
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 98 */       log.error("Exception Occured in GetCountryListJson : " + e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\GetEmailPreference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */