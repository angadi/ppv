/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/getLandingPageOffersPremium"}, methods={"POST"}, metatype=false)
/*     */ public class GetLandingPageOffersPremium
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  32 */   private static final Logger log = LoggerFactory.getLogger(GetLandingPageOffersPremium.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  47 */     JSONObject offerData = getLandingPageOffers(request);
/*  48 */     response.setContentType("application/json");
/*  49 */     response.setCharacterEncoding("UTF-8");
/*  50 */     response.getWriter().write(offerData.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getLandingPageOffers(SlingHttpServletRequest request)
/*     */   {
/*  61 */     Session jcrSession = null;
/*  62 */     String currentPagePath = "";
/*  63 */     ResourceResolver resolver = null;
/*  64 */     String landingDetails = "";
/*  65 */     String jsonFileName = "failure";
/*  66 */     resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  67 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  68 */     currentPagePath = request.getParameter("currentPagePath");
/*  69 */     currentPagePath = xssApi.encodeForHTML(currentPagePath);
/*  70 */     String offerJsonLocation = VppJsonUtil.getOfferJsonLocation(currentPagePath);
/*  71 */     JSONObject offerJson = new JSONObject();
/*  72 */     if (offerJsonLocation.equalsIgnoreCase("invalidPath")) {
/*  73 */       log.debug("Invalid JSON Location Path ,returning empty JSON ");
/*  74 */       return offerJson;
/*     */     }
/*     */     try {
/*  77 */       jcrSession = (Session)resolver.adaptTo(Session.class);
/*  78 */       Resource resource = resolver.getResource(currentPagePath);
/*  79 */       Node searchPageNode = (Node)resource.adaptTo(Node.class);
/*  80 */       Node landingPageNode = searchPageNode.getParent();
/*     */       
/*  82 */       StringBuffer sb = null;
/*  83 */       if (landingPageNode.hasNode("jcr:content")) {
/*  84 */         Node landingJcrNode = landingPageNode.getNode("jcr:content");
/*  85 */         if (landingJcrNode.hasProperty("landingJsonName"))
/*     */         {
/*  87 */           landingDetails = landingJcrNode.getProperty("landingJsonName").getString();
/*  88 */           if (landingDetails.equalsIgnoreCase("")) {
/*  89 */             log.debug("Landing Page JSON Name Property Not found . Offers cannot be fetched ");
/*  90 */             return offerJson;
/*     */           }
/*  92 */           sb = new StringBuffer(landingDetails);
/*  93 */           sb.append(".json");
/*  94 */           jsonFileName = sb.toString();
/*     */         }
/*     */       }
/*  97 */       if (jsonFileName.equalsIgnoreCase("failure")) {
/*  98 */         jsonFileName = VppJsonUtil.getLandingJsonFileName(landingPageNode);
/*  99 */         jsonFileName = jsonFileName + ".json";
/*     */       }
/*     */       
/* 102 */       offerJson = VppJsonUtil.getOfferJson(jcrSession, offerJsonLocation, jsonFileName);
/*     */     } catch (RepositoryException e) {
/* 104 */       log.error("RepositoryException occured in GetLandingPageOffers getOfferData() : " + e
/* 105 */         .getMessage());
/*     */     } catch (Exception e) {
/* 107 */       log.error("Exception occured in GetLandingPageOffers getOfferData() : " + e.getMessage());
/*     */     } finally {
/* 109 */       VppJsonUtil.closeResolver(resolver);
/*     */     }
/* 111 */     return offerJson;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\GetLandingPageOffersPremium.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */