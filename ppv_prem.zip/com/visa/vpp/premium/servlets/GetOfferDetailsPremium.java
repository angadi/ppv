/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.Session;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/OfferPopupPremium"}, methods={"GET"}, metatype=false)
/*     */ public class GetOfferDetailsPremium
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private static final Logger log = LoggerFactory.getLogger(GetOfferDetailsPremium.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  56 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  57 */     Node moreOffers = null;
/*  58 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  59 */     Session session = null;
/*     */     try {
/*  61 */       session = (Session)resolver.adaptTo(Session.class);
/*  62 */       String offerId = request.getParameter("id");
/*  63 */       offerId = xssApi.encodeForHTML(offerId);
/*  64 */       String currentPagePath = request.getParameter("currentPagePath");
/*  65 */       currentPagePath = xssApi.encodeForHTML(currentPagePath);
/*  66 */       Page searchPage = null;
/*     */       
/*  68 */       String previewUrl = "";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */       Node pageNode = session.getNode(currentPagePath + "/jcr:content");
/*  76 */       if (pageNode.getProperty("sling:resourceType").getString().contains("category_page")) {
/*  77 */         if (pageNode.hasNode("more_offers")) {
/*  78 */           moreOffers = pageNode.getNode("more_offers");
/*  79 */           if (moreOffers.hasNode(offerId)) {
/*  80 */             Node offer = moreOffers.getNode(offerId);
/*  81 */             previewUrl = offer.getProperty("previewURL").getString();
/*     */           }
/*     */         }
/*     */       } else {
/*  85 */         PageManager pageMgr = (PageManager)resolver.adaptTo(PageManager.class);
/*  86 */         if ((pageNode.getProperty("sling:resourceType").getString().contains("bookmarks_page")) || 
/*  87 */           (pageNode.getProperty("sling:resourceType").getString().contains("search_page"))) {
/*  88 */           searchPage = pageMgr.getPage(currentPagePath).getParent();
/*     */         } else {
/*  90 */           searchPage = pageMgr.getPage(currentPagePath);
/*     */         }
/*  92 */         Iterator<Page> listChildPages = searchPage.listChildren();
/*  93 */         while (listChildPages.hasNext()) {
/*  94 */           Page child = (Page)listChildPages.next();
/*     */           
/*  96 */           pageNode = session.getNode(child.getPath() + "/jcr:content");
/*  97 */           if (pageNode.hasNode("more_offers")) {
/*  98 */             moreOffers = pageNode.getNode("more_offers");
/*  99 */             if (moreOffers.hasNode(offerId)) {
/* 100 */               Node offer = moreOffers.getNode(offerId);
/* 101 */               previewUrl = offer.getProperty("previewURL").getString();
/* 102 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */       String finalPath = previewUrl.split(".html")[0] + ".popup.html";
/* 115 */       response.setCharacterEncoding("UTF-8");
/* 116 */       RequestDispatcher dispatcher = request.getRequestDispatcher(finalPath);
/* 117 */       dispatcher.include(request, response);
/*     */     }
/*     */     catch (Exception e) {
/* 120 */       log.error("Exception occured in " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\GetOfferDetailsPremium.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */