/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.jcr.Binary;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.Workspace;
/*     */ import javax.jcr.query.Query;
/*     */ import javax.jcr.query.QueryManager;
/*     */ import javax.jcr.query.QueryResult;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(immediate=true, metatype=true, label="[VPP Platform] - ImageRenderServlet")
/*     */ @Service({Servlet.class})
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="sling.servlet.extensions", value={"jpg", "gif", "png", "jpeg"}), @org.apache.felix.scr.annotations.Property(name="sling.servlet.resourceTypes", value={"sling/servlet/default"}), @org.apache.felix.scr.annotations.Property(name="sling.servlet.methods", value={"GET"}), @org.apache.felix.scr.annotations.Property(name="sling.servlet.selectors", value={"web"})})
/*     */ public class ImageRenderServlet
/*     */   extends SlingSafeMethodsServlet
/*     */ {
/*  41 */   private static final Logger log = LoggerFactory.getLogger(ImageRenderServlet.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String CROP_SELECTOR = "web";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String IMAGE_NOT_EXIST = "";
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  56 */     log.debug(" ImageRenderServlet called");
/*  57 */     log.debug(" request resourece path " + request.getResource().getPath());
/*  58 */     String originalPath = request.getResource().getPath();
/*  59 */     String selectorsPath = originalPath.substring(originalPath.lastIndexOf("/")).replace("/", "");
/*     */     
/*     */ 
/*  62 */     String[] array = selectorsPath.split("\\.");
/*     */     
/*  64 */     String fileName = array[0] + "." + array[(array.length - 1)];
/*  65 */     String renditionSize = array[2] + "." + array[3];
/*  66 */     String mimeType = "";
/*     */     
/*     */ 
/*  69 */     String modPath = originalPath.replace(selectorsPath, fileName);
/*     */     
/*  71 */     Node node = null;
/*     */     
/*  73 */     InputStream content = null;
/*     */     try
/*     */     {
/*  76 */       if (null != modPath) {
/*  77 */         ResourceResolver resourceResolver = request.getResourceResolver();
/*  78 */         log.debug("modpath " + modPath);
/*  79 */         log.debug("renditionSize" + renditionSize);
/*  80 */         if (resourceResolver != null) {
/*  81 */           Session session = (Session)resourceResolver.adaptTo(Session.class);
/*  82 */           QueryManager queryManager = session.getWorkspace().getQueryManager();
/*     */           
/*     */ 
/*  85 */           String sqlStatement = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + modPath + "]) and CONTAINS(s.*, '" + renditionSize + "')";
/*     */           
/*     */ 
/*  88 */           Query query = queryManager.createQuery(sqlStatement, "JCR-SQL2");
/*     */           
/*     */ 
/*  91 */           QueryResult result = query.execute();
/*     */           
/*     */ 
/*  94 */           NodeIterator nodeIter = result.getNodes();
/*     */           
/*  96 */           while (nodeIter.hasNext())
/*     */           {
/*  98 */             node = nodeIter.nextNode();
/*     */             
/* 100 */             mimeType = node.getNode("jcr:content").getProperty("jcr:mimeType").getValue().getString();
/* 101 */             response.setContentType(mimeType);
/*     */             try {
/* 103 */               content = node.getNode("jcr:content").getProperty("jcr:data").getBinary().getStream();
/*     */             } finally {
/* 105 */               VppUtil.closeInputStream(content);
/*     */             }
/*     */             
/* 108 */             response.getOutputStream().write(IOUtils.toByteArray(content));
/* 109 */             log.debug("test  node path" + node.getPath());
/* 110 */             log.debug("mime type " + mimeType);
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 116 */           log.error("resourceResolver is Null");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 121 */       log.error("ImageRenderServlet RepositoryException" + e);
/*     */     }
/*     */     catch (Exception e) {
/* 124 */       log.error("Image Not Found" + e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\ImageRenderServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */