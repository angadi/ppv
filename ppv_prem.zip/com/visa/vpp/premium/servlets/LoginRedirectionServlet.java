/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/userRedirection"}, methods={"GET"}, metatype=false)
/*     */ public class LoginRedirectionServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final String LANDING_PAGE_TEMPLATE = "welcome_page";
/*     */   private static final String FIRSTNAME = "firstName";
/*     */   private static final String ID = "id";
/*     */   private static final String BENEFIT_CODE = "benefitCode";
/*  38 */   private static final Logger log = LoggerFactory.getLogger(LoginRedirectionServlet.class);
/*     */   
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  48 */     String redirectPath = "";
/*  49 */     String userId = "";
/*  50 */     String firstName = "";
/*  51 */     String benefitCode = "";
/*     */     
/*     */     try
/*     */     {
/*  55 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*     */       
/*  57 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  58 */       String currPagePath = xssApi.encodeForHTML(request.getParameter("currentPagePath"));
/*  59 */       String validUserId = xssApi.encodeForHTML(request.getParameter("id"));
/*  60 */       String validFirstName = xssApi.encodeForHTML(request.getParameter("firstName"));
/*  61 */       String validBenefitCode = xssApi.encodeForHTML(request.getParameter("benefitCode"));
/*  62 */       if (validString(validUserId, "^[0-9]{4,50}$")) {
/*  63 */         userId = validUserId;
/*     */       }
/*  65 */       if (validString(validFirstName, "^[a-zA-Z ]{1,50}$")) {
/*  66 */         firstName = validFirstName;
/*     */       }
/*  68 */       if (validString(validBenefitCode, "^[a-zA-Z0-9-]{1,500}$")) {
/*  69 */         benefitCode = validBenefitCode;
/*     */       }
/*  71 */       response.setContentType("text/plain");
/*  72 */       Resource resource = resolver.getResource(currPagePath);
/*  73 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  75 */       Page landingPage = getLandingPage(currentPage.getPath());
/*  76 */       if (landingPage != null) {
/*  77 */         log.debug("Redirecting to landing page ");
/*  78 */         StringBuilder sb = new StringBuilder(landingPage.getPath());
/*  79 */         sb.append(".html");
/*  80 */         redirectPath = sb.toString();
/*  81 */         HttpSession session = request.getSession();
/*  82 */         if (null != userId) {
/*  83 */           session.setAttribute("userId", userId);
/*     */         }
/*  85 */         if (null != firstName) {
/*  86 */           session.setAttribute("firstName", firstName);
/*     */         }
/*  88 */         if (null != benefitCode) {
/*  89 */           session.setAttribute("benefitTypeCode", benefitCode);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/*  95 */         log.debug("landing page not found redirecting to home page");
/*  96 */         StringBuilder sb = new StringBuilder(currentPage.getPath());
/*  97 */         sb.append(".html");
/*  98 */         redirectPath = sb.toString();
/*     */       }
/*     */       
/* 101 */       response.getWriter().write(redirectPath);
/*     */     } catch (Exception e) {
/* 103 */       log.error("Exception Occured in LoginRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getLandingPage(String path)
/*     */   {
/* 118 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 119 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 120 */     Page rootPage = pageManager.getPage(path);
/* 121 */     Page landingPage = null;
/*     */     
/* 123 */     if (null != rootPage) {
/* 124 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 125 */       while (rootPageIterator.hasNext()) {
/* 126 */         Page childPage = (Page)rootPageIterator.next();
/* 127 */         if ((childPage != null) && (childPage.getTemplate().getName().equals("welcome_page"))) {
/* 128 */           landingPage = childPage;
/* 129 */           break;
/*     */         }
/*     */       }
/*     */       
/* 133 */       return landingPage;
/*     */     }
/* 135 */     return landingPage;
/*     */   }
/*     */   
/*     */   public boolean validString(String accessTokenString, String pattern) {
/* 139 */     if (accessTokenString.matches(pattern)) {
/* 140 */       return true;
/*     */     }
/* 142 */     log.debug("This is an invalid string");
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\LoginRedirectionServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */