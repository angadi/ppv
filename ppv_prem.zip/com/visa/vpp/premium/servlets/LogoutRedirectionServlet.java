/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/userSignout"}, methods={"GET"}, metatype=false)
/*     */ public class LogoutRedirectionServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final String LOGIN_LINK = "#log-in";
/*     */   private static final int HOME_PAGE_DEPTH = 6;
/*  38 */   private static final Logger log = LoggerFactory.getLogger(LogoutRedirectionServlet.class);
/*     */   
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  47 */     String currPagePath = request.getParameter("currentPagePath");
/*     */     
/*  49 */     String redirectPath = "";
/*     */     
/*     */     try
/*     */     {
/*  53 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  54 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  55 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/*     */       
/*  57 */       response.setContentType("text/plain");
/*  58 */       Resource resource = resolver.getResource(currPagePath);
/*  59 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  61 */       Page homePage = getHomePage(currentPage.getPath());
/*  62 */       if (homePage != null) {
/*  63 */         log.debug("Redirecting to home page ");
/*  64 */         StringBuilder sb = new StringBuilder(homePage.getPath());
/*  65 */         sb.append(".html");
/*  66 */         sb.append("#log-in");
/*  67 */         redirectPath = sb.toString();
/*     */         
/*  69 */         HttpSession session = request.getSession(true);
/*  70 */         session.invalidate();
/*     */       }
/*     */       else {
/*  73 */         log.debug("landing page not found redirecting to home page");
/*  74 */         StringBuilder sb = new StringBuilder(currentPage.getPath());
/*  75 */         sb.append(".html");
/*  76 */         redirectPath = xssApi.encodeForHTML(sb.toString());
/*     */       }
/*  78 */       response.getWriter().write(redirectPath);
/*     */     } catch (Exception e) {
/*  80 */       log.error("Exception Occured in LogoutRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getHomePage(String path)
/*     */   {
/*  95 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  96 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/*  97 */     Page rootPage = pageManager.getPage(path);
/*  98 */     Page homePage = null;
/*  99 */     if (null != rootPage) {
/* 100 */       homePage = rootPage.getAbsoluteParent(5);
/*     */     }
/* 102 */     return homePage;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\LogoutRedirectionServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */