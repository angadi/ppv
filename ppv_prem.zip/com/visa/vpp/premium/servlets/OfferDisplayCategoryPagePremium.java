/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.InvalidItemStateException;
/*     */ import javax.jcr.ItemExistsException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.ReferentialIntegrityException;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.ValueFactory;
/*     */ import javax.jcr.lock.LockException;
/*     */ import javax.jcr.nodetype.ConstraintViolationException;
/*     */ import javax.jcr.nodetype.NoSuchNodeTypeException;
/*     */ import javax.jcr.version.VersionException;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/offerDisplayCategoryPagePremium"}, methods={"POST"}, metatype=false)
/*     */ public class OfferDisplayCategoryPagePremium
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String SELECTED_OFFER_JSON_STRING = "selectedJson";
/*     */   private static final String PAGE_PATH = "pagePath";
/*     */   private static final String NT_UNSTRUCTURED = "nt:unstructured";
/*     */   private static final String SLING_RESOURCETYPE_PROPERTY = "foundation/components/parsys";
/*     */   private static final String SLING_RESOURCETYPE_COMPONENT = "vpp_premium/components/content/offer_category";
/*     */   private static final String TRUE = "true";
/*  61 */   private static final Logger logger = LoggerFactory.getLogger(OfferDisplayCategoryPagePremium.class);
/*     */   
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  73 */     String checkCondition = createDynamicComponents(request);
/*  74 */     response.setContentType("application/text");
/*  75 */     response.getWriter().write(checkCondition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createDynamicComponents(SlingHttpServletRequest request)
/*     */   {
/*  84 */     String firstTimeCheck = "false";
/*  85 */     Node moreOffers = null;
/*  86 */     String condition = "failure";
/*  87 */     String catPageName = "";
/*  88 */     ArrayList<String> nodeCombinedArrList = new ArrayList();
/*     */     
/*  90 */     String jsonString = request.getParameter("selectedJson");
/*     */     
/*  92 */     String selectedJsonString = null;
/*  93 */     if (validString(jsonString, ".*")) {
/*  94 */       selectedJsonString = jsonString;
/*     */     }
/*     */     
/*  97 */     String pagePath = request.getParameter("pagePath");
/*  98 */     if ((selectedJsonString == null) || (selectedJsonString.length() == 0)) {
/*  99 */       return condition;
/*     */     }
/* 101 */     if ((pagePath == null) || (pagePath.length() == 0)) {
/* 102 */       return condition;
/*     */     }
/*     */     
/*     */ 
/* 106 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 107 */     Session session = (Session)resolver.adaptTo(Session.class);
/* 108 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/* 109 */     pagePath = xssApi.encodeForHTML(pagePath);
/*     */     try
/*     */     {
/* 112 */       Node rootNode = session.getRootNode();
/* 113 */       if (rootNode.hasNode(pagePath.substring(1) + "/jcr:content")) {
/* 114 */         Node pageNode = rootNode.getNode(pagePath.substring(1) + "/jcr:content");
/*     */         
/* 116 */         catPageName = pageNode.getParent().getName();
/* 117 */         Node landingPageNode = pageNode.getParent().getParent();
/* 118 */         String checkFileCreation = createCategoryJson(selectedJsonString, catPageName, session, pagePath, landingPageNode);
/*     */         
/* 120 */         if (checkFileCreation.equalsIgnoreCase("success")) {
/* 121 */           logger.debug("file created successfully!!!!");
/*     */         } else {
/* 123 */           logger.debug("file creation failed!!!!");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 128 */         if (!pageNode.hasNode("more_offers")) {
/* 129 */           firstTimeCheck = "true";
/* 130 */           moreOffers = pageNode.addNode("more_offers", "nt:unstructured");
/* 131 */           moreOffers.setProperty("sling:resourceType", "foundation/components/parsys");
/* 132 */           logger.debug("added the more offers parsys node" + firstTimeCheck);
/*     */         } else {
/* 134 */           moreOffers = pageNode.getNode("more_offers");
/*     */         }
/*     */         
/* 137 */         JSONObject selectedJsonObj = new JSONObject(selectedJsonString);
/* 138 */         Iterator<String> iterator = selectedJsonObj.keys();
/* 139 */         if (firstTimeCheck.equalsIgnoreCase("true")) {
/* 140 */           logger.debug("first time the components will be created");
/* 141 */           while (iterator.hasNext()) {
/* 142 */             String jsonObjKey = ((String)iterator.next()).toString();
/* 143 */             JSONObject childJsonObj = selectedJsonObj.getJSONObject(jsonObjKey);
/* 144 */             createNode(childJsonObj, jsonObjKey, moreOffers, pagePath, session);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 149 */           Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(pagePath, rootNode, "MODIFIED");
/* 150 */           if (setPropertyCheck.booleanValue()) {
/* 151 */             logger.debug("modified property set successfully");
/*     */           }
/*     */         }
/*     */         else {
/* 155 */           ArrayList<String> selectedArrList = copyIterator(iterator);
/*     */           
/*     */ 
/* 158 */           ArrayList<String> moreofferArrList = getNodeArray(moreOffers);
/*     */           
/*     */ 
/*     */ 
/* 162 */           nodeCombinedArrList.addAll(moreofferArrList);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */           ArrayList<String> deletedArrayList = getmodifiedArrList(nodeCombinedArrList, selectedArrList);
/* 171 */           if (deletedArrayList.size() != 0)
/*     */           {
/*     */ 
/* 174 */             moreofferArrList = removeElement(moreofferArrList, deletedArrayList);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */           ArrayList<String> newOfferArrList = getmodifiedArrList(selectedArrList, nodeCombinedArrList);
/*     */           
/* 183 */           if ((deletedArrayList.size() != 0) || (newOfferArrList.size() != 0)) {
/* 184 */             ArrayList<String> newOrderArrList = new ArrayList();
/* 185 */             newOrderArrList.addAll(newOfferArrList);
/* 186 */             newOrderArrList.addAll(moreofferArrList);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 191 */             if (pageNode.hasNode("more_offers")) {
/* 192 */               pageNode.getNode("more_offers").remove();
/* 193 */               logger.debug("node removed successfully");
/*     */             }
/* 195 */             moreOffers = pageNode.addNode("more_offers", "nt:unstructured");
/* 196 */             moreOffers.setProperty("sling:resourceType", "foundation/components/parsys");
/* 197 */             logger.debug("added the more offers parsys node next time");
/* 198 */             for (String jsonObjKey : newOrderArrList) {
/* 199 */               JSONObject childJsonObj = selectedJsonObj.getJSONObject(jsonObjKey);
/* 200 */               createNode(childJsonObj, jsonObjKey, moreOffers, pagePath, session);
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 205 */             Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(pagePath, rootNode, "MODIFIED");
/* 206 */             if (setPropertyCheck.booleanValue()) {
/* 207 */               logger.debug("modified property set successfully");
/*     */             }
/*     */           } else {
/* 210 */             logger.debug("no new offers are added/deleted ,so no changes");
/*     */           }
/*     */         }
/*     */         
/* 214 */         session.save();
/* 215 */         condition = "success";
/*     */       }
/*     */     } catch (JSONException e) {
/* 218 */       logger.error("JSONException occured in createDynamicComponents()" + e.getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 220 */       logger.error("PathNotFoundException occured in createDynamicComponents()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 222 */       logger.error("RepositoryException occured in createDynamicComponents()" + e.getMessage());
/*     */     } finally {
/* 224 */       VppJsonUtil.closeResolver(resolver);
/*     */     }
/*     */     
/* 227 */     logger.debug("condition" + condition);
/* 228 */     return condition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNode(JSONObject childJsonObj, String key, Node moreOffers, String pagePath, Session session)
/*     */   {
/* 242 */     logger.debug("creating more-offer nodes");
/* 243 */     String offerTitle = "";
/* 244 */     String offerShortDesc = "";
/* 245 */     String thumbImage = "";
/* 246 */     String previewUrl = "";
/* 247 */     String offerSource = "";
/* 248 */     String offerLastModified = "";
/* 249 */     ArrayList valueArray = new ArrayList();
/* 250 */     String heroImage = "";
/* 251 */     Boolean isMulti = Boolean.valueOf(false);
/* 252 */     String checkMulti = "";
/* 253 */     String pageType = "";
/*     */     try {
/* 255 */       ValueFactory valueFactory = session.getValueFactory();
/* 256 */       if (childJsonObj.has("offerTitle")) {
/* 257 */         offerTitle = childJsonObj.get("offerTitle").toString();
/*     */       }
/* 259 */       if (childJsonObj.has("offerShortDesc")) {
/* 260 */         offerShortDesc = childJsonObj.get("offerShortDesc").toString();
/*     */       }
/* 262 */       if (childJsonObj.has("thumbImage")) {
/* 263 */         thumbImage = childJsonObj.get("thumbImage").toString();
/*     */       }
/* 265 */       if (childJsonObj.has("heroImage")) {
/* 266 */         heroImage = childJsonObj.get("heroImage").toString();
/*     */       }
/* 268 */       if (childJsonObj.has("previewURL")) {
/* 269 */         previewUrl = childJsonObj.get("previewURL").toString();
/*     */       }
/* 271 */       if (childJsonObj.has("pageType")) {
/* 272 */         pageType = childJsonObj.get("pageType").toString();
/*     */       }
/* 274 */       if (childJsonObj.has("offerSource")) {
/* 275 */         offerSource = childJsonObj.get("offerSource").toString();
/*     */       }
/* 277 */       if (childJsonObj.has("offerLastModified")) {
/* 278 */         offerLastModified = childJsonObj.get("offerLastModified").toString();
/*     */       }
/* 280 */       if (childJsonObj.has("benefitTypeCode")) {
/* 281 */         checkMulti = childJsonObj.get("benefitTypeCode").toString();
/* 282 */         if (checkMulti.contains("[")) {
/* 283 */           isMulti = Boolean.valueOf(true);
/* 284 */           JSONArray arr = childJsonObj.getJSONArray("benefitTypeCode");
/* 285 */           for (int i = 0; i < arr.length(); i++)
/*     */           {
/* 287 */             valueArray.add(arr.getString(i));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 293 */       if (offerSource.equalsIgnoreCase("AEM")) {
/* 294 */         Boolean check = offerMap(previewUrl, pagePath, session);
/* 295 */         if (check.booleanValue()) {
/* 296 */           logger.debug("offer tagged to category page");
/*     */         }
/*     */       }
/* 299 */       String validKey = "";
/* 300 */       if (validString(key, "^[a-zA-Z0-9-]{1,50}$")) {
/* 301 */         validKey = key;
/*     */       }
/* 303 */       if (!moreOffers.hasNode(key)) {
/* 304 */         Node offerNode = moreOffers.addNode(key, "nt:unstructured");
/*     */         
/* 306 */         offerNode.setProperty("offerId", validKey);
/* 307 */         offerNode.setProperty("offerTitle", offerTitle);
/* 308 */         offerNode.setProperty("offerShortDesc", offerShortDesc);
/* 309 */         offerNode.setProperty("thumbImage", thumbImage);
/* 310 */         offerNode.setProperty("heroImage", heroImage);
/* 311 */         offerNode.setProperty("previewURL", previewUrl);
/* 312 */         offerNode.setProperty("pageType", pageType);
/* 313 */         offerNode.setProperty("offerSource", offerSource);
/* 314 */         offerNode.setProperty("offerLastModified", offerLastModified);
/* 315 */         if (isMulti.booleanValue()) {
/* 316 */           Value[] benefitTypeCode = new Value[valueArray.size()];
/* 317 */           for (int i = 0; i < valueArray.size(); i++) {
/* 318 */             benefitTypeCode[i] = valueFactory.createValue(valueArray.get(i).toString());
/*     */           }
/* 320 */           if (valueArray.size() > 0) {
/* 321 */             offerNode.setProperty("benefitTypeCode", benefitTypeCode);
/*     */           }
/*     */         } else {
/* 324 */           offerNode.setProperty("benefitTypeCode", checkMulti);
/*     */         }
/* 326 */         offerNode.setProperty("sling:resourceType", "vpp_premium/components/content/offer_category");
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 330 */       logger.error("JSONException occured in createNode()" + e.getMessage());
/*     */     } catch (ItemExistsException e) {
/* 332 */       logger.error("ItemExistsException occured in createNode()" + e.getMessage());
/*     */     } catch (PathNotFoundException e) {
/* 334 */       logger.error("PathNotFoundException occured in createNode()" + e.getMessage());
/*     */     } catch (NoSuchNodeTypeException e) {
/* 336 */       logger.error("NoSuchNodeTypeException occured in createNode()" + e.getMessage());
/*     */     } catch (LockException e) {
/* 338 */       logger.error("LockException occured in createNode()" + e.getMessage());
/*     */     } catch (VersionException e) {
/* 340 */       logger.error("VersionException occured in createNode()" + e.getMessage());
/*     */     } catch (ConstraintViolationException e) {
/* 342 */       logger.error("ConstraintViolationException occured in createNode()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 344 */       logger.error("RepositoryException occured in createNode()" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> copyIterator(Iterator<String> iter)
/*     */   {
/* 356 */     ArrayList<String> selectedArrList = new ArrayList();
/* 357 */     while (iter.hasNext()) {
/* 358 */       selectedArrList.add(iter.next());
/*     */     }
/* 360 */     return selectedArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getNodeArray(Node offerNode)
/*     */   {
/* 370 */     ArrayList<String> subNodeArrList = new ArrayList();
/*     */     try {
/* 372 */       NodeIterator offerNodeItr = offerNode.getNodes();
/* 373 */       while (offerNodeItr.hasNext()) {
/* 374 */         Node childNode = offerNodeItr.nextNode();
/* 375 */         if (childNode.hasProperty("offerId")) {
/* 376 */           String offerId = childNode.getProperty("offerId").getString();
/* 377 */           subNodeArrList.add(offerId);
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 381 */       logger.error("RepositoryException in getNodeArray " + e.getMessage());
/*     */     }
/* 383 */     return subNodeArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> getmodifiedArrList(ArrayList<String> list1, ArrayList<String> list2)
/*     */   {
/* 394 */     ArrayList<String> modifiedArrList = new ArrayList(list1);
/* 395 */     modifiedArrList.removeAll(list2);
/* 396 */     return modifiedArrList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> removeElement(ArrayList<String> moreOffers, ArrayList<String> deletedOffers)
/*     */   {
/* 408 */     for (String i : deletedOffers) {
/* 409 */       if (moreOffers.contains(i)) {
/* 410 */         moreOffers.remove(i);
/* 411 */         logger.debug("removed offer ******" + i);
/*     */       }
/*     */     }
/* 414 */     return moreOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createCategoryJson(String selectedJsonString, String catPageName, Session session, String pagePath, Node landingPageNode)
/*     */   {
/* 432 */     String statusCheck = "failure";
/* 433 */     String landingPageFileName = "";
/*     */     try {
/* 435 */       String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(pagePath);
/*     */       
/* 437 */       if (landingPageNode.hasNode("jcr:content")) {
/* 438 */         Node landPageJcrContent = landingPageNode.getNode("jcr:content");
/* 439 */         if (!landPageJcrContent.hasProperty("landingJsonName"))
/*     */         {
/* 441 */           landingPageFileName = VppJsonUtil.getLandingJsonFileName(landingPageNode);
/*     */           
/* 443 */           landPageJcrContent.setProperty("landingJsonName", landingPageFileName);
/*     */         } else {
/* 445 */           logger.debug("landingPageFileName property is already set");
/*     */           
/* 447 */           landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/*     */         }
/*     */       }
/* 450 */       JSONObject selectedJson = new JSONObject(selectedJsonString);
/*     */       
/* 452 */       JSONObject categoryPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileName);
/* 453 */       categoryPageJson.put(pagePath, selectedJson);
/* 454 */       String catPageJsonName = catPageName + ".json";
/*     */       
/* 456 */       String fileCheck = createCategoryJsonFile(jsonFileLocation, landingPageFileName, session, categoryPageJson, catPageJsonName);
/*     */       
/* 458 */       session.save();
/* 459 */       if (fileCheck.equalsIgnoreCase("success")) {
/* 460 */         statusCheck = "success";
/*     */       }
/*     */     } catch (JSONException e) {
/* 463 */       logger.debug("JSONException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 464 */         .getMessage());
/*     */     } catch (AccessDeniedException e) {
/* 466 */       logger.debug("AccessDeniedException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 467 */         .getMessage());
/*     */     } catch (ItemExistsException e) {
/* 469 */       logger.debug("ItemExistsException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 470 */         .getMessage());
/*     */     }
/*     */     catch (ReferentialIntegrityException e) {
/* 473 */       logger.debug("ReferentialIntegrityException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 474 */         .getMessage());
/*     */     }
/*     */     catch (ConstraintViolationException e) {
/* 477 */       logger.debug("ConstraintViolationException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 478 */         .getMessage());
/*     */     } catch (InvalidItemStateException e) {
/* 480 */       logger.debug("InvalidItemStateException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 481 */         .getMessage());
/*     */     } catch (VersionException e) {
/* 483 */       logger.debug("VersionException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 484 */         .getMessage());
/*     */     } catch (LockException e) {
/* 486 */       logger.debug("LockException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 487 */         .getMessage());
/*     */     } catch (NoSuchNodeTypeException e) {
/* 489 */       logger.debug("NoSuchNodeTypeException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 490 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 492 */       logger.debug("RepositoryException in OfferDisplayCategoryPage of createCategoryJSON()" + e
/* 493 */         .getMessage());
/*     */     }
/* 495 */     return statusCheck;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createCategoryJsonFile(String jsonFileLocation, String landingFileName, Session session, JSONObject jsonObj, String categoryPageName)
/*     */   {
/* 510 */     String checkStatus = "failure";
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 516 */       Node rootNode = session.getRootNode();
/* 517 */       if (rootNode.hasNode(jsonFileLocation)) {
/* 518 */         Node parentFilePathNode = rootNode.getNode(jsonFileLocation);
/* 519 */         Node landingFolder; Node landingFolder; if (!parentFilePathNode.hasNode(landingFileName)) {
/* 520 */           landingFolder = parentFilePathNode.addNode(landingFileName, "nt:folder");
/*     */         } else
/* 522 */           landingFolder = parentFilePathNode.getNode(landingFileName);
/*     */         Node fileJcrNode;
/* 524 */         if (!landingFolder.hasNode(categoryPageName)) {
/* 525 */           Node fileNode = landingFolder.addNode(categoryPageName, "nt:file");
/* 526 */           Node fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 527 */           logger.debug("Create  Operation : JSON Created for the first time");
/*     */         } else {
/* 529 */           Node fileNode = landingFolder.getNode(categoryPageName);
/* 530 */           fileJcrNode = fileNode.getNode("jcr:content");
/*     */         }
/* 532 */         if (fileJcrNode != null) {
/* 533 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 534 */           fileJcrNode.setProperty("jcr:data", jsonObj.toString());
/* 535 */           checkStatus = "success";
/* 536 */           logger.debug("json file updated" + checkStatus);
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 540 */       logger.error("RepositoryException  Occured in  createCategoryJsonFile() :" + e.getMessage());
/*     */     }
/* 542 */     return checkStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean offerMap(String previewUrl, String pagePath, Session session)
/*     */   {
/* 554 */     Boolean offerMapStatus = Boolean.valueOf(false);
/* 555 */     String offerPath = VppJsonUtil.getOfferDataPath(previewUrl);
/*     */     
/* 557 */     Node offerNode = null;
/* 558 */     String categoryMap = "";
/* 559 */     JSONObject categoryMapObj = new JSONObject();
/*     */     try {
/* 561 */       Node rootNode = session.getRootNode();
/* 562 */       if (rootNode.hasNode(offerPath)) {
/* 563 */         offerNode = rootNode.getNode(offerPath);
/*     */       }
/* 565 */       if (offerNode != null) {
/* 566 */         if (offerNode.hasProperty("categoryMap")) {
/* 567 */           categoryMap = offerNode.getProperty("categoryMap").getString();
/* 568 */           categoryMapObj = new JSONObject(categoryMap);
/*     */         }
/* 570 */         categoryMapObj.put(pagePath, pagePath);
/* 571 */         categoryMap = categoryMapObj.toString();
/* 572 */         offerNode.setProperty("categoryMap", categoryMap);
/*     */         
/* 574 */         offerMapStatus = Boolean.valueOf(true);
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 577 */       logger.error("RepositoryException  Occured in  offerMap() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 579 */       logger.error("JSONException  Occured in  offerMap() :" + e.getMessage());
/*     */     }
/* 581 */     return offerMapStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean validString(String jsonString, String pattern)
/*     */   {
/* 591 */     if (jsonString.matches(pattern)) {
/* 592 */       return true;
/*     */     }
/* 594 */     logger.debug("This is an invalid string");
/* 595 */     return false;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\OfferDisplayCategoryPagePremium.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */