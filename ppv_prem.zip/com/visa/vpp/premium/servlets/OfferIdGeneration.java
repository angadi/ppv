/*    */ package com.visa.vpp.premium.servlets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.security.SecureRandom;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.PathNotFoundException;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.api.SlingHttpServletResponse;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*    */ import org.apache.sling.xss.XSSAPI;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SlingServlet(paths={"/bin/issuerOfferIdGenerationPremium"}, methods={"POST"}, metatype=false)
/*    */ public class OfferIdGeneration
/*    */   extends SlingAllMethodsServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String PAGE_PATH = "pagePath";
/*    */   private static final String CONTENT = "/content/";
/*    */   private static final String DOT_HTML = ".html";
/*    */   private static final String FORMATTER = "%06d";
/*    */   private static final String OFFER_APPROVAL_STATUS = "offerApprovalStatus";
/*    */   private static final String MODIFIED = "MODIFIED";
/*    */   private static final String AEM_OFFER_ID_PREFIX = "A";
/* 44 */   private static final Logger logger = LoggerFactory.getLogger(OfferIdGeneration.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 53 */     String pagePath = request.getParameter("pagePath");
/* 54 */     ResourceResolver resolver = request.getResourceResolver();
/* 55 */     XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/* 56 */     pagePath = xssApi.encodeForHTML(pagePath);
/* 57 */     int contentIndex = 0;
/* 58 */     int htmlIndex = 0;
/* 59 */     if (pagePath.contains("/content/")) {
/* 60 */       contentIndex = pagePath.indexOf("/content/");
/*    */     }
/* 62 */     String pagePathOri = pagePath.substring(contentIndex);
/* 63 */     if (pagePathOri.contains(".html")) {
/* 64 */       htmlIndex = pagePathOri.lastIndexOf(".html");
/*    */     }
/* 66 */     pagePathOri = pagePathOri.substring(0, htmlIndex);
/*    */     
/* 68 */     String offerId = "NotGenerated";
/*    */     
/*    */ 
/* 71 */     Session session = (Session)resolver.adaptTo(Session.class);
/*    */     try {
/* 73 */       Node pageNode = session.getNode(pagePathOri + "/jcr:content");
/* 74 */       if (!pageNode.hasProperty("offerId")) {
/* 75 */         SecureRandom random = new SecureRandom();
/* 76 */         int num = random.nextInt(1000000);
/* 77 */         String formatted = String.format("%06d", new Object[] { Integer.valueOf(num) });
/* 78 */         StringBuilder sb = new StringBuilder("A");
/* 79 */         sb.append(formatted);
/* 80 */         offerId = sb.toString();
/* 81 */         pageNode.setProperty("offerId", offerId);
/* 82 */         logger.debug("pageNode offer id property is created");
/*    */       }
/* 84 */       pageNode.setProperty("offerApprovalStatus", "MODIFIED");
/* 85 */       logger.debug("property set");
/* 86 */       session.save();
/*    */     } catch (PathNotFoundException e) {
/* 88 */       logger.error("PathNotFoundException" + e.getMessage());
/*    */     } catch (RepositoryException e) {
/* 90 */       logger.error("RepositoryException" + e.getMessage());
/*    */     } catch (Exception e) {
/* 92 */       logger.error("Exception Occured" + e.getMessage());
/*    */     } finally {
/* 94 */       if ((session != null) && (session.isLive())) {
/* 95 */         session.logout();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\OfferIdGeneration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */