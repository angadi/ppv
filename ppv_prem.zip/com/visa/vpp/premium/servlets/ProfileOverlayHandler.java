/*    */ package com.visa.vpp.premium.servlets;
/*    */ 
/*    */ import com.day.cq.wcm.api.Page;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*    */ import org.apache.sling.api.SlingHttpServletRequest;
/*    */ import org.apache.sling.api.SlingHttpServletResponse;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*    */ import org.apache.sling.xss.XSSAPI;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SlingServlet(paths={"/bin/profileOverlayHandlerPremium"}, methods={"GET"}, metatype=false)
/*    */ public class ProfileOverlayHandler
/*    */   extends SlingAllMethodsServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*    */   private static final String POPUP_SELECTOR = "popup";
/* 32 */   private static int LANDING_PAGE_DEPTH = 7;
/* 33 */   private static final Logger log = LoggerFactory.getLogger(ProfileOverlayHandler.class);
/*    */   
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/*    */   
/*    */ 
/*    */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 42 */     String currPagePath = request.getParameter("currentPagePath");
/* 43 */     String popupSelector = request.getParameter("popup");
/*    */     
/*    */     try
/*    */     {
/* 47 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 48 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/* 49 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/*    */       
/* 51 */       popupSelector = xssApi.encodeForHTML(popupSelector);
/*    */       
/* 53 */       Resource resource = resolver.getResource(currPagePath);
/* 54 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*    */       
/* 56 */       if (currentPage.getDepth() >= LANDING_PAGE_DEPTH) {
/* 57 */         Page landingPage = currentPage.getAbsoluteParent(LANDING_PAGE_DEPTH - 1);
/*    */         
/* 59 */         StringBuilder sb = new StringBuilder(landingPage.getPath());
/* 60 */         sb.append(".").append(popupSelector).append(".html");
/* 61 */         RequestDispatcher dispatcher = request.getRequestDispatcher(sb.toString());
/* 62 */         dispatcher.include(request, response);
/*    */       }
/*    */     } catch (Exception e) {
/* 65 */       log.debug("Exception Occured in ProfileOverlayHandler : " + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\ProfileOverlayHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */