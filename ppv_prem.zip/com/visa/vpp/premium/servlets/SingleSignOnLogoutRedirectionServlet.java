/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/userSingleSignOnSignout"}, methods={"GET"}, metatype=false)
/*     */ public class SingleSignOnLogoutRedirectionServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String CURR_PAGE_PATH = "currentPagePath";
/*     */   private static final int LOCALE_PAGE_DEPTH = 5;
/*  36 */   private static final Logger log = LoggerFactory.getLogger(SingleSignOnLogoutRedirectionServlet.class);
/*     */   
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  45 */     String currPagePath = request.getParameter("currentPagePath");
/*     */     
/*  47 */     String redirectPath = "";
/*     */     
/*     */     try
/*     */     {
/*  51 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  52 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  53 */       currPagePath = xssApi.encodeForHTML(currPagePath);
/*     */       
/*  55 */       response.setContentType("text/plain");
/*  56 */       Resource resource = resolver.getResource(currPagePath);
/*  57 */       Page currentPage = (Page)resource.adaptTo(Page.class);
/*     */       
/*  59 */       Page logoutPage = getLogoutPage(currentPage.getPath());
/*  60 */       if (logoutPage != null) {
/*  61 */         log.debug("Redirecting to logout page ");
/*  62 */         StringBuilder sb = new StringBuilder(logoutPage.getPath());
/*  63 */         sb.append(".html");
/*  64 */         redirectPath = sb.toString();
/*     */         
/*  66 */         HttpSession session = request.getSession(true);
/*  67 */         session.invalidate();
/*     */       }
/*     */       else {
/*  70 */         log.debug("landing page not found redirecting to home page");
/*  71 */         StringBuilder sb = new StringBuilder(currentPage.getPath());
/*  72 */         sb.append(".html");
/*  73 */         redirectPath = xssApi.encodeForHTML(sb.toString());
/*     */       }
/*  75 */       response.getWriter().write(redirectPath);
/*     */     } catch (Exception e) {
/*  77 */       log.error("Exception Occured in LogoutRedirectionServlet : " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getLogoutPage(String path)
/*     */   {
/*  91 */     log.debug("INside logout" + path);
/*     */     
/*  93 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  94 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/*  95 */     Page rootPage = pageManager.getPage(path);
/*  96 */     Page localePage = null;
/*  97 */     Page logoutPage = null;
/*  98 */     if (null != rootPage) {
/*  99 */       localePage = rootPage.getAbsoluteParent(4);
/* 100 */       log.debug("locale page" + localePage.getPath());
/* 101 */       Iterator<Page> rootPageIterator = localePage.listChildren();
/* 102 */       while (rootPageIterator.hasNext())
/*     */       {
/* 104 */         Page childPage = (Page)rootPageIterator.next();
/* 105 */         if ((childPage.getTemplate() != null) && (childPage.getTemplate().getName().contains("logout_page")))
/* 106 */           logoutPage = childPage;
/*     */       }
/*     */     }
/* 109 */     return logoutPage;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\SingleSignOnLogoutRedirectionServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */