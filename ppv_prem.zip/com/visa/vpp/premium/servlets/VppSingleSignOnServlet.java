/*     */ package com.visa.vpp.premium.servlets;
/*     */ 
/*     */ import com.day.cq.wcm.api.Page;
/*     */ import com.day.cq.wcm.api.PageManager;
/*     */ import com.day.cq.wcm.api.Template;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.sling.SlingServlet;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.apache.sling.xss.XSSAPI;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SlingServlet(paths={"/bin/vppSingleSignOn"}, methods={"POST"}, metatype=false)
/*     */ public class VppSingleSignOnServlet
/*     */   extends SlingAllMethodsServlet
/*     */ {
/*  47 */   private static final Logger logger = LoggerFactory.getLogger(VppSingleSignOnServlet.class);
/*     */   
/*     */   private static final String LANDING_PAGE_TEMPLATE = "welcome_page";
/*     */   
/*     */   private static final String LOGOUT_PAGE_TEMPLATE = "logout_page";
/*     */   private static final String HOME_PAGE_TEMPLATE = "home_page";
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */   protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  59 */     logger.debug("doPost init");
/*  60 */     String guid = "";
/*  61 */     String firstName = "";
/*  62 */     String benefitCode = "";
/*  63 */     String language = "";
/*  64 */     String issuer = "";
/*  65 */     String isNewUser = "";
/*  66 */     String redirectPath = "";
/*     */     try
/*     */     {
/*  69 */       ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*  70 */       XSSAPI xssApi = (XSSAPI)resolver.adaptTo(XSSAPI.class);
/*  71 */       String validGuId = xssApi.encodeForHTML(request.getParameter("guid"));
/*     */       
/*  73 */       String validFirstName = xssApi.encodeForHTML(request.getParameter("firstName"));
/*     */       
/*  75 */       String validBenefitCode = xssApi.encodeForHTML(request.getParameter("benefitCode"));
/*  76 */       String validLanguage = xssApi.encodeForHTML(request.getParameter("language"));
/*  77 */       String validIssuer = xssApi.encodeForHTML(request.getParameter("issuerName"));
/*  78 */       String validNewUser = xssApi.encodeForHTML(request.getParameter("isNewUser"));
/*  79 */       logger.debug("=========before sanitisation========");
/*  80 */       logger.debug("validGuId " + validGuId);
/*  81 */       logger.debug("validFirstName" + validFirstName);
/*  82 */       logger.debug("validBenefitCode" + validBenefitCode);
/*  83 */       logger.debug("validLanguage" + validLanguage);
/*  84 */       logger.debug("validIssuer " + validIssuer);
/*  85 */       logger.debug("validNewUser " + validNewUser);
/*  86 */       if ((null != validGuId) && (validString(validGuId, "^[0-9]{4,50}$"))) {
/*  87 */         guid = validGuId;
/*     */       }
/*  89 */       if ((null != validFirstName) && (validString(validFirstName, "^[a-zA-Z ]{1,50}$"))) {
/*  90 */         firstName = validFirstName;
/*     */       }
/*  92 */       if ((null != validBenefitCode) && 
/*  93 */         (validString(validBenefitCode, "^[a-zA-Z0-9-]{1,500}$"))) {
/*  94 */         benefitCode = validBenefitCode;
/*     */       }
/*  96 */       if ((null != validLanguage) && (validString(validLanguage, "^[a-zA-Z_]{1,50}$"))) {
/*  97 */         language = validLanguage;
/*     */       }
/*  99 */       if ((null != validIssuer) && (validString(validIssuer, "^[a-zA-Z ]{1,50}$"))) {
/* 100 */         issuer = validIssuer;
/*     */       }
/* 102 */       if ((null != validNewUser) && (validString(validNewUser, "^[a-zA-Z ]{1,50}$"))) {
/* 103 */         isNewUser = validNewUser;
/*     */       }
/* 105 */       logger.debug("========after sanitisation=============");
/* 106 */       logger.debug("guid " + guid);
/* 107 */       logger.debug("firstName " + firstName);
/* 108 */       logger.debug("benefitCode" + benefitCode);
/* 109 */       logger.debug("language " + language);
/* 110 */       logger.debug("issuer " + issuer);
/* 111 */       logger.debug("isNewUser " + isNewUser);
/* 112 */       if ((null != issuer) && (!"".equals(issuer)) && (null != language) && (!"".equals(language)) && (null != guid) && 
/* 113 */         (!"".equals(guid))) {
/* 114 */         logger.debug("redirecting to landing page");
/* 115 */         Page homePage = getPageByTemplateName("/content/vpp/premium/" + issuer + "/" + language, "home_page");
/*     */         
/* 117 */         Page landingPage = null;
/* 118 */         if (null != homePage) {
/* 119 */           logger.debug("homePage PATH" + homePage.getPath());
/* 120 */           landingPage = getPageByTemplateName(homePage.getPath(), "welcome_page");
/*     */         }
/* 122 */         if (null != landingPage) {
/* 123 */           logger.debug("landing page path" + landingPage.getPath());
/* 124 */           StringBuilder sb = new StringBuilder(landingPage.getPath());
/* 125 */           sb.append(".html");
/* 126 */           redirectPath = xssApi.encodeForHTML(sb.toString());
/* 127 */           HttpSession session = request.getSession();
/* 128 */           if (null != guid) {
/* 129 */             session.setAttribute("userId", guid);
/* 130 */             session.setAttribute("isSsoUser", guid);
/*     */           }
/*     */           
/* 133 */           if (null != firstName) {
/* 134 */             session.setAttribute("firstName", firstName);
/*     */           }
/* 136 */           if (null != benefitCode) {
/* 137 */             session.setAttribute("benefitTypeCode", benefitCode);
/*     */           }
/*     */         } else {
/* 140 */           Page lagoutPage = getPageByTemplateName("/content/vpp/premium/" + issuer + "/" + language, "logout_page");
/*     */           
/* 142 */           if (null != lagoutPage) {
/* 143 */             logger.debug("issuer landing page not found ,redirecting to logout page");
/* 144 */             StringBuilder sb = new StringBuilder(lagoutPage.getPath());
/* 145 */             sb.append(".html");
/* 146 */             redirectPath = xssApi.encodeForHTML(sb.toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 152 */       logger.error("Exception Occured in VppSingleSignOnServlet : " + e);
/*     */     }
/*     */     
/*     */ 
/* 156 */     if ((redirectPath != null) && (!"".equals(redirectPath)))
/*     */     {
/* 158 */       response.sendRedirect(redirectPath);
/*     */     }
/*     */     else {
/* 161 */       response.sendError(404);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 169 */     logger.debug("doGet init");
/* 170 */     doPost(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Page getPageByTemplateName(String path, String templateName)
/*     */   {
/* 182 */     logger.debug("path" + path);
/* 183 */     logger.debug("templateName" + templateName);
/*     */     
/* 185 */     ResourceResolver resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 186 */     PageManager pageManager = (PageManager)resolver.adaptTo(PageManager.class);
/* 187 */     Page rootPage = pageManager.getPage(path);
/* 188 */     Page landingPage = null;
/*     */     
/* 190 */     if (null != rootPage) {
/* 191 */       Iterator<Page> rootPageIterator = rootPage.listChildren();
/* 192 */       while (rootPageIterator.hasNext()) {
/* 193 */         Page childPage = (Page)rootPageIterator.next();
/* 194 */         if ((childPage != null) && (childPage.getTemplate().getName().equals(templateName))) {
/* 195 */           landingPage = childPage;
/* 196 */           break;
/*     */         }
/*     */       }
/*     */       
/* 200 */       logger.debug("found page path " + landingPage.getPath());
/* 201 */       return landingPage;
/*     */     }
/* 203 */     return landingPage;
/*     */   }
/*     */   
/*     */   public boolean validString(String accessTokenString, String pattern) {
/* 207 */     if (accessTokenString.matches(pattern)) {
/* 208 */       return true;
/*     */     }
/* 210 */     logger.debug("This is an invalid string");
/* 211 */     return false;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\servlets\VppSingleSignOnServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */