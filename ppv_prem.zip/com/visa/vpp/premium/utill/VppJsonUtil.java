/*     */ package com.visa.vpp.premium.utill;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.Binary;
/*     */ import javax.jcr.ItemNotFoundException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import javax.jcr.lock.LockException;
/*     */ import javax.jcr.nodetype.ConstraintViolationException;
/*     */ import javax.jcr.version.VersionException;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public final class VppJsonUtil
/*     */ {
/*  35 */   private static final Logger log = LoggerFactory.getLogger(VppJsonUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean checkPromotionDateValidity(String promoStart, String promoEnd)
/*     */   {
/*  47 */     Date currDate = new Date();
/*  48 */     DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  53 */       currDate = sdf.parse(sdf.format(currDate));
/*  54 */       Date promoStartDate = sdf.parse(promoStart);
/*  55 */       Date promoEndDate = sdf.parse(promoEnd);
/*  56 */       if ((currDate.compareTo(promoStartDate) >= 0) && (promoEndDate.compareTo(currDate) >= 0)) {
/*  57 */         return true;
/*     */       }
/*     */     }
/*     */     catch (ParseException e) {
/*  61 */       log.error("ParseException occured while parsing date in GetAvailableOffersJSON checkPromotionDateValidity()" + e
/*  62 */         .getMessage());
/*     */     } catch (Exception e) {
/*  64 */       log.error("Exception occured while parsing date in GetAvailableOffersJSON checkPromotionDateValidity()" + e
/*  65 */         .getMessage());
/*     */     }
/*  67 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONObject getOfferJson(Session jcrSession, String offerJsonLocation, String jsonFileName)
/*     */   {
/*  82 */     InputStream inputStream = null;
/*  83 */     StringBuilder jsonSb = new StringBuilder();
/*  84 */     JSONObject offerJson = new JSONObject();
/*  85 */     BufferedReader bufferRead = null;
/*     */     try
/*     */     {
/*  88 */       StringBuilder sb = new StringBuilder(offerJsonLocation);
/*  89 */       sb.append("/");
/*  90 */       sb.append(jsonFileName);
/*  91 */       sb.append("/");
/*  92 */       sb.append("jcr:content");
/*  93 */       String offerJsonfilePath = sb.toString();
/*  94 */       Node rootNode = jcrSession.getRootNode();
/*  95 */       if (rootNode.hasNode(offerJsonfilePath)) {
/*  96 */         Node fileJcrNode = rootNode.getNode(offerJsonfilePath);
/*  97 */         if (fileJcrNode.hasProperty("jcr:data")) {
/*  98 */           inputStream = fileJcrNode.getProperty("jcr:data").getBinary().getStream();
/*  99 */           bufferRead = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
/*     */           
/* 101 */           String line = "";
/* 102 */           while ((line = bufferRead.readLine()) != null) {
/* 103 */             jsonSb.append(line);
/*     */           }
/*     */         }
/*     */         
/* 107 */         offerJson = new JSONObject(jsonSb.toString());
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 110 */       log.error("Repository Exception Occured in GetAvailableOffersJSON getOfferJSON() :" + e
/* 111 */         .getMessage());
/*     */     } catch (IOException e) {
/* 113 */       log.error("IO Exception Occured in GetAvailableOffersJSON getOfferJSON() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 115 */       log.error("JSONException Occured in GetAvailableOffersJSON getOfferJSON()" + e.getMessage());
/*     */     } finally {
/* 117 */       VppUtil.closeBufferReader(bufferRead);
/* 118 */       VppUtil.closeInputStream(inputStream);
/*     */     }
/* 120 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOfferJsonLocation(String catPagePath)
/*     */   {
/* 131 */     String offerJsonLocation = "";
/*     */     try {
/* 133 */       String[] catPageArr = catPagePath.split("/");
/* 134 */       StringBuilder sb = new StringBuilder("etc/vpp-premium-tools/offers");
/* 135 */       sb.append("/");
/* 136 */       sb.append(catPageArr[4]);
/* 137 */       sb.append("/");
/* 138 */       sb.append(catPageArr[5]);
/* 139 */       offerJsonLocation = sb.toString();
/*     */     }
/*     */     catch (Exception e) {
/* 142 */       log.error("Exception Occured in GetAvailableOffersJSON getOfferJSONLocation() :" + e
/* 143 */         .getMessage());
/* 144 */       return "invalidPath";
/*     */     }
/* 146 */     return offerJsonLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeResolver(ResourceResolver resolver)
/*     */   {
/* 158 */     if (resolver != null) {
/* 159 */       log.debug("resolver closed ");
/* 160 */       resolver.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOfferDataPath(String offerUrl)
/*     */   {
/* 173 */     String offerDataPath = "invalidPath";
/*     */     try {
/* 175 */       offerUrl = offerUrl.substring(1, offerUrl.lastIndexOf(".html"));
/*     */       
/* 177 */       StringBuilder sb = new StringBuilder(offerUrl);
/* 178 */       sb.append("/");
/* 179 */       sb.append("jcr:content");
/* 180 */       sb.append("/");
/* 181 */       sb.append("offer_creation");
/* 182 */       offerDataPath = sb.toString();
/*     */     } catch (Exception e) {
/* 184 */       log.error("Exception Occured in  getOfferDataPath() :" + e.getMessage());
/*     */     }
/* 186 */     return offerDataPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createUpdateJsonFile(String jsonFileLocation, String jsonFileName, Session session, JSONObject jsonObj)
/*     */   {
/* 198 */     log.debug("jsonFileName" + jsonFileName);
/* 199 */     String checkStatus = "failure";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 204 */       Node rootNode = session.getRootNode();
/* 205 */       if (rootNode.hasNode(jsonFileLocation)) {
/* 206 */         Node parentFilePathNode = rootNode.getNode(jsonFileLocation);
/* 207 */         Node fileJcrNode; if (!parentFilePathNode.hasNode(jsonFileName)) {
/* 208 */           Node fileNode = parentFilePathNode.addNode(jsonFileName, "nt:file");
/* 209 */           Node fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 210 */           log.debug("Create  Operation : JSON Created for the first time");
/*     */         } else {
/* 212 */           Node fileNode = parentFilePathNode.getNode(jsonFileName);
/* 213 */           fileJcrNode = fileNode.getNode("jcr:content");
/*     */         }
/* 215 */         if (fileJcrNode != null) {
/* 216 */           fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 217 */           fileJcrNode.setProperty("jcr:data", jsonObj.toString());
/* 218 */           checkStatus = "success";
/* 219 */           log.debug("json file updated" + checkStatus);
/*     */         }
/*     */       }
/* 222 */       session.save();
/*     */     }
/*     */     catch (RepositoryException e) {
/* 225 */       log.error("RepositoryException  Occured in  createUpdateJsonFile() :" + e.getMessage());
/*     */     } catch (Exception e) {
/* 227 */       log.error("Exception  Occured in  createUpdateJsonFile() :" + e.getMessage());
/*     */     }
/*     */     
/* 230 */     return checkStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean areEqual(JSONObject targetObj, JSONObject sourceObj)
/*     */     throws JSONException
/*     */   {
/* 241 */     log.debug("Comparing Two JSONObjects for modifications ");
/* 242 */     log.debug("targetObj " + targetObj);
/* 243 */     log.debug("sourceObj " + sourceObj);
/*     */     try {
/* 245 */       Iterator<String> keys = sourceObj.keys();
/* 246 */       while (keys.hasNext()) {
/* 247 */         String key = (String)keys.next();
/* 248 */         String toCompare = sourceObj.getString(key);
/* 249 */         if (targetObj.has(key)) {
/* 250 */           String withCompare = targetObj.getString(key);
/* 251 */           if (!toCompare.equals(withCompare)) {
/* 252 */             log.debug("Key : " + key + " has unequal value in Both JSONs");
/* 253 */             return false;
/*     */           }
/*     */         } else {
/* 256 */           log.debug("Key : " + key + " not found in Target JSON Object");
/* 257 */           return false;
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 261 */       log.debug("Exception Occured while comparing two JSON Objects . Proceed as unequal objects " + e
/* 262 */         .getMessage());
/* 263 */       return false;
/*     */     }
/* 265 */     log.debug("Two JSONObjects are equal. No modifications found");
/* 266 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONObject getCurrOfferData(JSONObject aemOffers, String currOfferId)
/*     */   {
/* 276 */     JSONObject currentData = new JSONObject();
/*     */     
/* 278 */     String offerTitle = "";
/* 279 */     String merchName = "";
/* 280 */     String offerShortDesc = "";
/* 281 */     String thumbImage = "";
/* 282 */     String previewUrl = "";
/* 283 */     String offerLastModified = "";
/* 284 */     String offerSource = "";
/* 285 */     String benefitTypeCode = "";
/* 286 */     String heroImage = "";
/*     */     try {
/* 288 */       JSONObject currentOfferJson = aemOffers.getJSONObject(currOfferId);
/* 289 */       if (currentOfferJson.has("offerTitle")) {
/* 290 */         offerTitle = currentOfferJson.getString("offerTitle");
/*     */       }
/* 292 */       if (currentOfferJson.has("offerShortDesc")) {
/* 293 */         offerShortDesc = currentOfferJson.getString("offerShortDesc");
/*     */       }
/* 295 */       if (currentOfferJson.has("thumbImage")) {
/* 296 */         thumbImage = currentOfferJson.getString("thumbImage");
/*     */       }
/* 298 */       if (currentOfferJson.has("merchantName")) {
/* 299 */         merchName = currentOfferJson.getString("merchantName");
/*     */       }
/* 301 */       if (currentOfferJson.has("previewURL")) {
/* 302 */         previewUrl = currentOfferJson.getString("previewURL");
/*     */       }
/* 304 */       if (currentOfferJson.has("offerSource")) {
/* 305 */         offerSource = currentOfferJson.getString("offerSource");
/*     */       }
/* 307 */       if (currentOfferJson.has("offerLastModified")) {
/* 308 */         offerLastModified = currentOfferJson.getString("offerLastModified");
/*     */       }
/* 310 */       if (currentOfferJson.has("benefitTypeCode")) {
/* 311 */         benefitTypeCode = currentOfferJson.getString("benefitTypeCode");
/*     */       }
/* 313 */       if (currentOfferJson.has("heroImage")) {
/* 314 */         heroImage = currentOfferJson.getString("heroImage");
/*     */       }
/* 316 */       if (!merchName.equalsIgnoreCase("")) {
/* 317 */         offerTitle = merchName;
/*     */       }
/* 319 */       currentData.put("offerId", currOfferId);
/* 320 */       currentData.put("offerShortDesc", offerShortDesc);
/* 321 */       currentData.put("thumbImage", thumbImage);
/* 322 */       currentData.put("previewURL", previewUrl);
/* 323 */       currentData.put("offerTitle", offerTitle);
/* 324 */       currentData.put("offerSource", offerSource);
/* 325 */       currentData.put("offerLastModified", offerLastModified);
/* 326 */       currentData.put("benefitTypeCode", benefitTypeCode);
/* 327 */       currentData.put("heroImage", heroImage);
/*     */     } catch (JSONException e) {
/* 329 */       log.error("JSONException Occured in VPPJSONUtil getCurrOfferData()" + e.getMessage());
/*     */     } catch (Exception e) {
/* 331 */       log.error("Exception Occured in VPPJSONUtil getCurrOfferData()" + e.getMessage());
/*     */     }
/*     */     
/* 334 */     return currentData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean setCategoryApprovalStatus(String pagePath, Node rootNode, String propVal)
/*     */   {
/* 346 */     boolean catPropSet = false;
/* 347 */     StringBuffer sb = new StringBuffer();
/* 348 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/* 349 */     String catJcrPath = sb.toString();
/*     */     try
/*     */     {
/* 352 */       if (rootNode.hasNode(catJcrPath)) {
/* 353 */         Node catNode = rootNode.getNode(catJcrPath);
/*     */         
/* 355 */         catNode.setProperty("catApprovalStatus", propVal);
/* 356 */         log.debug("cat page approval status is set successfully" + propVal);
/* 357 */         catPropSet = true;
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 360 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 361 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 363 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 364 */         .getMessage());
/*     */     } catch (VersionException e) {
/* 366 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 367 */         .getMessage());
/*     */     } catch (LockException e) {
/* 369 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 370 */         .getMessage());
/*     */     } catch (ConstraintViolationException e) {
/* 372 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 373 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 375 */       log.error("PathNotFoundException in setCategoryApprovalStatus() of VPPJSONUtil" + e
/* 376 */         .getMessage());
/*     */     }
/* 378 */     return Boolean.valueOf(catPropSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized int offerFileIteration(String fileLangPath, Session session)
/*     */   {
/* 389 */     int count = 0;
/*     */     try {
/* 391 */       Node rootNode = session.getRootNode();
/* 392 */       if (rootNode.hasNode(fileLangPath)) {
/* 393 */         Node fileLangNode = rootNode.getNode(fileLangPath);
/* 394 */         log.debug("fileLangNode name" + fileLangNode.getName());
/* 395 */         NodeIterator nodeItr = fileLangNode.getNodes();
/* 396 */         while (nodeItr.hasNext()) {
/* 397 */           Node childNode = nodeItr.nextNode();
/* 398 */           if (childNode.hasProperty("jcr:primaryType"))
/*     */           {
/* 400 */             String jcrProp = childNode.getProperty("jcr:primaryType").getValue().getString();
/* 401 */             if (jcrProp.equalsIgnoreCase("nt:file")) {
/* 402 */               count++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 408 */       log.error("RepositoryException in offerFileIteration() of VPPJSONUtil" + e.getMessage());
/*     */     }
/* 410 */     log.debug("filecount" + count);
/* 411 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getLandingPageName(Node landingNode)
/*     */   {
/* 421 */     String landingPageFileName = "invalid";
/*     */     try {
/* 423 */       if (landingNode.hasNode("jcr:content")) {
/* 424 */         Node landPageJcrContent = landingNode.getNode("jcr:content");
/* 425 */         if (landPageJcrContent.hasProperty("landingJsonName"))
/*     */         {
/* 427 */           landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/* 428 */           log.debug("landingPageFileName property value" + landingPageFileName);
/*     */         } else {
/* 430 */           log.debug("landingPageFileName property is not set" + landingPageFileName);
/*     */         }
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 434 */       log.error("PathNotFoundException in getLandingPageName() of CreateLandingPageJson" + e
/* 435 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 437 */       log.error("ValueFormatException in getLandingPageName() of CreateLandingPageJson" + e
/* 438 */         .getMessage());
/*     */     } catch (IllegalStateException e) {
/* 440 */       log.error("IllegalStateException in getLandingPageName() of CreateLandingPageJson" + e
/* 441 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 443 */       log.error("RepositoryException in getLandingPageName() of CreateLandingPageJson" + e
/* 444 */         .getMessage());
/*     */     }
/* 446 */     return landingPageFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getLandingJsonFileName(Node landingNode)
/*     */   {
/* 456 */     String landingJsonFileName = "";
/*     */     try {
/* 458 */       Node subHomePageNode = landingNode.getParent();
/* 459 */       Node homePageNode = subHomePageNode.getParent();
/* 460 */       boolean isTwoLevelHome = false;
/* 461 */       String landingName = landingNode.getName();
/* 462 */       String subHomeName = subHomePageNode.getName();
/* 463 */       StringBuffer sb = new StringBuffer();
/*     */       
/* 465 */       if (homePageNode.hasNode("jcr:content")) {
/* 466 */         Node homePageJcrNode = homePageNode.getNode("jcr:content");
/* 467 */         if (homePageJcrNode.hasProperty("cq:template"))
/*     */         {
/* 469 */           String templateValue = homePageJcrNode.getProperty("cq:template").getValue().getString();
/*     */           
/* 471 */           if (templateValue.equalsIgnoreCase("/apps/vpp/templates/issuer_home")) {
/* 472 */             isTwoLevelHome = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 477 */       if (isTwoLevelHome) {
/* 478 */         String homePageName = homePageNode.getName();
/* 479 */         sb.append(homePageName).append("_").append(subHomeName)
/* 480 */           .append("_").append(landingName);
/* 481 */         log.debug("Two level home page");
/*     */       } else {
/* 483 */         sb.append(subHomeName).append("_").append(landingName);
/* 484 */         log.debug("One level home page");
/*     */       }
/* 486 */       landingJsonFileName = sb.toString();
/*     */     }
/*     */     catch (AccessDeniedException e)
/*     */     {
/* 490 */       log.error("AccessDeniedException in getLandingJsonFileName() of VppJSonUtil" + e
/* 491 */         .getMessage());
/*     */     } catch (ItemNotFoundException e) {
/* 493 */       log.error("ItemNotFoundException in getLandingJsonFileName() of VppJSonUtil" + e
/* 494 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 496 */       log.error("RepositoryException in getLandingJsonFileName() of VppJSonUtil" + e
/* 497 */         .getMessage());
/*     */     }
/* 499 */     return landingJsonFileName;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\utill\VppJsonUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */