/*     */ package com.visa.vpp.premium.utill;
/*     */ 
/*     */ import com.adobe.granite.asset.api.Asset;
/*     */ import com.adobe.granite.asset.api.AssetManager;
/*     */ import com.adobe.granite.asset.api.Rendition;
/*     */ import com.adobe.granite.workflow.exec.Route;
/*     */ import com.day.cq.replication.ReplicationActionType;
/*     */ import com.day.cq.replication.ReplicationException;
/*     */ import com.day.cq.replication.Replicator;
/*     */ import com.day.cq.wcm.resource.details.AssetDetails;
/*     */ import com.visa.vpp.premium.interfaces.CustomImageRenditionConfig;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.NodeIterator;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Workspace;
/*     */ import javax.jcr.query.Query;
/*     */ import javax.jcr.query.QueryManager;
/*     */ import javax.jcr.query.QueryResult;
/*     */ import org.apache.jackrabbit.api.security.user.Authorizable;
/*     */ import org.apache.jackrabbit.api.security.user.Group;
/*     */ import org.apache.jackrabbit.api.security.user.UserManager;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VppUtil
/*     */ {
/*  70 */   private static Logger logger = LoggerFactory.getLogger(VppUtil.class);
/*     */   
/*     */ 
/*     */   public static final String USERID_PATTERN = "^[0-9]{10,50}$";
/*     */   
/*     */ 
/*     */   public static final String TOKEN_PATTERN = "^[a-zA-Z0-9]{10,50}$";
/*     */   
/*     */   public static final String FNAME_PATTERN = "^[a-zA-Z]{10,50}$";
/*     */   
/*     */   public static final String BENEFIT_TYPE_PATTERN = "^[a-zA-Z0-9-]{10,500}$";
/*     */   
/*     */ 
/*     */   public static List<Map<String, String>> getMultiFieldPanelValuesMap(String[] items)
/*     */   {
/*  85 */     List<Map<String, String>> results = new ArrayList();
/*  86 */     if (null != items) {
/*  87 */       String[] values = items;
/*  88 */       for (String value : values) {
/*     */         try
/*     */         {
/*  91 */           value = value.replace("[\"", "[").replace("\"]", "]").replace("\\n", "").replace("}\"", "}").replace("\"{", "{");
/*     */           
/*  93 */           value = value.replace("\\", "");
/*     */           
/*  95 */           JSONObject parsed = new JSONObject(value);
/*     */           
/*  97 */           Map<String, String> columnMap = new HashMap();
/*  98 */           for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
/*  99 */             String key = (String)iter.next();
/* 100 */             String innerValue = parsed.getString(key);
/* 101 */             columnMap.put(key, innerValue);
/*     */           }
/*     */           
/* 104 */           results.add(columnMap);
/*     */         }
/*     */         catch (JSONException e) {
/* 107 */           logger.error("JSON Error while reading content {}", e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 112 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Map<String, String>> getMultiLinkJsonData(String fieldValue)
/*     */   {
/* 122 */     String value = fieldValue;
/* 123 */     logger.debug("inside getMultiLinkJsonData  " + value);
/* 124 */     value = value.replace("[", "").replace("]", "").replace("},", "}~@#!");
/* 125 */     ArrayList<Map<String, String>> results = new ArrayList();
/* 126 */     String[] strvalue = value.split("~@#!");
/*     */     try {
/* 128 */       for (String strJson : strvalue) {
/* 129 */         JSONObject parsed = new JSONObject(strJson);
/*     */         
/* 131 */         Map<String, String> columnMap = new HashMap();
/* 132 */         for (Iterator<String> iter = parsed.keys(); iter.hasNext();) {
/* 133 */           String key = (String)iter.next();
/* 134 */           String innerValue = parsed.getString(key);
/* 135 */           columnMap.put(key, innerValue);
/*     */         }
/* 137 */         results.add(columnMap);
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 141 */       logger.error("JSON Error while reading content {}", e.getMessage());
/*     */     }
/* 143 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertCalendarToString(Calendar dateCal, String dateFormatter)
/*     */   {
/* 154 */     String dateStr = "";
/* 155 */     if (dateCal != null) {
/* 156 */       SimpleDateFormat sdf = new SimpleDateFormat(dateFormatter);
/* 157 */       dateStr = sdf.format(dateCal.getTime());
/*     */     }
/* 159 */     return dateStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Session getUserJcrSession(ResourceResolverFactory resolverFactory, String userService)
/*     */   {
/* 171 */     ResourceResolver resolver = null;
/* 172 */     Session session = null;
/* 173 */     Map<String, Object> param = new HashMap();
/* 174 */     param.put("sling.service.subservice", userService);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 179 */       resolver = resolverFactory.getServiceResourceResolver(param);
/* 180 */       session = (Session)resolver.adaptTo(Session.class);
/*     */       
/* 182 */       logger.debug("####### session ######### : " + session.getUserID());
/*     */     } catch (Exception e) {
/* 184 */       logger.error("Access denied in " + e);
/*     */     }
/* 186 */     return session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResourceResolver getUserResourceResolver(ResourceResolverFactory resolverFactory, String userService)
/*     */   {
/* 198 */     ResourceResolver resolver = null;
/*     */     
/* 200 */     Map<String, Object> param = new HashMap();
/* 201 */     param.put("sling.service.subservice", userService);
/*     */     try
/*     */     {
/* 204 */       resolver = resolverFactory.getServiceResourceResolver(param);
/*     */     }
/*     */     catch (Exception e) {
/* 207 */       logger.error("Access denied in " + e);
/*     */     }
/* 209 */     return resolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeInputStream(InputStream inptStrmParam)
/*     */   {
/*     */     try
/*     */     {
/* 220 */       if (null != inptStrmParam) {
/* 221 */         inptStrmParam.close();
/*     */       }
/*     */     } catch (IOException ex) {
/* 224 */       logger.error("IO Exception occured while closing inputStream in closeInputStream() " + ex
/* 225 */         .getMessage());
/*     */     } catch (Exception e) {
/* 227 */       logger.error("Exception Occured while closing inputStream in closeInputStream() " + e
/* 228 */         .getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeBufferReader(BufferedReader bufferedReader)
/*     */   {
/*     */     try
/*     */     {
/* 240 */       if (null != bufferedReader) {
/* 241 */         bufferedReader.close();
/*     */       }
/*     */     } catch (IOException ex) {
/* 244 */       logger.error("IO Exception occured while closing BufferedReader in closeBufferReader() " + ex
/* 245 */         .getMessage());
/*     */     } catch (Exception e) {
/* 247 */       logger.error("Exception Occured while closing BufferedReader in closeBufferReader() " + e
/* 248 */         .getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void closeJcrSession(Session sessionob)
/*     */   {
/* 260 */     if ((sessionob != null) && (sessionob.isLive())) {
/* 261 */       sessionob.logout();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertGmtToDate(String parseFmt, String formatFmt, String dateString)
/*     */   {
/* 273 */     DateFormat mod = new SimpleDateFormat(formatFmt);
/* 274 */     DateFormat gmt = new SimpleDateFormat(parseFmt);
/* 275 */     String formattedDate = "";
/*     */     try
/*     */     {
/* 278 */       Date dateGmt = gmt.parse(dateString);
/* 279 */       formattedDate = mod.format(dateGmt);
/*     */     }
/*     */     catch (ParseException e) {
/* 282 */       logger.error("Date format error " + e);
/*     */     }
/* 284 */     return formattedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JSONArray duplicateImages(String imgRef, JSONObject jsonlist)
/*     */   {
/* 297 */     String linkReference = "linkReference";
/* 298 */     String linkText = "linkText";
/* 299 */     String link = "link";
/* 300 */     Iterator itr = jsonlist.keys();
/* 301 */     JSONArray arr = new JSONArray();
/*     */     try
/*     */     {
/* 304 */       while (itr.hasNext()) {
/* 305 */         String defaultVal = "";
/* 306 */         String key = (String)itr.next();
/* 307 */         JSONObject cardartdetails = (JSONObject)jsonlist.get(key);
/* 308 */         if (imgRef.equals(cardartdetails.getString(linkReference))) {
/* 309 */           JSONObject cardDetails = new JSONObject();
/* 310 */           if (cardartdetails.getString(linkText).length() != 0) {
/* 311 */             cardDetails.put(linkText, cardartdetails.getString(linkText));
/*     */           } else {
/* 313 */             cardDetails.put(linkText, defaultVal);
/*     */           }
/* 315 */           if (cardartdetails.getString(link).length() != 0) {
/* 316 */             cardDetails.put(link, cardartdetails.getString(link));
/*     */           } else {
/* 318 */             cardDetails.put(link, defaultVal);
/*     */           }
/* 320 */           arr.put(cardDetails);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 324 */       logger.error("Could not get JSON", e.getMessage());
/*     */     }
/*     */     
/* 327 */     return arr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAuthorMode(SlingSettingsService settingsService)
/*     */   {
/* 339 */     boolean authorMode = false;
/* 340 */     if (null != settingsService) {
/* 341 */       Set<String> runModes = settingsService.getRunModes();
/* 342 */       if (null != runModes) {
/* 343 */         authorMode = runModes.contains("author");
/*     */       }
/*     */     }
/* 346 */     return authorMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void replicateResource(Session session, String resourcePath, Replicator replicator)
/*     */   {
/* 357 */     logger.debug("replicator" + replicator);
/* 358 */     if (replicator != null) {
/*     */       try {
/* 360 */         replicator.replicate(session, ReplicationActionType.ACTIVATE, resourcePath);
/* 361 */         logger.debug("Resource Replicated Successfully");
/*     */       } catch (ReplicationException e) {
/* 363 */         logger.error("ReplicationException Occured in  replicateResource() :" + e.getMessage());
/*     */       } catch (Exception e) {
/* 365 */         logger.error("Exception Occured in  replicateResource() :" + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void deactivateResource(Session session, String resourcePath, Replicator replicator)
/*     */   {
/* 380 */     logger.debug("replicator" + replicator);
/* 381 */     if (replicator != null) {
/*     */       try {
/* 383 */         replicator.replicate(session, ReplicationActionType.DEACTIVATE, resourcePath);
/* 384 */         logger.debug("Resource Deactivated Successfully");
/*     */       } catch (ReplicationException e) {
/* 386 */         logger.error("ReplicationException Occured in  deactivateResource() :" + e.getMessage());
/*     */       } catch (Exception e) {
/* 388 */         logger.error("Exception Occured in  deactivateResource() :" + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node getCatgoryOfferNode(Session session, String path, String offerid)
/*     */   {
/* 404 */     logger.debug("initialize getCatgoryOfferNode" + path);
/*     */     
/* 406 */     Node node = null;
/*     */     try
/*     */     {
/* 409 */       QueryManager queryManager = session.getWorkspace().getQueryManager();
/*     */       
/* 411 */       String sqlStatement = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + path + "]) and CONTAINS(s.offerId, '" + offerid + "')";
/*     */       
/*     */ 
/* 414 */       Query query = queryManager.createQuery(sqlStatement, "JCR-SQL2");
/*     */       
/* 416 */       QueryResult result = query.execute();
/*     */       
/* 418 */       NodeIterator nodeIter = result.getNodes();
/*     */       
/* 420 */       while (nodeIter.hasNext())
/*     */       {
/* 422 */         node = nodeIter.nextNode();
/*     */         
/* 424 */         logger.debug("node path =============>" + node.getPath());
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 428 */       logger.error("repository exception " + e);
/*     */     }
/* 430 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String updateCurrentCategoryPage(String catPagePath, String offerId, JSONObject currentData, Session jcrSession)
/*     */   {
/* 442 */     logger.debug("Initiazing Updation of Category Page ");
/*     */     try
/*     */     {
/* 445 */       Node offerNode = getCatgoryOfferNode(jcrSession, catPagePath, offerId);
/* 446 */       if (offerNode == null) {
/* 447 */         logger.debug("Offer Node Not found on Category Page");
/* 448 */         return catPagePath;
/*     */       }
/* 450 */       if (currentData.length() == 0) {
/* 451 */         offerNode.remove();
/* 452 */         logger.debug("Offer Node Successfully Removed from Category Page");
/*     */       } else {
/* 454 */         offerNode.setProperty("offerId", currentData.getString("offerId"));
/* 455 */         offerNode.setProperty("offerTitle", currentData
/* 456 */           .getString("offerTitle"));
/* 457 */         offerNode.setProperty("offerShortDesc", currentData
/* 458 */           .getString("offerShortDesc"));
/* 459 */         offerNode.setProperty("thumbImage", currentData
/* 460 */           .getString("thumbImage"));
/* 461 */         offerNode.setProperty("previewURL", currentData
/* 462 */           .getString("previewURL"));
/* 463 */         offerNode.setProperty("offerSource", currentData
/* 464 */           .getString("offerSource"));
/* 465 */         offerNode.setProperty("offerLastModified", currentData
/* 466 */           .getString("offerLastModified"));
/* 467 */         offerNode.setProperty("heroImage", currentData
/* 468 */           .getString("heroImage"));
/*     */         
/* 470 */         String bTypeCode = currentData.getString("benefitTypeCode");
/* 471 */         if ((bTypeCode.contains("[\"")) && (bTypeCode.contains("\"]"))) {
/* 472 */           bTypeCode = bTypeCode.substring(2, bTypeCode.length() - 2);
/* 473 */           String[] btcArr = bTypeCode.split("\",\"");
/* 474 */           offerNode.setProperty("benefitTypeCode", btcArr);
/*     */         } else {
/* 476 */           offerNode.setProperty("benefitTypeCode", currentData
/* 477 */             .getString("benefitTypeCode"));
/*     */         }
/*     */         
/* 480 */         logger.debug("Offer Node Successfully Updated on Category Page");
/*     */       }
/* 482 */       jcrSession.save();
/* 483 */       return "success";
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 486 */       logger.error("Path Not Found Exception Occured in VPPUtil updateCurrentCategoryPage()" + e
/* 487 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 489 */       logger.error("Repository Exception Occured in VPPUtil updateCurrentCategoryPage()" + e
/* 490 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 492 */       logger.error("JSONException Occured in VPPUtil updateCurrentCategoryPage()");
/*     */     } catch (Exception e) {
/* 494 */       logger.error("Exception Occured in VPPUtil updateCurrentCategoryPage()" + e.getMessage());
/*     */     }
/* 496 */     return "failure";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Map<String, String>> getMultifieldPaths(ArrayList<Map<String, String>> linkedList, String fieldName)
/*     */   {
/* 510 */     ArrayList<Map<String, String>> list = new ArrayList();
/*     */     
/* 512 */     for (int a = 0; a < linkedList.size(); a++) {
/* 513 */       HashMap<String, String> map = new HashMap();
/* 514 */       String keyName = "";
/* 515 */       String data = "";
/* 516 */       Map<String, String> tmpData = (Map)linkedList.get(a);
/*     */       
/* 518 */       for (Map.Entry<String, String> entry : tmpData.entrySet()) {
/* 519 */         keyName = (String)entry.getKey();
/* 520 */         data = (String)entry.getValue();
/*     */         
/* 522 */         if (keyName.equals(fieldName)) {
/* 523 */           data = getUrl(data);
/* 524 */           logger.debug("fieldName is" + fieldName);
/* 525 */           logger.debug("PathField after update  is" + data);
/*     */         }
/* 527 */         logger.debug("Key Value is" + keyName);
/* 528 */         logger.debug("The data is" + data);
/* 529 */         map.put(keyName, data);
/*     */       }
/*     */       
/*     */ 
/* 533 */       list.add(map);
/*     */     }
/*     */     
/* 536 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUrl(String path)
/*     */   {
/* 547 */     if ((path == null) || (path.equals("")))
/* 548 */       return "";
/* 549 */     if ((path.startsWith("http")) || 
/* 550 */       (path.startsWith("https")) || 
/* 551 */       (path.startsWith("/content/dam")))
/* 552 */       return path;
/* 553 */     if ((path.startsWith("/content/vpp")) && 
/* 554 */       (path.indexOf(".html") == -1)) {
/* 555 */       return path + ".html";
/*     */     }
/* 557 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getImageWidthHeight(Resource res)
/*     */   {
/*     */     try
/*     */     {
/* 569 */       AssetDetails assetDetails = new AssetDetails(res);
/* 570 */       int imgWidth = (int)assetDetails.getWidth();
/* 571 */       logger.debug("Image Width : " + imgWidth);
/* 572 */       int imgHeight = (int)assetDetails.getHeight();
/* 573 */       logger.debug("Image Height : " + imgHeight);
/* 574 */       StringBuilder sb = new StringBuilder();
/* 575 */       sb.append(imgWidth).append("_").append(imgHeight);
/* 576 */       return sb.toString();
/*     */     } catch (RepositoryException e) {
/* 578 */       logger.error("Repository Exception Occured while trying to access the asset in VPPUtil getImageWidthHeight()" + e
/* 579 */         .getMessage());
/*     */     } catch (Exception e) {
/* 581 */       logger.error("Exception Occured while trying to access the asset in VPPUtil getImageWidthHeight()" + e
/* 582 */         .getMessage());
/*     */     }
/* 584 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Route getRoute(List<Route> routes, String routeName)
/*     */   {
/* 595 */     Route finalRoute = null;
/* 596 */     for (Route route : routes) {
/* 597 */       if (route.getName().equalsIgnoreCase(routeName)) {
/* 598 */         finalRoute = route;
/* 599 */         break;
/*     */       }
/*     */     }
/* 602 */     return finalRoute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<String> getUserIds(String workFlowInitiator, ResourceResolver resourceResolver)
/*     */   {
/* 614 */     logger.debug("workFlowInitiator in vpp util" + workFlowInitiator);
/* 615 */     ArrayList<String> userGroupIds = new ArrayList();
/* 616 */     UserManager userManager = (UserManager)resourceResolver.adaptTo(UserManager.class);
/*     */     try
/*     */     {
/* 619 */       Authorizable auth = userManager.getAuthorizable(workFlowInitiator);
/* 620 */       if (!auth.isGroup()) {
/* 621 */         Iterator<Group> groups = auth.memberOf();
/* 622 */         while (groups.hasNext()) {
/* 623 */           Group group = (Group)groups.next();
/* 624 */           logger.debug("groupID Name." + group.getID());
/* 625 */           userGroupIds.add(group.getID());
/*     */         }
/* 627 */         logger.debug("Group Ids in getUserIds()" + Arrays.toString(userGroupIds.toArray()));
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 630 */       logger.debug("RepositoryException in getUserIds() of VppUtils" + e.getMessage());
/*     */     }
/* 632 */     return userGroupIds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> getRenditionList(String assetPath, Resource rs, String compName)
/*     */   {
/* 648 */     logger.debug("VPP getRenditionList() initiated");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 653 */     BundleContext bundleContext = FrameworkUtil.getBundle(CustomImageRenditionConfig.class).getBundleContext();
/*     */     
/* 655 */     ServiceReference factoryRef = bundleContext.getServiceReference(CustomImageRenditionConfig.class.getName());
/*     */     
/* 657 */     CustomImageRenditionConfig renditionService = (CustomImageRenditionConfig)bundleContext.getService(factoryRef);
/* 658 */     Map<String, String> renditionMap = renditionService.getRenditionByComponentName(compName);
/*     */     
/* 660 */     Map<String, String> renditionList = new HashMap();
/*     */     try
/*     */     {
/* 663 */       AssetManager assetManager = (AssetManager)rs.getResourceResolver().adaptTo(AssetManager.class);
/* 664 */       Asset asset = assetManager.getAsset(assetPath);
/* 665 */       logger.debug("asset name" + asset.getName());
/* 666 */       Iterator<? extends Rendition> it = asset.listRenditions();
/* 667 */       String renditionType; while (it.hasNext()) {
/* 668 */         renditionType = ((Rendition)it.next()).getPath().toString();
/*     */         
/* 670 */         for (Map.Entry<String, String> entry : renditionMap.entrySet()) {
/* 671 */           if (renditionType.contains((CharSequence)entry.getValue())) {
/* 672 */             logger.debug("renditionType" + renditionType);
/* 673 */             logger.debug("customeRenditionPath" + 
/* 674 */               getCustomRenditionPath(asset.getName(), renditionType));
/* 675 */             logger.debug("Util KEY Value -------::" + (String)entry.getKey() + "value" + (String)entry.getValue());
/* 676 */             renditionList.put(entry.getKey(), 
/* 677 */               getCustomRenditionPath(asset.getName(), renditionType));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 684 */       logger.error(" Exception in Rendition" + e);
/*     */     }
/*     */     
/* 687 */     return renditionList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCustomRenditionPath(String assetName, String renditionPath)
/*     */   {
/* 701 */     logger.info("inside getCustomRenditionPath  ");
/* 702 */     String replacePath = renditionPath.substring(renditionPath.indexOf(assetName));
/* 703 */     logger.debug("renditionPath" + renditionPath);
/* 704 */     logger.debug("replacePath" + replacePath);
/* 705 */     String[] fileDetails = assetName.split("\\.");
/* 706 */     String imageFileName = fileDetails[0];
/* 707 */     String imageExt = fileDetails[1];
/* 708 */     String renditionName = replacePath.substring(replacePath.lastIndexOf("/")).replace("/", "");
/* 709 */     String[] renditionDetails = renditionName.split("\\.");
/* 710 */     String renditionSize = renditionDetails[2] + "." + renditionDetails[3];
/* 711 */     logger.debug("renditionSize" + renditionSize);
/* 712 */     String customRenditionName = imageFileName + ".web." + renditionSize + "." + imageExt;
/* 713 */     String customRenditionPath = renditionPath.replace(replacePath, customRenditionName);
/*     */     
/* 715 */     logger.debug("customRenditionPath" + customRenditionPath);
/* 716 */     return customRenditionPath;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\utill\VppUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */