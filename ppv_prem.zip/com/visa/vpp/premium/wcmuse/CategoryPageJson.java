/*    */ package com.visa.vpp.premium.wcmuse;
/*    */ 
/*    */ import com.adobe.cq.sightly.WCMUsePojo;
/*    */ import com.visa.vpp.premium.interfaces.CreateCategoryPageJson;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.scripting.SlingScriptHelper;
/*    */ import org.apache.sling.commons.json.JSONObject;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ public class CategoryPageJson extends WCMUsePojo
/*    */ {
/* 12 */   private static final Logger logger = org.slf4j.LoggerFactory.getLogger(CategoryPageJson.class);
/*    */   private String catPageJsonStr;
/*    */   
/*    */   public void activate() throws Exception
/*    */   {
/* 17 */     Resource resource = getResource();
/* 18 */     String pagePath = resource.getPath();
/* 19 */     logger.debug("pagePath " + pagePath);
/*    */     
/* 21 */     CreateCategoryPageJson createCategoryPageJson = (CreateCategoryPageJson)getSlingScriptHelper().getService(CreateCategoryPageJson.class);
/* 22 */     JSONObject catPageJson = createCategoryPageJson.getCreateCategoryPageJson(pagePath);
/* 23 */     this.catPageJsonStr = catPageJson.toString();
/*    */   }
/*    */   
/*    */   public String getCatPageJsonStr() {
/* 27 */     return this.catPageJsonStr;
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\wcmuse\CategoryPageJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */