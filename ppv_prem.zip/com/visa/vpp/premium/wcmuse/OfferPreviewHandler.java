/*     */ package com.visa.vpp.premium.wcmuse;
/*     */ 
/*     */ import com.adobe.cq.sightly.WCMUsePojo;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.sling.api.resource.ValueMap;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.parser.Tag;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OfferPreviewHandler
/*     */   extends WCMUsePojo
/*     */ {
/*     */   private String visaTermsandConditions;
/*     */   private String merchantTermsandConditions;
/*     */   public String totalTermsandConditions;
/*     */   public String totalTermsandConditionsHtml;
/*     */   private Calendar validStartDate;
/*     */   private Calendar validEndDate;
/*     */   public String eventStartDate;
/*     */   public String eventEndDate;
/*  39 */   public ArrayList<String> allElements = new ArrayList();
/*  40 */   public ArrayList<String> restElements = new ArrayList();
/*  41 */   public int visaTermsandConditionsCount = 0;
/*  42 */   public int merchantTermsandConditionsCount = 0;
/*  43 */   private int finalTermsandConditionsCount = 0;
/*     */   public static final String VISA_TandC = "visaTandC";
/*     */   public static final String MERCHANT_TandC = "merchantTandC";
/*     */   public static final String VAL_START_DATE = "valStartDate";
/*     */   public static final String VAL_END_DATE = "valEndDate";
/*     */   public static final String TAG_LI = "li";
/*     */   public static final String TAG_P = "p";
/*     */   public static final String TAG_OL = "ol";
/*     */   public static final String TAG_UL = "ul";
/*     */   public static final String TAG_UL_HTML_START_CLASS = "<ul class= \"tcList\">";
/*     */   public static final String TAG_OL_HTML_START_CLASS = "<ol class= \"tcList\">";
/*     */   public static final String TAG_P_HTML_START_CLASS = "<p class= \"tcList\">";
/*     */   public static final String TAG_UL_HTML_START = "<ul>";
/*     */   public static final String TAG_UL_HTML_END = "</ul>";
/*     */   public static final String TAG_OL_HTML_START = "<ol>";
/*     */   public static final String TAG_OL_HTML_END = "</ol>";
/*     */   public static final String TAG_P_HTML_START = "<p>";
/*     */   public static final String TAG_P_HTML_END = "</p>";
/*     */   public static final String TAG_HIDE_ELEM = "<span class= \"remainingTC hideElem\">";
/*     */   public static final int TERMS_AND_CONDITIONS_COUNT = 9;
/*     */   public String parentTagStart;
/*     */   public String parentTagEnd;
/*  65 */   public String moreTag = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String parentTagRestStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionTelChecked;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionTel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionMail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redemptionMailChecked;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String EMAIL_PATTERN = "[a-zA-Z0-9]+[._a-zA-Z0-9!#$%&'*+-=?^_`{|}~]*[a-zA-Z]*@[a-zA-Z0-9]{2,8}.[a-zA-Z.]{2,6}";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String TEL_PATTERN = "(\\d-)?(\\d{3}-)?\\d{3,4}-\\d{4}|\\+(\\d{2}-\\(\\d{1}\\)\\d{2}-\\d{4}-\\d{4})|\\+(\\d{2}-\\d{10})|\\+(\\d{2}-\\d{4}-\\d{4})|(\\d{1}\\s\\d{2}\\s\\d{8})|(\\d{2}\\s\\d{2}\\s\\d{8})|(\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\(\\d{2}\\)\\-\\d{10})|(\\(\\d{2}\\)\\s\\d{10})|(\\(\\d{4}\\)\\s\\d{6})|(\\(\\+(\\d{2}\\s\\d{4}\\))\\s\\d{6})|(\\(\\+(\\d{3}\\))\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\(\\+(\\d{2}\\s\\-\\d{2}\\))\\s\\d{8})|(\\(\\d{2}\\)\\s\\-\\s\\(\\d{2}\\)\\s\\-\\s\\d{8})|(\\(\\+(\\d{2}\\))\\-\\d{2}\\s\\d{8})|(\\(\\d{3}\\s\\d{3}\\)\\s\\d{8})|(\\(\\d{2}\\)\\-\\(\\d{2}\\)\\-\\s\\d{8})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{8})|(\\d{3}-\\d{3}-\\d{4})|(\\[\\+\\d{1}]\\s\\d{3}-\\d{3}-\\d{4})|(\\(\\d{3}\\)\\-\\d{3}-\\d{4})|(\\d{2}-\\d{2}-\\d{8})|(\\d{2}-\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\-\\s\\d{2}\\s\\-\\s\\d{8})|(\\d{2}-\\d{4}-\\d{6})|(\\d{2}\\s\\-\\s\\d{4}\\s\\-\\s\\d{6})|(\\d{1}-\\d{3}-\\d{3}-\\d{4})|(\\d{2}-\\d{3}-\\d{3}-\\d{4})|(\\d{1}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{2}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{3}-\\d{7})|(\\d{2}-\\d{10})|(\\d{1}\\-\\d{3}-\\d{7})|(\\d{2}\\-\\d{3}-\\d{7})|(\\d{1}\\s\\d{3}-\\d{7})|(\\d{2}\\s\\d{3}-\\d{7})|(^(\\+\\d{2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$)|(\\d{1}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\d{3}\\s\\d{4})|(\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{1}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{1}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{7})|(\\d{1}\\s\\d{3}\\s\\d{7})|(\\d{3}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{4}\\s\\d{4})|(\\d{2}\\-\\d{2}\\-\\d{4}\\s\\d{4})|(\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{2}\\s\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{1}\\.\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{5}\\s\\d{9})|(\\d{4}\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\(\\d{1}\\)\\s\\d{7})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\d{3}\\s\\d{2}\\s\\d{5})|(\\d{2}\\s\\(\\d{1}\\)\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{4}\\s\\d{3}\\s\\d{4})|(\\d{4}-\\d{3}-\\d{4})|(\\d{3}-\\d{8})|(\\d{3}-\\d{2}-\\d{5})|(\\d{2}\\s\\d{2}\\s\\d{4}-\\d{4})|(\\d{2}\\-\\d{2}\\. ISSN \\d{4}-\\d{4})|(\\d{4}\\-\\d{4}\\-\\d{1}-\\d{3})|(\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{3}\\s\\d{1}\\s\\d{7})|(\\d{13})|(\\d{12})|(\\d{11})|(\\d{10})|(\\d{9})|(\\d{2}\\s\\d{10})|(\\d{1}\\s\\d{10})|(^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$)";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private static final Logger logger = LoggerFactory.getLogger(OfferPreviewHandler.class);
/*     */   
/*     */   public void activate() throws Exception
/*     */   {
/* 137 */     logger.debug("OfferPreviewHandler Activate initialised");
/*     */     
/* 139 */     this.eventStartDate = VppUtil.convertCalendarToString(getValidStartDate(), "MMM d,yyyy");
/*     */     
/* 141 */     this.eventEndDate = VppUtil.convertCalendarToString(getValidEndDate(), "MMM d,yyyy");
/* 142 */     this.redemptionTelChecked = formatTelephone(getRedemptionTel());
/* 143 */     this.redemptionMailChecked = formatEmail(getRedemptionEmail());
/* 144 */     logger.debug("redemptionMailChck--" + this.redemptionMailChecked);
/* 145 */     this.totalTermsandConditions = (getVisaTermsandConditions() + getMerchantTermsandConditions());
/*     */     
/* 147 */     this.totalTermsandConditionsHtml = renderTotalTermsandConditionsHtml(this.allElements, this.restElements);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVisaTermsandConditions()
/*     */   {
/* 157 */     this.visaTermsandConditions = ((String)getProperties().get("visaTandC", String.class));
/* 158 */     if (this.visaTermsandConditions != null) {
/* 159 */       this.visaTermsandConditionsCount = getTermsAndConditionsCount(this.visaTermsandConditions).intValue();
/*     */     }
/* 161 */     return this.visaTermsandConditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMerchantTermsandConditions()
/*     */   {
/* 170 */     this.merchantTermsandConditions = ((String)getProperties().get("merchantTandC", String.class));
/* 171 */     if (this.merchantTermsandConditions != null) {
/* 172 */       this.merchantTermsandConditionsCount = getTermsAndConditionsCount(this.merchantTermsandConditions).intValue();
/*     */     }
/* 174 */     return this.merchantTermsandConditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getValidStartDate()
/*     */   {
/* 183 */     this.validStartDate = ((Calendar)getProperties().get("valStartDate", Calendar.class));
/* 184 */     return this.validStartDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getValidEndDate()
/*     */   {
/* 193 */     this.validEndDate = ((Calendar)getProperties().get("valEndDate", Calendar.class));
/* 194 */     return this.validEndDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFinalTermsandConditionsCount()
/*     */   {
/* 204 */     this.finalTermsandConditionsCount = (this.visaTermsandConditionsCount + this.merchantTermsandConditionsCount);
/* 205 */     return this.finalTermsandConditionsCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRedemptionTel()
/*     */   {
/* 215 */     this.redemptionTel = ((String)getProperties().get("redemptionTel", String.class));
/* 216 */     return this.redemptionTel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRedemptionEmail()
/*     */   {
/* 226 */     this.redemptionMail = ((String)getProperties().get("redemptionEmail", String.class));
/* 227 */     return this.redemptionMail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getTermsAndConditionsCount(String text)
/*     */   {
/* 237 */     Document doc = Jsoup.parse(text);
/* 238 */     Elements elements = doc.getAllElements();
/* 239 */     Integer count = Integer.valueOf(0);
/*     */     
/* 241 */     for (Element em : elements) {
/* 242 */       Tag tg = em.tag();
/* 243 */       if ((tg.getName().equalsIgnoreCase("ul")) || (tg.getName().equalsIgnoreCase("ol")) || 
/* 244 */         (tg.getName().equalsIgnoreCase("p"))) {
/* 245 */         this.moreTag = "<span class= \"remainingTC hideElem\">";
/*     */         
/* 247 */         if (tg.getName().equalsIgnoreCase("ul")) {
/* 248 */           this.parentTagStart = "<ul class= \"tcList\">";
/* 249 */           this.parentTagRestStart = "<ul>";
/* 250 */           this.parentTagEnd = "</ul>";
/*     */         }
/* 252 */         else if (tg.getName().equalsIgnoreCase("ol")) {
/* 253 */           this.parentTagStart = "<ol class= \"tcList\">";
/* 254 */           this.parentTagRestStart = "<ol>";
/* 255 */           this.parentTagEnd = "</ol>";
/*     */         } else {
/* 257 */           this.parentTagStart = "<p class= \"tcList\">";
/* 258 */           this.parentTagRestStart = "<p>";
/* 259 */           this.parentTagEnd = "</p>";
/*     */         }
/*     */       }
/*     */       
/* 263 */       if (((tg.getName().equalsIgnoreCase("li")) || (tg.getName().equalsIgnoreCase("p"))) && 
/* 264 */         (em.hasText()) && (em.text() != null)) {
/* 265 */         Integer localInteger1 = count;Integer localInteger2 = count = Integer.valueOf(count.intValue() + 1);
/* 266 */         this.finalTermsandConditionsCount += 1;
/* 267 */         if (this.finalTermsandConditionsCount <= 9) {
/* 268 */           this.allElements.add(em.toString());
/*     */         } else {
/* 270 */           this.restElements.add(em.toString());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 275 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String renderTotalTermsandConditionsHtml(ArrayList<String> allElements2, ArrayList<String> restElements2)
/*     */   {
/* 289 */     String result = "";
/* 290 */     StringBuffer resultFinal = new StringBuffer();
/*     */     
/* 292 */     if ((!allElements2.isEmpty()) || (!restElements2.isEmpty()))
/*     */     {
/* 294 */       resultFinal.append(this.parentTagStart);
/*     */       
/*     */ 
/* 297 */       for (int i = 0; i < allElements2.size(); i++) {
/* 298 */         String item = (String)allElements2.get(i);
/* 299 */         resultFinal.append(item);
/*     */       }
/*     */       
/* 302 */       if (!restElements2.isEmpty()) {
/* 303 */         resultFinal.append(this.moreTag);
/* 304 */         for (int i = 0; i < restElements2.size(); i++) {
/* 305 */           String item = (String)restElements2.get(i);
/* 306 */           resultFinal.append(item);
/*     */         }
/*     */       }
/*     */       
/* 310 */       resultFinal.append(this.parentTagEnd);
/*     */     }
/* 312 */     result = resultFinal.toString();
/* 313 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatTelephone(String redemptionTel)
/*     */   {
/* 323 */     Boolean hasAnchor = Boolean.valueOf(false);
/* 324 */     logger.debug("OfferPreviewHandler format Telephone" + redemptionTel);
/* 325 */     if (redemptionTel != null)
/*     */     {
/* 327 */       Document doc = Jsoup.parse(redemptionTel);
/* 328 */       Elements elements = doc.getAllElements();
/* 329 */       for (Element em : elements) {
/* 330 */         Tag tg = em.tag();
/* 331 */         if (tg.getName().equalsIgnoreCase("a")) {
/* 332 */           hasAnchor = Boolean.valueOf(true);
/*     */         }
/*     */       }
/*     */       
/* 336 */       if (!hasAnchor.booleanValue())
/*     */       {
/* 338 */         Pattern p = Pattern.compile("(\\d-)?(\\d{3}-)?\\d{3,4}-\\d{4}|\\+(\\d{2}-\\(\\d{1}\\)\\d{2}-\\d{4}-\\d{4})|\\+(\\d{2}-\\d{10})|\\+(\\d{2}-\\d{4}-\\d{4})|(\\d{1}\\s\\d{2}\\s\\d{8})|(\\d{2}\\s\\d{2}\\s\\d{8})|(\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\d{1}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\(\\d{3}\\)\\s\\d{3}-\\d{4})|(\\(\\d{2}\\)\\-\\d{10})|(\\(\\d{2}\\)\\s\\d{10})|(\\(\\d{4}\\)\\s\\d{6})|(\\(\\+(\\d{2}\\s\\d{4}\\))\\s\\d{6})|(\\(\\+(\\d{3}\\))\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\(\\+(\\d{2}\\s\\-\\d{2}\\))\\s\\d{8})|(\\(\\d{2}\\)\\s\\-\\s\\(\\d{2}\\)\\s\\-\\s\\d{8})|(\\(\\+(\\d{2}\\))\\-\\d{2}\\s\\d{8})|(\\(\\d{3}\\s\\d{3}\\)\\s\\d{8})|(\\(\\d{2}\\)\\-\\(\\d{2}\\)\\-\\s\\d{8})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{8})|(\\d{3}-\\d{3}-\\d{4})|(\\[\\+\\d{1}]\\s\\d{3}-\\d{3}-\\d{4})|(\\(\\d{3}\\)\\-\\d{3}-\\d{4})|(\\d{2}-\\d{2}-\\d{8})|(\\d{2}-\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\-\\s\\d{2}\\s\\-\\s\\d{8})|(\\d{2}-\\d{4}-\\d{6})|(\\d{2}\\s\\-\\s\\d{4}\\s\\-\\s\\d{6})|(\\d{1}-\\d{3}-\\d{3}-\\d{4})|(\\d{2}-\\d{3}-\\d{3}-\\d{4})|(\\d{1}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{2}\\s\\d{3}-\\d{3}-\\d{4})|(\\d{3}-\\d{7})|(\\d{2}-\\d{10})|(\\d{1}\\-\\d{3}-\\d{7})|(\\d{2}\\-\\d{3}-\\d{7})|(\\d{1}\\s\\d{3}-\\d{7})|(\\d{2}\\s\\d{3}-\\d{7})|(^(\\+\\d{2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$)|(\\d{1}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{3}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\d{3}\\s\\d{4})|(\\(\\d{3}\\)\\s\\d{3}\\s\\d{4})|(\\d{1}\\s\\d{5}\\s\\d{5})|(\\d{2}\\s\\d{1}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{4})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\d{3}\\s\\d{7})|(\\d{1}\\s\\d{3}\\s\\d{7})|(\\d{3}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{2}\\s\\(\\d{2}\\)\\s\\d{4}\\s\\d{4})|(\\d{2}\\-\\d{2}\\-\\d{4}\\s\\d{4})|(\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{2}\\s\\d{3}\\.\\d{3}\\.\\d{4})|(\\d{1}\\.\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{5}\\s\\d{9})|(\\d{4}\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\s\\d{3}\\s\\d{4})|(\\d{3}\\s\\(\\d{1}\\)\\s\\d{7})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{3}\\s\\d{3})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\s\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{3}\\-\\d{3}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\d{3}\\s\\d{2}\\s\\d{5})|(\\d{2}\\s\\(\\d{1}\\)\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2})|(\\d{2}\\s\\(\\d{1}\\)\\s\\d{4}\\s\\d{6})|(\\d{2}\\s\\(\\d{1}\\)\\d{4}\\s\\d{6})|(\\d{4}\\s\\d{3}\\s\\d{4})|(\\d{4}-\\d{3}-\\d{4})|(\\d{3}-\\d{8})|(\\d{3}-\\d{2}-\\d{5})|(\\d{2}\\s\\d{2}\\s\\d{4}-\\d{4})|(\\d{2}\\-\\d{2}\\. ISSN \\d{4}-\\d{4})|(\\d{4}\\-\\d{4}\\-\\d{1}-\\d{3})|(\\d{2}\\s\\d{4}\\s\\d{4})|(\\d{3}\\s\\d{1}\\s\\d{7})|(\\d{13})|(\\d{12})|(\\d{11})|(\\d{10})|(\\d{9})|(\\d{2}\\s\\d{10})|(\\d{1}\\s\\d{10})|(^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$)");
/* 339 */         Matcher matcher = p.matcher(redemptionTel);
/* 340 */         while (matcher.find()) {
/* 341 */           String str1 = matcher.group();
/* 342 */           logger.debug("Text found " + str1 + " starting at index " + matcher.start() + " and ending at index " + matcher
/* 343 */             .end());
/* 344 */           Element anchorCheck = doc.createElement("a");
/* 345 */           anchorCheck = anchorCheck.attr("href", "tel:" + str1);
/* 346 */           anchorCheck = anchorCheck.attr("target", "TARGET");
/* 347 */           anchorCheck = anchorCheck.text(str1);
/* 348 */           String str2 = anchorCheck.toString();
/* 349 */           logger.debug("New Element-----" + str2);
/* 350 */           redemptionTel = redemptionTel.replace(str1, str2);
/* 351 */           logger.debug("New string-- " + redemptionTel);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 356 */     return redemptionTel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatEmail(String redemptionmail)
/*     */   {
/* 366 */     Boolean hasAnchor = Boolean.valueOf(false);
/* 367 */     logger.debug("OfferPreviewHandler format Email" + redemptionmail);
/* 368 */     if (redemptionmail != null)
/*     */     {
/* 370 */       Document doc = Jsoup.parse(redemptionmail);
/* 371 */       Elements elements = doc.getAllElements();
/* 372 */       for (Element em : elements) {
/* 373 */         Tag tg = em.tag();
/* 374 */         if (tg.getName().equalsIgnoreCase("a")) {
/* 375 */           hasAnchor = Boolean.valueOf(true);
/*     */         }
/*     */       }
/*     */       
/* 379 */       if (!hasAnchor.booleanValue())
/*     */       {
/* 381 */         Pattern p = Pattern.compile("[a-zA-Z0-9]+[._a-zA-Z0-9!#$%&'*+-=?^_`{|}~]*[a-zA-Z]*@[a-zA-Z0-9]{2,8}.[a-zA-Z.]{2,6}");
/* 382 */         Matcher matcher = p.matcher(redemptionmail);
/* 383 */         while (matcher.find()) {
/* 384 */           String str1 = matcher.group();
/* 385 */           logger.debug("Text found " + str1 + " starting at index " + matcher.start() + " and ending at index " + matcher
/* 386 */             .end());
/* 387 */           Element anchorCheck = doc.createElement("a");
/* 388 */           anchorCheck = anchorCheck.attr("href", "mailto:" + str1.trim());
/* 389 */           anchorCheck = anchorCheck.attr("target", "TARGET");
/* 390 */           anchorCheck = anchorCheck.text(str1);
/* 391 */           String str2 = anchorCheck.toString();
/* 392 */           logger.debug("New Element-----" + str2.trim());
/* 393 */           redemptionmail = redemptionmail.replace(str1, str2.trim());
/* 394 */           logger.debug("New string-- " + redemptionmail);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 399 */     return redemptionmail;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\wcmuse\OfferPreviewHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */