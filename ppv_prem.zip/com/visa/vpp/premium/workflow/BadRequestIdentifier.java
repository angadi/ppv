/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.Route;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.Workflow;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.interfaces.TemplateConfig;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.jackrabbit.api.security.user.Authorizable;
/*     */ import org.apache.jackrabbit.api.security.user.Group;
/*     */ import org.apache.jackrabbit.api.security.user.UserManager;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Bad Request Identifier"})})
/*     */ public class BadRequestIdentifier
/*     */   implements WorkflowProcess
/*     */ {
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   @Reference
/*     */   private TemplateConfig tempConfig;
/*  48 */   private static final Logger log = LoggerFactory.getLogger(BadRequestIdentifier.class);
/*  49 */   String rootOne = "True";
/*  50 */   String rootTwo = "False";
/*  51 */   String userGroup = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfsession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  63 */     Session jcrSession = null;
/*  64 */     String payLoad = workItem.getWorkflowData().getPayload().toString();
/*  65 */     String initiator = workItem.getWorkflow().getInitiator();
/*     */     try {
/*  67 */       jcrSession = (Session)wfsession.adaptTo(Session.class);
/*  68 */       Node pageJcrNode = jcrSession.getNode(payLoad + "/jcr:content");
/*     */       
/*  70 */       MetaDataMap wfd = workItem.getWorkflow().getWorkflowData().getMetaDataMap();
/*     */       
/*  72 */       if ((isVmorc(payLoad)) || (isInvalid(workItem, payLoad, pageJcrNode))) {
/*  73 */         log.info(" workflow Bad REquest--" + payLoad + "--" + initiator);
/*  74 */         List<Route> routes = wfsession.getRoutes(workItem, false);
/*  75 */         Route route = getRoute(routes, this.rootOne);
/*  76 */         wfd.put("comment", " You do not have the permission to publish this page. Please check with VPP admin for more detail.");
/*     */         
/*  78 */         log.debug("running default" + route.getName());
/*  79 */         wfsession.complete(workItem, route);
/*     */       } else {
/*  81 */         List<Route> routes = wfsession.getRoutes(workItem, false);
/*  82 */         Route route = getRoute(routes, this.rootTwo);
/*  83 */         log.debug("running default" + route.getName());
/*  84 */         wfsession.complete(workItem, route);
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/*  87 */       log.error("Path Not Found Exception Occured in UpdateCategoryPages execute()" + e
/*  88 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/*  90 */       log.error("ValueFormat Exception Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/*  92 */       log.error("Repository Exception Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVmorc(String payload)
/*     */   {
/* 101 */     if (payload.contains("VMORC_OFFER_LIST")) {
/* 102 */       return true;
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInvalid(WorkItem workItem, String payLoad, Node pageJcrNode)
/*     */   {
/* 116 */     ResourceResolver resourceResolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 117 */     UserManager userManager = (UserManager)resourceResolver.adaptTo(UserManager.class);
/*     */     try {
/* 119 */       String workFlowInitiator = workItem.getWorkflow().getInitiator();
/* 120 */       log.debug("workFlowInitiator" + workFlowInitiator);
/* 121 */       log.debug("Templatetype--" + pageJcrNode.getProperty("sling:resourceType").getString());
/* 122 */       String templateType = pageJcrNode.getProperty("sling:resourceType").getString();
/* 123 */       Authorizable auth = userManager.getAuthorizable(workFlowInitiator);
/* 124 */       if (!auth.isGroup()) {
/* 125 */         Iterator<Group> groups = auth.memberOf();
/* 126 */         Iterator<Group> copygroups = groups;
/*     */         
/* 128 */         ArrayList<String> getGroupPrincipals = new ArrayList();
/* 129 */         while (copygroups.hasNext()) {
/* 130 */           Group group = (Group)groups.next();
/* 131 */           log.debug("group Principal Name." + group.getPrincipal().getName());
/* 132 */           getGroupPrincipals.add(group.getPrincipal().getName());
/*     */         }
/* 134 */         String checkAuthor = isIssuerAuthor(getGroupPrincipals);
/* 135 */         log.debug("Issuer highest level check--" + checkAuthor);
/*     */         
/* 137 */         log.debug("workflow --" + this.userGroup);
/*     */         
/* 139 */         if (checkAuthor == "vpppremiumadmin") {
/* 140 */           log.debug("Get Admin Template Path");
/* 141 */           String[] adminAllowedTemplates = this.tempConfig.getAdminTemplatePaths();
/* 142 */           log.debug("Get Admin Template Path 2 " + adminAllowedTemplates.length);
/* 143 */           for (int i = 0; i < adminAllowedTemplates.length; i++) {
/* 144 */             log.debug("Get Admin Template Path 3");
/* 145 */             if (adminAllowedTemplates[i].equals(templateType)) {
/* 146 */               return false;
/*     */             }
/*     */           }
/* 149 */           log.debug("Get Admin Template Path 4");
/* 150 */           return true; }
/* 151 */         if (checkAuthor == "author") {
/* 152 */           log.debug("Get Author Template Path");
/* 153 */           String[] authorAllowedTemplates = this.tempConfig.getAuthorTemplatePaths();
/* 154 */           log.debug("Get Author Template Path 2");
/* 155 */           for (int i = 0; i < authorAllowedTemplates.length; i++) {
/* 156 */             log.debug("Get Author Template Path 3--" + authorAllowedTemplates[i]);
/* 157 */             if (authorAllowedTemplates[i].equals(templateType)) {
/* 158 */               return false;
/*     */             }
/*     */           }
/* 161 */           return true; }
/* 162 */         if (checkAuthor == "approver") {
/* 163 */           log.debug("Get Approver Template Path");
/* 164 */           String[] approverAllowedTemplates = this.tempConfig.getApproverTemplatePaths();
/* 165 */           log.debug("Get Approver Template Path 1--" + approverAllowedTemplates.length);
/* 166 */           for (int i = 0; i < approverAllowedTemplates.length; i++) {
/* 167 */             log.debug("Get Approver Template Path 2 --" + approverAllowedTemplates[i]);
/* 168 */             if (approverAllowedTemplates[i].equals(templateType)) {
/* 169 */               log.debug("Get Approver Template Path 3");
/* 170 */               return false;
/*     */             }
/*     */           }
/* 173 */           log.debug("Get Approver Template Path 4");
/* 174 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 179 */       log.error("RepositoryException occured in execute() of WorkFlowInitiator " + e.getMessage());
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   private Route getRoute(List<Route> routes, String routeName) {
/* 185 */     Route finalRoute = null;
/* 186 */     for (Route route : routes) {
/* 187 */       if (route.getName().equalsIgnoreCase(routeName)) {
/* 188 */         finalRoute = route;
/* 189 */         break;
/*     */       }
/*     */     }
/* 192 */     return finalRoute;
/*     */   }
/*     */   
/*     */   private String isIssuerAuthor(ArrayList<String> userGroupIds) {
/* 196 */     for (String userGroupId : userGroupIds) {
/* 197 */       if ((userGroupId.contains("vpppremiumadmin")) || 
/* 198 */         (userGroupId.contains("approver"))) {
/* 199 */         if (userGroupId.contains("vpppremiumadmin")) {
/* 200 */           this.userGroup = "vpppremiumadmin";
/* 201 */           break;
/*     */         }
/* 203 */         this.userGroup = "approver";
/*     */       }
/* 205 */       else if ((userGroupId.contains("author")) && (this.userGroup != "approver")) {
/* 206 */         this.userGroup = "author";
/*     */       }
/*     */     }
/* 209 */     return this.userGroup;
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindTempConfig(TemplateConfig paramTemplateConfig)
/*     */   {
/*     */     this.tempConfig = paramTemplateConfig;
/*     */   }
/*     */   
/*     */   protected void unbindTempConfig(TemplateConfig paramTemplateConfig)
/*     */   {
/*     */     if (this.tempConfig == paramTemplateConfig) {
/*     */       this.tempConfig = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\BadRequestIdentifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */