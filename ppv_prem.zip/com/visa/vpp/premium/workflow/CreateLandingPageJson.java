/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Create Landing Page JSON"})})
/*     */ public class CreateLandingPageJson
/*     */   implements WorkflowProcess
/*     */ {
/*  37 */   private static final Logger log = LoggerFactory.getLogger(CreateLandingPageJson.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*     */     throws WorkflowException
/*     */   {
/*  48 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/*  49 */     if (wfMetaDataMap.get("customPropertyCheck") != null) {
/*  50 */       String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/*  51 */       log.debug("categoryPagePath" + categoryPagePath);
/*  52 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*     */       try {
/*  54 */         Node rootNode = session.getRootNode();
/*  55 */         if (rootNode.hasNode(categoryPagePath.substring(1))) {
/*  56 */           Node catNode = rootNode.getNode(categoryPagePath.substring(1));
/*  57 */           Node landingNode = catNode.getParent();
/*  58 */           String catNodeName = catNode.getName();
/*  59 */           boolean cherryPic = false;
/*  60 */           String jsonObjKey = "";
/*  61 */           JSONObject childJsonObj = null;
/*  62 */           log.debug("catNodeName" + catNodeName);
/*  63 */           String landingPageFileName = "invalid";
/*     */           
/*  65 */           landingPageFileName = VppJsonUtil.getLandingPageName(landingNode);
/*  66 */           log.debug("landingPageFileName" + landingPageFileName);
/*  67 */           String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(categoryPagePath);
/*  68 */           log.debug("jsonFileLocation" + jsonFileLocation);
/*  69 */           if (rootNode.hasNode(jsonFileLocation)) {
/*  70 */             Node parentFileNode = rootNode.getNode(jsonFileLocation);
/*  71 */             if (parentFileNode.hasNode(landingPageFileName)) {
/*  72 */               Node landingPageFileNode = parentFileNode.getNode(landingPageFileName);
/*  73 */               String landingPageFilePath = landingPageFileNode.getPath();
/*  74 */               log.debug("landingPageFilePath" + landingPageFilePath);
/*  75 */               StringBuffer catNameBuffer = new StringBuffer(catNodeName);
/*  76 */               catNodeName = ".json";
/*  77 */               log.debug("catNodeName with json extension" + catNodeName);
/*     */               
/*  79 */               if (landingPageFileNode.hasNode(catNodeName)) {
/*  80 */                 cherryPic = true;
/*  81 */                 JSONObject categoryPageJson = VppJsonUtil.getOfferJson(session, landingPageFilePath
/*  82 */                   .substring(1), catNodeName);
/*  83 */                 log.debug("categoryPageJSON" + categoryPageJson);
/*  84 */                 Iterator<String> iterator = categoryPageJson.keys();
/*  85 */                 while (iterator.hasNext()) {
/*  86 */                   jsonObjKey = ((String)iterator.next()).toString();
/*  87 */                   childJsonObj = categoryPageJson.getJSONObject(jsonObjKey);
/*  88 */                   log.debug("childJsonObj" + childJsonObj);
/*     */                 }
/*     */                 
/*  91 */                 Node catFileNode = landingPageFileNode.getNode(catNodeName);
/*  92 */                 catFileNode.remove();
/*  93 */                 log.debug("catFileNode removed successfully");
/*     */                 
/*  95 */                 boolean landingPageStatus = createLandingPageJson(landingPageFileName, session, jsonFileLocation, jsonObjKey, childJsonObj, workItem);
/*     */                 
/*  97 */                 session.save();
/*  98 */                 if (landingPageStatus) {
/*  99 */                   workItem.getWorkflowData().getMetaDataMap().put("landingPageJsonCheck", "landingPageJsonCheck");
/*     */                 }
/*     */               }
/*     */               else {
/* 103 */                 log.debug("cat json doesn't exists so cat page is not cherry picked");
/*     */               }
/*     */             } else {
/* 106 */               log.debug("landing page filename property is not set");
/*     */             }
/* 108 */             if (!cherryPic) {
/* 109 */               log.debug("cherryPic" + cherryPic);
/* 110 */               workItem.getWorkflowData().getMetaDataMap().put("no", "no");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (RepositoryException e) {
/* 116 */         log.error("RepositoryException in execute() of CreateLandingPageJson " + e.getMessage());
/*     */       } catch (JSONException e) {
/* 118 */         log.error("JSONException in execute() of CreateLandingPageJson " + e.getMessage());
/*     */       }
/*     */     } else {
/* 121 */       log.error("Landing page JSON is not created because the custom publish property is not set");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean createLandingPageJson(String landingPageFileName, Session session, String jsonFileLocation, String jsonObjKey, JSONObject childJsonObj, WorkItem workItem)
/*     */   {
/* 139 */     Boolean checkfileStatus = Boolean.valueOf(false);
/* 140 */     StringBuffer sb = new StringBuffer(landingPageFileName);
/* 141 */     String landingPageFileNameJsonExt = ".json";
/*     */     
/* 143 */     JSONObject landingPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileNameJsonExt);
/*     */     try {
/* 145 */       landingPageJson.put(jsonObjKey, childJsonObj);
/*     */       
/* 147 */       String filecreationCheck = VppJsonUtil.createUpdateJsonFile(jsonFileLocation, landingPageFileNameJsonExt, session, landingPageJson);
/*     */       
/* 149 */       log.debug("filecreationCheck" + filecreationCheck);
/* 150 */       if (filecreationCheck.equalsIgnoreCase("success"))
/*     */       {
/* 152 */         MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 153 */         StringBuffer landPageJsonBuffer = new StringBuffer();
/* 154 */         landPageJsonBuffer.append("/").append(jsonFileLocation)
/* 155 */           .append("/").append(landingPageFileNameJsonExt);
/* 156 */         String landingPageJsonFilePath = landPageJsonBuffer.toString();
/* 157 */         log.debug("landingPageJSonFileName" + landingPageJsonFilePath);
/* 158 */         catwfmetadata.put("landingPageJsonFilePath", landingPageJsonFilePath);
/* 159 */         log.debug("LANDING_PAGE_JSON_FILE_NAME property is set in metadata");
/* 160 */         checkfileStatus = Boolean.valueOf(true);
/*     */       }
/*     */     } catch (JSONException e) {
/* 163 */       log.error("JSONException in createLandingPageJson() of CreateLandingPageJson" + e
/* 164 */         .getMessage());
/*     */     }
/* 166 */     return checkfileStatus.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\CreateLandingPageJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */