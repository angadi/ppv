/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.Route;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.Workflow;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium CustomWorkFlowInitiator"})})
/*    */ public class CustomWorkFlowInitiator
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/* 39 */   private static final Logger log = LoggerFactory.getLogger(CustomWorkFlowInitiator.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String ADMIN_APPROVER_ROUTE = "Approver/VppAdmin";
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String AUTHOR_ROUTE = "Author";
/*    */   
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 54 */     ResourceResolver resourceResolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*    */     try {
/* 56 */       String workFlowInitiator = workItem.getWorkflow().getInitiator();
/* 57 */       ArrayList<String> userGroupIds = VppUtil.getUserIds(workFlowInitiator, resourceResolver);
/*    */       
/* 59 */       Boolean isAuthor = isIssuerAuthor(userGroupIds);
/* 60 */       log.debug("isAuthor" + isAuthor);
/*    */       
/* 62 */       List<Route> routes = wfSession.getRoutes(workItem, false);
/* 63 */       Route route = null;
/* 64 */       if (isAuthor.booleanValue()) {
/* 65 */         log.debug("in author route");
/* 66 */         route = VppUtil.getRoute(routes, "Author".trim());
/* 67 */         wfSession.complete(workItem, route);
/*    */       }
/*    */       else {
/* 70 */         log.debug("in admin/approver route");
/* 71 */         route = VppUtil.getRoute(routes, "Approver/VppAdmin".trim());
/* 72 */         wfSession.complete(workItem, route);
/*    */       }
/*    */     } catch (Exception e) {
/* 75 */       log.error("Exception occured in execute() of WorkFlowInitiator " + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Boolean isIssuerAuthor(ArrayList<String> userGroupIds)
/*    */   {
/* 86 */     Boolean isAuthor = Boolean.valueOf(false);
/* 87 */     for (String userGroupId : userGroupIds) {
/* 88 */       if ((userGroupId.contains("vpppremiumadmin")) || 
/* 89 */         (userGroupId.contains("approver"))) {
/* 90 */         isAuthor = Boolean.valueOf(false);
/* 91 */       } else if (userGroupId.contains("author")) {
/* 92 */         isAuthor = Boolean.valueOf(true);
/*    */       }
/*    */     }
/* 95 */     return isAuthor;
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\CustomWorkFlowInitiator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */