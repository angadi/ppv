/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.day.cq.replication.Replicator;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.Property;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import javax.jcr.Value;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={" Premium Deactivate VPP Page"})})
/*    */ public class DeactivatePage
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   private Replicator replicator;
/* 38 */   private static final Logger log = LoggerFactory.getLogger(DeactivatePage.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 49 */     String pagePath = workItem.getWorkflowData().getPayload().toString();
/* 50 */     Session jcrSession = (Session)wfSession.adaptTo(Session.class);
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/* 53 */     String pageJcrPath = sb.toString();
/* 54 */     String pageTemplate = "";
/* 55 */     Boolean categoryCheck = Boolean.valueOf(false);
/* 56 */     log.debug("pageJcrPath in deactivate page" + pageJcrPath);
/*    */     try
/*    */     {
/* 59 */       Node rootNode = jcrSession.getRootNode();
/* 60 */       if (rootNode.hasNode(pageJcrPath)) {
/* 61 */         Node pageJcrNode = rootNode.getNode(pageJcrPath);
/* 62 */         if (pageJcrNode.hasProperty("cq:template")) {
/* 63 */           pageTemplate = pageJcrNode.getProperty("cq:template").getValue().getString();
/* 64 */           log.debug("pageTemplate" + pageTemplate);
/* 65 */           if (pageTemplate.trim().equalsIgnoreCase("/apps/vpp/templates/category_page".trim())) {
/* 66 */             categoryCheck = Boolean.valueOf(true);
/*    */           }
/*    */         }
/* 69 */         MetaDataMap wfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 70 */         if (((categoryCheck.booleanValue()) && (wfmetadata.get("landingPageJsonReplicated") != null)) || 
/* 71 */           ((categoryCheck.booleanValue()) && (wfmetadata.get("no") != null)) || 
/* 72 */           (!categoryCheck.booleanValue())) {
/* 73 */           VppUtil.deactivateResource(jcrSession, pagePath, this.replicator);
/*    */           
/* 75 */           MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 76 */           wfMetaDataMap.put("offerApprovalStatus", "APPROVED");
/* 77 */           log.debug("Page is deactivated");
/*    */         } else {
/* 79 */           log.debug("some error has occured and page is not deactivated");
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (RepositoryException e) {
/* 84 */       log.error("RepositoryException in execute() of DeactivatePage" + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     this.replicator = paramReplicator;
/*    */   }
/*    */   
/*    */   protected void unbindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     if (this.replicator == paramReplicator) {
/*    */       this.replicator = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\DeactivatePage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */