/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.Route;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.util.List;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Identify Vpp Premium Page"})})
/*     */ public class IdentifyVppPage
/*     */   implements WorkflowProcess
/*     */ {
/*  37 */   private static Logger log = LoggerFactory.getLogger(IdentifyVppPage.class);
/*     */   
/*     */   private static final String CATEGORY_CHECK = "category_page";
/*     */   
/*     */   private static final String OFFER_CHECK = "offer_creation";
/*     */   
/*     */   private static final String OTHER_PAGES_CHECK = "other";
/*     */   
/*     */   private static final String CATEGORY_ROUTE = "Category Page";
/*     */   
/*     */   private static final String OFFER_ROUTE = "Offer Page";
/*     */   
/*     */   private static final String OTHER_PAGES_ROUTE = "Other Pages";
/*     */   
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  54 */     Session session = (Session)wfSession.adaptTo(Session.class);
/*  55 */     String pagePath = workItem.getWorkflowData().getPayload().toString();
/*  56 */     String pageTemplate = "";
/*  57 */     StringBuffer sb = new StringBuffer();
/*  58 */     sb.append(pagePath.substring(1)).append("/jcr:content");
/*  59 */     String pageJcrPath = sb.toString();
/*  60 */     log.debug("pageJcrPath" + pageJcrPath);
/*     */     try {
/*  62 */       Node rootNode = session.getRootNode();
/*  63 */       if (rootNode.hasNode(pageJcrPath)) {
/*  64 */         Node pageJcrNode = rootNode.getNode(pageJcrPath);
/*  65 */         if (pageJcrNode.hasProperty("cq:template")) {
/*  66 */           pageTemplate = pageJcrNode.getProperty("cq:template").getValue().toString();
/*  67 */           String[] templateArr = pageTemplate.split("/");
/*  68 */           String templateName = templateArr[(templateArr.length - 1)];
/*  69 */           log.debug("templateName" + templateName);
/*  70 */           String tempCheck = getTemplateName(templateName);
/*  71 */           log.debug("tempCheck" + tempCheck);
/*     */           
/*  73 */           List<Route> routes = wfSession.getRoutes(workItem, false);
/*  74 */           Route route = null;
/*  75 */           if (tempCheck.equalsIgnoreCase("category_page")) {
/*  76 */             log.debug("in category");
/*  77 */             route = VppUtil.getRoute(routes, "Category Page".trim());
/*  78 */             wfSession.complete(workItem, route);
/*  79 */           } else if (tempCheck.equalsIgnoreCase("offer_creation")) {
/*  80 */             log.debug("offer route");
/*  81 */             route = VppUtil.getRoute(routes, "Offer Page".trim());
/*  82 */             wfSession.complete(workItem, route);
/*     */           }
/*     */           else {
/*  85 */             log.debug("other pages route");
/*  86 */             route = VppUtil.getRoute(routes, "Other Pages".trim());
/*  87 */             wfSession.complete(workItem, route);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RepositoryException e) {
/*  92 */       log.error("RepositoryException occured in execute()of IdentifyVppPage" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTemplateName(String templateName)
/*     */   {
/* 103 */     String tempName = "";
/* 104 */     if (templateName.equalsIgnoreCase("category_page")) {
/* 105 */       tempName = "category_page";
/* 106 */     } else if (templateName.equalsIgnoreCase("offer_creation")) {
/* 107 */       tempName = "offer_creation";
/*     */     } else {
/* 109 */       tempName = "other";
/*     */     }
/* 111 */     return tempName;
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\IdentifyVppPage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */