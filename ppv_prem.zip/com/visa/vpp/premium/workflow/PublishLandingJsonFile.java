/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.day.cq.replication.Replicator;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Publish Landing Page JSON"})})
/*    */ public class PublishLandingJsonFile
/*    */   implements WorkflowProcess
/*    */ {
/*    */   @Reference
/*    */   private Replicator replicator;
/* 36 */   private static final Logger log = LoggerFactory.getLogger(PublishLandingJsonFile.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 47 */     MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 48 */     if (catwfmetadata.get("landingPageJsonCheck") != null)
/*    */     {
/* 50 */       String landingPageJsonPath = (String)catwfmetadata.get("landingPageJsonFilePath", String.class);
/* 51 */       log.debug("landingPageJsonPath in PublishLandingJsonFiless" + landingPageJsonPath);
/* 52 */       Session jcrSession = (Session)wfSession.adaptTo(Session.class);
/* 53 */       VppUtil.replicateResource(jcrSession, landingPageJsonPath, this.replicator);
/* 54 */       log.debug("landing page json is replicated");
/* 55 */       catwfmetadata.put("landingPageJsonReplicated", "landingPageJsonReplicated");
/*    */     }
/*    */     else {
/* 58 */       log.debug("landing page json is not replicated beacuse landing page json is not created or no modifications required");
/*    */     }
/*    */   }
/*    */   
/*    */   protected void bindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     this.replicator = paramReplicator;
/*    */   }
/*    */   
/*    */   protected void unbindReplicator(Replicator paramReplicator)
/*    */   {
/*    */     if (this.replicator == paramReplicator) {
/*    */       this.replicator = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\PublishLandingJsonFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */