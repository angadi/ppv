/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Remove Category Page from Landing Page JSON"})})
/*     */ public class RemoveCategoryFromLandingPageJson
/*     */   implements WorkflowProcess
/*     */ {
/*  39 */   private static final Logger log = LoggerFactory.getLogger(RemoveCategoryFromLandingPageJson.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*     */     throws WorkflowException
/*     */   {
/*  50 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/*  51 */     if (wfMetaDataMap.get("customPropertyCheck") != null) {
/*  52 */       String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/*  53 */       log.debug("categoryPagePath in RemoveCategoryFromLandingPageJson" + categoryPagePath);
/*  54 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*     */       try {
/*  56 */         Node rootNode = session.getRootNode();
/*  57 */         String jsonFileLocation = VppJsonUtil.getOfferJsonLocation(categoryPagePath);
/*  58 */         log.debug("jsonFileLocation" + jsonFileLocation);
/*  59 */         if (rootNode.hasNode(categoryPagePath.substring(1))) {
/*  60 */           Node catNode = rootNode.getNode(categoryPagePath.substring(1));
/*  61 */           Node landingNode = catNode.getParent();
/*  62 */           String catNodeName = catNode.getName();
/*  63 */           log.debug("catNodeName" + catNodeName);
/*  64 */           String landingPageFileName = "invalid";
/*     */           
/*  66 */           if (landingNode.hasNode("jcr:content")) {
/*  67 */             Node landPageJcrContent = landingNode.getNode("jcr:content");
/*  68 */             if (landPageJcrContent.hasProperty("landingJsonName"))
/*     */             {
/*  70 */               landingPageFileName = landPageJcrContent.getProperty("landingJsonName").getValue().getString();
/*  71 */               log.debug("landingPageFileName property value" + landingPageFileName);
/*     */             } else {
/*  73 */               log.debug("landingPageFileName property is not set" + landingPageFileName);
/*     */             }
/*     */           }
/*  76 */           log.debug("landingPageFileName" + landingPageFileName);
/*  77 */           StringBuffer sb = new StringBuffer(landingPageFileName);
/*  78 */           String landingPageFileNameJsonExt = ".json";
/*     */           
/*  80 */           JSONObject landingPageJson = VppJsonUtil.getOfferJson(session, jsonFileLocation, landingPageFileNameJsonExt);
/*  81 */           JSONObject categoryPageJson = null;
/*  82 */           if (landingPageJson.has(categoryPagePath)) {
/*  83 */             categoryPageJson = landingPageJson.getJSONObject(categoryPagePath);
/*  84 */             log.debug("categoryPageJson in remove cat from land json" + categoryPageJson);
/*  85 */             landingPageJson.remove(categoryPagePath);
/*  86 */             log.debug("after removing the cat page from landing page json" + landingPageJson);
/*     */             
/*  88 */             String filecreationCheck = VppJsonUtil.createUpdateJsonFile(jsonFileLocation, landingPageFileNameJsonExt, session, landingPageJson);
/*     */             
/*  90 */             log.debug("filecreationCheck" + filecreationCheck);
/*     */             
/*  92 */             if (rootNode.hasNode(jsonFileLocation)) {
/*  93 */               Node parentFileNode = rootNode.getNode(jsonFileLocation);
/*  94 */               if (parentFileNode.hasNode(landingPageFileName)) {
/*  95 */                 Node landingPageFileNode = parentFileNode.getNode(landingPageFileName);
/*  96 */                 String landingPageFilePath = landingPageFileNode.getPath();
/*  97 */                 landingPageFilePath = landingPageFilePath.substring(1);
/*  98 */                 log.debug("landingPageFilePath" + landingPageFilePath);
/*  99 */                 StringBuffer catNameBuffer = new StringBuffer(catNodeName);
/* 100 */                 catNodeName = ".json";
/* 101 */                 log.debug("catNodeName with json extension" + catNodeName);
/*     */                 
/* 103 */                 JSONObject catFileJson = new JSONObject();
/* 104 */                 catFileJson.put(categoryPagePath, categoryPageJson);
/* 105 */                 log.debug("catFileJSON" + catFileJson);
/* 106 */                 String catfilecreationCheck = VppJsonUtil.createUpdateJsonFile(landingPageFilePath, catNodeName, session, catFileJson);
/*     */                 
/* 108 */                 log.debug("catfilecreationCheck" + catfilecreationCheck);
/*     */                 
/* 110 */                 MetaDataMap catwfmetadata = workItem.getWorkflowData().getMetaDataMap();
/* 111 */                 StringBuffer landPageJsonBuffer = new StringBuffer();
/* 112 */                 landPageJsonBuffer.append("/").append(jsonFileLocation)
/* 113 */                   .append("/").append(landingPageFileNameJsonExt);
/* 114 */                 String landingPageJsonFilePath = landPageJsonBuffer.toString();
/* 115 */                 log.debug("landingPageJSonFileName" + landingPageJsonFilePath);
/* 116 */                 catwfmetadata.put("landingPageJsonFilePath", landingPageJsonFilePath);
/*     */                 
/* 118 */                 log.debug("set the LANDING_PAGE_JSON_FILE_NAME property in metadata");
/* 119 */                 session.save();
/* 120 */                 workItem.getWorkflowData().getMetaDataMap().put("landingPageJsonCheck", "landingPageJsonCheck");
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 126 */             log.debug("remove operation not required ,json file name property is not set for landing page or landingPageJson doesnot contain categoryPagePath");
/*     */             
/*     */ 
/* 129 */             if (catNode.hasNode("jcr:content")) {
/* 130 */               Node catJcrNode = catNode.getNode("jcr:content");
/* 131 */               if (catJcrNode.hasNode("more_offers")) {
/* 132 */                 log.debug("it has more offers node");
/*     */               } else {
/* 134 */                 log.debug("it doesn't have more offers node");
/* 135 */                 workItem.getWorkflowData().getMetaDataMap().put("no", "no");
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (RepositoryException e) {
/* 142 */         log.error("RepositoryException occured in execute() of RemoveCategoryFromLandingPageJson" + e
/* 143 */           .getMessage());
/*     */       } catch (JSONException e) {
/* 145 */         log.error("JSONException occured in execute() of RemoveCategoryFromLandingPageJson" + e
/* 146 */           .getMessage());
/*     */       }
/*     */     } else {
/* 149 */       log.error("Category page JSON is not removed because the custom publish property is not set");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\RemoveCategoryFromLandingPageJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */