/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.Route;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.util.List;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"VPP Premium Approver Route"})})
/*    */ public class RouteApprover
/*    */   implements WorkflowProcess
/*    */ {
/* 33 */   private static final Logger log = LoggerFactory.getLogger(RouteApprover.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String APPROVED_ROUTE = "APPROVED";
/*    */   
/*    */ 
/*    */   private static final String REJECTED_ROUTE = "REJECTED";
/*    */   
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/* 47 */     List<Route> routes = wfSession.getRoutes(workItem, false);
/* 48 */     MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 49 */     Route route = null;
/* 50 */     if (wfMetaDataMap.get("offerApprovalStatus") != null) {
/* 51 */       route = VppUtil.getRoute(routes, "APPROVED".trim());
/* 52 */       wfSession.complete(workItem, route);
/* 53 */       log.debug("In approve route");
/*    */     } else {
/* 55 */       route = VppUtil.getRoute(routes, "REJECTED".trim());
/* 56 */       wfSession.complete(workItem, route);
/* 57 */       log.debug("In rejected route");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\RouteApprover.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */