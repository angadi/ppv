/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Category Page Publish Status"})})
/*    */ public class SetCategoryPagePublishStatus
/*    */   implements WorkflowProcess
/*    */ {
/* 34 */   private static final Logger log = LoggerFactory.getLogger(SetCategoryPagePublishStatus.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metadataMap)
/*    */     throws WorkflowException
/*    */   {
/* 45 */     String categoryPagePath = workItem.getWorkflowData().getPayload().toString();
/* 46 */     log.debug("categoryPagePath" + categoryPagePath);
/* 47 */     Session session = (Session)wfSession.adaptTo(Session.class);
/* 48 */     String argument = ((String)metadataMap.get("PROCESS_ARGS", "string")).toString();
/* 49 */     log.debug("argument" + argument);
/*    */     try {
/* 51 */       Node rootNode = session.getRootNode();
/*    */       
/*    */ 
/* 54 */       Boolean setPropertyCheck = VppJsonUtil.setCategoryApprovalStatus(categoryPagePath, rootNode, argument);
/* 55 */       if (setPropertyCheck.booleanValue()) {
/* 56 */         log.debug(argument + "property set successfully");
/* 57 */         MetaDataMap wfMetaDataMap = workItem.getWorkflowData().getMetaDataMap();
/* 58 */         wfMetaDataMap.put("customPropertyCheck", "customPropertyCheck");
/*    */       }
/*    */     } catch (RepositoryException e) {
/* 61 */       log.error("RepositoryException in execute()of SetCategoryPagePublishStatus" + e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\SetCategoryPagePublishStatus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */