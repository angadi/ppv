/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.util.Iterator;
/*     */ import javax.jcr.AccessDeniedException;
/*     */ import javax.jcr.ItemNotFoundException;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.ValueFormatException;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Update Category Pages for current offer changes"})})
/*     */ public class UpdateCategoryPages
/*     */   implements WorkflowProcess
/*     */ {
/*  40 */   private static final Logger log = LoggerFactory.getLogger(UpdateCategoryPages.class);
/*     */   
/*     */ 
/*     */   private static final String OFFER_CREATION_NODE = "offer_creation";
/*     */   
/*     */ 
/*     */   private static final String DATA_SEPARATOR = "##";
/*     */   
/*     */ 
/*     */   private static final String TO_BE_UNTAGGED = "toBeUntagged";
/*     */   
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  55 */     String payLoad = workItem.getWorkflowData().getPayload().toString();
/*  56 */     WorkflowData workflowData = workItem.getWorkflowData();
/*  57 */     MetaDataMap wfmetadata = workflowData.getMetaDataMap();
/*  58 */     String offerApprovalStatus = (String)wfmetadata.get("offerApprovalStatus", String.class);
/*  59 */     log.debug("Offer Approval Status  : " + offerApprovalStatus);
/*  60 */     String offerJsonLocation = (String)wfmetadata.get("offerJSONLocation", String.class);
/*  61 */     Session jcrSession = null;
/*  62 */     String offerId = "";
/*     */     try {
/*  64 */       jcrSession = (Session)wfSession.adaptTo(Session.class);
/*  65 */       if ((offerApprovalStatus != null) && (offerJsonLocation != null)) {
/*  66 */         Node pageJcrNode = jcrSession.getNode(payLoad + "/jcr:content");
/*  67 */         offerId = pageJcrNode.getProperty("offerId").getString();
/*  68 */         Node offerCreation = pageJcrNode.getNode("offer_creation");
/*  69 */         if (offerCreation.hasProperty("categoryMap")) {
/*  70 */           String categoryMap = offerCreation.getProperty("categoryMap").getString();
/*     */           
/*  72 */           JSONObject updateResult = updateCategoryPages(jcrSession, offerJsonLocation, categoryMap, offerId);
/*  73 */           log.debug("Final String for Updated Content " + updateResult.toString());
/*  74 */           if (updateResult.has("toBePublished")) {
/*  75 */             JSONArray jsonUpdateRes = updateResult.getJSONArray("toBePublished");
/*  76 */             if (jsonUpdateRes.length() != 0) {
/*  77 */               StringBuilder toBePublishedRes = new StringBuilder(jsonUpdateRes.getString(0));
/*  78 */               for (int i = 1; i < jsonUpdateRes.length(); i++) {
/*  79 */                 toBePublishedRes.append("##").append(jsonUpdateRes.getString(i));
/*     */               }
/*  81 */               wfmetadata.put("toBePublished", toBePublishedRes.toString());
/*     */             }
/*     */           }
/*  84 */           if (updateResult.has("toBeUntagged")) {
/*  85 */             JSONArray pageUpdateRes = updateResult.getJSONArray("toBeUntagged");
/*  86 */             if (pageUpdateRes.length() != 0) {
/*  87 */               JSONObject categoryMapObj = new JSONObject(categoryMap);
/*  88 */               for (int i = 0; i < pageUpdateRes.length(); i++) {
/*  89 */                 categoryMapObj.remove(pageUpdateRes.getString(i));
/*  90 */                 log.debug("Untagged Category Page " + pageUpdateRes.getString(i));
/*     */               }
/*  92 */               offerCreation.setProperty("categoryMap", categoryMapObj.toString());
/*     */             }
/*     */           }
/*  95 */           jcrSession.save();
/*     */         } else {
/*  97 */           log.debug("Offer Not Tagged Under Any Category Page . Aborting Category Page Updation.");
/*     */         }
/*     */       } else {
/* 100 */         log.debug("Failed to create/update Offer JSON . Aborting Category Page Updation.");
/*     */       }
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 104 */       log.error("Path Not Found Exception Occured in UpdateCategoryPages execute()" + e
/* 105 */         .getMessage());
/*     */     } catch (ValueFormatException e) {
/* 107 */       log.error("ValueFormat Exception Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     } catch (RepositoryException e) {
/* 109 */       log.error("Repository Exception Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 111 */       log.error("JSONException Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     } catch (Exception e) {
/* 113 */       log.error("Exception Occured in UpdateCategoryPages execute()" + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject updateCategoryPages(Session jcrSession, String offerJsonLocation, String categoryMap, String currOfferId)
/*     */   {
/* 130 */     JSONObject currentData = new JSONObject();
/* 131 */     JSONObject resultJson = new JSONObject();
/* 132 */     JSONObject aemOffers = VppJsonUtil.getOfferJson(jcrSession, offerJsonLocation, "aem_offers.json");
/*     */     
/* 134 */     if (aemOffers.has(currOfferId)) {
/* 135 */       currentData = VppJsonUtil.getCurrOfferData(aemOffers, currOfferId);
/*     */     } else {
/* 137 */       log.debug("Inactive Offer to be removed from Category Pages");
/*     */     }
/*     */     try {
/* 140 */       JSONObject categoryPages = new JSONObject(categoryMap);
/* 141 */       Iterator<?> catPagePaths = categoryPages.keys();
/* 142 */       JSONArray jsonUpdateResult = new JSONArray();
/* 143 */       JSONArray pageUpdateResult = new JSONArray();
/*     */       
/* 145 */       while (catPagePaths.hasNext()) {
/* 146 */         String currCatPagePath = (String)catPagePaths.next();
/*     */         
/* 148 */         String currPageUpdateRes = "";
/* 149 */         String[] currJsonUpdateRes = updateCurrentJsonData(jcrSession, currCatPagePath, offerJsonLocation, currOfferId, currentData);
/*     */         
/* 151 */         if (!currJsonUpdateRes[0].equalsIgnoreCase("failure")) {
/* 152 */           if (!currJsonUpdateRes[0].equalsIgnoreCase("success")) {
/* 153 */             jsonUpdateResult.put(currJsonUpdateRes[0]);
/* 154 */             jsonUpdateResult.put(currJsonUpdateRes[1]);
/*     */           }
/* 156 */           currPageUpdateRes = VppUtil.updateCurrentCategoryPage(currCatPagePath, currOfferId, currentData, jcrSession);
/*     */           
/* 158 */           if ((!currPageUpdateRes.equalsIgnoreCase("success")) && 
/* 159 */             (!currPageUpdateRes.equalsIgnoreCase("failure"))) {
/* 160 */             pageUpdateResult.put(currPageUpdateRes);
/*     */           }
/* 162 */           resultJson.put("toBePublished", jsonUpdateResult);
/* 163 */           resultJson.put("toBeUntagged", pageUpdateResult);
/*     */         }
/*     */       }
/*     */     } catch (JSONException e) {
/* 167 */       log.error("JSONException Occured in UpdateCategoryPages updateCategoryPages()" + e.getMessage());
/*     */     } catch (Exception e) {
/* 169 */       log.error("Exception Occured in UpdateCategoryPages updateCategoryPages()" + e.getMessage());
/*     */     }
/*     */     
/* 172 */     return resultJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] updateCurrentJsonData(Session jcrSession, String catPagePath, String offerJsonLocation, String currOfferId, JSONObject currentData)
/*     */   {
/* 188 */     log.debug("Current Page Path " + catPagePath);
/* 189 */     boolean updateTracker = false;
/* 190 */     String[] toBePublished = new String[2];
/* 191 */     toBePublished[0] = "failure";
/*     */     try {
/* 193 */       StringBuilder sb = new StringBuilder(catPagePath);
/* 194 */       sb.append("/");
/* 195 */       sb.append("jcr:content");
/* 196 */       Node catContentNode = jcrSession.getNode(sb.toString());
/* 197 */       String landingDetails = getLandingDetails(catContentNode);
/* 198 */       log.debug("Landing Details : " + landingDetails);
/* 199 */       String catePageName = catContentNode.getParent().getName();
/* 200 */       JSONObject currCatJson = new JSONObject();
/*     */       
/* 202 */       if (catContentNode.hasProperty("catApprovalStatus"))
/*     */       {
/* 204 */         if (catContentNode.getProperty("catApprovalStatus").getString().equalsIgnoreCase("ACTIVATED")) {
/* 205 */           log.debug("Published Category Page, Initiating Updation of Landing Page JSON");
/* 206 */           JSONObject landingPageJson = VppJsonUtil.getOfferJson(jcrSession, offerJsonLocation, landingDetails + ".json");
/*     */           
/* 208 */           if (landingPageJson.has(catPagePath)) {
/* 209 */             currCatJson = landingPageJson.getJSONObject(catPagePath);
/* 210 */             if (currentData.length() == 0) {
/* 211 */               currCatJson.remove(currOfferId);
/* 212 */               updateTracker = true;
/*     */             }
/* 214 */             else if (currCatJson.has(currOfferId)) {
/* 215 */               JSONObject categoryOfferObj = currCatJson.getJSONObject(currOfferId);
/* 216 */               if (!VppJsonUtil.areEqual(categoryOfferObj, currentData)) {
/* 217 */                 currCatJson.put(currOfferId, currentData);
/* 218 */                 updateTracker = true;
/*     */               }
/*     */             } else {
/* 221 */               toBePublished[0] = "success";
/* 222 */               return toBePublished;
/*     */             }
/*     */           }
/*     */           
/* 226 */           if (updateTracker) {
/* 227 */             toBePublished[0] = catPagePath;
/* 228 */             StringBuilder sb1 = new StringBuilder("/");
/* 229 */             sb1.append(offerJsonLocation).append("/").append(landingDetails)
/* 230 */               .append(".json");
/* 231 */             toBePublished[1] = sb1.toString();
/* 232 */             landingPageJson.put(catPagePath, currCatJson);
/* 233 */             String updateJson = VppJsonUtil.createUpdateJsonFile(offerJsonLocation, landingDetails + ".json", jcrSession, landingPageJson);
/*     */             
/* 235 */             if (updateJson.equalsIgnoreCase("success"))
/* 236 */               log.debug("Landing Page JSON Updated Successfully");
/*     */           }
/*     */           break label636;
/*     */         } }
/* 240 */       log.debug("UnPublished Category Page , Initiating Updation Category Page JSON");
/* 241 */       StringBuilder sb1 = new StringBuilder(catePageName);
/* 242 */       sb1.append(".json");
/* 243 */       StringBuilder sb2 = new StringBuilder(offerJsonLocation);
/* 244 */       sb2.append("/").append(landingDetails);
/*     */       
/* 246 */       JSONObject categoryPageJson = VppJsonUtil.getOfferJson(jcrSession, sb2.toString(), sb1.toString());
/* 247 */       if (categoryPageJson.has(catPagePath)) {
/* 248 */         currCatJson = categoryPageJson.getJSONObject(catPagePath);
/* 249 */         if (currentData.length() == 0) {
/* 250 */           currCatJson.remove(currOfferId);
/* 251 */           updateTracker = true;
/*     */         }
/* 253 */         else if (currCatJson.has(currOfferId)) {
/* 254 */           JSONObject categoryOfferObj = currCatJson.getJSONObject(currOfferId);
/* 255 */           if (!VppJsonUtil.areEqual(categoryOfferObj, currentData)) {
/* 256 */             currCatJson.put(currOfferId, currentData);
/* 257 */             updateTracker = true;
/*     */           }
/*     */         } else {
/* 260 */           toBePublished[0] = "success";
/* 261 */           return toBePublished;
/*     */         }
/*     */       }
/*     */       
/* 265 */       if (updateTracker) {
/* 266 */         toBePublished[0] = "success";
/* 267 */         categoryPageJson.put(catPagePath, currCatJson);
/* 268 */         String updateJson = VppJsonUtil.createUpdateJsonFile(sb2.toString(), sb1.toString(), jcrSession, categoryPageJson);
/*     */         
/* 270 */         if (updateJson.equalsIgnoreCase("success")) {
/* 271 */           log.debug("Category Page JSON Updated Successfully");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (PathNotFoundException e) {
/* 276 */       log.error("Path Not Found Exception Occured in UpdateCategoryPages updateCurrentJSONData()" + e
/* 277 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 279 */       log.error("Repository Exception Occured in UpdateCategoryPages updateCurrentJSONData()" + e
/* 280 */         .getMessage());
/*     */     } catch (JSONException e) {
/* 282 */       log.error("JSONException Occured in UpdateCategoryPages updateCurrentJSONData()" + e.getMessage());
/*     */     } catch (Exception e) { label636:
/* 284 */       log.error("Exception Occured in UpdateCategoryPages updateCurrentJSONData()" + e
/* 285 */         .getMessage());
/*     */     }
/* 287 */     return toBePublished;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getLandingDetails(Node catContentNode)
/*     */   {
/*     */     try
/*     */     {
/* 298 */       Node landingPageNode = catContentNode.getParent().getParent();
/* 299 */       if (landingPageNode.hasNode("jcr:content")) {
/* 300 */         Node landingJcrNode = landingPageNode.getNode("jcr:content");
/* 301 */         if (landingJcrNode.hasProperty("landingJsonName")) {
/* 302 */           return landingJcrNode.getProperty("landingJsonName").getString();
/*     */         }
/*     */       }
/*     */     } catch (AccessDeniedException e) {
/* 306 */       log.error("AccessDeniedException Occured in UpdateCategoryPages getLandingDetails()" + e
/* 307 */         .getMessage());
/*     */     } catch (ItemNotFoundException e) {
/* 309 */       log.error("ItemNotFoundException Occured in UpdateCategoryPages getLandingDetails()" + e
/* 310 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 312 */       log.error("Repository Exception Occured in UpdateCategoryPages getLandingDetails()" + e
/* 313 */         .getMessage());
/*     */     } catch (Exception e) {
/* 315 */       log.error("Exception Occured in UpdateCategoryPages getLandingDetails()" + e.getMessage());
/*     */     }
/* 317 */     log.debug("Landing Page Details Not found , No Update operation will be performed");
/* 318 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\UpdateCategoryPages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */