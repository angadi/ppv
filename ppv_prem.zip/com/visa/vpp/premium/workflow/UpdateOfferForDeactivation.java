/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.adobe.granite.workflow.WorkflowException;
/*    */ import com.adobe.granite.workflow.WorkflowSession;
/*    */ import com.adobe.granite.workflow.exec.WorkItem;
/*    */ import com.adobe.granite.workflow.exec.WorkflowData;
/*    */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*    */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.PathNotFoundException;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import javax.jcr.ValueFormatException;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Update Offer For Deactivation"})})
/*    */ public class UpdateOfferForDeactivation
/*    */   implements WorkflowProcess
/*    */ {
/* 38 */   private static final Logger log = LoggerFactory.getLogger(UpdateOfferForDeactivation.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/* 49 */     String payLoad = workItem.getWorkflowData().getPayload().toString();
/* 50 */     Session session = (Session)wfSession.adaptTo(Session.class);
/*    */     try
/*    */     {
/* 53 */       Node rootNode = session.getRootNode();
/* 54 */       if (rootNode.hasNode(payLoad.substring(1) + "/jcr:content")) {
/* 55 */         Node pageJcrNode = rootNode.getNode(payLoad.substring(1) + "/jcr:content");
/* 56 */         if (pageJcrNode.hasNode("offer_creation")) {
/* 57 */           Node offerCreation = pageJcrNode.getNode("offer_creation");
/* 58 */           offerCreation.setProperty("offerStatus", "inactive");
/*    */         } else {
/* 60 */           log.debug("Unauthored Page Inactive property Not Set, Page is invalid");
/*    */         }
/*    */       }
/* 63 */       session.save();
/*    */     } catch (PathNotFoundException e) {
/* 65 */       log.error("Path Not Found Exception Occured in UpdateOfferForDeactivation execute()" + e
/* 66 */         .getMessage());
/*    */     } catch (ValueFormatException e) {
/* 68 */       log.error("Value Format Exception Occured in UpdateOfferForDeactivation execute()" + e
/* 69 */         .getMessage());
/*    */     } catch (RepositoryException e) {
/* 71 */       log.error("Repository Exception Occured in UpdateOfferForDeactivation execute()" + e
/* 72 */         .getMessage());
/*    */     } catch (Exception e) {
/* 74 */       log.error("Exception Occured in UpdateOfferForDeactivation execute()" + e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\UpdateOfferForDeactivation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */