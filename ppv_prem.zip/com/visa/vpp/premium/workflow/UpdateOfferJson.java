/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.adobe.granite.workflow.WorkflowException;
/*     */ import com.adobe.granite.workflow.WorkflowSession;
/*     */ import com.adobe.granite.workflow.exec.WorkItem;
/*     */ import com.adobe.granite.workflow.exec.WorkflowData;
/*     */ import com.adobe.granite.workflow.exec.WorkflowProcess;
/*     */ import com.adobe.granite.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.utill.VppJsonUtil;
/*     */ import com.visa.vpp.premium.utill.VppUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.jcr.Binary;
/*     */ import javax.jcr.Node;
/*     */ import javax.jcr.PathNotFoundException;
/*     */ import javax.jcr.Property;
/*     */ import javax.jcr.RepositoryException;
/*     */ import javax.jcr.Session;
/*     */ import javax.jcr.Value;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Properties;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*     */ import org.apache.sling.commons.json.JSONArray;
/*     */ import org.apache.sling.commons.json.JSONException;
/*     */ import org.apache.sling.commons.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ @Service
/*     */ @Properties({@org.apache.felix.scr.annotations.Property(name="process.label", value={"Premium Create/Update AEM Offer Listing JSON"})})
/*     */ public class UpdateOfferJson
/*     */   implements WorkflowProcess
/*     */ {
/*  55 */   private static final Logger log = LoggerFactory.getLogger(UpdateOfferJson.class);
/*     */   private static final String TYPE_JCR_PATH = "JCR_PATH";
/*     */   private static final String PREVIEW_URL = "previewURL";
/*     */   private static final String PREVIEW_DEFINITION = "?wcmmode=disabled";
/*     */   private static final String OFFER_FIELDS_MULTI = "categories,cardProducts,cardPayment";
/*  60 */   private static final String[] OFFER_FIELDS = { "pageType", "offerTitle", "offerShortDesc", "promoStartDate", "promoEndDate", "categories", "cardProducts", "cardPayment", "offerStatus", "merchantName", "benefitTypeCode" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   ResourceResolverFactory resolverFactory;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*     */     throws WorkflowException
/*     */   {
/*  79 */     String payLoad = workItem.getWorkflowData().getPayload().toString();
/*  80 */     String offerId = "";
/*  81 */     WorkflowData workflowData = workItem.getWorkflowData();
/*  82 */     MetaDataMap wfmetadata = workflowData.getMetaDataMap();
/*  83 */     if (workflowData.getPayloadType().equals("JCR_PATH")) {
/*  84 */       Session session = (Session)wfSession.adaptTo(Session.class);
/*  85 */       ResourceResolver resolver = null;
/*     */       try {
/*  87 */         Node rootNode = session.getRootNode();
/*  88 */         JSONObject currentOfferJson = new JSONObject();
/*  89 */         String lastModified = "";
/*  90 */         if (rootNode.hasNode(payLoad.substring(1) + "/jcr:content"))
/*     */         {
/*  92 */           Node pageJcrNode = rootNode.getNode(payLoad.substring(1) + "/jcr:content");
/*  93 */           if (pageJcrNode.hasProperty("offerId")) {
/*  94 */             offerId = pageJcrNode.getProperty("offerId").getString();
/*     */           }
/*  96 */           if (pageJcrNode.hasProperty("cq:lastModified")) {
/*  97 */             lastModified = pageJcrNode.getProperty("cq:lastModified").getString();
/*     */           }
/*     */           
/* 100 */           if (pageJcrNode.hasNode("offer_creation")) {
/* 101 */             Node offerCreation = pageJcrNode.getNode("offer_creation");
/* 102 */             String offerStatus = "";
/* 103 */             if (offerCreation.hasProperty("offerStatus")) {
/* 104 */               offerStatus = offerCreation.getProperty("offerStatus").getString();
/*     */             }
/* 106 */             String offerJsonLocation = "";
/* 107 */             boolean updateStatus = false;
/* 108 */             offerJsonLocation = VppJsonUtil.getOfferJsonLocation(payLoad);
/* 109 */             JSONObject offerJson = getOfferJson(session, offerJsonLocation);
/* 110 */             if (offerStatus.equalsIgnoreCase("active")) {
/* 111 */               for (int j = 0; j < OFFER_FIELDS.length; j++) {
/* 112 */                 if (offerCreation.hasProperty(OFFER_FIELDS[j])) {
/* 113 */                   Property currentProp = offerCreation.getProperty(OFFER_FIELDS[j]);
/* 114 */                   if (currentProp.isMultiple()) {
/* 115 */                     Value[] values = currentProp.getValues();
/* 116 */                     JSONArray stringValues = new JSONArray();
/* 117 */                     for (int i = 0; i < values.length; i++) {
/* 118 */                       stringValues.put(values[i].getString());
/*     */                     }
/* 120 */                     currentOfferJson.put(OFFER_FIELDS[j], stringValues);
/*     */                   }
/* 122 */                   else if ("categories,cardProducts,cardPayment".contains(OFFER_FIELDS[j])) {
/* 123 */                     JSONArray stringValues = new JSONArray();
/* 124 */                     stringValues.put(currentProp.getValue().getString());
/* 125 */                     currentOfferJson.put(OFFER_FIELDS[j], stringValues);
/*     */                   } else {
/* 127 */                     currentOfferJson.put(OFFER_FIELDS[j], currentProp.getValue().getString());
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/* 132 */               resolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/*     */               
/*     */ 
/* 135 */               String defaultHeroImg = getDefaultImage("fileReferenceHeroImage", payLoad, session);
/*     */               
/* 137 */               String defaultMerchLogoImg = getDefaultImage("fileReferenceLogoImage", payLoad, session);
/*     */               
/* 139 */               String defaultThumbnailImg = getDefaultImage("fileReferenceThumbImage", payLoad, session);
/*     */               
/* 141 */               if (offerCreation.hasProperty("heroImage"))
/*     */               {
/* 143 */                 String heroImage = offerCreation.getProperty("heroImage").getString();
/* 144 */                 Resource res = resolver.getResource(heroImage);
/* 145 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 146 */                 log.debug("Current Hero Image Width_Height  : " + currImgWidthHeight);
/* 147 */                 String defaultImgWidthHeight = "";
/* 148 */                 if (!defaultHeroImg.equalsIgnoreCase("failure")) {
/* 149 */                   res = resolver.getResource(defaultHeroImg);
/* 150 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 152 */                 log.debug("Default Hero Image Width_Height  : " + defaultImgWidthHeight);
/* 153 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 154 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 155 */                   offerCreation.setProperty("validHeroImg", "VALID");
/* 156 */                   currentOfferJson.put("heroImage", heroImage);
/*     */                 } else {
/* 158 */                   offerCreation.setProperty("validHeroImg", defaultHeroImg);
/* 159 */                   currentOfferJson.put("heroImage", defaultHeroImg);
/*     */                 }
/*     */               } else {
/* 162 */                 log.debug("No Hero Image Authored . Assigning default Hero Image");
/* 163 */                 offerCreation.setProperty("validHeroImg", defaultHeroImg);
/* 164 */                 currentOfferJson.put("heroImage", defaultHeroImg);
/*     */               }
/* 166 */               if (offerCreation.hasProperty("thumbImage"))
/*     */               {
/* 168 */                 String thumbImage = offerCreation.getProperty("thumbImage").getString();
/* 169 */                 Resource res = resolver.getResource(thumbImage);
/* 170 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 171 */                 log.debug("Current Thumbnail Image Width_Height  : " + currImgWidthHeight);
/* 172 */                 String defaultImgWidthHeight = "";
/* 173 */                 if (!defaultThumbnailImg.equalsIgnoreCase("failure")) {
/* 174 */                   res = resolver.getResource(defaultThumbnailImg);
/* 175 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 177 */                 log.debug("Default Thumbnail Image Width_Height  : " + defaultImgWidthHeight);
/* 178 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 179 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 180 */                   currentOfferJson.put("thumbImage", thumbImage);
/*     */                 } else {
/* 182 */                   currentOfferJson.put("thumbImage", defaultThumbnailImg);
/*     */                 }
/*     */               } else {
/* 185 */                 log.debug("No ThumbNail Image Authored . Assigning default ThumbNail Image");
/* 186 */                 currentOfferJson.put("thumbImage", defaultThumbnailImg);
/*     */               }
/* 188 */               if (offerCreation.hasProperty("merchantLogo"))
/*     */               {
/* 190 */                 String merchLogo = offerCreation.getProperty("merchantLogo").getString();
/* 191 */                 Resource res = resolver.getResource(merchLogo);
/* 192 */                 String currImgWidthHeight = VppUtil.getImageWidthHeight(res);
/* 193 */                 log.debug("Current Merchant Logo Image Width_Height  : " + currImgWidthHeight);
/* 194 */                 String defaultImgWidthHeight = "";
/* 195 */                 if (!defaultMerchLogoImg.equalsIgnoreCase("failure")) {
/* 196 */                   res = resolver.getResource(defaultMerchLogoImg);
/* 197 */                   defaultImgWidthHeight = VppUtil.getImageWidthHeight(res);
/*     */                 }
/* 199 */                 log.debug("Default Merchant Logo Image Width_Height  : " + defaultImgWidthHeight);
/* 200 */                 if ((currImgWidthHeight.equalsIgnoreCase(defaultImgWidthHeight)) && 
/* 201 */                   (!currImgWidthHeight.equalsIgnoreCase(""))) {
/* 202 */                   offerCreation.setProperty("validMerchLogoImg", "VALID");
/*     */                 }
/*     */                 else {
/* 205 */                   offerCreation.setProperty("validMerchLogoImg", defaultMerchLogoImg);
/*     */                 }
/*     */               }
/*     */               else {
/* 209 */                 log.debug("No Merchant Logo Image Authored . Assigning default Merchant Logo Image");
/*     */                 
/* 211 */                 offerCreation.setProperty("validMerchLogoImg", defaultMerchLogoImg);
/*     */               }
/* 213 */               currentOfferJson.put("offerId", offerId);
/* 214 */               currentOfferJson.put("previewURL", payLoad + ".html" + "?wcmmode=disabled");
/*     */               
/* 216 */               currentOfferJson.put("offerSource", "AEM");
/* 217 */               currentOfferJson.put("offerLastModified", lastModified);
/* 218 */               offerJson.put(offerId, currentOfferJson);
/* 219 */               updateStatus = createUpdateOfferJson(session, offerJson, offerJsonLocation);
/* 220 */               wfmetadata.put("offerJSONLocation", offerJsonLocation);
/*     */             }
/*     */             else {
/* 223 */               if (offerJson.has(offerId)) {
/* 224 */                 offerJson.remove(offerId);
/* 225 */                 updateStatus = createUpdateOfferJson(session, offerJson, offerJsonLocation);
/* 226 */                 wfmetadata.put("offerJSONLocation", offerJsonLocation);
/* 227 */                 log.debug("INACTIVE Offer removed from Aggregated Offer JSON");
/*     */               } else {
/* 229 */                 log.debug("Offer JSON Not updated as the offer is currently in INACTIVE state");
/*     */               }
/* 231 */               updateStatus = true;
/*     */             }
/*     */             
/* 234 */             if (updateStatus) {
/* 235 */               pageJcrNode.setProperty("offerApprovalStatus", "APPROVED");
/*     */               
/* 237 */               wfmetadata.put("offerApprovalStatus", "APPROVED");
/* 238 */               log.debug("Offer Approval Property Set Successfully");
/*     */             }
/*     */           } else {
/* 241 */             log.debug("Unauthored Page Approval Not Set, Page is rejected");
/*     */           }
/* 243 */           session.save();
/*     */         }
/*     */       } catch (PathNotFoundException e) {
/* 246 */         log.error("Path Not Found Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } catch (RepositoryException e) {
/* 248 */         log.error("Repository Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } catch (Exception e) {
/* 250 */         log.error("Exception Occured in UpdateOfferJSON execute()" + e.getMessage());
/*     */       } finally {
/* 252 */         if (resolver != null) {
/* 253 */           log.debug("Resolver closed in UpdateOfferJSON execute()");
/* 254 */           resolver.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSONObject getOfferJson(Session jcrSession, String offerJsonLocation)
/*     */   {
/* 271 */     InputStream inputStream = null;
/* 272 */     StringBuilder jsonSb = new StringBuilder();
/* 273 */     JSONObject offerJson = new JSONObject();
/* 274 */     BufferedReader bufferRead = null;
/*     */     try
/*     */     {
/* 277 */       StringBuilder sb = new StringBuilder(offerJsonLocation);
/* 278 */       sb.append("/");
/* 279 */       sb.append("aem_offers.json");
/* 280 */       sb.append("/");
/* 281 */       sb.append("jcr:content");
/* 282 */       String offerJsonfilePath = sb.toString();
/* 283 */       Node rootNode = jcrSession.getRootNode();
/* 284 */       if (rootNode.hasNode(offerJsonfilePath)) {
/* 285 */         Node fileJcrNode = rootNode.getNode(offerJsonfilePath);
/* 286 */         if (fileJcrNode.hasProperty("jcr:data")) {
/* 287 */           inputStream = fileJcrNode.getProperty("jcr:data").getBinary().getStream();
/* 288 */           bufferRead = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
/*     */           
/* 290 */           String line = "";
/* 291 */           while ((line = bufferRead.readLine()) != null) {
/* 292 */             jsonSb.append(line);
/*     */           }
/*     */         }
/* 295 */         offerJson = new JSONObject(jsonSb.toString());
/*     */       }
/*     */     } catch (RepositoryException e) {
/* 298 */       log.error("Repository Exception Occured in UpdateOfferJSON getOfferJSON():" + e.getMessage());
/*     */     } catch (IOException e) {
/* 300 */       log.error("IO Exception Occured in UpdateOfferJSON getOfferJSON() :" + e.getMessage());
/*     */     } catch (JSONException e) {
/* 302 */       log.error("JSONException Occured in UpdateOfferJSON getOfferJSON()" + e.getMessage());
/*     */     } catch (Exception e) {
/* 304 */       log.error("Exception Occured in UpdateOfferJSON getOfferJSON():" + e.getMessage());
/*     */     } finally {
/* 306 */       VppUtil.closeBufferReader(bufferRead);
/* 307 */       VppUtil.closeInputStream(inputStream);
/*     */     }
/* 309 */     return offerJson;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean createUpdateOfferJson(Session jcrSession, JSONObject offerJson, String offerJsonLocation)
/*     */   {
/* 321 */     boolean updateStatus = false;
/*     */     try
/*     */     {
/* 324 */       Node rootNode = jcrSession.getRootNode();
/* 325 */       Node folderPathNode = null;
/* 326 */       Node fileNode = null;
/* 327 */       Node fileJcrNode = null;
/*     */       
/* 329 */       if (rootNode.hasNode(offerJsonLocation)) {
/* 330 */         folderPathNode = rootNode.getNode(offerJsonLocation);
/*     */       }
/* 332 */       else if (rootNode.hasNode("etc/vpp-premium-tools/offers")) {
/* 333 */         Node issuerNode = null;
/* 334 */         Node baseFolderNode = rootNode.getNode("etc/vpp-premium-tools/offers");
/* 335 */         String[] offerLocationArr = offerJsonLocation.split("/");
/* 336 */         String issuerString = offerLocationArr[(offerLocationArr.length - 2)];
/* 337 */         String languageString = offerLocationArr[(offerLocationArr.length - 1)];
/* 338 */         if (baseFolderNode.hasNode(issuerString)) {
/* 339 */           issuerNode = baseFolderNode.getNode(issuerString);
/*     */         } else {
/* 341 */           issuerNode = baseFolderNode.addNode(issuerString, "nt:folder");
/*     */         }
/* 343 */         if (issuerNode.hasNode(languageString)) {
/* 344 */           folderPathNode = issuerNode.getNode(languageString);
/*     */         } else {
/* 346 */           folderPathNode = issuerNode.addNode(languageString, "nt:folder");
/*     */         }
/*     */       } else {
/* 349 */         log.debug("Base Folder not Available , JSON not created ");
/*     */       }
/*     */       
/* 352 */       if (folderPathNode != null) {
/* 353 */         if (folderPathNode.hasNode("aem_offers.json")) {
/* 354 */           fileNode = folderPathNode.getNode("aem_offers.json");
/* 355 */           fileJcrNode = fileNode.getNode("jcr:content");
/* 356 */           log.debug("Update Operation : JSON Updated");
/*     */         } else {
/* 358 */           fileNode = folderPathNode.addNode("aem_offers.json", "nt:file");
/*     */           
/* 360 */           fileJcrNode = fileNode.addNode("jcr:content", "nt:resource");
/* 361 */           log.debug("Create Operation : JSON Created");
/*     */         }
/*     */       }
/* 364 */       if (fileJcrNode != null) {
/* 365 */         fileJcrNode.setProperty("jcr:mimeType", "application/json");
/* 366 */         fileJcrNode.setProperty("jcr:data", offerJson.toString());
/* 367 */         updateStatus = true;
/*     */       }
/*     */     } catch (PathNotFoundException e) {
/* 370 */       log.error("Path Not Found Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e
/* 371 */         .getMessage());
/*     */     } catch (RepositoryException e) {
/* 373 */       log.error("Repository Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e
/* 374 */         .getMessage());
/*     */     } catch (Exception e) {
/* 376 */       log.error("Exception Occured in UpdateOfferJSON createUpdateOfferJSON() :" + e.getMessage());
/*     */     }
/* 378 */     return updateStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getDefaultImage(String currImg, String payLoad, Session jcrSession)
/*     */   {
/* 391 */     String defaultImg = "";
/*     */     try {
/* 393 */       String langPagePath = payLoad.substring(0, payLoad.indexOf("/aem"));
/* 394 */       StringBuilder sb = new StringBuilder(langPagePath.substring(1));
/* 395 */       sb.append("/");
/* 396 */       sb.append("VMORC_Offer_Program_List/jcr:content/imageDimension");
/* 397 */       Node rootNode = jcrSession.getRootNode();
/* 398 */       if (rootNode.hasNode(sb.toString())) {
/* 399 */         Node imgNode = rootNode.getNode(sb.toString());
/* 400 */         if (imgNode.hasProperty(currImg)) {
/* 401 */           return imgNode.getProperty(currImg).getString();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RepositoryException e) {
/* 406 */       log.error("Repository Exception Occured in UpdateOfferJSON getDefaultImage() : " + e
/* 407 */         .getMessage());
/*     */     } catch (Exception e) {
/* 409 */       log.error("Exception Occured in UpdateOfferJSON getDefaultImage() : " + e.getMessage());
/*     */     }
/* 411 */     log.debug("No default Image found for key : " + currImg);
/* 412 */     return "failure";
/*     */   }
/*     */   
/*     */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     this.resolverFactory = paramResourceResolverFactory;
/*     */   }
/*     */   
/*     */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*     */   {
/*     */     if (this.resolverFactory == paramResourceResolverFactory) {
/*     */       this.resolverFactory = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\UpdateOfferJson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */