/*    */ package com.visa.vpp.premium.workflow;
/*    */ 
/*    */ import com.day.cq.workflow.WorkflowException;
/*    */ import com.day.cq.workflow.WorkflowSession;
/*    */ import com.day.cq.workflow.exec.ParticipantStepChooser;
/*    */ import com.day.cq.workflow.exec.WorkItem;
/*    */ import com.day.cq.workflow.exec.Workflow;
/*    */ import com.day.cq.workflow.metadata.MetaDataMap;
/*    */ import com.visa.vpp.premium.utill.VppUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import org.apache.felix.scr.annotations.Component;
/*    */ import org.apache.felix.scr.annotations.Properties;
/*    */ import org.apache.felix.scr.annotations.Reference;
/*    */ import org.apache.felix.scr.annotations.Service;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ @Service
/*    */ @Properties({@org.apache.felix.scr.annotations.Property(name="chooser.label", value={"Vpp Premium Dynamic Participant Chooser"})})
/*    */ public class VppDynamicParticipantStep
/*    */   implements ParticipantStepChooser
/*    */ {
/*    */   @Reference
/*    */   ResourceResolverFactory resolverFactory;
/* 39 */   private static final Logger log = LoggerFactory.getLogger(VppDynamicParticipantStep.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String UNDERSCORE = "_";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getParticipant(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/* 51 */     log.debug(" Inside Dynamic Participient Step ");
/*    */     
/* 53 */     ResourceResolver resourceResolver = VppUtil.getUserResourceResolver(this.resolverFactory, "vpppremiumcronservice");
/* 54 */     String approverGroupName = "";
/* 55 */     String workFlowInitiator = workItem.getWorkflow().getInitiator();
/* 56 */     ArrayList<String> userGroupIds = VppUtil.getUserIds(workFlowInitiator, resourceResolver);
/* 57 */     log.debug("Group Ids in VppDynamicParticipantStep" + Arrays.toString(userGroupIds.toArray()));
/*    */     
/* 59 */     for (String userGroupId : userGroupIds) {
/* 60 */       if ((userGroupId.contains("author")) && (userGroupId.indexOf("_") != -1)) {
/* 61 */         String[] userArr = userGroupId.split("_");
/* 62 */         String approver = userArr[0];
/* 63 */         log.debug("approver name" + approver);
/* 64 */         StringBuilder sb = new StringBuilder(approver);
/* 65 */         sb.append("_").append("approver");
/* 66 */         approverGroupName = sb.toString();
/* 67 */         log.debug("approverGroupName" + approverGroupName);
/*    */       }
/*    */     }
/*    */     
/* 71 */     return approverGroupName;
/*    */   }
/*    */   
/*    */   protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     this.resolverFactory = paramResourceResolverFactory;
/*    */   }
/*    */   
/*    */   protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
/*    */   {
/*    */     if (this.resolverFactory == paramResourceResolverFactory) {
/*    */       this.resolverFactory = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\VppDynamicParticipantStep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */