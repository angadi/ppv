/*     */ package com.visa.vpp.premium.workflow;
/*     */ 
/*     */ import com.day.cq.dam.api.Asset;
/*     */ import com.day.cq.dam.api.renditions.RenditionMaker;
/*     */ import com.day.cq.dam.api.renditions.RenditionTemplate;
/*     */ import com.day.cq.dam.commons.process.AbstractAssetWorkflowProcess;
/*     */ import com.day.cq.dam.commons.util.MemoryUtil;
/*     */ import com.day.cq.workflow.WorkflowException;
/*     */ import com.day.cq.workflow.WorkflowSession;
/*     */ import com.day.cq.workflow.exec.WorkItem;
/*     */ import com.day.cq.workflow.exec.WorkflowData;
/*     */ import com.day.cq.workflow.exec.WorkflowProcess;
/*     */ import com.day.cq.workflow.metadata.MetaDataMap;
/*     */ import com.visa.vpp.premium.interfaces.CustomImageRenditionConfig;
/*     */ import java.util.List;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.felix.scr.annotations.Component;
/*     */ import org.apache.felix.scr.annotations.Property;
/*     */ import org.apache.felix.scr.annotations.Reference;
/*     */ import org.apache.felix.scr.annotations.Service;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component(immediate=true, metatype=true, label="VPP: Workflow", description=" This is a custom workflow to generate renditions")
/*     */ @Service
/*     */ @Property(name="process.label", value={"VPP Renditions"})
/*     */ public class VppImageRenditions
/*     */   extends AbstractAssetWorkflowProcess
/*     */   implements WorkflowProcess
/*     */ {
/*  45 */   private static final Logger LOG = LoggerFactory.getLogger(VppImageRenditions.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private RenditionMaker renditionMaker;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Reference
/*     */   private CustomImageRenditionConfig customImageConfig;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap args)
/*     */     throws WorkflowException
/*     */   {
/*     */     try
/*     */     {
/*  67 */       LOG.info("VppImageRenditions execution startet======>>>>>>>>>>>>");
/*  68 */       String[] renditionArguments = buildArguments(args);
/*  69 */       String wfPayloadPath = workItem.getWorkflowData().getPayload().toString();
/*  70 */       LOG.debug(" wfPayloadPath " + wfPayloadPath);
/*  71 */       String[] imageSize = null;
/*  72 */       String[] imageRenditions = this.customImageConfig.getImagerenditions();
/*  73 */       if ((null != imageRenditions) && (imageRenditions.length > 0)) {
/*  74 */         for (int i = 0; i < imageRenditions.length; i++)
/*     */         {
/*  76 */           if (wfPayloadPath.contains(imageRenditions[i].split("=")[0])) {
/*  77 */             LOG.debug("image folder name :: " + imageRenditions[i].split("=")[0]);
/*  78 */             imageSize = getImageDimension(imageRenditions[i]);
/*  79 */             break;
/*     */           }
/*     */         }
/*     */       }
/*  83 */       if ((null != imageSize) && (imageSize.length > 0)) {
/*  84 */         Asset asset = getAssetFromPayload(workItem, workflowSession.getSession());
/*  85 */         RenditionTemplate[] renditionTemplate = createRenditionTemplates(asset, imageSize);
/*     */         
/*     */ 
/*     */ 
/*  89 */         if ((null != asset) && (!canIgnore(renditionArguments, asset))) {
/*  90 */           asset.setBatchMode(true);
/*     */           
/*  92 */           if (MemoryUtil.hasEnoughSystemMemory(asset)) {
/*  93 */             this.renditionMaker.generateRenditions(asset, renditionTemplate);
/*  94 */             LOG.debug("Renditions generated");
/*     */           } else {
/*  96 */             LOG.error("Increase heap size up to [{}bytes] for asset [{}].", 
/*  97 */               Long.valueOf(MemoryUtil.suggestMaxHeapSize(asset)), asset.getPath());
/*     */           }
/*     */         }
/*     */         else {
/* 101 */           String wfPayload = workItem.getWorkflowData().getPayload().toString();
/*     */           
/* 103 */           String message = "execute: cannot create web enabled image, asset [{" + wfPayload + "}] in payload doesn't exist for workflow [{" + workItem.getId() + "}].";
/* 104 */           throw new WorkflowException(message);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (PatternSyntaxException e) {
/* 109 */       LOG.error("Exception ::" + e.getMessage());
/*     */     } catch (Exception e) {
/* 111 */       LOG.error("Exception :: " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canIgnore(String[] args, Asset asset)
/*     */   {
/* 125 */     String mimeType = asset.getMimeType();
/* 126 */     if (mimeType == null) {
/* 127 */       LOG.debug("canIgnore: no mimetype available for asset [{}].", asset.getPath());
/* 128 */       return true;
/*     */     }
/* 130 */     List<String> values = getValuesFromArgs("skip", args);
/* 131 */     for (String val : values) {
/* 132 */       if (mimeType.matches(val)) {
/* 133 */         return true;
/*     */       }
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] buildArguments(MetaDataMap metaData)
/*     */   {
/* 148 */     LOG.info("buildArguments");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     String[] configs = (String[])metaData.get(Arguments.CONFIGS.name(), String[].class);
/* 158 */     if (configs != null) {
/* 159 */       return configs;
/*     */     }
/* 161 */     return new String[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static enum Arguments
/*     */   {
/* 171 */     PROCESS_ARGS, 
/*     */     
/* 173 */     CONFIGS;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Arguments() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RenditionTemplate[] createRenditionTemplates(Asset asset, String[] arg)
/*     */   {
/* 188 */     LOG.info("createRenditionTemplates arg" + arg);
/*     */     
/*     */ 
/* 191 */     String keepFormat = !getValuesFromArgs("keepFormatList", arg).isEmpty() ? (String)getValuesFromArgs("keepFormatList", arg).get(0) : "image/pjpeg,image/jpeg,image/jpg,image/gif";
/*     */     
/*     */ 
/*     */ 
/* 195 */     String qualityStr = !getValuesFromArgs("quality", arg).isEmpty() ? (String)getValuesFromArgs("quality", arg).get(0) : "90";
/*     */     
/* 197 */     RenditionTemplate[] templates = new RenditionTemplate[arg.length];
/*     */     
/* 199 */     for (int i = 0; i < arg.length; i++)
/*     */     {
/* 201 */       String[] imgSize = arg[i].split("x");
/* 202 */       templates[i] = this.renditionMaker.createWebRenditionTemplate(asset, Integer.parseInt(imgSize[0]), 
/* 203 */         Integer.parseInt(imgSize[1]), Integer.parseInt(qualityStr), "image/jpeg", keepFormat
/* 204 */         .split(","));
/*     */     }
/*     */     
/* 207 */     return templates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getImageDimension(String imageConfig)
/*     */   {
/* 219 */     String[] compArray = imageConfig.split("=");
/* 220 */     String[] dimensionArray = compArray[1].replace("[", "").replaceAll("]", "").split("\\|");
/* 221 */     String[] imageDimensionVal = new String[dimensionArray.length];
/* 222 */     for (int i = 0; i < dimensionArray.length; i++) {
/* 223 */       imageDimensionVal[i] = dimensionArray[i].split(":")[1];
/*     */     }
/* 225 */     return imageDimensionVal;
/*     */   }
/*     */   
/*     */   protected void bindRenditionMaker(RenditionMaker paramRenditionMaker)
/*     */   {
/*     */     this.renditionMaker = paramRenditionMaker;
/*     */   }
/*     */   
/*     */   protected void unbindRenditionMaker(RenditionMaker paramRenditionMaker)
/*     */   {
/*     */     if (this.renditionMaker == paramRenditionMaker) {
/*     */       this.renditionMaker = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bindCustomImageConfig(CustomImageRenditionConfig paramCustomImageRenditionConfig)
/*     */   {
/*     */     this.customImageConfig = paramCustomImageRenditionConfig;
/*     */   }
/*     */   
/*     */   protected void unbindCustomImageConfig(CustomImageRenditionConfig paramCustomImageRenditionConfig)
/*     */   {
/*     */     if (this.customImageConfig == paramCustomImageRenditionConfig) {
/*     */       this.customImageConfig = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\shankar\Downloads\vpp-premium-apps-1.0-SNAPSHOT\jcr_root\apps\vpp_premium\install\vpp-premium-bundle-1.0-SNAPSHOT.jar!\com\visa\vpp\premium\workflow\VppImageRenditions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */